// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.restapi;

public class QueryLimit
{
    private int limit;
    
    public int getLimit() {
        return this.limit;
    }
    
    public void setLimit(final int limit) {
        this.limit = limit;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof QueryLimit)) {
            return false;
        }
        final QueryLimit other = (QueryLimit)o;
        return other.canEqual(this) && this.getLimit() == other.getLimit();
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof QueryLimit;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        result = result * 59 + this.getLimit();
        return result;
    }
    
    @Override
    public String toString() {
        return "QueryLimit(limit=" + this.getLimit() + ")";
    }
}

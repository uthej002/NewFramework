// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DefectMapping
{
    @JsonProperty("type_id")
    private Long typeId;
    @JsonProperty("type")
    private String type;
    @JsonProperty("type_label")
    private String typeLabel;
    @JsonProperty("project_id")
    private Long projectId;
    @JsonProperty("project")
    private String project;
    @JsonProperty("project_label")
    private String projectLabel;
    @JsonProperty("fields")
    private List<DefectFieldMapping> fields;
    
    public DefectMapping() {
        this.typeId = null;
        this.type = null;
        this.typeLabel = null;
        this.projectId = null;
        this.project = null;
        this.projectLabel = null;
        this.fields = new ArrayList<DefectFieldMapping>();
    }
    
    public DefectMapping typeId(final Long typeId) {
        this.typeId = typeId;
        return this;
    }
    
    public Long getTypeId() {
        return this.typeId;
    }
    
    public void setTypeId(final Long typeId) {
        this.typeId = typeId;
    }
    
    public DefectMapping type(final String type) {
        this.type = type;
        return this;
    }
    
    public String getType() {
        return this.type;
    }
    
    public void setType(final String type) {
        this.type = type;
    }
    
    public DefectMapping typeLabel(final String typeLabel) {
        this.typeLabel = typeLabel;
        return this;
    }
    
    public String getTypeLabel() {
        return this.typeLabel;
    }
    
    public void setTypeLabel(final String typeLabel) {
        this.typeLabel = typeLabel;
    }
    
    public DefectMapping projectId(final Long projectId) {
        this.projectId = projectId;
        return this;
    }
    
    public Long getProjectId() {
        return this.projectId;
    }
    
    public void setProjectId(final Long projectId) {
        this.projectId = projectId;
    }
    
    public DefectMapping project(final String project) {
        this.project = project;
        return this;
    }
    
    public String getProject() {
        return this.project;
    }
    
    public void setProject(final String project) {
        this.project = project;
    }
    
    public DefectMapping projectLabel(final String projectLabel) {
        this.projectLabel = projectLabel;
        return this;
    }
    
    public String getProjectLabel() {
        return this.projectLabel;
    }
    
    public void setProjectLabel(final String projectLabel) {
        this.projectLabel = projectLabel;
    }
    
    public DefectMapping fields(final List<DefectFieldMapping> fields) {
        this.fields = fields;
        return this;
    }
    
    public DefectMapping addFieldsItem(final DefectFieldMapping fieldsItem) {
        this.fields.add(fieldsItem);
        return this;
    }
    
    public List<DefectFieldMapping> getFields() {
        return this.fields;
    }
    
    public void setFields(final List<DefectFieldMapping> fields) {
        this.fields = fields;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final DefectMapping defectMapping = (DefectMapping)o;
        return Objects.equals(this.typeId, defectMapping.typeId) && Objects.equals(this.type, defectMapping.type) && Objects.equals(this.typeLabel, defectMapping.typeLabel) && Objects.equals(this.projectId, defectMapping.projectId) && Objects.equals(this.project, defectMapping.project) && Objects.equals(this.projectLabel, defectMapping.projectLabel) && Objects.equals(this.fields, defectMapping.fields);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.typeId, this.type, this.typeLabel, this.projectId, this.project, this.projectLabel, this.fields);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class DefectMapping {\n");
        sb.append("    typeId: ").append(this.toIndentedString(this.typeId)).append("\n");
        sb.append("    type: ").append(this.toIndentedString(this.type)).append("\n");
        sb.append("    typeLabel: ").append(this.toIndentedString(this.typeLabel)).append("\n");
        sb.append("    projectId: ").append(this.toIndentedString(this.projectId)).append("\n");
        sb.append("    project: ").append(this.toIndentedString(this.project)).append("\n");
        sb.append("    projectLabel: ").append(this.toIndentedString(this.projectLabel)).append("\n");
        sb.append("    fields: ").append(this.toIndentedString(this.fields)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.text.PDFTextStripper;

public class PDFReader {
  String pdfDocumentFile;
  
  PDDocument pdfDocument;
  
  PDFTextStripper pdfTextExtracter;
  
  OneframeSoftAssert ofsa;
  
  public PDFReader(String pdfFilePathAndName) {
    this.pdfDocumentFile = pdfFilePathAndName;
    OneframeContainer.OneframeLogger("Initializing PDF Reader for [" + this.pdfDocumentFile + "]");
    this.ofsa = new OneframeSoftAssert();
    try {
      String pdfOutput = null;
      this.pdfDocument = PDDocument.load(new File(pdfFilePathAndName));
      checkDocumentAccess();
      this.pdfTextExtracter = new PDFTextStripper();
      pdfOutput = this.pdfTextExtracter.getText(this.pdfDocument);
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  private void checkDocumentAccess() {
    AccessPermission ap = this.pdfDocument.getCurrentAccessPermission();
    if (!ap.canExtractContent())
      OneframeContainer.OneframeErrorLogger("You do not have permission to extract text"); 
  }
  
  public PDFReader(URL pdfFileURL) {
    try {
      BufferedInputStream bufferedInputStream = new BufferedInputStream(pdfFileURL.openStream());
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public void OutputPDFContentToConsole() {
    OneframeContainer.OneframeLogger("Printing PDF content of [" + this.pdfDocumentFile + "]");
    this.pdfTextExtracter.setSortByPosition(true);
    for (int p = 1; p <= this.pdfDocument.getNumberOfPages(); p++) {
      this.pdfTextExtracter.setStartPage(p);
      this.pdfTextExtracter.setEndPage(p);
      String text = null;
      try {
        text = this.pdfTextExtracter.getText(this.pdfDocument);
      } catch (IOException e) {
        e.printStackTrace();
      } 
      String pageStr = String.format("Page %d:", new Object[] { Integer.valueOf(p) });
      System.out.println(pageStr);
      for (int i = 0; i < pageStr.length(); i++)
        System.out.print("-"); 
      System.out.println();
      System.out.println(text.trim());
      System.out.println();
    } 
  }
  
  public void FindStringInPDF(String expectedValue) {
    OneframeContainer.OneframeLogger("Finding string [" + expectedValue + "] in the PDF");
    this.pdfTextExtracter.setSortByPosition(true);
    int intPosition = 0;
    int foundPageNbr = 0;
    for (int p = 1; p <= this.pdfDocument.getNumberOfPages(); p++) {
      this.pdfTextExtracter.setStartPage(p);
      this.pdfTextExtracter.setEndPage(p);
      foundPageNbr = p;
      String text = null;
      intPosition = 0;
      try {
        text = this.pdfTextExtracter.getText(this.pdfDocument);
      } catch (IOException e) {
        e.printStackTrace();
      } 
      intPosition = text.indexOf(expectedValue);
      if (intPosition >= 0)
        break; 
    } 
    if (intPosition >= 0) {
      this.ofsa.assertTrue(true, "Expected string [" + expectedValue + "] is found in page [" + foundPageNbr + "] of the PDF document");
    } else {
      this.ofsa.assertTrue(false, "Expected string [" + expectedValue + "] not found in the PDF document");
    } 
  }
  
  protected void finalize() {
    try {
      this.pdfDocument.close();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
}
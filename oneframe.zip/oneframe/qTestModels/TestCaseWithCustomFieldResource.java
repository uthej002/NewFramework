// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import org.joda.time.DateTime;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class TestCaseWithCustomFieldResource
{
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("order")
    private Integer order;
    @JsonProperty("pid")
    private String pid;
    @JsonProperty("created_date")
    private DateTime createdDate;
    @JsonProperty("last_modified_date")
    private DateTime lastModifiedDate;
    @JsonProperty("properties")
    private List<PropertyResource> properties;
    @JsonProperty("web_url")
    private String webUrl;
    @JsonProperty("test_steps")
    private List<TestStepResource> testSteps;
    @JsonProperty("parent_id")
    private Long parentId;
    @JsonProperty("test_case_version_id")
    private Long testCaseVersionId;
    @JsonProperty("version")
    private String version;
    @JsonProperty("description")
    private String description;
    @JsonProperty("precondition")
    private String precondition;
    @JsonProperty("creator_id")
    private Long creatorId;
    @JsonProperty("agent_ids")
    private List<Long> agentIds;
    @JsonProperty("tosca_guid")
    private String toscaGuid;
    @JsonProperty("tosca_node_path")
    private String toscaNodePath;
    @JsonProperty("tosca_test_case_unique_id")
    private String toscaTestCaseUniqueId;
    
    public TestCaseWithCustomFieldResource() {
        this.links = new ArrayList<Link>();
        this.id = null;
        this.name = null;
        this.order = null;
        this.pid = null;
        this.createdDate = null;
        this.lastModifiedDate = null;
        this.properties = new ArrayList<PropertyResource>();
        this.webUrl = null;
        this.testSteps = new ArrayList<TestStepResource>();
        this.parentId = null;
        this.testCaseVersionId = null;
        this.version = null;
        this.description = null;
        this.precondition = null;
        this.creatorId = null;
        this.agentIds = new ArrayList<Long>();
        this.toscaGuid = null;
        this.toscaNodePath = null;
        this.toscaTestCaseUniqueId = null;
    }
    
    public TestCaseWithCustomFieldResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public TestCaseWithCustomFieldResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public TestCaseWithCustomFieldResource id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public TestCaseWithCustomFieldResource name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public TestCaseWithCustomFieldResource order(final Integer order) {
        this.order = order;
        return this;
    }
    
    public Integer getOrder() {
        return this.order;
    }
    
    public void setOrder(final Integer order) {
        this.order = order;
    }
    
    public TestCaseWithCustomFieldResource pid(final String pid) {
        this.pid = pid;
        return this;
    }
    
    public String getPid() {
        return this.pid;
    }
    
    public void setPid(final String pid) {
        this.pid = pid;
    }
    
    public TestCaseWithCustomFieldResource createdDate(final DateTime createdDate) {
        this.createdDate = createdDate;
        return this;
    }
    
    public DateTime getCreatedDate() {
        return this.createdDate;
    }
    
    public void setCreatedDate(final DateTime createdDate) {
        this.createdDate = createdDate;
    }
    
    public TestCaseWithCustomFieldResource lastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
        return this;
    }
    
    public DateTime getLastModifiedDate() {
        return this.lastModifiedDate;
    }
    
    public void setLastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
    
    public TestCaseWithCustomFieldResource properties(final List<PropertyResource> properties) {
        this.properties = properties;
        return this;
    }
    
    public TestCaseWithCustomFieldResource addPropertiesItem(final PropertyResource propertiesItem) {
        this.properties.add(propertiesItem);
        return this;
    }
    
    public List<PropertyResource> getProperties() {
        return this.properties;
    }
    
    public void setProperties(final List<PropertyResource> properties) {
        this.properties = properties;
    }
    
    public String getWebUrl() {
        return this.webUrl;
    }
    
    public TestCaseWithCustomFieldResource testSteps(final List<TestStepResource> testSteps) {
        this.testSteps = testSteps;
        return this;
    }
    
    public TestCaseWithCustomFieldResource addTestStepsItem(final TestStepResource testStepsItem) {
        this.testSteps.add(testStepsItem);
        return this;
    }
    
    public List<TestStepResource> getTestSteps() {
        return this.testSteps;
    }
    
    public void setTestSteps(final List<TestStepResource> testSteps) {
        this.testSteps = testSteps;
    }
    
    public TestCaseWithCustomFieldResource parentId(final Long parentId) {
        this.parentId = parentId;
        return this;
    }
    
    public Long getParentId() {
        return this.parentId;
    }
    
    public void setParentId(final Long parentId) {
        this.parentId = parentId;
    }
    
    public TestCaseWithCustomFieldResource testCaseVersionId(final Long testCaseVersionId) {
        this.testCaseVersionId = testCaseVersionId;
        return this;
    }
    
    public Long getTestCaseVersionId() {
        return this.testCaseVersionId;
    }
    
    public void setTestCaseVersionId(final Long testCaseVersionId) {
        this.testCaseVersionId = testCaseVersionId;
    }
    
    public TestCaseWithCustomFieldResource version(final String version) {
        this.version = version;
        return this;
    }
    
    public String getVersion() {
        return this.version;
    }
    
    public void setVersion(final String version) {
        this.version = version;
    }
    
    public TestCaseWithCustomFieldResource description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public TestCaseWithCustomFieldResource precondition(final String precondition) {
        this.precondition = precondition;
        return this;
    }
    
    public String getPrecondition() {
        return this.precondition;
    }
    
    public void setPrecondition(final String precondition) {
        this.precondition = precondition;
    }
    
    public TestCaseWithCustomFieldResource creatorId(final Long creatorId) {
        this.creatorId = creatorId;
        return this;
    }
    
    public Long getCreatorId() {
        return this.creatorId;
    }
    
    public void setCreatorId(final Long creatorId) {
        this.creatorId = creatorId;
    }
    
    public TestCaseWithCustomFieldResource agentIds(final List<Long> agentIds) {
        this.agentIds = agentIds;
        return this;
    }
    
    public TestCaseWithCustomFieldResource addAgentIdsItem(final Long agentIdsItem) {
        this.agentIds.add(agentIdsItem);
        return this;
    }
    
    public List<Long> getAgentIds() {
        return this.agentIds;
    }
    
    public void setAgentIds(final List<Long> agentIds) {
        this.agentIds = agentIds;
    }
    
    public TestCaseWithCustomFieldResource toscaGuid(final String toscaGuid) {
        this.toscaGuid = toscaGuid;
        return this;
    }
    
    public String getToscaGuid() {
        return this.toscaGuid;
    }
    
    public void setToscaGuid(final String toscaGuid) {
        this.toscaGuid = toscaGuid;
    }
    
    public TestCaseWithCustomFieldResource toscaNodePath(final String toscaNodePath) {
        this.toscaNodePath = toscaNodePath;
        return this;
    }
    
    public String getToscaNodePath() {
        return this.toscaNodePath;
    }
    
    public void setToscaNodePath(final String toscaNodePath) {
        this.toscaNodePath = toscaNodePath;
    }
    
    public TestCaseWithCustomFieldResource toscaTestCaseUniqueId(final String toscaTestCaseUniqueId) {
        this.toscaTestCaseUniqueId = toscaTestCaseUniqueId;
        return this;
    }
    
    public String getToscaTestCaseUniqueId() {
        return this.toscaTestCaseUniqueId;
    }
    
    public void setToscaTestCaseUniqueId(final String toscaTestCaseUniqueId) {
        this.toscaTestCaseUniqueId = toscaTestCaseUniqueId;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final TestCaseWithCustomFieldResource testCaseWithCustomFieldResource = (TestCaseWithCustomFieldResource)o;
        return Objects.equals(this.links, testCaseWithCustomFieldResource.links) && Objects.equals(this.id, testCaseWithCustomFieldResource.id) && Objects.equals(this.name, testCaseWithCustomFieldResource.name) && Objects.equals(this.order, testCaseWithCustomFieldResource.order) && Objects.equals(this.pid, testCaseWithCustomFieldResource.pid) && Objects.equals(this.createdDate, testCaseWithCustomFieldResource.createdDate) && Objects.equals(this.lastModifiedDate, testCaseWithCustomFieldResource.lastModifiedDate) && Objects.equals(this.properties, testCaseWithCustomFieldResource.properties) && Objects.equals(this.webUrl, testCaseWithCustomFieldResource.webUrl) && Objects.equals(this.testSteps, testCaseWithCustomFieldResource.testSteps) && Objects.equals(this.parentId, testCaseWithCustomFieldResource.parentId) && Objects.equals(this.testCaseVersionId, testCaseWithCustomFieldResource.testCaseVersionId) && Objects.equals(this.version, testCaseWithCustomFieldResource.version) && Objects.equals(this.description, testCaseWithCustomFieldResource.description) && Objects.equals(this.precondition, testCaseWithCustomFieldResource.precondition) && Objects.equals(this.creatorId, testCaseWithCustomFieldResource.creatorId) && Objects.equals(this.agentIds, testCaseWithCustomFieldResource.agentIds) && Objects.equals(this.toscaGuid, testCaseWithCustomFieldResource.toscaGuid) && Objects.equals(this.toscaNodePath, testCaseWithCustomFieldResource.toscaNodePath) && Objects.equals(this.toscaTestCaseUniqueId, testCaseWithCustomFieldResource.toscaTestCaseUniqueId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links, this.id, this.name, this.order, this.pid, this.createdDate, this.lastModifiedDate, this.properties, this.webUrl, this.testSteps, this.parentId, this.testCaseVersionId, this.version, this.description, this.precondition, this.creatorId, this.agentIds, this.toscaGuid, this.toscaNodePath, this.toscaTestCaseUniqueId);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class TestCaseWithCustomFieldResource {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    order: ").append(this.toIndentedString(this.order)).append("\n");
        sb.append("    pid: ").append(this.toIndentedString(this.pid)).append("\n");
        sb.append("    createdDate: ").append(this.toIndentedString(this.createdDate)).append("\n");
        sb.append("    lastModifiedDate: ").append(this.toIndentedString(this.lastModifiedDate)).append("\n");
        sb.append("    properties: ").append(this.toIndentedString(this.properties)).append("\n");
        sb.append("    webUrl: ").append(this.toIndentedString(this.webUrl)).append("\n");
        sb.append("    testSteps: ").append(this.toIndentedString(this.testSteps)).append("\n");
        sb.append("    parentId: ").append(this.toIndentedString(this.parentId)).append("\n");
        sb.append("    testCaseVersionId: ").append(this.toIndentedString(this.testCaseVersionId)).append("\n");
        sb.append("    version: ").append(this.toIndentedString(this.version)).append("\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("    precondition: ").append(this.toIndentedString(this.precondition)).append("\n");
        sb.append("    creatorId: ").append(this.toIndentedString(this.creatorId)).append("\n");
        sb.append("    agentIds: ").append(this.toIndentedString(this.agentIds)).append("\n");
        sb.append("    toscaGuid: ").append(this.toIndentedString(this.toscaGuid)).append("\n");
        sb.append("    toscaNodePath: ").append(this.toIndentedString(this.toscaNodePath)).append("\n");
        sb.append("    toscaTestCaseUniqueId: ").append(this.toIndentedString(this.toscaTestCaseUniqueId)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

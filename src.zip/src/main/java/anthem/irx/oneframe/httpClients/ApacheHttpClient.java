package anthem.irx.oneframe.httpClients;

public class ApacheHttpClient {}
// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.restapi;

import anthem.irx.oneframe.utilities.ExcelIOStream;
import java.util.List;
import io.restassured.path.json.JsonPath;
import io.qameta.allure.Step;
import io.restassured.response.ValidatableResponse;
import io.restassured.http.ContentType;
import io.restassured.config.EncoderConfig;
import io.restassured.filter.Filter;
import io.qameta.allure.restassured.AllureRestAssured;
import java.util.Map;
import java.util.HashMap;
import anthem.irx.oneframe.utilities.ConfigFileReader;
import io.restassured.config.SSLConfig;
import io.restassured.RestAssured;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.core.OneframeAssert;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import anthem.irx.oneframe.core.OneframeContainer;

public class OneframeAPITest extends OneframeContainer
{
    static String userName;
    public static String deprecated_DB_URL;
    public static String deprecated_DB_USER;
    public static String deprecated_DB_PASSWORD;
    public static String GroupDataIngestionAPI;
    public static String MemberDataIngestionAPI;
    static String password;
    public static String baseURI;
    public static RequestSpecification Request;
    public static Response response;
    static RestAssuredConfig sslConfig;
    public static String FilePath;
    public static String oAuthToken;
    static String authTokenEndPoint;
    protected static String apiKey;
    protected static String siteKeyStorePath;
    protected static String siteKeyStorePathPWD;
    protected static String caCertPath;
    protected static String caCertPathPWD;
    protected static boolean httpsValidation;
    public static final String API_CONFIGURATION = "APIConfig.properties";
    public static final String API_CONFIG_FILE;
    public static String portNumber;
    OneframeAssert ha;
    OneframeSoftAssert sa;
    
    public OneframeAPITest() {
        this.ha = new OneframeAssert();
        this.sa = new OneframeSoftAssert();
    }
    
    public static void InitializeApiSuite(final String ScenarioID) {
        OneframeAPITest.TestScenarioID = ScenarioID;
        ReadAPITestSuiteScriptConfiguration();
        readAPIConfigurations();
        readOneframeConfiguration();
        RestAssured.baseURI = OneframeAPITest.baseURI;
        if (!OneframeAPITest.httpsValidation) {
            RestAssured.useRelaxedHTTPSValidation();
            OneframeAPITest.sslConfig = (RestAssured.config = RestAssured.config().sslConfig(SSLConfig.sslConfig().relaxedHTTPSValidation()));
            OneframeContainer.OneframeLogger("SSL Configuration - Relaxed HTTPS Validation");
        }
        else {
            OneframeAPITest.sslConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().keyStore(OneframeAPITest.siteKeyStorePath, OneframeAPITest.siteKeyStorePathPWD).trustStore(OneframeAPITest.caCertPath, OneframeAPITest.caCertPathPWD));
        }
    }
    
    public static void OverrideBaseURI(final String strbaseURI) {
        RestAssured.baseURI = strbaseURI;
    }
    
    public static void readAPIConfigurations() {
        final ConfigFileReader OneframeConfiguration1 = new ConfigFileReader(OneframeAPITest.API_CONFIG_FILE);
        OneframeAPITest.siteKeyStorePath = OneframeConfiguration1.getProperty("siteKeyStore");
        OneframeAPITest.caCertPath = OneframeConfiguration1.getProperty("caCert");
        OneframeAPITest.siteKeyStorePathPWD = OneframeConfiguration1.getProperty("siteKeyStorePathPWD");
        OneframeAPITest.caCertPathPWD = OneframeConfiguration1.getProperty("caCertPathPWD");
        OneframeAPITest.apiKey = OneframeConfiguration1.getProperty(OneframeAPITest.TSAppEnvKey + ".ApiKey");
        OneframeAPITest.baseURI = OneframeConfiguration1.getProperty(OneframeAPITest.TSAppEnvKey + ".baseURL");
        if (OneframeConfiguration1.checkPropertyExists(OneframeAPITest.TSAppEnvKey + ".enableHTTPSValidation")) {
            OneframeAPITest.httpsValidation = Boolean.valueOf(OneframeConfiguration1.getProperty(OneframeAPITest.TSAppEnvKey + ".enableHTTPSValidation"));
        }
        else {
            OneframeAPITest.httpsValidation = false;
        }
        OneframeAPITest.oAuthToken = OneframeConfiguration1.getProperty("oAuthToken");
        OneframeAPITest.userName = OneframeConfiguration1.getProperty("UserName");
        OneframeAPITest.password = OneframeConfiguration1.getProperty("Password");
        OneframeAPITest.deprecated_DB_URL = OneframeConfiguration1.getProperty("dburl");
        OneframeAPITest.deprecated_DB_USER = OneframeConfiguration1.getProperty("db_userid");
        OneframeAPITest.deprecated_DB_PASSWORD = OneframeConfiguration1.getProperty("db_password");
        OneframeAPITest.authTokenEndPoint = OneframeConfiguration1.getProperty("authTokenEndPoint");
        OneframeAPITest.portNumber = OneframeConfiguration1.getProperty("portNumber");
        final String[] dbRefArray = { "db1", "db2", "db3", "db4", "db5" };
        OneframeAPITest.AppConfigDBMap = new HashMap<String, HashMap<String, String>>();
        for (final String dbref : dbRefArray) {
            if (!OneframeAPITest.AppConfigDBMap.containsKey(dbref)) {
                OneframeAPITest.AppConfigDBMap.put(dbref, new HashMap<String, String>());
            }
        }
        for (final String dbref : dbRefArray) {
            if (OneframeConfiguration1.checkPropertyExists(OneframeAPITest.TSAppEnvKey + "." + dbref + ".dburl")) {
                OneframeContainer.OneframeLogger("[ONEFRAME]Database configuration for " + dbref);
                String tdbref = OneframeConfiguration1.getProperty(OneframeAPITest.TSAppEnvKey + "." + dbref + ".dburl");
                OneframeAPITest.AppConfigDBMap.get(dbref).put(".dburl", tdbref);
                tdbref = OneframeConfiguration1.getProperty(OneframeAPITest.TSAppEnvKey + "." + dbref + ".username");
                OneframeAPITest.AppConfigDBMap.get(dbref).put(".username", tdbref);
                tdbref = OneframeConfiguration1.getProperty(OneframeAPITest.TSAppEnvKey + "." + dbref + ".password");
                OneframeAPITest.AppConfigDBMap.get(dbref).put(".password", tdbref);
            }
        }
    }
    
    @Step("Generating token")
    public Object getAHDAccessTokenWithBearerToken() {
        OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)this.getBasicAuthHeadersWithApiKey()).filter((Filter)new AllureRestAssured()).config(OneframeAPITest.sslConfig.encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC))).contentType(ContentType.URLENC.withCharset("UTF-8")).formParam("grant_type", new Object[] { "client_credentials" }).log().all()).request();
        OneframeAPITest.response = (Response)OneframeAPITest.Request.post(OneframeAPITest.authTokenEndPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        this.ha.assertEquals(200, OneframeAPITest.response.getStatusCode(), "Access Token is generated");
        final Object accessToken = getValueFromResponse(OneframeAPITest.response, "access_token");
        this.ha.assertNotNull(accessToken, "Access token generated");
        return accessToken;
    }
    
    @Step("Generating token")
    public Object getAccessTokenWithBearerTokenIbp() {
        final int portValue = Integer.parseInt(OneframeAPITest.portNumber);
        OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)this.getBasicAuthHeaders()).filter((Filter)new AllureRestAssured()).config(OneframeAPITest.sslConfig.encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC))).contentType(ContentType.URLENC.withCharset("UTF-8")).formParam("grant_type", new Object[] { "automation" }).formParam("automation_id", new Object[] { "automation" }).formParam("automation_secret", new Object[] { "automation1234!" }).port(portValue).log().all()).request();
        OneframeAPITest.response = (Response)OneframeAPITest.Request.post(OneframeAPITest.authTokenEndPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        this.ha.assertEquals(200, OneframeAPITest.response.getStatusCode(), "Access Token is generated");
        final Object accessToken = getValueFromResponse(OneframeAPITest.response, "access_token");
        this.ha.assertNotNull(accessToken, "Access token generated");
        return accessToken;
    }
    
    @Step("Generating token")
    public Object getAccessTokenWithBearerTokenWithApiKey() {
        OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)this.getBasicAuthHeadersWithApiKey()).filter((Filter)new AllureRestAssured()).config(OneframeAPITest.sslConfig.encoderConfig(EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC))).contentType(ContentType.URLENC.withCharset("UTF-8")).formParam("grant_type", new Object[] { "client_credentials" }).formParam("scope", new Object[] { "public" }).log().all()).request();
        OneframeAPITest.response = (Response)OneframeAPITest.Request.post(OneframeAPITest.authTokenEndPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        this.ha.assertEquals(200, OneframeAPITest.response.getStatusCode(), "Access Token is generated");
        final Object accessToken = getValueFromResponse(OneframeAPITest.response, "access_token");
        this.ha.assertNotNull(accessToken, "Access token generated");
        return accessToken;
    }
    
    @Step("Sending POST Request")
    public static Response post(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint) {
        return post(requestHeaders, requestObject, endPoint, 0);
    }
    
    @Step("Sending POST Request")
    public static Response post(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).port(portNumber).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).post(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().all();
        return OneframeAPITest.response;
    }
    
    @Step("Sending POST Request")
    public static Response postWithParameters(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint, final Map<String, String> queryParameters) {
        return postWithParameters(requestHeaders, requestObject, endPoint, queryParameters, 0);
    }
    
    @Step("Sending POST Request")
    public static Response postWithParameters(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint, final Map<String, String> queryParameters, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).port(portNumber).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).post(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().all();
        return OneframeAPITest.response;
    }
    
    @Step("Sending POST Request")
    public static Response postWithOutBody(final Map<String, String> requestHeaders, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).port(portNumber).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.post(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().all();
        return OneframeAPITest.response;
    }
    
    public static Response postWithOutBody(final Map<String, String> requestHeaders, final String endPoint) {
        return postWithOutBody(requestHeaders, endPoint, 0);
    }
    
    @Step("Sending GET Request")
    public static Response get(final Map<String, String> requestHeaders, final String endPoint) {
        return get(requestHeaders, endPoint, 0);
    }
    
    @Step("Sending GET Request")
    public static Response get(final Map<String, String> requestHeaders, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).port(portNumber).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.get(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        return OneframeAPITest.response;
    }
    
    @Step("Sending GET Request")
    public static Response getRequestPathAndQueryParameters(final Map<String, String> requestHeaders, final Map<String, String> pathParameters, final Map<String, String> queryParameters, final String endPoint) {
        return getRequestPathAndQueryParameters(requestHeaders, pathParameters, queryParameters, endPoint, 0);
    }
    
    @Step("Sending GET Request")
    public static Response getRequestPathAndQueryParameters(final Map<String, String> requestHeaders, final Map<String, String> pathParameters, final Map<String, String> queryParameters, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).port(portNumber).pathParams((Map)pathParameters).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).pathParams((Map)pathParameters).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.get(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        return OneframeAPITest.response;
    }
    
    @Step("Sending GET Request")
    public static Response getRequestWithQueryParameters(final Map<String, String> requestHeaders, final String endPoint, final Map<String, String> queryParameters) {
        return getRequestWithQueryParameters(requestHeaders, endPoint, queryParameters, 0);
    }
    
    @Step("Sending GET Request")
    public static Response getRequestWithQueryParameters(final Map<String, String> requestHeaders, final String endPoint, final Map<String, String> queryParameters, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).port(portNumber).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.get(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        return OneframeAPITest.response;
    }
    
    @Step("Sending GET Request")
    public Response getRequestWithPathParameters(final Map<String, String> requestHeaders, final Map<String, String> pathParameters, final String endPoint) {
        return this.getRequestWithPathParameters(requestHeaders, pathParameters, endPoint);
    }
    
    @Step("Sending GET Request")
    public Response getRequestWithPathParameters(final Map<String, String> requestHeaders, final Map<String, String> pathParameters, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).pathParams((Map)pathParameters).port(portNumber).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).pathParams((Map)pathParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.get(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        this.ha.assertEquals(200, OneframeAPITest.response.getStatusCode(), "Actual response code  " + OneframeAPITest.response.getStatusCode());
        return OneframeAPITest.response;
    }
    
    @Step("Sending PUT Request")
    public static Response put(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint) {
        return put(requestHeaders, requestObject, endPoint, 0);
    }
    
    @Step("Sending PUT Request")
    public static Response put(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).port(portNumber).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).put(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().all();
        return OneframeAPITest.response;
    }
    
    @Step("Sending PUT Request")
    public static Response putWithParameters(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint, final Map<String, String> queryParameters) {
        return putWithParameters(requestHeaders, requestObject, endPoint, queryParameters, 0);
    }
    
    @Step("Sending PUT Request")
    public static Response putWithParameters(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint, final Map<String, String> queryParameters, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).port(portNumber).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).put(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().all();
        return OneframeAPITest.response;
    }
    
    @Step("Sending POST Request")
    public Response postWithHttpsRelaxation(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint) {
        OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).relaxedHTTPSValidation().auth().basic(OneframeAPITest.userName, OneframeAPITest.password).log().all()).request();
        OneframeContainer.OneframeLogger("End Point is: " + endPoint);
        return OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).post(endPoint, new Object[0]);
    }
    
    @Step("Sending PUT Request")
    public Response putWithHttpsRelaxation(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint) {
        OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).relaxedHTTPSValidation().auth().basic(OneframeAPITest.userName, OneframeAPITest.password).log().all()).request();
        OneframeContainer.OneframeLogger("End Point is: " + endPoint);
        return OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).put(endPoint, new Object[0]);
    }
    
    @Step("Validate status code")
    public void validateStatusCode(final Response actualResponse, final int expectedStatusCode) {
        OneframeContainer.OneframeLogger("Reponse code is " + actualResponse.getStatusCode());
        this.ha.assertEquals(actualResponse.getStatusCode(), expectedStatusCode, "Response code is as expected");
    }
    
    public static Object getValueFromResponse(final Response response, final String fieldName) {
        final JsonPath js = response.jsonPath();
        final String value = (String)js.get(fieldName);
        return value;
    }
    
    public static Object getListOfValuesFromRespose(final Response response, final String fieldName) {
        final JsonPath js = response.jsonPath();
        final List<String> value = (List<String>)js.getList(fieldName);
        return value;
    }
    
    public static Object getListOfValuesFromResponse(final Response response, final String Path) {
        final List<String> jsonResponse = (List<String>)response.jsonPath().getList(Path);
        System.out.println("List of values diplayed from respone are :" + jsonResponse);
        return jsonResponse;
    }
    
    public static String getSingleValueFromResponse(final Response response, final String Path) {
        final String jsonResponse = response.jsonPath().getString(Path);
        System.out.println("Values diplayed from respone are :" + jsonResponse);
        return jsonResponse;
    }
    
    public Map<String, String> getDefaultHeadersWithApiKey() {
        final Map<String, String> deafaultHeaders = new HashMap<String, String>();
        deafaultHeaders.put("Content-Type", "application/json");
        deafaultHeaders.put("apikey", OneframeAPITest.apiKey);
        return deafaultHeaders;
    }
    
    public Map<String, String> getDefaultHeaders() {
        final Map<String, String> deafaultHeaders = new HashMap<String, String>();
        deafaultHeaders.put("Content-Type", "application/json");
        return deafaultHeaders;
    }
    
    public Map<String, String> getDefaultWebHeadersDB() {
        final Map<String, String> deafaultHeaders = new HashMap<String, String>();
        deafaultHeaders.put("Authorization", "Basic aXJ4ZXBfaW5ib3VuZF9zZXJ2aWNlczpIYXNoZWRJRVBQd2QxMjM0ISEhISEkKioq");
        deafaultHeaders.put("Content-Type", "application/json");
        return deafaultHeaders;
    }
    
    public Map<String, String> getBearerAuthHeadersWithApiKey() {
        final Map<String, String> deafaultHeaders = this.getDefaultHeadersWithApiKey();
        deafaultHeaders.put("Authorization", "Bearer " + this.getAccessTokenWithBearerTokenWithApiKey());
        return deafaultHeaders;
    }
    
    public Map<String, String> getBasicAuthHeadersWithApiKey() {
        final Map<String, String> authHeaders = new HashMap<String, String>();
        authHeaders.put("Content-Type", "application/x-www-form-urlencoded");
        authHeaders.put("Authorization", "Basic " + OneframeAPITest.oAuthToken);
        authHeaders.put("apikey", OneframeAPITest.apiKey);
        return authHeaders;
    }
    
    public Map<String, String> getBasicAuthHeaders() {
        final Map<String, String> authHeaders = new HashMap<String, String>();
        authHeaders.put("Content-Type", "application/x-www-form-urlencoded");
        authHeaders.put("Authorization", "Basic " + OneframeAPITest.oAuthToken);
        return authHeaders;
    }
    
    public Response postDbIep(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint) {
        OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).relaxedHTTPSValidation().auth().basic(OneframeAPITest.userName, OneframeAPITest.password).log().all()).request();
        OneframeContainer.OneframeLogger("End Point is: " + endPoint);
        OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).post(endPoint, new Object[0]);
        this.ha.assertEquals(200, OneframeAPITest.response.getStatusCode(), "Actual response code  " + OneframeAPITest.response.getStatusCode());
        return OneframeAPITest.response;
    }
    
    public Response putDbIep(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint) {
        OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).relaxedHTTPSValidation().auth().basic("irxep_inbound_services", "HashedIEPPwd1234!!!!!$***").log().all()).request();
        OneframeContainer.OneframeLogger("End Point is: " + endPoint);
        OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).put(endPoint, new Object[0]);
        this.ha.assertEquals(200, OneframeAPITest.response.getStatusCode(), "Actual response code  " + OneframeAPITest.response.getStatusCode());
        return OneframeAPITest.response;
    }
    
    @Step("Sending DELETE Request")
    public static Response delete(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint) {
        return delete(requestHeaders, requestObject, endPoint, 0);
    }
    
    @Step("Sending DELETE Request")
    public static Response delete(final Map<String, String> requestHeaders, final Object requestObject, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).port(portNumber).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.body(requestObject).delete(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().all();
        return OneframeAPITest.response;
    }
    
    @Step("Sending DELETE Request")
    public static Response delete(final Map<String, String> requestHeaders, final String endPoint) {
        return delete(requestHeaders, endPoint, 0);
    }
    
    @Step("Sending DELETE Request")
    public static Response delete(final Map<String, String> requestHeaders, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).port(portNumber).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().filter((Filter)new AllureRestAssured()).headers((Map)requestHeaders).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.delete(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        return OneframeAPITest.response;
    }
    
    @Step("Sending DELETE Request")
    public static Response deleteRequestWithQueryParameters(final Map<String, String> requestHeaders, final String endPoint, final Map<String, String> queryParameters) {
        return deleteRequestWithQueryParameters(requestHeaders, endPoint, queryParameters, 0);
    }
    
    @Step("Sending DELETE Request")
    public static Response deleteRequestWithQueryParameters(final Map<String, String> requestHeaders, final String endPoint, final Map<String, String> queryParameters, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).port(portNumber).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.delete(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        return OneframeAPITest.response;
    }
    
    @Step("Sending DELETE Request")
    public Response deleteRequestWithPathParameters(final Map<String, String> requestHeaders, final Map<String, String> pathParameters, final String endPoint) {
        return this.deleteRequestWithPathParameters(requestHeaders, pathParameters, endPoint);
    }
    
    @Step("Sending DELETE Request")
    public Response deleteRequestWithPathParameters(final Map<String, String> requestHeaders, final Map<String, String> pathParameters, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).pathParams((Map)pathParameters).port(portNumber).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).pathParams((Map)pathParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.delete(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        this.ha.assertEquals(200, OneframeAPITest.response.getStatusCode(), "Actual response code  " + OneframeAPITest.response.getStatusCode());
        return OneframeAPITest.response;
    }
    
    @Step("Sending DELETE Request")
    public static Response deleteRequestPathAndQueryParameters(final Map<String, String> requestHeaders, final Map<String, String> pathParameters, final Map<String, String> queryParameters, final String endPoint) {
        return deleteRequestPathAndQueryParameters(requestHeaders, pathParameters, queryParameters, endPoint, 0);
    }
    
    @Step("Sending DELETE Request")
    public static Response deleteRequestPathAndQueryParameters(final Map<String, String> requestHeaders, final Map<String, String> pathParameters, final Map<String, String> queryParameters, final String endPoint, final int portNumber) {
        if (portNumber > 0) {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).port(portNumber).pathParams((Map)pathParameters).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        else {
            OneframeAPITest.Request = ((RequestSpecification)RestAssured.given().headers((Map)requestHeaders).filter((Filter)new AllureRestAssured()).pathParams((Map)pathParameters).queryParams((Map)queryParameters).config(OneframeAPITest.sslConfig).log().all()).request();
        }
        OneframeAPITest.response = (Response)OneframeAPITest.Request.delete(endPoint, new Object[0]);
        ((ValidatableResponse)OneframeAPITest.response.then()).log().body();
        return OneframeAPITest.response;
    }
    
    private static void ReadAPITestSuiteScriptConfiguration() {
        final ConfigFileReader OneframeConfiguration = new ConfigFileReader(OneframeAPITest.API_CONFIG_FILE);
        OneframeAPITest.FilePath = OneframeConfiguration.getProperty("path");
        OneframeAPITest.TestSuiteFile = OneframeAPITest.TESTSUITES_FOLDER + OneframeAPITest.FilePath;
        final ExcelIOStream excelDoc = new ExcelIOStream(OneframeAPITest.TestSuiteFile);
        OneframeAPITest.TSScriptConfigSheet = "ScriptConfigurations";
        OneframeAPITest.TSScriptConfigurations = excelDoc.readScriptConfiguration(OneframeAPITest.TestScenarioID);
        OneframeAPITest.TSTestScenarioName = OneframeContainer.getTestScenarioNamefromScriptConfig();
        OneframeAPITest.TSScriptName = OneframeContainer.getScriptNamefromScriptConfig();
        OneframeAPITest.TSScriptParameters = OneframeContainer.getScriptParametersfromScriptConfig();
        OneframeAPITest.TSTags = OneframeContainer.getTagsfromScriptConfig();
        OneframeAPITest.TSRunFlag = OneframeContainer.getRunFlagfromScriptConfig();
        OneframeAPITest.TSAppEnvKey = OneframeContainer.getAppEnvKeyfromScriptConfig();
        OneframeAPITest.TSTDSDocument = OneframeContainer.getTDSDocumentfromScriptConfig();
        OneframeAPITest.ScriptTDSFile = OneframeContainer.getScriptTDSFile();
        OneframeAPITest.TSDataSheetKey = OneframeContainer.getDataSheetKeyfromScriptConfig();
        OneframeAPITest.TSExecutionMode = OneframeContainer.getExecutionModefromScriptConfig();
        OneframeContainer.OneframeLogger("[ONEFRAME]Read test suite script configuration..........Done");
    }
    
    static {
        OneframeAPITest.httpsValidation = false;
        API_CONFIG_FILE = OneframeAPITest.PROJECT_FOLDER + "/src/test/resources/Configurations/" + "APIConfig.properties";
    }
}

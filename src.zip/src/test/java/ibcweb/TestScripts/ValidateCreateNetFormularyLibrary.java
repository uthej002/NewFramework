package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreateNetFormularyLibrary extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesNetFormularies LibrariesNetFormularies;
	IBPLibrariesProgramsPage librariesprogramspage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Libraries Net Formulary is created")
	public void setUp() {
		InitializeLaunchPad("IBPW_600");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		LibrariesNetFormularies = new IBPLibrariesNetFormularies();
		librariesprogramspage = new IBPLibrariesProgramsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId", "EffectiveDate",
				"StopSaleDate", "TermDate","ImpDate","costShare" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validating Libraries Net Formulary is created", dataProvider = "TestData")
	@Description("Validate Libraries Net Formulary is created")
	public void ValidateLibrariesCreateNetFormulary(String TestCaseID, String TestStatus, String ClientId, String LOBId,
			String StateId, String EffectiveDate, String StopSaleDate, String TermDate,String ImpDate,String costShare)
			throws AWTException, InterruptedException, IOException, ParseException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			LibrariesNetFormularies.clickFormularyViewButton();
			sa.assertTrue(LibrariesNetFormularies.verifyFormularyHeader(),
					"Verified 'Formularies header' is displayed");
			LibrariesNetFormularies.clickNetFormularyTab();
			LibrariesNetFormularies.clickCreateNetFormularyButton();
			sa.assertTrue(LibrariesNetFormularies.verifyCreateANetFormularyHeader(),
					"Verfied 'Create A Net Formulary' header is Displayed");
			sa.assertTrue(LibrariesNetFormularies.selectValueFromFormularyIDDropdown("EHB"),
					"Verified and Selected value from 'Formulary dropdown'");
			sa.assertTrue(LibrariesNetFormularies.inputRandomNumericValueInNetFormularyID(),
					"Verified and Entered 'Net Formulary ID' ");
			sa.assertTrue(LibrariesNetFormularies.inputRandomNumericValueInAdjudicationFormularyID(),
					"Verified and Entered 'Adjudication Formulary ID' ");
			sa.assertTrue(LibrariesNetFormularies.selectTiersValue(), "Verified and selected 'tier value'");

			String netFormularyName = LibrariesNetFormularies.inputRandomAlphaNumericValueInNetFormularyNameField();
			//createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			createbenefitpage.EnterCurrentEffectiveDate();
			LibrariesNetFormularies.EnterStopSaleDate(StopSaleDate);
			LibrariesNetFormularies.EnterTermDate(TermDate);

			sa.assertTrue(librariesprogramspage.selLobdropdown(LOBId), "Verified and selected 'LOB dropdown'");
			sa.assertTrue(LibrariesNetFormularies.selectStateDropdown(StateId),
					"Verified and Selected 'State dropdown'");

			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId),
					"Verified and selected 'ClientID dropdown'");
			sa.assertTrue(LibrariesNetFormularies.selectCostShareTierStructure(costShare),
					"Verified and selected 'cost share tier structure'");
			sa.assertTrue(LibrariesNetFormularies.selectEmployerGroupDropdown(),
					"Verified and Selected 'Employer Group Dropdown'");
			sa.assertTrue(LibrariesNetFormularies.selectManagedByDropdown(),
					"Verified and Selected 'Managed By Dropdown'");
			LibrariesNetFormularies.EnterImplementationDate(ImpDate);
			sa.assertTrue(LibrariesNetFormularies.inputValueInFormularyLinkField("www.google.com"),
					"Verified and Entered 'Formulary Link'");
			sa.assertTrue(LibrariesNetFormularies.selectFormularyTagsDropdown(),
					"Verified and Selected 'Formulary Tags Dropdown'");
			LibrariesNetFormularies.clickAddFormularyButton();
			LibrariesNetFormularies.verifyNetFormularyCreateddMessage();
			/* sa.assertTrue(LibrariesNetFormularies.VerifyNetFormularyIsCreated(netFormularyName),
					"Verified the ' Net Formulary Name' is created and present in the Net Formulary List");  */
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Libraries Net Formulary is created Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Libraries Create Net Formulary");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}
}

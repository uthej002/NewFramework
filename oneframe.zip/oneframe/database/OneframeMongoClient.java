// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.database;

import com.mongodb.client.MongoClients;
import anthem.irx.oneframe.core.OneframeContainer;
import java.util.HashMap;
import org.bson.Document;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoClient;

public class OneframeMongoClient
{
    protected String ofDBurl;
    protected String ofDBMS;
    protected String ofDBname;
    protected String ofDBusername;
    protected String ofDBpassword;
    protected String ofDBParameters;
    private MongoClient mongo;
    private MongoDatabase CurrDatabase;
    private MongoCollection<Document> CurrMngoCollection;
    private HashMap<String, String> DBConfigMap;
    
    public OneframeMongoClient OpenDBConnection(final String dbReference) {
        if (OneframeContainer.AppConfigDBMap.containsKey(dbReference)) {
            this.DBConfigMap = OneframeContainer.AppConfigDBMap.get(dbReference);
            this.ofDBurl = this.DBConfigMap.get(".dburl");
            if (this.ofDBurl == null) {
                OneframeContainer.OneframeLogger("DB URL is missing for configuration -> : " + dbReference);
                System.exit(0);
            }
            final String[] dbURLdetails = this.ofDBurl.split(":");
            if (dbURLdetails.length > 0) {
                this.ofDBMS = dbURLdetails[0].toLowerCase();
            }
            else {
                OneframeContainer.OneframeLogger("Error found in DB configuration -> : " + this.ofDBurl);
            }
            this.ofDBusername = this.DBConfigMap.get(".username");
            this.ofDBpassword = this.DBConfigMap.get(".password");
            this.DBConfigMap.forEach((key, value) -> OneframeContainer.OneframeLogger("[ONEFRAME]" + key + " : " + value));
            if (this.ofDBMS.isEmpty() || this.ofDBMS == null || this.ofDBMS.trim() == "") {
                OneframeContainer.OneframeLogger("Database configuration is missing for reference : " + dbReference);
                System.exit(0);
            }
            try {
                OneframeContainer.OneframeLogger("Initializing database connection object.........");
                this.mongo = MongoClients.create(this.ofDBurl);
            }
            catch (Exception e) {
                e.printStackTrace();
                return null;
            }
            if (this.mongo == null) {
                return null;
            }
            OneframeContainer.OneframeLogger("Connection to MongoDB database......Success");
        }
        else {
            OneframeContainer.OneframeLogger("Database configuration is missing for reference : " + dbReference);
        }
        return this;
    }
    
    public OneframeMongoClient OpenDatabase(final String DBName) {
        try {
            this.CurrDatabase = this.mongo.getDatabase(DBName);
            if (this.CurrDatabase == null) {
                OneframeContainer.OneframeErrorLogger("Unable to open the Database : [" + DBName + "]");
            }
        }
        catch (Exception Ex) {
            OneframeContainer.OneframeErrorLogger("Exception occurred while opening the Database : " + DBName);
            Ex.printStackTrace();
        }
        return this;
    }
    
    public OneframeMongoClient getCollection(final String CollectionName) {
        try {
            this.CurrMngoCollection = (MongoCollection<Document>)this.CurrDatabase.getCollection(CollectionName);
            if (this.CurrMngoCollection == null) {
                OneframeContainer.OneframeErrorLogger("Unable to open the Database : [" + CollectionName + "]");
            }
        }
        catch (Exception Ex) {
            OneframeContainer.OneframeErrorLogger("Exception occurred while opening the Collection : " + CollectionName);
            Ex.printStackTrace();
        }
        return this;
    }
    
    public int getDocumentCount() {
        long DocCount = 0L;
        DocCount = this.CurrMngoCollection.countDocuments();
        return (int)DocCount;
    }
    
    public MongoCollection<Document> getCollectionObject(final String CollectionName) {
        try {
            this.CurrMngoCollection = (MongoCollection<Document>)this.CurrDatabase.getCollection(CollectionName);
            if (this.CurrMngoCollection == null) {
                OneframeContainer.OneframeErrorLogger("Unable to open the Database : [" + CollectionName + "]");
            }
        }
        catch (Exception Ex) {
            OneframeContainer.OneframeErrorLogger("Exception occurred while opening the Collection : " + CollectionName);
            Ex.printStackTrace();
        }
        return this.CurrMngoCollection;
    }
    
    public static void main(final String[] args) {
        final MongoClient mongodb1 = MongoClients.create("mongodb://srcibhrw:SrcxBqGDAsL@ip-22-174-70-201.aws.internal.das:37043/IRXBHUBS?ssl=true");
        final MongoDatabase database = mongodb1.getDatabase("IRXBHUBS");
        final MongoCollection<Document> collection = (MongoCollection<Document>)database.getCollection("Content.PrimaryBranding");
        System.out.println("Collection Primary Branding selected successfully");
        System.out.println("Record Count - " + collection.countDocuments());
    }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBenefitProgramsPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesSpecialtyProgramLabels extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;
	IBPLibrariesBaseFormularies baseFormulary;
	IBPBenefitProgramsPage benefitProgramsPage;

	@BeforeClass
	@Step("Initializing Test Script for Validate Specialty Program details, General labels and field Details")
	public void setUp() {
		InitializeLaunchPad("IBPW_439");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();
		baseFormulary = new IBPLibrariesBaseFormularies();
		benefitProgramsPage = new IBPBenefitProgramsPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Specialty Program details, General labels and field Details", dataProvider = "TestData")
	@Description("Validate Specialty Program details, General labels and field Details")
	public void ValidateSpecialtyGeneralLabels(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickOnSpeciality();
			librariesprogramspage.verifyAndClickProgramName("TESTAUTO");
			//benefitProgramsPage.clickonExistingSpecialtyProgram();
			benefitProgramsPage.clickonSpecialtyDetails();
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Program ID");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Category");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Subcategory");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Specialty Name");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Program Association Name");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Effective Date");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Termination Date");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Non Sellable Date");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Implementation Date");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Client");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("LOB");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("State");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Auto Apply");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Business Entity");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Business Unit");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("CDHP Type");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Formulary");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Funding Type");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Market Segment");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Product Type");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Other");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("General Overrides");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Network Overrides");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Cost Share Overrides");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Accums Overrides");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Priority");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Specialty Description");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Details");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Specialty Customization");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("Drug List");
			benefitProgramsPage.clickonDruglisthdr();
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("DRUG LIST ID");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("CVS CODE");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("DRUG LIST NAME");
			benefitProgramsPage.verifyDescriptionSpecialtyDetailsTab("DESCRIPTION");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("OWNED BY");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("ADJ. SYS STATUS");
			benefitProgramsPage.verifyEffectiveDateSpecialtyDetailsTab("EFFECTIVE DATE");
			benefitProgramsPage.verifyTermDateSpecialtyDetailsTab("TERMINATION DATE");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("COVERAGE OPTION");
			
			librariesprogramspage.clickOnGeneralTab();
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("High Dollar Amounts");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Retail High Dollar Amount");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Mail High Dollar Amount");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("UM");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Channel Name");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Quantity Limit");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Quantity Limitation Time Period");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Days Supply");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Initial Fill Days Supply");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Lookback Days");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Max Fill Days Supply");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Lower Age Limit Restriction");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("Upper Age Limit Restriction");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("What Happens Under Age Restriction");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("What Happens Over Age Restriction");
			benefitProgramsPage.verifyGeneralTablabelsAreDisplayed("What Happens Between Age Restriction");
			benefitProgramsPage.clickDownArrowButton();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Specialty Program details, General labels and field Details Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Specialty Program details, General labels and field Details");
		}

		homepage.clickLogout();
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

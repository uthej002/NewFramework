// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TestRunWithCustomFieldResource
{
    @JsonProperty("parentId")
    private Long parentId;
    @JsonProperty("parentType")
    private ParentTypeEnum parentType;
    @JsonProperty("automation")
    private String automation;
    @JsonProperty("created")
    private String created;
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("order")
    private Integer order;
    @JsonProperty("pid")
    private String pid;
    @JsonProperty("created_date")
    private String createdDate;
    @JsonProperty("last_modified_date")
    private String lastModifiedDate;
    @JsonProperty("properties")
    private List<PropertyResource> properties;
    @JsonProperty("test_case")
    private TestCaseWithCustomFieldResource testCase;
    @JsonProperty("test_case_version_id")
    private Long testCaseVersionId;
    @JsonProperty("test_case_version")
    private String testCaseVersion;
    @JsonProperty("creator_id")
    private Long creatorId;
    @JsonProperty("assign_parameter_values")
    private List<ParameterTestStepResource> assignParameterValues;
    
    public TestRunWithCustomFieldResource() {
        this.parentId = null;
        this.parentType = null;
        this.automation = null;
        this.created = null;
        this.links = new ArrayList<Link>();
        this.id = null;
        this.name = null;
        this.order = null;
        this.pid = null;
        this.createdDate = null;
        this.lastModifiedDate = null;
        this.properties = new ArrayList<PropertyResource>();
        this.testCase = null;
        this.testCaseVersionId = null;
        this.testCaseVersion = null;
        this.creatorId = null;
        this.assignParameterValues = new ArrayList<ParameterTestStepResource>();
    }
    
    public TestRunWithCustomFieldResource parentId(final Long parentId) {
        this.parentId = parentId;
        return this;
    }
    
    public Long getParentId() {
        return this.parentId;
    }
    
    public void setParentId(final Long parentId) {
        this.parentId = parentId;
    }
    
    public TestRunWithCustomFieldResource parentType(final ParentTypeEnum parentType) {
        this.parentType = parentType;
        return this;
    }
    
    public ParentTypeEnum getParentType() {
        return this.parentType;
    }
    
    public void setParentType(final ParentTypeEnum parentType) {
        this.parentType = parentType;
    }
    
    public TestRunWithCustomFieldResource automation(final String automation) {
        this.automation = automation;
        return this;
    }
    
    public String getAutomation() {
        return this.automation;
    }
    
    public void setAutomation(final String automation) {
        this.automation = automation;
    }
    
    public TestRunWithCustomFieldResource created(final String created) {
        this.created = created;
        return this;
    }
    
    public String getCreated() {
        return this.created;
    }
    
    public void setCreated(final String created) {
        this.created = created;
    }
    
    public TestRunWithCustomFieldResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public TestRunWithCustomFieldResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public TestRunWithCustomFieldResource id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public TestRunWithCustomFieldResource name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public TestRunWithCustomFieldResource order(final Integer order) {
        this.order = order;
        return this;
    }
    
    public Integer getOrder() {
        return this.order;
    }
    
    public void setOrder(final Integer order) {
        this.order = order;
    }
    
    public TestRunWithCustomFieldResource pid(final String pid) {
        this.pid = pid;
        return this;
    }
    
    public String getPid() {
        return this.pid;
    }
    
    public void setPid(final String pid) {
        this.pid = pid;
    }
    
    public TestRunWithCustomFieldResource createdDate(final String createdDate) {
        this.createdDate = createdDate;
        return this;
    }
    
    public String getCreatedDate() {
        return this.createdDate;
    }
    
    public void setCreatedDate(final String createdDate) {
        this.createdDate = createdDate;
    }
    
    public TestRunWithCustomFieldResource lastModifiedDate(final String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
        return this;
    }
    
    public String getLastModifiedDate() {
        return this.lastModifiedDate;
    }
    
    public void setLastModifiedDate(final String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
    
    public TestRunWithCustomFieldResource properties(final List<PropertyResource> properties) {
        this.properties = properties;
        return this;
    }
    
    public TestRunWithCustomFieldResource addPropertiesItem(final PropertyResource propertiesItem) {
        this.properties.add(propertiesItem);
        return this;
    }
    
    public List<PropertyResource> getProperties() {
        return this.properties;
    }
    
    public void setProperties(final List<PropertyResource> properties) {
        this.properties = properties;
    }
    
    public TestRunWithCustomFieldResource testCase(final TestCaseWithCustomFieldResource testCase) {
        this.testCase = testCase;
        return this;
    }
    
    public TestCaseWithCustomFieldResource getTestCase() {
        return this.testCase;
    }
    
    public void setTestCase(final TestCaseWithCustomFieldResource testCase) {
        this.testCase = testCase;
    }
    
    public TestRunWithCustomFieldResource testCaseVersionId(final Long testCaseVersionId) {
        this.testCaseVersionId = testCaseVersionId;
        return this;
    }
    
    public Long getTestCaseVersionId() {
        return this.testCaseVersionId;
    }
    
    public void setTestCaseVersionId(final Long testCaseVersionId) {
        this.testCaseVersionId = testCaseVersionId;
    }
    
    public TestRunWithCustomFieldResource testCaseVersion(final String testCaseVersion) {
        this.testCaseVersion = testCaseVersion;
        return this;
    }
    
    public String getTestCaseVersion() {
        return this.testCaseVersion;
    }
    
    public void setTestCaseVersion(final String testCaseVersion) {
        this.testCaseVersion = testCaseVersion;
    }
    
    public TestRunWithCustomFieldResource creatorId(final Long creatorId) {
        this.creatorId = creatorId;
        return this;
    }
    
    public Long getCreatorId() {
        return this.creatorId;
    }
    
    public void setCreatorId(final Long creatorId) {
        this.creatorId = creatorId;
    }
    
    public TestRunWithCustomFieldResource assignParameterValues(final List<ParameterTestStepResource> assignParameterValues) {
        this.assignParameterValues = assignParameterValues;
        return this;
    }
    
    public TestRunWithCustomFieldResource addAssignParameterValuesItem(final ParameterTestStepResource assignParameterValuesItem) {
        this.assignParameterValues.add(assignParameterValuesItem);
        return this;
    }
    
    public List<ParameterTestStepResource> getAssignParameterValues() {
        return this.assignParameterValues;
    }
    
    public void setAssignParameterValues(final List<ParameterTestStepResource> assignParameterValues) {
        this.assignParameterValues = assignParameterValues;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final TestRunWithCustomFieldResource testRunWithCustomFieldResource = (TestRunWithCustomFieldResource)o;
        return Objects.equals(this.parentId, testRunWithCustomFieldResource.parentId) && Objects.equals(this.parentType, testRunWithCustomFieldResource.parentType) && Objects.equals(this.automation, testRunWithCustomFieldResource.automation) && Objects.equals(this.created, testRunWithCustomFieldResource.created) && Objects.equals(this.links, testRunWithCustomFieldResource.links) && Objects.equals(this.id, testRunWithCustomFieldResource.id) && Objects.equals(this.name, testRunWithCustomFieldResource.name) && Objects.equals(this.order, testRunWithCustomFieldResource.order) && Objects.equals(this.pid, testRunWithCustomFieldResource.pid) && Objects.equals(this.createdDate, testRunWithCustomFieldResource.createdDate) && Objects.equals(this.lastModifiedDate, testRunWithCustomFieldResource.lastModifiedDate) && Objects.equals(this.properties, testRunWithCustomFieldResource.properties) && Objects.equals(this.testCase, testRunWithCustomFieldResource.testCase) && Objects.equals(this.testCaseVersionId, testRunWithCustomFieldResource.testCaseVersionId) && Objects.equals(this.testCaseVersion, testRunWithCustomFieldResource.testCaseVersion) && Objects.equals(this.creatorId, testRunWithCustomFieldResource.creatorId) && Objects.equals(this.assignParameterValues, testRunWithCustomFieldResource.assignParameterValues);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.parentId, this.parentType, this.automation, this.created, this.links, this.id, this.name, this.order, this.pid, this.createdDate, this.lastModifiedDate, this.properties, this.testCase, this.testCaseVersionId, this.testCaseVersion, this.creatorId, this.assignParameterValues);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class TestRunWithCustomFieldResource {\n");
        sb.append("    parentId: ").append(this.toIndentedString(this.parentId)).append("\n");
        sb.append("    parentType: ").append(this.toIndentedString(this.parentType)).append("\n");
        sb.append("    automation: ").append(this.toIndentedString(this.automation)).append("\n");
        sb.append("    created: ").append(this.toIndentedString(this.created)).append("\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    order: ").append(this.toIndentedString(this.order)).append("\n");
        sb.append("    pid: ").append(this.toIndentedString(this.pid)).append("\n");
        sb.append("    createdDate: ").append(this.toIndentedString(this.createdDate)).append("\n");
        sb.append("    lastModifiedDate: ").append(this.toIndentedString(this.lastModifiedDate)).append("\n");
        sb.append("    properties: ").append(this.toIndentedString(this.properties)).append("\n");
        sb.append("    testCase: ").append(this.toIndentedString(this.testCase)).append("\n");
        sb.append("    testCaseVersionId: ").append(this.toIndentedString(this.testCaseVersionId)).append("\n");
        sb.append("    testCaseVersion: ").append(this.toIndentedString(this.testCaseVersion)).append("\n");
        sb.append("    creatorId: ").append(this.toIndentedString(this.creatorId)).append("\n");
        sb.append("    assignParameterValues: ").append(this.toIndentedString(this.assignParameterValues)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
    
    public enum ParentTypeEnum
    {
        @JsonProperty("root")
        ROOT("root"), 
        @JsonProperty("release")
        RELEASE("release"), 
        @JsonProperty("test-cycle")
        TEST_CYCLE("test-cycle"), 
        @JsonProperty("test-suite")
        TEST_SUITE("test-suite");
        
        private String value;
        
        private ParentTypeEnum(final String value) {
            this.value = value;
        }
        
        @Override
        public String toString() {
            return String.valueOf(this.value);
        }
    }
}

package APIUtilities;

import anthem.irx.oneframe.restapi.ApiStatusCodes;
import anthem.irx.oneframe.restapi.OneframeAPITest;
import io.qameta.allure.Step;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;

public class ApiUrlHelper extends OneframeAPITest {
	public final String IBP_BRE_Staging = "/ruleStaging";
	public final String IBP_BRE_Production = "/rule";
	public final String ACTIVERULES = "activeRules";


	public String getActiveRulesStaging() {
		return new StringBuilder("48110").append(IBP_BRE_Staging).append("/").append(ACTIVERULES).toString();
	}
	
	public String getActiveRulesProduction() {
		return new StringBuilder("48110").append(IBP_BRE_Production).append("/").append(ACTIVERULES).toString();
	}
	
	public String AddRulesStaging() {
		return new StringBuilder("48110").append(IBP_BRE_Staging).toString();
	}


	
	

		
}

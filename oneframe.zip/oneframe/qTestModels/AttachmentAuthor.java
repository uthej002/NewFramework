// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AttachmentAuthor
{
    @JsonProperty("id")
    private Long id;
    @JsonProperty("email")
    private String email;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    
    public AttachmentAuthor() {
        this.id = null;
        this.email = null;
        this.firstName = null;
        this.lastName = null;
    }
    
    public AttachmentAuthor id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public AttachmentAuthor email(final String email) {
        this.email = email;
        return this;
    }
    
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(final String email) {
        this.email = email;
    }
    
    public AttachmentAuthor firstName(final String firstName) {
        this.firstName = firstName;
        return this;
    }
    
    public String getFirstName() {
        return this.firstName;
    }
    
    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }
    
    public AttachmentAuthor lastName(final String lastName) {
        this.lastName = lastName;
        return this;
    }
    
    public String getLastName() {
        return this.lastName;
    }
    
    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final AttachmentAuthor attachmentAuthor = (AttachmentAuthor)o;
        return Objects.equals(this.id, attachmentAuthor.id) && Objects.equals(this.email, attachmentAuthor.email) && Objects.equals(this.firstName, attachmentAuthor.firstName) && Objects.equals(this.lastName, attachmentAuthor.lastName);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.email, this.firstName, this.lastName);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class AttachmentAuthor {\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    email: ").append(this.toIndentedString(this.email)).append("\n");
        sb.append("    firstName: ").append(this.toIndentedString(this.firstName)).append("\n");
        sb.append("    lastName: ").append(this.toIndentedString(this.lastName)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

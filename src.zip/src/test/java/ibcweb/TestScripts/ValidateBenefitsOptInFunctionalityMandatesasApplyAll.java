package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
public class ValidateBenefitsOptInFunctionalityMandatesasApplyAll extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;

	@BeforeClass
	@Step("Initializing Test Script for Validating Opt In Header is Displayed in the Federal tab when Mandates selected as APPLY ALL")
	public void setUp() {
		InitializeLaunchPad("IBPW_676");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType", "MarketSegment",
				"ProductType"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Opt In Header is Displayed in the Federal tab when Mandates selected as APPLY ALL", dataProvider = "TestData")
	@Description("Validate Opt In Header is Displayed in the Federal tab when Mandates selected as APPLY ALL")
	public void ValidateCreateBenefitDynamicLayer(String TestCaseID, String TestStatus, String Benefit, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String AutoApply, String BusinessEntity,
			String BusinessUnit, String CDHP, String Formulary, String FundingType, String MarketSegment,
			String ProductType) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			benefitpage.verifyCreateaBenefitButtonDisplay();
			benefitpage.clickCreateaBenefitButton();
			sa.assertTrue(createbenefitpage.verifyCreateBenefit(), "Verified 'Create Benefit button' is displayed");
			sa.assertTrue(createbenefitpage.verifyBenefitHeader(), "Verified 'Benefit Header' is displayed");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(createbenefitpage.selectClientDropdown(ClientId), "Verified and selected 'Client dropdown'");
			sa.assertTrue(createbenefitpage.selectLOBDropdown(LOBId), "Verified and selected 'LOB dropdown' ");
			sa.assertTrue(createbenefitpage.selectStateDropdown(StateId), "Verified and selected 'State dropdown'");
			createbenefitpage.clickBenefitHeader();
			sa.assertTrue(createbenefitpage.verifyAutoApplyDropdown(), "Verified 'Auto Apply dropdown' is displayed");
			String autoApply = createbenefitpage.selectBenefitAutoApplyDropdown(AutoApply);
			sa.assertTrue(createbenefitpage.selectBusinessEntityDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(createbenefitpage.selectBusinessUnitDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' dropdown");
			sa.assertTrue(createbenefitpage.selectCDHPTypeDropdown(CDHP), "Verified and Selected 'CDHP Type' dropdown");
			sa.assertTrue(createbenefitpage.selectFormularyDropdown(Formulary),
					"Verified and Selected 'Formulary' dropdown");
			sa.assertTrue(createbenefitpage.selectFundingTypeDropdown(FundingType),
					"Verified and Selected 'Funding Type' dropdown");
			sa.assertTrue(createbenefitpage.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' dropdown");
			sa.assertTrue(createbenefitpage.selectProductTypeDropdown(ProductType),
					"Verified and Selected 'Product Type' dropdown");
//			sa.assertTrue(createbenefitpage.selectOtherDropdown(Other), "Verified and Selected 'Others' dropdown");
			sa.assertTrue(createbenefitpage.selectMandatesDropdownForDynamicLayer(),
					"Verified and Selected 'Mandates Dropdown'");
//			String NewBenefitId = createbenefitpage.EnterNewBenefitId();
			createbenefitpage.clickRequestBenefitIDButtonGetBenefitID();
			createbenefitpage.ClickCBCreateButton();
//			sa.assertTrue(createbenefitpage.verifyBenefitCreatedHeader(NewBenefitId),
//					"Verified 'Created Benefit' header is same as expected");
//			sa.assertTrue(createbenefitpage.verifyAutoApplyInBenefitPage(autoApply),
//					"Verified 'Auto Apply is 'Yes' in Benefit Details Page");
			createbenefitpage.clickMandatesTab();
//			sa.assertTrue(!createbenefitpage.verifyMandateIsNotDisplayedWhenAutoApplyIsNo(),
//					"Verified the 'Federal Mandate Tab' is not Displayed when Auto Apply Functionality is given as 'No'");
			createbenefitpage.clickAddMandateButton();
			createbenefitpage.verifyAddAMandateHeader();
			createbenefitpage.clickAndGetFirstMandate();
			createbenefitpage.clickAddToMandateButton();
			createbenefitpage.clickOptoutBtn();
			createbenefitpage.clickPopupOptoutBtn();
			createbenefitpage.ClickSaveButton();
			sa.assertTrue(createbenefitpage.VerifyAutoApplyOutHdr(),"Verified AutoApplyNoOne (In) Header is displayed");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger(
					"Validated AutoApplyNoOne (In) Header in the Federal tab when Mandates selected as APPLY ALL Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger(
					"Unable to Validate AutoApplyNoOne (In) Header in the Federal tab when Mandates selected as APPLY ALL");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

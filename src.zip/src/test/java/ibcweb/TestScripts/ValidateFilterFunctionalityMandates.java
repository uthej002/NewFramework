package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateFilterFunctionalityMandates extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validating Filter Functionality of Mandate")
	public void setUp() {
		InitializeLaunchPad("IBPW_271");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"TerminationDate", "GeneralOverrides", "NetworkOverrides", "CostShareOverrides", "AccumOverrides" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "IBPW_271 Validate Filter Functionality of Mandate", dataProvider = "TestData")
	@Description("Validate Filter Functionality of Mandate")
	public void ValidateCOBDefaultDynamicLayer(String TestCaseID, String TestStatus, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String TerminationDate, String GeneralOverrides,
			String NetworkOverrides, String CostShareOverrides, String AccumOverrides)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			mandate.clickViewButtonofMandates();
			sa.assertTrue(mandate.verifyMandatesHeader(), "Verified Mandates header");

			controls.clickFilterButton();

			String effectiveDate = controls.EnterCBEffectiveDate(EffectiveDate);
			String terminationDate = controls.EnterTerminationDate(TerminationDate);
			String clientValue = controls.selectAndGetClientValue(ClientId);
			String lobValue = controls.selectAndGetLobValue(LOBId);
			String stateValue = controls.selectAndGetStateValue(StateId);

			String genOverride = mandate.selectGeneralOverrides(GeneralOverrides);
			String netOverride = mandate.selectNetworkOverrides(NetworkOverrides);
			String costShareOverride = mandate.selectCostShareOverrides(CostShareOverrides);
			String accumOverride = mandate.selectAccumOverrides(AccumOverrides);

			controls.clickApplyFilterButton();
			mandate.clickMandatesHeader();

			mandate.verifyEffectiveDateFilterList(effectiveDate);
			mandate.verifyTerminationDateFilterList(terminationDate);
			mandate.verifyClientFilterList(clientValue);
			mandate.verifyLOBFilterList(lobValue);
			mandate.verifyStateFilterList(stateValue);
			mandate.verifyGeneralOverrideFilterList(genOverride);
			mandate.verifyNetworkOverrideFilterList(netOverride);
			mandate.verifyCostShareOverrideFilterList(costShareOverride);
			mandate.verifyAccumsOverrideFilterList(accumOverride);

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Filter Functionality of Mandate is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Filter Functionality of Mandate");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

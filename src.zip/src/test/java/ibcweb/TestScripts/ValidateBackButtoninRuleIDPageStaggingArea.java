package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBackButtoninRuleIDPageStaggingArea extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;

	@BeforeClass
	@Step("Initializing Test Script for validating back button in RuleID Page Stagging Area")
	public void setUp() {
		InitializeLaunchPad("IBPW_34");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate back button in RuleID Page Stagging Area", dataProvider = "TestData")
	@Description("Validate back button in RuleID Page Stagging Area")
	public void ValidateBackButtonRuleIDPage(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {
		
	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickStagingLink();          
			rulebuilderstaging.clickBaseFormualry();
			rulebuilderstaging.clickFirstRuleID();
			sa.assertTrue(rulebuilderstaging.verifyRuleIDTitleDisplay(), "Verified Rule ID Title is displayed");
			sa.assertTrue(ruleid.verifyBackbuttondisplay(), "Verified Back Button is Dsiplayed");
			ruleid.clickBackbutton();
			sa.assertTrue(rulebuilderstaging.verifyRuleEngineHeaderdisplay(), "Verified Benefit Validation Rules Engine is dislayed");
			sa.assertTrue(rulebuilderstaging.verifyStagingHeaderdisplay(), "Verified STAGING is displayed");
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate back button in RuleID Page Stagging Area successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unale to Validate back button in RuleID Page Stagging Area");
		}
		
		sa.assertAll();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}


}

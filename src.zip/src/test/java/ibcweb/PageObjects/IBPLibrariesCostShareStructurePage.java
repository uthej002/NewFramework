package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForApplicationToLoadCompletely;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

public class IBPLibrariesCostShareStructurePage extends OneframeContainer {
	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//div[contains(text(),\"Libraries\")]")
	WebElement txtLibraries;

	@FindBy(xpath = "//a[@routerlink=\"/admin/library/cost-shares\"]")
	WebElement btnView;

	@FindBy(xpath = "//div[@class=\"mat-title title\"]")
	WebElement hdrCostShareStrcuture;

	@FindBy(xpath = "//tr[@class=\"mat-row cdk-row ng-star-inserted\"]")
	WebElement lstCostShareTierStructure;

	@FindBy(xpath = "//h3[contains(text(),\"Cost Share Structure Details\")]")
	WebElement hdrCostShareStructureDetails;

	@FindBy(xpath = "//mat-icon[@svgicon=\"edit\"]")
	WebElement btnEditCostShareStructureDetails;

	@FindBy(xpath = "//input[@formcontrolname=\"structureType\"]")
	WebElement txtStructureTypeField;

	@FindBy(xpath = "//input[@formcontrolname=\"name\"]")
	WebElement txtStructureNameField;

	@FindBy(xpath = "//input[@formcontrolname=\"tierRows\"]")
	WebElement txtStructureCostShareRows;

	@FindBy(xpath = "//input[@formcontrolname=\"content\"]")
	WebElement txtStructureContent;

	@FindBy(xpath = "//button[@class=\"mat-focus-indicator link mat-flat-button mat-button-base\"]")
	WebElement btnSaveChanges;

	@FindBy(xpath = "//button[@class=\"mat-focus-indicator sidenav-close mat-icon-button mat-button-base ng-tns-c179-8\"]")
	WebElement btnBack;

	@FindBy(xpath = "//span[contains(.,'Changes Saved')]")
	WebElement txtChangesSaved;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-structureType mat-column-structureType ng-star-inserted\"]")
	List<WebElement> txtFirstRecordStructureType;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted\"]")
	List<WebElement> txtFirstRecordStructureName;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-costShareRows mat-column-costShareRows ng-star-inserted\"]")
	List<WebElement> txtCostShareRows;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-content mat-column-content ng-star-inserted\"]")
	List<WebElement> txtFirstRecordStructureContent;

	@FindBy(xpath = "//*[text()=' Create Cost Share Structure ']")
	WebElement btnCreateCostShareStructure;

	@FindBy(xpath = "//span[text()=' Create Structure ']")
	WebElement btnCreateStructure;

	@FindBy(xpath = "//span[text()='Cost Share Structure was created successfully!']")
	WebElement txtCostShareStructureCreated;

	@FindBy(xpath = "//button[@class=\"mat-focus-indicator filter mat-icon-button mat-button-base\"]")
	WebElement btnFilter;

	@FindBy(xpath = "//*[text() and normalize-space()='Cancel']")
	WebElement btnCancel;

	@FindBy(xpath = "//tr[@class='mat-row cdk-row ng-star-inserted']")
	List<WebElement> lstCostShareStructure;

	public IBPLibrariesCostShareStructurePage() {
		// Initializing the Page Objects
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify and click Libraries Section on Menu bar")
	public boolean verifyAndClickLibrariesSection() {
		boolean flag = false;
		WaitForApplicationToLoadCompletely();
		if (WaitForObjectVisibility(txtLibraries)) {
			txtLibraries.isDisplayed();
			ClickWebObject(txtLibraries);
			OneframeLogger("Libraries section clicked");
			flag = true;
		}
		return flag;
	}

	@Step("Click Libraries header")
	public void clickLibrariesHeader() {
		txtLibraries.click();
		txtLibraries.click();
	}

	@Step("Click View button of Cost Share structure")
	public void clickViewButtonOfCostShareStructure() {
		if (ObjectExist(btnView)) {
			ClickWebObject(btnView);
			OneframeLogger("Cost Share Structure view button is clicked");
		}
	}

	@Step("Verify Cost Share Structure header is displayed")
	public boolean verifyCostShareStructureHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCostShareStrcuture)) {
			if (hdrCostShareStrcuture.getText().equalsIgnoreCase("Cost Shares Structures")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click first record of Cost share tier Structure from list")
	public void clickFirstRecordOfCostShareTierStructure() {
		if (ObjectExist(lstCostShareTierStructure)) {
			ClickWebObject(lstCostShareTierStructure);
			OneframeLogger("First record is clicked of Cost Share Tier Structure");
		}
	}

	@Step("Verify Cost Share Structure Details header is displayed")
	public boolean verifyCostShareStructureDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCostShareStructureDetails)) {
			if (hdrCostShareStructureDetails.getText().equalsIgnoreCase("Cost Share Structure Details")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click edit button of Cost Share structure Details")
	public void clickEditButton() {
		ObjectExist(btnEditCostShareStructureDetails);
		ClickWebObject(btnEditCostShareStructureDetails);
		OneframeLogger("Edit button clicked");
	}

	@Step("Edit and Get Text Structure Type field in Cost Share Structure details")
	public String editAndGetTextStructureType() {
		ObjectExist(txtStructureTypeField);
		ClickWebObject(txtStructureTypeField);
		while (!txtStructureTypeField.getAttribute("value").equalsIgnoreCase("")) {
			txtStructureTypeField.sendKeys(Keys.BACK_SPACE);
		}
		String type = "AUTO";
		int randomNumber = getRandomNumber();
		String structureType = type + randomNumber;
		txtStructureTypeField.sendKeys(structureType);

		OneframeLogger("The structure type is : " + txtStructureTypeField.getAttribute("value"));
		return txtStructureTypeField.getAttribute("value");
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Edit and Get Text Structure Name field in Cost Share Structure details")
	public String editAndGetTextStructureName() {
		ObjectExist(txtStructureNameField);
		ClickWebObject(txtStructureNameField);
		while (!txtStructureNameField.getAttribute("value").equalsIgnoreCase("")) {
			txtStructureNameField.sendKeys(Keys.BACK_SPACE);
		}
		String name = "AUTO";
		int randomNumber = getRandomNumber();
		String structureName = name + randomNumber;
		txtStructureNameField.sendKeys(structureName);
		OneframeLogger("The structure name is : " + txtStructureNameField.getAttribute("value"));
		return txtStructureNameField.getAttribute("value");
	}

	@Step("Edit and Get Text cost Share Rows in Cost Share Structure details")
	public String editAndGetCostShareRows() {
		ObjectExist(txtStructureCostShareRows);
		ClickWebObject(txtStructureCostShareRows);

		if (txtStructureCostShareRows.getAttribute("value").equalsIgnoreCase("1")) {
			while (!txtStructureCostShareRows.getAttribute("value").equalsIgnoreCase("")) {
				txtStructureCostShareRows.sendKeys(Keys.BACK_SPACE);
			}
			txtStructureCostShareRows.sendKeys("2");
			OneframeLogger("The cost share Rows is : " + txtStructureCostShareRows.getAttribute("value"));
		} else if (txtStructureCostShareRows.getAttribute("value").equalsIgnoreCase("2")) {
			while (!txtStructureCostShareRows.getAttribute("value").equalsIgnoreCase("")) {
				txtStructureCostShareRows.sendKeys(Keys.BACK_SPACE);
			}
			txtStructureCostShareRows.sendKeys("1");
			OneframeLogger("The cost share Rows is : " + txtStructureCostShareRows.getAttribute("value"));
		}
		return txtStructureCostShareRows.getAttribute("value");
	}

	@Step("Edit and Get Text cost Share Rows in Cost Share Structure details")
	public String editAndGetStructureContent() {
		ObjectExist(txtStructureContent);
		ClickWebObject(txtStructureContent);
		while (!txtStructureContent.getAttribute("value").equalsIgnoreCase("")) {
			txtStructureContent.sendKeys(Keys.BACK_SPACE);
		}
		String costShareRows = txtStructureCostShareRows.getAttribute("value");
		int costShareRowsInt = Integer.parseInt(costShareRows);
		String structureContent = "";
		String structContent = "";
		for (int i = 0; i < costShareRowsInt; i++) {
			String content = "AUTO";
			int randomNumber = getRandomNumber();
			structureContent = content + randomNumber;
			if (txtStructureCostShareRows.getAttribute("value").equalsIgnoreCase("2") && i == 0) {
				structContent = structureContent + ",";
				txtStructureContent.sendKeys(structContent);
			}

		}
		txtStructureContent.sendKeys(structureContent);
		OneframeLogger("The content is : " + txtStructureContent.getAttribute("value"));
		return txtStructureContent.getAttribute("value");
	}

	@Step("Get Random alphabetical String")
	public String getRandomAlphabeticalString(int length) {
		String value = "";
		String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		for (int i = 1; i < length; i++) {
			value += letters.charAt((int) Math.floor(Math.random() * letters.length()));
		}
		return value;
	}

	@Step("Click Save Changes button from Cost Share Structure Details")
	public void clickSaveChangesButton() {
		ObjectExist(btnSaveChanges);
		ClickWebObject(btnSaveChanges);
		OneframeLogger("Save Changes button clicked");
	}

	@Step("Click back button from Cost Share Structure Details")
	public void clickBackButton() {
		ObjectExist(btnBack);
		ClickWebObject(btnBack);
		OneframeLogger("Back button clicked");
	}

	@Step("Verify Changes Saved Text Is Displayed")
	public boolean verifyTextChangesSaved() {
		boolean flag = false;
		if (ObjectExist(txtChangesSaved)) {
			txtChangesSaved.isDisplayed();
			flag = true;
		}
		return flag;
	}

	@Step("Verify the edited structure type is same in first record on Cost Share Structure Page")
	public boolean verifyEditedStructureTypeIsSame(String strucType) {
		boolean bln = false;
		ObjectExist(txtFirstRecordStructureType.get(0));
		highlightElement(txtFirstRecordStructureType.get(0));
		String structureTypeFirstRecord = txtFirstRecordStructureType.get(0).getText();
		if (structureTypeFirstRecord.equalsIgnoreCase(strucType)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the edited structure name is same in first record on Cost Share Structure Page")
	public boolean verifyEditedStructureNameIsSame(String strucName) {
		boolean bln = false;
		ObjectExist(txtFirstRecordStructureName.get(0));
		highlightElement(txtFirstRecordStructureName.get(0));
		String structureNameFirstRecord = txtFirstRecordStructureName.get(0).getText();
		if (structureNameFirstRecord.equalsIgnoreCase(strucName)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the edited Cost Share is same in first record on Cost Share Structure Page")
	public boolean verifyEditedCostShareRowsIsSame(String costShareRows) {
		boolean bln = false;
		ObjectExist(txtCostShareRows.get(0));
		highlightElement(txtCostShareRows.get(0));
		String costShareRowsFirstRecord = txtCostShareRows.get(0).getText();
		if (costShareRowsFirstRecord.equalsIgnoreCase(costShareRows)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the edited structure content is same in first record on Cost Share Structure Page")
	public boolean verifyEditedStructureContentIsSame(String strucContent) {
		boolean bln = false;
		ObjectExist(txtFirstRecordStructureContent.get(0));
		highlightElement(txtFirstRecordStructureContent.get(0));
		String structureContentFirstRecord = txtFirstRecordStructureContent.get(0).getText();
		if (structureContentFirstRecord.equalsIgnoreCase(strucContent)) {
			bln = true;
		}
		return bln;
	}

	@Step("Click on Create Cost Share Structure")
	public void clickCreateCostShareStructure() {
		WaitForObjectVisibility(btnCreateCostShareStructure);
		btnCreateCostShareStructure.click();
		OneframeLogger("Clicked on Create Cost Share Structure button");
	}

	@Step("Enter and Get Text Structure Type field in Create Cost Share Structure")
	public String enterAndGetTextStructureType() {
		ObjectExist(txtStructureTypeField);
		ClickWebObject(txtStructureTypeField);
		String type = "AUTO";
		int randomNumber = getRandomNumber();
		String structureType = type + randomNumber;
		txtStructureTypeField.sendKeys(structureType);

		OneframeLogger("The structure type is : " + txtStructureTypeField.getAttribute("value"));
		return txtStructureTypeField.getAttribute("value");
	}

	@Step("Enter and Get Text Structure Name field in Cost Share Structure")
	public String enterAndGetTextStructureName() {
		ObjectExist(txtStructureNameField);
		ClickWebObject(txtStructureNameField);
		String name = "AUTO";
		int randomNumber = getRandomNumber();
		String structureName = name + randomNumber;
		txtStructureNameField.sendKeys(structureName);
		OneframeLogger("The structure name is : " + txtStructureNameField.getAttribute("value"));
		return txtStructureNameField.getAttribute("value");
	}

	@Step("Enter and Get Text cost Share Rows in Cost Share Structure")
	public String enterAndGetCostShareRows() {
		ObjectExist(txtStructureCostShareRows);
		ClickWebObject(txtStructureCostShareRows);

		txtStructureCostShareRows.sendKeys("1");
		OneframeLogger("The cost share Rows is : " + txtStructureCostShareRows.getAttribute("value"));

		return txtStructureCostShareRows.getAttribute("value");
	}

	@Step("Enter and Get Text cost Share Rows in Cost Share Structure")
	public String enterAndGetStructureContent() {
		ObjectExist(txtStructureContent);
		ClickWebObject(txtStructureContent);

		String structureContent = "";

		String content = "AUTO";
		int randomNumber = getRandomNumber();
		structureContent = content + randomNumber;

		txtStructureContent.sendKeys(structureContent);
		OneframeLogger("The content is : " + txtStructureContent.getAttribute("value"));
		return txtStructureContent.getAttribute("value");
	}

	@Step("Verify Cost Share Tier Structure url")
	public void verifyCostShareTierStructureUrl() {
		String currentUrl = oneframeDriver.getCurrentUrl();
		ha.assertTrue(currentUrl.contains("admin/library/cost-shares/cost-shares-tier-structure/new"),
				"Validated New Cost Share Tier Structure url is as expected");
	}

	@Step("Click on Create Structure button")
	public void clickCreateStructureButton() {
		WaitForObjectVisibility(btnCreateStructure);
		btnCreateStructure.click();
		OneframeLogger("Clicked on Create Structure button");
	}

	@Step("Verify Cost Share Structure was created Successfully Message is displayed")
	public void verifyCostShareStructureCreatedMessage() {
		WaitForObjectVisibility(txtCostShareStructureCreated);
		if (txtCostShareStructureCreated.isDisplayed()) {
			highlightElement(txtCostShareStructureCreated);
			sa.assertTrue(true, "Verified Cost Share Structure was created successfully Message");
		} else {
			sa.assertTrue(false, "Unable to verify Cost Share Structure was created successfully Message");
		}
	}

	@Step("Verify Filter button is displayed")
	public void verifyFilterButtonIsDisplayed() {
		WaitForObjectVisibility(btnFilter);
		if (btnFilter.isDisplayed()) {
			sa.assertTrue(true, "Verified Filter button is displayed");
		} else {
			sa.assertTrue(false, "Unable to verify Filter button");
		}
	}

	@Step("Click on Cancel button")
	public void clickCancelButton() {
		WaitForObjectVisibility(btnCancel);
		highlightElement(btnCancel);
		btnCancel.click();
		OneframeLogger("Clicked on Cancel button");
	}

	@Step("Verify 'Cost Share Structure' list colour")
	public void verifyCostShareStructureListColor() {
		verifyColorCostShareStructure(lstCostShareStructure.get(0), "rgba(255, 255, 255, 1)");
		verifyColorCostShareStructure(lstCostShareStructure.get(1), "rgba(245, 245, 245, 1)");

	}

	@Step("Verify Color in Cost Share Structure")
	public void verifyColorCostShareStructure(WebElement element, String rgba) {
		if (WaitForObjectVisibility(element)) {
			String actualColor = element.getCssValue("background-color");
			if (rgba.equalsIgnoreCase("rgba(255, 255, 255, 1)")) {
				if (actualColor.equalsIgnoreCase(rgba)) {
					OneframeLogger(actualColor + " Background color is white in first Cost Share Structure list: "
							+ element.getCssValue("background-color"));
					sa.assertEquals(actualColor, rgba, "Verified color is white in first Cost Share Structure list");
				} else {
					OneframeLogger(element.getText()
							+ " Background color is not in white color in first Cost Share Structure list");
				}
			} else {
				if (actualColor.equalsIgnoreCase(rgba)) {
					OneframeLogger(actualColor + " Background color is grey in first Cost Share Structure list: "
							+ element.getCssValue("background-color"));
					sa.assertEquals(actualColor, rgba, "Verified color is grey in first Cost Share Structure list");
				} else {
					OneframeLogger(element.getText()
							+ " Background color is not in grey in first color in Cost Share Structure list");
				}

			}

		}
	}

}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateWFEInRemediationCancelEditButtonDisplay extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
    IBPHomePage homepage;
    IBPBenefitPage benefitpage;
    IBPCreateBenefitPage createbenefitpage ;

	@BeforeClass
	@Step("Initializing Test Script for validate Cancel and Edit Buttons display For the Rejected Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_57");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "NewBenefitId"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Cancel and Edit Buttons display For the Rejected Benefit", dataProvider = "TestData")
	@Description("Validate Cancel and Edit Buttons display For the Rejected Benefit")
	public void ValidateCancelEditButtonsFortheRejectedBenefit(String TestCaseID, String TestStatus,String NewBenefitId) throws AWTException, InterruptedException, IOException {	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitId);
			//sa.assertTrue(benefitpage.verifySearchResults(), "Benefit Results is displayed");
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Given Benefit header is displayed");
			sa.assertTrue(benefitpage.verifyAssignYourselfbuttondisplay(), "Verified Assign to Yourslef button is displayed");
			benefitpage.clickAssignToYourselfButton();
			sa.assertTrue(benefitpage.verifyInRemediationStatusRejectedBenefit(), "InRemediation Version Status is displayed");
			sa.assertTrue(benefitpage.verifyEditButtondisplayforRejectedBenefit(), "Cancel Button is displayed");
			sa.assertTrue(benefitpage.verifyCancelButtondisplayforRejectedBenefit(), "Edit Button is displayed");
			sa.assertTrue(benefitpage.verifyclientFeedbackWidgetdisplay(), "Client Feedback Widget is displayed");
			sa.assertTrue(benefitpage.verifybenefitBannerInRemediationMessage(), "Benefit has been Assigned to You Message is displayed");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Cancel and Edit Buttons display For the Rejected Benefit Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate Cancel and Edit Buttons display For the Rejected Benefit UnSuccessfully");
		}
	}


	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

	

}

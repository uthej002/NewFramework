package anthem.irx.oneframe.qTest;

import anthem.irx.oneframe.core.OneframeConstants;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import org.qas.qtest.api.auth.PropertiesQTestCredentials;
import org.qas.qtest.api.auth.QTestCredentials;

public class QTestConnection {
  public QTestCredentials QTestCredential;
  
  InputStream qTestCredInputStream;
  
  public QTestConnection() {
    try {
      this.qTestCredInputStream = new FileInputStream(OneframeConstants.CONFIG_FOLDER + "qTestCredentials.properties");
    } catch (FileNotFoundException e1) {
      e1.printStackTrace();
    } 
    try {
      this.QTestCredential = (QTestCredentials)new PropertiesQTestCredentials(this.qTestCredInputStream);
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
}

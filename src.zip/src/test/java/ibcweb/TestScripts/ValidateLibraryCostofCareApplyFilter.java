package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibraryCostofCareApplyFilter extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPLibrariesMandatesPage mandate;

	@BeforeClass
	@Step("Initializing Test Script for Validate if the user is able to filter the Cost of Care programs after filling the filter options and clicking on Apply Filter")
	public void setUp() {
		InitializeLaunchPad("IBPW_751");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		mandate =  new IBPLibrariesMandatesPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId","LOBId", "StateId"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate if the user is able to filter the Cost of Care programs after filling the filter options and clicking on Apply Filter", dataProvider = "TestData")
	@Description("Validate if the user is able to filter the Cost of Care programs after filling the filter options and clicking on Apply Filter")
	public void ValidateLibrariesApplyFilter(String TestCaseID, String TestStatus,String ClientId,
		    String LOBId, String StateId)throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickCostofCareofPrograms();
			librariesprogramspage.clickFilterButton();
			sa.assertTrue(librariesprogramspage.verifyFilterText(),"Verified 'Filter By' is displayed");
			String drodpownValues = librariesprogramspage.selectValuesFromFilter();
			librariesprogramspage.clickApplyFilterButton();
			librariesprogramspage.clickProgramsHeader();
//			sa.assertTrue(librariesprogramspage.verifySelectedValuesDisplayed(drodpownValues),
//					"Verified and Implemented Filter Function in Cost of Care Library");		
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if the user is able to filter the Cost of Care programs after filling the filter options and clicking on Apply Filter Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to filter the Cost of Care programs after filling the filter options and clicking on Apply Filter");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}



}

package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeConstants;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeReporter;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileOpsHelper {
  public static File createFile(String FolderPath, String FileName) {
    Boolean status = Boolean.valueOf(false);
    File newFile = new File(FolderPath + "\\" + FileName);
    try {
      status = Boolean.valueOf(newFile.createNewFile());
    } catch (IOException ioe) {
      OneframeContainer.OneframeLogger("Error occured while creating the file" + ioe);
    } 
    if (status.booleanValue()) {
      OneframeContainer.OneframeLogger("File [" + newFile.getPath() + "] created");
    } else {
      OneframeContainer.OneframeLogger("File [" + newFile.getPath() + "] already exists");
    } 
    return newFile;
  }
  
  public static void writeToFile(String FileName, String Content) {
    try {
      Files.write(Paths.get(FileName, new String[0]), Content.getBytes(), new java.nio.file.OpenOption[0]);
    } catch (IOException e) {
      OneframeContainer.OneframeLogger(e.getMessage());
    } 
  }
  
  public static boolean checkFolderExist(String FolderPath) {
    File file = new File(FolderPath);
    if (!file.isDirectory())
      OneframeContainer.OneframeLogger("Path is not directory"); 
    return file.exists();
  }
  
  public static boolean createDirectory(String FolderPath) {
    Boolean status = Boolean.valueOf(false);
    File newFolder = new File(FolderPath);
    try {
      status = Boolean.valueOf(newFolder.mkdir());
    } catch (SecurityException se) {
      OneframeContainer.OneframeLogger("Error occured while creating the folder" + se);
    } 
    if (status.booleanValue()) {
      OneframeContainer.OneframeLogger("Folder [" + newFolder.getPath() + "] created");
    } else {
      OneframeContainer.OneframeLogger("Folder [" + newFolder.getPath() + "] already exists");
    } 
    return status.booleanValue();
  }
  
  public static String createTodaysLogFolder(String ReportType) {
    String ReportDir = OneframeConstants.TESTOUTPUT_FOLDER + ReportType + "/";
    createDirectory(ReportDir);
    String todaysLogDir = "FAILED TO CREATE DIRECTORY";
    Date currentDate = new Date();
    try {
      DateFormat dateFormatter = new SimpleDateFormat("MM-dd-yyyy");
      String date = dateFormatter.format(currentDate);
      todaysLogDir = ReportDir + date;
      Path todaysDirectoryPath = Paths.get(todaysLogDir, new String[0]);
      if (Files.exists(todaysDirectoryPath, new java.nio.file.LinkOption[0])) {
        OneframeContainer.OneframeLogger("[ONEFRAME]Log folder already exist...");
      } else {
        createDirectory(todaysLogDir);
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return todaysLogDir;
  }
  
  public static void createBatchFile(String FileName) {
    String BatchFileFolder = OneframeConstants.BATCHFILE_FOLDER;
    BufferedWriter writer = null;
    try {
      File batchFile = new File(BatchFileFolder + "\\" + FileName);
      writer = new BufferedWriter(new FileWriter(batchFile));
      writer.write("cd %ProgramFiles(x86)%\\SOME_FOLDER \r\nstart xyz.bat \r\nexit");
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        writer.close();
      } catch (Exception exception) {}
    } 
  }
  
  public static void executeBatchFile(String BatchFileName) {
    String batchFile = OneframeConstants.BATCHFILE_FOLDER + "\\" + BatchFileName;
    Runtime objRunTime = Runtime.getRuntime();
    try {
      Process objProcess = objRunTime.exec("powershell /c start \"\" \"" + batchFile);
      OneframeContainer.OneframeLogger("Executed Batch File : " + batchFile);
      objProcess.getOutputStream().close();
    } catch (IOException ex) {
      OneframeContainer.OneframeLogger(ex.getMessage());
    } 
  }
  
  public static void backupTestNGReports() throws IOException {
    createTodaysLogFolder("TestNG_Reports");
    Path destinationPath = Paths.get("src/test/resources/copiedWithNio.txt", new String[0]);
    Path originalPath = OneframeReporter.getSourcePathTestNGemailableReport().toPath();
    Files.copy(originalPath, destinationPath, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
  }
}
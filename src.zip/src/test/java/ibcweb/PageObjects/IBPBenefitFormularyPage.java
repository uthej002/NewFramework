package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.EnterText;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ScrollToElement;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForApplicationToLoadCompletely;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ClearTextOnInputElement;
import static anthem.irx.oneframe.selenium.WebObjectHandler.FindObjectByLocator;
import static anthem.irx.oneframe.selenium.WebObjectHandler.FindObjectByLocatorNoWait;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;
import net.bytebuddy.asm.Advice.Enter;

public class IBPBenefitFormularyPage extends OneframeContainer {
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//div[text()=' Formulary ']")
	WebElement tabFormulary;

	@FindBy(xpath = "//input[@aria-label='Formulary']")
	WebElement addBaseFormulary;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	WebElement dropdownFirstOption;

	@FindBy(xpath = "//span[text()=' Add a Net Formulary ']")
	WebElement btnAddNetFormulary;

	@FindBy(xpath = "//span[text()=' Add to benefit ']")
	WebElement btnAddtoBenefit;

	@FindBy(xpath = "//span[text()='Add to benefit']")
	WebElement btnAddPOStoBenefit;

	@FindBy(xpath = "//div[@class='header__title']")
	WebElement txtAddaNetFormulary;

	@FindBy(xpath = "//h3[@class='header__title']")
	WebElement txtAddPOSDUR;

	@FindBy(xpath = "//div[@class='element element__formulary-id']//span[@class='label-value label-value__value']")
	WebElement txtFormularyIDValue;

	@FindBy(xpath = "//div[@class='element element__net-formulary-id']//span[@class='label-value label-value__value']")
	WebElement txtNetFormularyIDValue;

	@FindBy(xpath = "//div[@class='element element__tiers']//span[@class='label-value label-value__value']")
	WebElement txtTiersValue;

	@FindBy(xpath = "//div[@class='element element__net-formulary-name']//span[@class='label-value label-value__value']")
	WebElement txtNetFormularyName;

	@FindBy(xpath = "//div[text()='POS DUR Packages']")
	WebElement tabPOSDURPackages;

	@FindBy(xpath = "//div[@class='col name']")
	WebElement txtPOSDURName;

	@FindBy(xpath = "//h4[@class='sub-heading']")
	WebElement hdrPOSDURDetails;

	@FindBy(xpath = "//mat-icon[@svgicon='remove']")
	WebElement lnkRemove;

	@FindBy(xpath = "//span[normalize-space()='Remove']")
	WebElement btnRemove;

	@FindBy(xpath = "//h3[@class='mat-dialog-title']")
	WebElement hdrRemovePopup;

	@FindBy(xpath = "//span[text()=' Add a POS DUR package ']")
	WebElement btnAddaPOSDRPackage;

	@FindBy(xpath = "//span[text()=' Net Formularies ']")
	WebElement btnNetFormularies;

	@FindBy(xpath = "//a[@routerlink=\"/admin/library/formularies/base-formularies\"]")
	WebElement btnFormulariesView;

	@FindBy(xpath = "//span[text()=' Create a Net Formulary ']")
	WebElement btnCreateNetFormulary;

	@FindBy(xpath = "//input[@placeholder='Type to select formulary']")
	WebElement txtFormularyInput;

	@FindBy(xpath = "//div[@role='listbox']/mat-option/span")
	List<WebElement> lstFormularyValues;

	@FindBy(xpath = "//input[@placeholder='Enter Formulary']")
	WebElement newNetFormularyFormularyIdDropdown;
	
	@FindBy(xpath="//h3[text()='Formulary Data']")
	WebElement hdrFormularyData;

	@FindBy(xpath = "//tbody['rowgroup']/tr/td[1]")
	List<WebElement> lstNetFormularies;

	@FindBy(xpath = "//*[@svgicon='edit']")
	WebElement btnEdit;

	@FindBy(xpath = "//*[text()='Formularies']")
	WebElement hdrFormularies;

	@FindBy(xpath = "//h3[text()=' Net Formulary Details ']")
	WebElement hdrNetFormularyDetails;

	@FindBy(xpath = "//input[@type='text']")
	WebElement txtEditFormularyInput;

	@FindBy(xpath = "//h4[text()='Net Formulary']/following-sibling::div//mat-icon[@svgicon='remove']")
	WebElement removeIcon;

	@FindBy(xpath = "//*[text()=' Cancel ']")
	WebElement btnCancel;

	@FindBy(xpath = "//*[text()='Formulary']/../../../input[@disabled]")
	WebElement txtFormularyInputValue;

	@FindBy(xpath = "//*[text()='Net Formulary ID']/../../../input[@disabled]")
	WebElement txtNetFormularyIDInputValue;

	@FindBy(xpath = "//*[text()='Adjudication Formulary ID']/../../../input[@disabled]")
	WebElement txtAdjudicationFormularyIDValue;

	@FindBy(xpath = "//*[text()='# Tiers']/../../../mat-select")
	WebElement txtTiersInputValue;

	@FindBy(xpath = "//*[text()='Cost Share Tier Structure']/../../../mat-select")
	WebElement txtCostShareTierValue;

	@FindBy(xpath = "//*[text()='Net Formulary Name']/../../../input[@disabled]")
	WebElement txtNetFormularyNameValue;

	@FindBy(xpath = "//*[text()='Effective Date']/../../../input[@disabled]")
	WebElement txtEffectiveDateValue;

	@FindBy(xpath = "//*[text()='Stop Sale Date']/../../../input[@disabled]")
	WebElement txtStopSaleDateValue;

	@FindBy(xpath = "//*[text()='Termination Date']/../../../input[@disabled]")
	WebElement txtTermDateValue;

	@FindBy(xpath = "//*[text()='Client']/../../../mat-select")
	WebElement txtClientValue;

	@FindBy(xpath = "//*[text()='LOB']/../../../mat-select")
	WebElement txtLOBValue;

	@FindBy(xpath = "//*[text()='State']/../../../mat-select")
	WebElement txtStateValue;

	@FindBy(xpath = "//*[text()='Employer Group']/../../../mat-select")
	WebElement txtEmployerGroupValue;

	@FindBy(xpath = "//*[text()='Managed By']/../../../mat-select")
	WebElement txtManagedByValue;

	@FindBy(xpath = "//*[text()='Implementation Date']/../../../input[@disabled]")
	WebElement txtImplementationDateValue;

	@FindBy(xpath = "//*[text()='Formulary Link']/../../../input[@disabled]")
	WebElement txtFormularyLinkValue;

	@FindBy(xpath = "//input[@placeholder='Enter Formulary Tag']")
	WebElement txtFormularyTag;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[6]")
	List<WebElement> recordsCount;

	@FindBy(xpath = "//*[@aria-label='Previous page']")
	WebElement btnPreviousPage;

	@FindBy(xpath = "//*[@aria-label='Next page']")
	WebElement btnNextPage;

	@FindBy(xpath = "//*[text()=' FORMULARY ID']")
	WebElement btnFormularyID;

	@FindBy(xpath = "//span[text()=' Drug Exceptions ']")
	WebElement btnDrugException;

	@FindBy(xpath = "//span[text()=' Create a Drug Exception List ']")
	WebElement btnCreateDrugException;

	@FindBy(xpath = "//*[text()='CVS Code']")
	WebElement txtCvsCode;

	@FindBy(xpath = "//*[text()='Drug List Name']")
	WebElement txtDrugListName;

	@FindBy(xpath = "//*[text()='Drug List Description']")
	WebElement txtDrugListDescription;

	@FindBy(xpath = "//*[text()='Managed By']")
	WebElement txtManagedBy;

	@FindBy(xpath = "//*[text()='Adj. Sys Status']")
	WebElement txtAdjSysStatus;

	@FindBy(xpath = "//*[text()='Effective Date']")
	WebElement txtEffectiveDate;

	@FindBy(xpath = "//*[text()='Termination Date']")
	WebElement txtTerminationDate;

	@FindBy(xpath = "//*[text()='Client']")
	WebElement txtClient;

	@FindBy(xpath = "//*[text()='LOB']")
	WebElement txtLob;

	@FindBy(xpath = "//*[text()='State']")
	WebElement txtState;

	@FindBy(xpath = "//*[text()='List Data']")
	WebElement hdrListData;

	@FindBy(xpath = "//*[@data-automation-id = 'newNetFormularyManagedBy']")
	WebElement drpDownManagedBy;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> lstdrpDownManagedBy;

	@FindBy(css = ".element__tiers .label-value")
	WebElement tierCount;

	@FindBy(xpath = "//span[text()=' Create a Drug Exception List ']")
	WebElement btnCreateDrugExceptionList;

	@FindBy(xpath = "//*[text()='Create a Drug Exception List']")
	WebElement hdrCreateADrugExceptionList;

	@FindBy(xpath = "//*[@data-automation-id = 'createDrugListSource']")
	WebElement drpDownDrugExceptionManagedBy;

	@FindBy(xpath = "//*[@data-automation-id='createDrugListAdjSysStatus']")
	WebElement drpdownAdjSysStatus;

	@FindBy(xpath = "//*[text()=' Add Drug Exception List ']")
	WebElement btnAddDrugExceptionList;

	@FindBy(xpath = "//*[@data-automation-id='createDrugListCvsCodeList']")
	WebElement createCVSCode;

	@FindBy(xpath = "//*[@data-automation-id='createDrugListName']")
	WebElement createDrugListName;

	@FindBy(xpath = "//*[@data-automation-id='createDrugListDescription']")
	WebElement createDrugListDescription;

	@FindBy(xpath = "//*[@data-automation-id = 'newNetFormularyManagedBy']")
	WebElement drpdownManagedBy;

	@FindBy(xpath = "//*[@data-automation-id = 'editDrugAdjSysStatus']")
	WebElement drpDownAdjSysStatusDrugException;

	@FindBy(xpath = "//*[@formcontrolname='effectiveDate']")
	WebElement enterEffDate;

	@FindBy(xpath = "//*[@formcontrolname='terminationDate']")
	WebElement enterTermDate;

	@FindBy(xpath = "//*[text()='DRUG LIST ID']")
	WebElement btnDrugListID;

	@FindBy(xpath = "//*[@svgicon='audit']")
	WebElement btnAudit;

	@FindBy(xpath = "//*[@data-automation-id='editDrugCVSCodeList']")
	WebElement enterTxtCVScode;

	@FindBy(xpath = "//*[@data-automation-id='editDrugListName']")
	WebElement enterTxtDruglistName;

	@FindBy(xpath = "//*[@data-automation-id='editDrugDescription']")
	WebElement enterTxtDescription;

	@FindBy(xpath = "//*[@data-automation-id = 'editDrugSource']")
	WebElement drpDownManagedByDrugException;

	@FindBy(xpath = "//*[text()='Save Changes']")
	WebElement btnSaveChanges;

	@FindBy(xpath = "//*[@svgicon='down-arrow']")
	WebElement btnDownArrow;

	@FindBy(xpath = "//*[text()='Cancel']")
	WebElement btnDrugExceptionCancel;

	@FindBy(xpath = "//*[text()='Leave without Saving?']")
	WebElement hdrLeaveWithoutSaving;

	@FindBy(xpath = "//*[text()=\"You've made changes to \"]")
	WebElement txtPopupMsg;

	@FindBy(xpath = "//*[text()='Leave']")
	WebElement btnLeave;

	@FindBy(xpath = "//*[@formcontrolname='cvsId']")
	WebElement txtCvsCodeValue;

	@FindBy(xpath = "//*[@formcontrolname='name']")
	WebElement txtDruglistNameValue;

	@FindBy(xpath = "//*[@formcontrolname='description']")
	WebElement txtDescriptionValue;

	@FindBy(xpath = "//*[@formcontrolname='managedBy']")
	WebElement txtManagedByField;

	@FindBy(xpath = "//*[@formcontrolname='adjudicationStatus']")
	WebElement txtAdjStatusField;

	@FindBy(xpath = "//*[@formcontrolname='effectiveDate']")
	WebElement txtEffDateValue;

	@FindBy(xpath = "//*[@formcontrolname='terminationDate']")
	WebElement txtTermDateField;

	@FindBy(xpath = "//*[@formcontrolname=\"clients\"]")
	WebElement txtClientField;

	@FindBy(xpath = "//*[@formcontrolname=\"lobs\"]")
	WebElement txtLOBField;

	@FindBy(xpath = "//*[@formcontrolname=\"states\"]")
	WebElement txtStateField;

	@FindBy(xpath = "//*[@data-automation-id = 'editDrugListId']")
	WebElement txtDruglistID;

	@FindBy(xpath = "//h3[text()='Drug Exception List']")
	WebElement hdrDrugExceptionlist;
	
	@FindBy(css = ".pos-dur-container .name")
	WebElement posDurName;
	
	@FindBy(xpath = "//div[contains(@class, 'pos-dur-container')]/following-sibling::div//mat-icon")
	WebElement eyeIcon;
	
	@FindBy(xpath = "//h3[text()='Details']")
	WebElement hdrDetails;
	

	// Initializing the Page Objects:
	public IBPBenefitFormularyPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on Formulary Tab")
	public boolean clickFormularyTab() {
		boolean flg = false;

		try {
			if (WaitForObjectVisibility(tabFormulary)) {
				ClickWebObject(tabFormulary);
				OneframeLogger("Formulary Tab in Benefit is clicked");
				flg = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Formulary Tab in Benefit is not clicked: " + e);
		}

		return flg;
	}

	@Step("Click on POS DUR Packages Tab")
	public void clickPOSDURTab() {
		try {
			if (WaitForObjectVisibility(tabPOSDURPackages)) {
				ClickWebObject(tabPOSDURPackages);
				OneframeLogger("POS DUR Packages Tab in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("POS DUR Packages Tab in Benefit is not clicked");
		}
	}

	@Step("Select First Option from Formulary Dropdown")
	public void selectFirstOptionfromDropdown() {
		try {
			if (WaitForObjectVisibility(dropdownFirstOption)) {
				ClickWebObject(dropdownFirstOption);
				OneframeLogger("Selected First Option from Formulary Dropdown");
			}
		} catch (NoSuchElementException e) {
			OneframeLogger("Not able to Select First Option from Formulary Dropdown");
		}
	}

	@Step("Add the Base Formulary")
	public boolean addBaseFormulary() throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(addBaseFormulary)) {
				ClickWebObject(addBaseFormulary);
				ClickWebObject(addBaseFormulary);
				addBaseFormulary.sendKeys(Keys.CONTROL + "a");
				addBaseFormulary.sendKeys(Keys.DELETE);
				EnterText(addBaseFormulary, "EH");
				Thread.sleep(2000);
				addBaseFormulary.sendKeys(Keys.ENTER);
				// selectFirstOptionfromDropdown();
				blnRC = true;
			}
		} catch (NoSuchElementException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Add Net Formulary Tab")
	public void clickAddNetFormularyTab() {
		try {
			if (WaitForObjectVisibility(btnAddNetFormulary)) {
				ClickWebObject(btnAddNetFormulary);
				OneframeLogger("Add Net Formulary Button in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Net Formulary Button in Benefit is not clicked");
		}
	}

	@Step("Click on Add POS DUR Tab")
	public void clickAddPOSDURTab() {
		try {
			if (WaitForObjectVisibility(btnAddaPOSDRPackage)) {
				ClickWebObject(btnAddaPOSDRPackage);
				OneframeLogger("Add POS DUR Package Button in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add POS DUR Package Button in Benefit is not clicked");
		}
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int b = (int) Math.floor((Math.random() * 0) + 1);
		return b;
	}

	@Step("Select random Item in Formulary Tab")
	public void selectRandomItem() {
		int randomNetFormularyRow = getRandomNumber();
		String elementOne = String.format("//tbody/tr[' + %s + ']", randomNetFormularyRow);
		WebElement addRandomNetFormulary = oneframeDriver.findElement(By.xpath(elementOne));
		if (WaitForObjectVisibility(addRandomNetFormulary)) {
			ClickWebObject(addRandomNetFormulary);
			OneframeLogger("The random item has been selected for the benefit");
		}
	}

	@Step("Add the Net Formulary")
	public boolean addNetFormulary(String formularyID) throws Throwable {
		boolean blnRC = false;
		try {
			String xpath = "//tr/td[normalize-space()='" + formularyID + "']";

			clickAddNetFormularyTab();
			Thread.sleep(3000);
			ClickWebObject(txtAddaNetFormulary);
			WebElement addRandomNetFormulary = oneframeDriver.findElement(By.xpath(xpath));
			if (WaitForObjectVisibility(addRandomNetFormulary)) {
				ClickWebObject(addRandomNetFormulary);
				WaitForObjectVisibility(btnAddtoBenefit);
				ClickWebObject(btnAddtoBenefit);
				blnRC = true;
				OneframeLogger("Added Net Formulary: " + formularyID);
			}

		} catch (NoSuchElementException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether the Net Formulary fields are displayed")
	public boolean verifyNetFormularyFields() {
		boolean blnRc = false;
		try {
			if (WaitForObjectVisibility(txtFormularyIDValue)) {
				ClickWebObject(txtFormularyIDValue);
				ClickWebObject(txtNetFormularyIDValue);
				ClickWebObject(txtTiersValue);
				ClickWebObject(txtNetFormularyName);
				blnRc = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRc = false;
		}
		return blnRc;
	}

	@Step("Remove the POS DUR Packages")
	public boolean removePOSDURPackages() throws Throwable {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(hdrPOSDURDetails)) {
				ClickWebObject(hdrPOSDURDetails);
				Thread.sleep(2000);
				ClickWebObject(lnkRemove);
				WaitForObjectVisibility(hdrRemovePopup);
				ClickWebObject(btnRemove);
				WaitForObjectVisibility(btnAddaPOSDRPackage);
				if (btnAddaPOSDRPackage.isDisplayed())
					blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Add the POS DUR Package")
	public boolean addPOSDUR() throws Throwable {
		boolean blnRC = false;
		try {
			clickAddPOSDURTab();
			Thread.sleep(3000);
			ClickWebObject(txtAddPOSDUR);
			selectRandomItem();
			WaitForObjectVisibility(btnAddPOStoBenefit);
			ClickWebObject(btnAddPOStoBenefit);
			blnRC = true;
		} catch (NoSuchElementException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether the POS DUR fields are displayed")
	public boolean verifyPOSDURFields() {
		boolean blnRc = false;
		try {
			if (WaitForObjectVisibility(txtPOSDURName)) {
				ClickWebObject(txtPOSDURName);
				blnRc = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRc = false;
		}
		return blnRc;
	}

	@Step("Click View button of Formularies")
	public void clickViewButtonofFormularies() {
		try {
			if (WaitForObject(btnFormulariesView)) {
				ClickWebObject(btnFormulariesView);
				OneframeLogger("Clicked on View button of Formularies");
			}
		} catch (TimeoutException e) {
			OneframeLogger("View button of Formularies is not Clicked");
		}
	}

	@Step("Click on Net Formularies Buton")
	public void clickNetFormulariesButton() {
		try {
			if (WaitForObject(btnNetFormularies)) {
				ClickWebObject(btnNetFormularies);
				OneframeLogger("Clicked on Net Formularies Button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Net Formularies Button is not Clicked");
		}
	}

	@Step("Click on Create a Net Formulary Buton")
	public void clickCreateNetFormularyButton() {
		try {
			if (WaitForObject(btnCreateNetFormulary)) {
				ClickWebObject(btnCreateNetFormulary);
				OneframeLogger("Clicked on Create a Net Formulary Button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Create a Net Formulary button is not Clicked");
		}
	}

	@Step("Enter Formulary input Text")
	public void EnterFormularyInput() {
		WaitForApplicationToLoadCompletely();
		String input = "EHB";
		try {
			if (ObjectExist(txtFormularyInput)) {

				ClickWebObject(txtFormularyInput);
				EnterText(txtFormularyInput, input);
				lstdrpDownManagedBy.get(0).click();
				OneframeLogger("Formulary Input has been Entered : " + txtFormularyInput.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Formulary Input has not Entered");
		}
	}

	@Step("Verify Formulary dropdown values")
	public boolean VerifyFormularyDropdownValues(String dropdownValue) throws InterruptedException {

		boolean blnRC = false;
		ArrayList<String> drdValue = new ArrayList<>(Arrays.asList());
		ArrayList<String> listOne = new ArrayList<>(Arrays.asList());
		drdValue.add(dropdownValue);
		if (WaitForObjectVisibility(newNetFormularyFormularyIdDropdown)) {
			//hdrFormularyData.click();
			newNetFormularyFormularyIdDropdown.sendKeys("EHB");
			Thread.sleep(2000);
			for (int i = 0; i < lstFormularyValues.size(); i++) {
				listOne.add(lstFormularyValues.get(i).getText());
			}
			if (listOne.size() > 0)
				blnRC = true;
			for (String drdVal : drdValue) {
				if (listOne.contains(drdVal)) {
					blnRC = blnRC & true;
				}
			}
			OneframeLogger("dropdown values provided from TDS: " + drdValue);
			OneframeLogger("dropdown values is same as expected: " + listOne);
		}
		lstFormularyValues.get(0).click();

		return blnRC;
	}

	@Step("Click on first Net Formulary")
	public void clickonFirstNetFormulary() {
		try {
			ClickWebObject(hdrFormularies);
			ClickWebObject(hdrFormularies);
			WaitForObjectVisibility(btnFormularyID);
			ClickWebObject(btnFormularyID);
			if (WaitForObject(lstNetFormularies.get(0))) {
				ClickWebObject(lstNetFormularies.get(0));
				OneframeLogger("Clicked on First Net Formulary");
			}
		} catch (TimeoutException e) {
			OneframeLogger("First Net Formulary is not Clicked");
		}
	}

	@Step("Verify and Click on Edit button")
	public boolean verifyAndClickEditButton() {
		boolean bln = false;
		if (ObjectExist(btnEdit)) {
			btnEdit.click();
			bln = true;
		}
		return bln;
	}

	@Step("Verify forumaluary text is entered")
	public void verifyFormularyTextisEntered() throws InterruptedException {
		ClickWebObject(hdrNetFormularyDetails);
		ClickWebObject(txtEditFormularyInput);
		txtEditFormularyInput.sendKeys(Keys.CONTROL + "a");
		txtEditFormularyInput.sendKeys(Keys.DELETE);
		// EnterFormularyInput();
		// VerifyFormularyDropdownValues();
		String input = "EH";
		try {
			if (ObjectExist(txtEditFormularyInput)) {

				ClickWebObject(txtEditFormularyInput);
				EnterText(txtEditFormularyInput, input);
				OneframeLogger("Formulary Input has been Entered : " + txtEditFormularyInput.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Formulary Input has not Entered");
		}

	}

	@Step("Remove Existing Net Formulary, if there are any.")
	public boolean removeExistingNetFormulary() {
		try {
			if (ObjectExist(removeIcon)) {
				ClickWebObject(removeIcon);
				if (WaitForObjectVisibility(btnRemove)) {
					ClickWebObject(btnRemove);
					OneframeLogger("Removed existing Net Formulary");
					return true;
				}
			}
		} catch (Exception e) {
			OneframeLogger("No Net Formulary Exists");
			return true;
		}

		return false;
	}

	@Step("Click Cancel button of Edit Formularies")
	public void clickCancelButtonofEditFormularies() {
		try {
			if (WaitForObject(btnCancel)) {
				ClickWebObject(btnCancel);
				OneframeLogger("Clicked on Cancel button of Edit Formularies");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cancl button of Edit Formularies is not Clicked");
		}
	}

	@Step("Verify Formulary Input field value is Disabled")
	public boolean verifyFormualryInputDisable() {
		boolean bln = false;
		if (txtFormularyInputValue.getAttribute("disabled") != null) {
			OneframeLogger("Formualry Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Net Formulary ID field value is Disabled")
	public boolean verifyNetFormualryIDInputDisable() {
		boolean bln = false;
		if (txtNetFormularyIDInputValue.getAttribute("disabled") != null) {
			OneframeLogger("Net Formulary ID Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Adjudication Formulary ID field value is Disabled")
	public boolean verifyAdjudicationFormualryIDInputDisable() {
		boolean bln = false;
		if (txtAdjudicationFormularyIDValue.getAttribute("disabled") != null) {
			OneframeLogger("Adjudication Formulary ID Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify #Tiers field value is Disabled")
	public boolean verifyTiersInputDisable() {
		boolean bln = false;
		if (txtTiersInputValue.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			OneframeLogger("#Tiers Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Cost Share Tier Structure field value is Disabled")
	public boolean verifyCostShareTierInputDisable() {
		boolean bln = false;
		if (txtCostShareTierValue.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			OneframeLogger("Cost Share Tier Structure Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Net Formulary Name field value is Disabled")
	public boolean verifyNetFormularyNameInputDisable() {
		boolean bln = false;
		if (txtNetFormularyNameValue.getAttribute("disabled") != null) {
			OneframeLogger("Net Formulary Name Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Effective Date field value is Disabled")
	public boolean verifyEffectiveDateInputDisable() {
		boolean bln = false;
		if (txtEffectiveDateValue.getAttribute("disabled") != null) {
			OneframeLogger("Effective Date Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Stop Sale Date field value is Disabled")
	public boolean verifyStopSaleDateInputDisable() {
		boolean bln = false;
		if (txtStopSaleDateValue.getAttribute("disabled") != null) {
			OneframeLogger("Stop Sale Date Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Term Date field value is Disabled")
	public boolean verifyTermDateInputDisable() {
		boolean bln = false;
		if (txtTermDateValue.getAttribute("disabled") != null) {
			OneframeLogger("Term Date Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Client field value is Disabled")
	public boolean verifyClientInputDisable() {
		boolean bln = false;
		if (txtClientValue.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			OneframeLogger("Client Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify LOB field value is Disabled")
	public boolean verifyLOBInputDisable() {
		boolean bln = false;
		if (txtLOBValue.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			OneframeLogger("LOB Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify State field value is Disabled")
	public boolean verifyStateInputDisable() {
		boolean bln = false;
		if (txtStateValue.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			OneframeLogger("State Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Employer Group field value is Disabled")
	public boolean verifyEmployerGroupInputDisable() {
		boolean bln = false;
		if (txtEmployerGroupValue.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			OneframeLogger("Employer Group Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Managed By field value is Disabled")
	public boolean verifyManagedByInputDisable() {
		boolean bln = false;
		if (txtManagedByValue.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			OneframeLogger("Managed By Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Implementation Date field value is Disabled")
	public boolean verifyImplementationDateInputDisable() {
		boolean bln = false;
		if (txtImplementationDateValue.getAttribute("disabled") != null) {
			OneframeLogger("Implementation Date Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Formulary Link field value is Disabled")
	public boolean verifyFormularyLinkInputDisable() {
		boolean bln = false;
		if (txtFormularyLinkValue.getAttribute("disabled") != null) {
			OneframeLogger("Formulary Link Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Formulary Tag field value is Disabled")
	public boolean verifyFormularyTagInputDisable() {
		boolean bln = false;
		if (txtFormularyTag.getAttribute("disabled").contains("true")) {
			OneframeLogger("Formulary Tag Input field value is Disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Items count in Net Formulary Page")
	public boolean verifyCountofNetFormularyItems() throws InterruptedException {
		WaitForObjectVisibility(btnFormularyID);
		ClickWebObject(btnFormularyID);
		Thread.sleep(2000);
		int size = recordsCount.size();
		// OneframeLogger("Total Items in Net Formulary Page : "+size);
		if (size == 10)

		{

			OneframeLogger("Total Items in Net Formulary Page : " + size);
			return true;
		}
		return false;
	}

	@Step("Verify Previous Page Button is Disabled")
	public boolean verifyPreviousButtonisDisable() {
		if (btnPreviousPage.getAttribute("disabled").equalsIgnoreCase("true")) {
			OneframeLogger("Previous Page Button is disabled");
			return true;
		}
		return false;
	}

	@Step("Verify Second page button is clicked")
	public boolean verifyNextPageButton() {
		if (WaitForObjectVisibility(btnNextPage)) {
			ClickWebObject(btnNextPage);
			OneframeLogger("Second page button is clicked");
			return true;
		}
		return false;
	}

	@Step("Verify Previous Page Button is enabled")
	public boolean verifyPreviousPageButton() {
		if (WaitForObjectVisibility(btnPreviousPage)) {
			ClickWebObject(btnPreviousPage);
			OneframeLogger("Previous Page Button is enabled");
			return true;
		}
		return false;
	}

	@Step("Click on Drug Exceptions Button")
	public void clickDrugExceptionsButton() {
		try {
			if (WaitForObject(btnDrugException)) {
				ClickWebObject(btnDrugException);
				OneframeLogger("Clicked on Drug Exception Button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Drug Exception Button is not Clicked");
		}
	}

	@Step("Click on Create a Drug Exception List Button")
	public void clickCreateDrugExceptionButton() {
		try {
			if (WaitForObject(btnCreateDrugException)) {
				ClickWebObject(btnCreateDrugException);
				OneframeLogger("Clicked on Create a Drug Exception List Button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Create a Drug Exception List button is not Clicked");
		}
	}

	public boolean verifyStateText() {
		boolean bln = false;
		String State = "State";
		WaitForObjectVisibility(txtState);
		ScrollToElement(txtState);
		if (txtState.getText().equalsIgnoreCase(State)) {
			bln = true;
			highlightElement(txtState);
			OneframeLogger("State value is same as expected");
		}
		return bln;
	}

	public boolean verifyLOBText() {
		boolean bln = false;
		String LOB = "LOB";
		WaitForObjectVisibility(txtLob);
		ScrollToElement(txtLob);
		if (txtLob.getText().equalsIgnoreCase(LOB)) {
			bln = true;
			highlightElement(txtLob);
			OneframeLogger("LOB value is same as expected");
		}
		return bln;
	}

	public boolean verifyClientText() {
		boolean bln = false;
		String Client = "Client";
		WaitForObjectVisibility(txtClient);
		ScrollToElement(txtClient);
		if (txtClient.getText().equalsIgnoreCase(Client)) {
			bln = true;
			highlightElement(txtClient);
			OneframeLogger("Client value is same as expected");
		}
		return bln;
	}

	public boolean verifyTerminationDateText() {
		boolean bln = false;
		String TerminationDate = "Termination Date";
		WaitForObjectVisibility(txtTerminationDate);
		ScrollToElement(txtTerminationDate);
		if (txtTerminationDate.getText().equalsIgnoreCase(TerminationDate)) {
			bln = true;
			highlightElement(txtTerminationDate);
			OneframeLogger("Termination Date value is same as expected");
		}
		return bln;
	}

	public boolean verifyEffectiveDateText() {
		boolean bln = false;
		String EffectiveDate = "Effective Date";
		WaitForObjectVisibility(txtEffectiveDate);
		ScrollToElement(txtEffectiveDate);
		if (txtEffectiveDate.getText().equalsIgnoreCase(EffectiveDate)) {
			bln = true;
			highlightElement(txtEffectiveDate);
			OneframeLogger("Effective Date value is same as expected");
		}
		return bln;
	}

	public boolean verifyAdjSysStatusText() {
		boolean bln = false;
		String AdjSysStatus = "Adj. Sys Status";
		WaitForObjectVisibility(txtAdjSysStatus);
		ScrollToElement(txtAdjSysStatus);
		if (txtAdjSysStatus.getText().equalsIgnoreCase(AdjSysStatus)) {
			bln = true;
			highlightElement(txtAdjSysStatus);
			OneframeLogger("Adj. Sys Status value is same as expected");
		}
		return bln;
	}

	public boolean verifyManagedByText() {
		boolean bln = false;
		String ManagedBy = "Managed By";
		WaitForObjectVisibility(txtManagedBy);
		ScrollToElement(txtManagedBy);
		if (txtManagedBy.getText().equalsIgnoreCase(ManagedBy)) {
			bln = true;
			highlightElement(txtManagedBy);
			OneframeLogger("Managed By value is same as expected");
		}
		return bln;
	}

	public boolean verifyDrugListDescText() {
		boolean bln = false;
		String DrugListDescription = "Drug List Description";
		WaitForObjectVisibility(txtDrugListDescription);
		ScrollToElement(txtDrugListDescription);
		if (txtDrugListDescription.getText().equalsIgnoreCase(DrugListDescription)) {
			bln = true;
			highlightElement(txtDrugListDescription);
			OneframeLogger("Drug List Description value is same as expected");
		}
		return bln;
	}

	public boolean verifyDrugListNameText() {
		boolean bln = false;
		String DrugListName = "Drug List Name";
		WaitForObjectVisibility(txtDrugListName);
		ScrollToElement(txtDrugListName);
		if (txtDrugListName.getText().equalsIgnoreCase(DrugListName)) {
			bln = true;
			highlightElement(txtDrugListName);
			OneframeLogger("Drug List Name value is same as expected");
		}
		return bln;
	}

	public boolean verifyCVSCodeText() {
		boolean bln = false;
		String CVSCode = "CVS Code";
		WaitForObjectVisibility(txtCvsCode);
		ScrollToElement(txtCvsCode);
		if (txtCvsCode.getText().equalsIgnoreCase(CVSCode)) {
			bln = true;
			highlightElement(txtCvsCode);
			OneframeLogger("CVS Code value is same as expected");
		}
		return bln;
	}

	@Step("Verify 'List Data' header in Drug Exception Page")
	public boolean verifyListDataHeader() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrListData);
		try {
			if (hdrListData.isDisplayed()) {
				highlightElement(hdrListData);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	/*
	 * @Step("Click on Managed By Dropdown") public void clickManagedByDropdown() {
	 * try { if (WaitForObjectVisibility(drpDownManagedBy)) {
	 * ClickWebObject(drpDownManagedBy);
	 * OneframeLogger("Managed By Dropdown is clicked"); } } catch (TimeoutException
	 * e) { OneframeLogger("Managed By Dropdown is not clicked"); } }
	 */

	@Step("Verify Managed By drop down Values are displayed and IRx dropdown value is selected")
	public void verifyManagedByDropdownValues() {
		ClickWebObject(drpDownManagedBy);
		OneframeLogger("Managed By Dropdown is clicked");
		for (int i = 0; i < 3; i++) {
			if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("IRX")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "IRX", "Validated IRX dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("Client")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "Client", "Validated Client dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("CVS")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "CVS", "Validated CVS dropdown values");
			} else {
				OneframeLogger("Managed By dropdown values are not validated");
			}

		}
		lstdrpDownManagedBy.get(0).click();
		OneframeLogger("IRx dropdown value is selected");

	}

	@Step("Get the Tier Value for Net Formulary")
	public String getTierValue() {
		String tierValue = null;

		try {
			if (WaitForObjectVisibility(tierCount)) {
				tierValue = tierCount.getText().trim();
				OneframeLogger("Tier value is: " + tierValue);
			}
		} catch (Exception e) {
			OneframeLogger("Unable to get tier value: " + e);
		}

		return tierValue;
	}

	@Step("Click on Create a Drug Exception List Button")
	public void clickCreateADrugExceptionListButton() {
		try {
			if (WaitForObject(btnCreateDrugExceptionList)) {
				ClickWebObject(btnCreateDrugExceptionList);
				OneframeLogger("Clicked on Create a Drug Exception List Button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Create a Drug Exception List Button is not Clicked");
		}
	}

	@Step("Verify 'Create a Drug Exception List' header in Drug Exception Page")
	public boolean verifyCreateADrugExceptionListHeader() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrCreateADrugExceptionList);
		try {
			if (hdrCreateADrugExceptionList.isDisplayed()) {
				highlightElement(hdrCreateADrugExceptionList);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Drug Excepton Managed By drop down Values are displayed")
	public void verifyDrugExceptionManagedByDropdownValues() {
		ClickWebObject(drpDownDrugExceptionManagedBy);
		OneframeLogger("Managed By Dropdown is clicked");
		for (int i = 0; i < 3; i++) {
			if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("IRX")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "IRX", "Validated IRX dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("Client")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "Client", "Validated Client dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("CVS")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "CVS", "Validated CVS dropdown values");
			} else {
				OneframeLogger("Managed By dropdown values are not validated");
			}

		}

	}

	@Step("Verify Adj. Sys Status drop down Values are displayed")
	public void verifyAdjSysStatusDropdownValues() {
		ClickWebObject(drpdownAdjSysStatus);
		OneframeLogger("Adj. Sys Status Dropdown is clicked");
		for (int i = 0; i < 2; i++) {
			if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("Yes")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "Yes", "Validated Yes dropdown value");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("No")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "No", "Validated No dropdown value");

			} else {
				OneframeLogger("Adj. Sys Status dropdown values are not validated");
			}

		}

	}

	@Step("Click Add Drug Exception List button")
	public void clickAddDrugExceptionListbutton() {
		try {
			if (WaitForObject(btnAddDrugExceptionList)) {
				ClickWebObject(btnAddDrugExceptionList);
				OneframeLogger("Clicked on Add Drug Exception List button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Drug Exception List is not clicked");
		}
	}

	@Step("Get Random Number")
	public int getRandomNum() {
		int min = 00002;
		int max = 99999;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Enter CVS Code value in Drug Exception")
	public String enterTextCVSCode() {
		ObjectExist(createCVSCode);
		ClickWebObject(createCVSCode);

		String name = "AUTOIRX";
		int randomNumber = getRandomNum();
		String CVSCode = name + randomNumber;
		createCVSCode.sendKeys(CVSCode);
		OneframeLogger("The CVS Code is : " + createCVSCode.getAttribute("value"));
		return createCVSCode.getAttribute("value");

	}

	@Step("Enter Drug List Name value in Drug Exception")
	public String enterTextDrugListName() {
		ObjectExist(createDrugListName);
		ClickWebObject(createDrugListName);

		String name = "AUTOIRX";
		int randomNumber = getRandomNum();
		String CVSCode = name + randomNumber;
		createDrugListName.sendKeys(CVSCode);
		OneframeLogger("The Drug List Name is : " + createDrugListName.getAttribute("value"));
		return createDrugListName.getAttribute("value");

	}

	@Step("Enter Drug List Description in Drug Exception")
	public String enterTextDrugListDescription() {
		ObjectExist(createDrugListDescription);
		ClickWebObject(createDrugListDescription);

		String name = "AUTOIRX";
		int randomNumber = getRandomNum();
		String CVSCode = name + randomNumber;
		createDrugListDescription.sendKeys(CVSCode);
		OneframeLogger("The CVS Code is : " + createDrugListDescription.getAttribute("value"));
		return createDrugListDescription.getAttribute("value");

	}

	@Step("Verify Managed By drop down Values are displayed and CVS dropdown value is selected")
	public void selectCVSManagedBy() {
		// ClickWebObject(drpdownManagedBy);
		ClickWebObject(drpDownDrugExceptionManagedBy);
		OneframeLogger("Managed By Dropdown is clicked");
		for (int i = 0; i < 3; i++) {
			if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("IRX")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "IRX", "Validated IRX dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("Client")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "Client", "Validated Client dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("CVS")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "CVS", "Validated CVS dropdown values");
			} else {
				OneframeLogger("Managed By dropdown values are not validated");
			}

		}
		lstdrpDownManagedBy.get(2).click();
		OneframeLogger("CVS dropdown value is selected");

	}

	@Step("Verify Adj. Sys Status drop down Values are displayed and 'Yes' dropdown value is selected")
	public void SelectAdjSysStatusDropdown() {
		ClickWebObject(drpDownAdjSysStatusDrugException);
		OneframeLogger("Adj. Sys Status Dropdown is clicked");
		for (int i = 0; i < 2; i++) {
			if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("Yes")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "Yes", "Validated Yes dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("No")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "No", "Validated No dropdown values");

			} else {
				OneframeLogger("Adj. Sys Status dropdown values are not validated");
			}

		}
		lstdrpDownManagedBy.get(0).click();
		OneframeLogger("Adj. Sys Status dropdown value 'Yes' is selected");

	}

	@Step("Verify Adj. Sys Status drop down Values are displayed and 'Yes' dropdown value is selected")
	public void SelectAdjSysStatus() {
		ClickWebObject(drpdownAdjSysStatus);
		OneframeLogger("Adj. Sys Status Dropdown is clicked");
		for (int i = 0; i < 2; i++) {
			if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("Yes")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "Yes", "Validated Yes dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("No")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "No", "Validated No dropdown values");

			} else {
				OneframeLogger("Adj. Sys Status dropdown values are not validated");
			}

		}
		lstdrpDownManagedBy.get(0).click();
		OneframeLogger("Adj. Sys Status dropdown value 'Yes' is selected");

	}

	@Step("Verify Effective Date is edited in Drug Exception")
	public void EditEffectiveDate(String effectiveDate) {
		ObjectExist(enterEffDate);
		ClickWebObject(enterEffDate);
		while (!enterEffDate.getAttribute("value").equalsIgnoreCase("")) {
			enterEffDate.sendKeys(Keys.BACK_SPACE);
		}
		try {
			if (ObjectExist(enterEffDate)) {
				enterEffDate.sendKeys(Keys.CONTROL + "a");
				enterEffDate.sendKeys(Keys.DELETE);
				enterEffDate.sendKeys(effectiveDate);
				OneframeLogger("Effective Date is updated and the value is " + effectiveDate);
			} else {
				OneframeLogger("Effective Date is not updated");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Verify Termination Date is edited in Drug Exception")
	public void EditTermDate(String termDate) {
		ObjectExist(enterTermDate);
		ClickWebObject(enterTermDate);
		while (!enterTermDate.getAttribute("value").equalsIgnoreCase("")) {
			enterTermDate.sendKeys(Keys.BACK_SPACE);
		}
		try {
			if (ObjectExist(enterTermDate)) {
				enterTermDate.sendKeys(Keys.CONTROL + "a");
				enterTermDate.sendKeys(Keys.DELETE);
				enterTermDate.sendKeys(termDate);
				OneframeLogger("Termination Date is updated and the value is " + termDate);
			} else {
				OneframeLogger("Termination Date is not updated");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Click on first Drug Exception Formulary")
	public void clickonFirstDrugExceptionFormulary() {
		try {
			ClickWebObject(hdrFormularies);
			ClickWebObject(hdrFormularies);
			WaitForObjectVisibility(btnDrugListID);
			ClickWebObject(btnDrugListID);
			if (WaitForObject(lstNetFormularies.get(0))) {
				ClickWebObject(lstNetFormularies.get(0));
				OneframeLogger("Clicked on First Drug Exception Formulary");
			}
		} catch (TimeoutException e) {
			OneframeLogger("First Drug Exception Formulary is not Clicked");
		}
	}

	@Step("Verify Audit button is displayed")
	public boolean verifyAuditButton() {
		boolean flag = false;
		if (WaitForObjectVisibility(btnAudit)) {
			if (btnAudit.getText().equalsIgnoreCase("audit")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Edit and Get CVS Code value in Drug Exception")
	public String editAndGetTextCVSCode() {
		ObjectExist(enterTxtCVScode);
		ClickWebObject(enterTxtCVScode);
		while (!enterTxtCVScode.getAttribute("value").equalsIgnoreCase("")) {
			enterTxtCVScode.sendKeys(Keys.BACK_SPACE);
		}
		String name = "AUTOIRX";
		int randomNumber = getRandomNum();
		String CVSCode = name + randomNumber;
		enterTxtCVScode.sendKeys(CVSCode);
		OneframeLogger("The CVS Code is : " + enterTxtCVScode.getAttribute("value"));
		return enterTxtCVScode.getAttribute("value");

	}

	@Step("Edit and Get Drug list Name in Drug Exception")
	public String editAndGetTextDrugList() {
		ObjectExist(enterTxtDruglistName);
		ClickWebObject(enterTxtDruglistName);
		while (!enterTxtDruglistName.getAttribute("value").equalsIgnoreCase("")) {
			enterTxtDruglistName.sendKeys(Keys.BACK_SPACE);
		}
		String name = "AUTOIRX";
		int randomNumber = getRandomNum();
		String Druglist = name + randomNumber;
		enterTxtDruglistName.sendKeys(Druglist);
		OneframeLogger("The Drug List is : " + enterTxtDruglistName.getAttribute("value"));
		return enterTxtDruglistName.getAttribute("value");
	}

	@Step("Edit and Get Description in Drug Exception")
	public String editAndGetTextDescriptiont() {
		ObjectExist(enterTxtDescription);
		ClickWebObject(enterTxtDescription);
		while (!enterTxtDescription.getAttribute("value").equalsIgnoreCase("")) {
			enterTxtDescription.sendKeys(Keys.BACK_SPACE);
		}
		String name = "AUTOIRX";
		int randomNumber = getRandomNum();
		String Description = name + randomNumber;
		enterTxtDescription.sendKeys(Description);
		OneframeLogger("The Description is : " + enterTxtDescription.getAttribute("value"));
		return enterTxtDescription.getAttribute("value");
	}

	@Step("Verify Managed By drop down Values are displayed and CVS dropdown value is selected")
	public void SelectCVSManagedByDropdown() {
		ClickWebObject(drpDownManagedByDrugException);
		OneframeLogger("Managed By Dropdown is clicked");
		for (int i = 0; i < 3; i++) {
			if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("IRX")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "IRX", "Validated IRX dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("Client")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "Client", "Validated Client dropdown values");
			} else if (lstdrpDownManagedBy.get(i).getText().equalsIgnoreCase("CVS")) {
				sa.assertEquals(lstdrpDownManagedBy.get(i).getText(), "CVS", "Validated CVS dropdown values");
			} else {
				OneframeLogger("Managed By dropdown values are not validated");
			}

		}
		lstdrpDownManagedBy.get(2).click();
		OneframeLogger("CVS dropdown value is selected");

	}

	@Step("Click Save Changes button of Edit Drug Exception List Formularies")
	public void clickSaveChangesButton() {
		try {
			if (WaitForObject(btnSaveChanges)) {
				ClickWebObject(btnSaveChanges);

				OneframeLogger("Clicked on Save Changes button of Edit Drug Exception Formularies");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Save Changes button of Edit Drug Exception Formularies is not Clicked");
		}
	}

	@Step("Verify CVS code value is same as expected")
	public void verifyCVSCodeValue(String cvsCode) {
		WaitForObjectVisibility(enterTxtCVScode);
		if (enterTxtCVScode.getAttribute("value").equalsIgnoreCase(cvsCode)) {
			// getText().equalsIgnoreCase(cvsCode)) {
			sa.assertEquals(enterTxtCVScode.getAttribute("value"), cvsCode,
					"Verified CVS code value is same as expected");
		}
	}

	@Step("Verify Drug List value is same as expected")
	public void verifyDrugListValue(String drugList) {
		WaitForObjectVisibility(enterTxtDruglistName);
		if (enterTxtDruglistName.getAttribute("value").equalsIgnoreCase(drugList)) {
			sa.assertEquals(enterTxtDruglistName.getAttribute("value"), drugList,
					"Verified Drug list value is same as expected");
		}
	}

	@Step("Verify Description value is same as expected")
	public void verifyDescriptionValue(String description) {
		WaitForObjectVisibility(enterTxtDescription);
		if (enterTxtDescription.getAttribute("value").equalsIgnoreCase(description)) {
			sa.assertEquals(enterTxtDescription.getAttribute("value"), description,
					"Verified Description value is same as expected");
		}
	}

	@Step("Verify Effective Date  is same as expected")
	public void verifyEffectiveDate(String effectiveDate) {
		WaitForObjectVisibility(enterEffDate);
		if (enterEffDate.getAttribute("value").equalsIgnoreCase(effectiveDate)) {
			sa.assertEquals(enterEffDate.getAttribute("value"), effectiveDate,
					"Verified Effective date is same as expected");
		}
	}

	@Step("Verify Term Date is same as expected")
	public void verifyTerminationDate(String termDate) {
		WaitForObjectVisibility(enterTermDate);
		if (enterTermDate.getAttribute("value").equalsIgnoreCase(termDate)) {
			sa.assertEquals(enterTermDate.getAttribute("value"), termDate,
					"Verified Termination date is same as expected");
		}
	}

	@Step("Click Down Arrow button of Drug Exception List Formularies")
	public void clickDownArrowButton() {
		try {
			if (WaitForObject(btnDownArrow)) {
				ClickWebObject(btnDownArrow);

				OneframeLogger("Clicked on Down Arrow button of Edit Drug Exception Formularies");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Down Arrow button of Edit Drug Exception Formularies is not Clicked");
		}
	}

	@Step("Verify Save Changes button is displayed")
	public boolean verifySaveChangesButton() {
		boolean flag = false;

		if (WaitForObjectVisibility(btnSaveChanges)) {
			if (btnSaveChanges.getText().equalsIgnoreCase("Save Changes")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Clear Text in CVS Code Field")
	public String clearCVSCodeText() {
		ObjectExist(enterTxtCVScode);
		ClickWebObject(enterTxtCVScode);
		while (!enterTxtCVScode.getAttribute("value").equalsIgnoreCase("")) {
			enterTxtCVScode.sendKeys(Keys.BACK_SPACE);
		}

		OneframeLogger("CVS Code is Cleared");
		return enterTxtCVScode.getAttribute("value");
	}

	@Step("Verify CVS Code Field is highlighted in red colour")
	public boolean verifyHilightedCVSCodeColour() throws InterruptedException {
		Thread.sleep(3000);
		return verifyMandatoryFieldColour(enterTxtCVScode);
	}

	@Step("Verify CVS Code Field is highlighted in red colour")
	public boolean verifyHilightedDrugListNameColour() {
		return verifyMandatoryFieldColour(enterTxtDruglistName);
	}

	@Step("Verify Effective Date Field is highlighted in red colour")
	public boolean verifyHilightedEffectiveDateColour() {
		return verifyMandatoryFieldColour(enterEffDate);
	}

	public boolean verifyMandatoryFieldColour(WebElement element) {
		if (ObjectExist(element)) {
			ClickWebObject(hdrDrugExceptionlist);
			ClickWebObject(hdrDrugExceptionlist);
			ClickWebObject(hdrDrugExceptionlist);
			String actualColor = element.getCssValue("caret-color");
			highlightElement(element);
			if (actualColor.contains("rgb(218, 41, 28)")) {
				OneframeLogger(element.getAttribute("data-automation-id") + " Field is highlighted in red color: "
						+ element.getCssValue("caret-color"));
				return true;
			}
		} else {
			OneframeLogger(element.getText() + " Field is not highlighted in red color");
			return false;
		}
		return false;
	}

	@Step("Clear Text in Drug List Name Field")
	public String clearDrugListText() {
		ObjectExist(enterTxtDruglistName);
		ClickWebObject(enterTxtDruglistName);
		while (!enterTxtDruglistName.getAttribute("value").equalsIgnoreCase("")) {
			enterTxtDruglistName.sendKeys(Keys.BACK_SPACE);
		}

		OneframeLogger("Drug list Name Date Field is Cleared");
		return enterTxtDruglistName.getAttribute("value");
	}

	@Step("Clear date in Effective Date Field")
	public void clearEffectiveDate() {
		ObjectExist(enterEffDate);
		ClickWebObject(enterEffDate);
		while (!enterEffDate.getAttribute("value").equalsIgnoreCase("")) {
			enterEffDate.sendKeys(Keys.BACK_SPACE);
		}
		verifyMandatoryFieldColour(enterEffDate);
		OneframeLogger("Effective Date is Cleared");

	}

	@Step("Click Cancel button of Edit Drug Exception Formularies")
	public void clickCancelButtonofEditDrugExceptionFormularies() {
		try {
			if (WaitForObject(btnDrugExceptionCancel)) {
				ClickWebObject(btnDrugExceptionCancel);
				OneframeLogger("Clicked on Cancel button of Edit Drug Exception Formularies");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cancel button of Edit Drug Exception Formularies is not Clicked");
		}
	}

	@Step("Verify Leave without saving? Header is displayed")
	public boolean verifyLeaveWitoutSavingHdr() {
		boolean flag = false;
		if (WaitForObjectVisibility(hdrLeaveWithoutSaving)) {
			if (hdrLeaveWithoutSaving.getText().equalsIgnoreCase("Leave without Saving?")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify You have made changes to message is displayed")
	public boolean verifyYouHaveMadeChangesMsg() {
		boolean flag = false;
		if (WaitForObjectVisibility(txtPopupMsg)) {
			if (txtPopupMsg.getText().contains("You've made changes to ")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click Leave button of Edit Drug Exception Formularies")
	public void clickLeaveButtonofEditDrugExceptionFormularies() {
		try {
			if (WaitForObject(btnLeave)) {
				ClickWebObject(btnLeave);
				OneframeLogger("Clicked on Leave button of Edit Drug Exception Formularies");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Leave button of Edit Drug Exception Formularies is not Clicked");
		}
	}

	@Step("Verify {drugExceptionList} labels is displayed")
	public void verifyDrugExceptionListlabelsAreDisplayed(String drugExceptionList) {
		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()=\"%s\"]", drugExceptionList)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to see base Drug Exception List labels");
		}
		sa.assertEquals(expectedHeader.getText(), drugExceptionList, "Validated Label is : " + drugExceptionList);
	}

	@Step("Verify {drugExceptionList} fields are displayed")
	public void verifyDrugExceptionListFieldsisDisplayed(String drugExceptionList) {
		switch (drugExceptionList) {

		case "Drug List ID":
			if (txtDruglistID.isDisplayed()) {
				highlightElement(txtDruglistID);
				sa.assertTrue(true, "Verified CVS code Field is displayed");
			}
			break;
		case "CVS Code":
			if (txtCvsCodeValue.isDisplayed()) {
				highlightElement(txtCvsCodeValue);
				sa.assertTrue(true, "Verified CVS code Field is displayed");
			}
			break;

		case "Drug List Name":
			if (txtDruglistNameValue.isDisplayed()) {
				highlightElement(txtDruglistNameValue);
				sa.assertTrue(true, "Verified Drug List Name Field is displayed");
			}
			break;
		case "Description":
			if (txtDescriptionValue.isDisplayed()) {
				highlightElement(txtDescriptionValue);
				sa.assertTrue(true, "Verified Description Field is displayed");
			}
			break;

		case "Managed By":
			if (txtManagedByField.isDisplayed()) {
				highlightElement(txtManagedByField);
				sa.assertTrue(true, "Verified Managed By Field is displayed");
			}
			break;

		case "Adj. Sys Status":
			if (txtAdjStatusField.isDisplayed()) {
				highlightElement(txtAdjStatusField);
				sa.assertTrue(true, "Verified Adj Sys Status Field is displayed");
			}
			break;

		case "Effective Date":
			if (txtEffDateValue.isDisplayed()) {
				highlightElement(txtEffDateValue);
				sa.assertTrue(true, "Verified Effective Date Field is displayed");
			}
			break;

		case "Termination Date":
			if (txtTermDateField.isDisplayed()) {
				highlightElement(txtTermDateField);
				sa.assertTrue(true, "Verified Term Date Field is displayed");
			}
			break;

		case "Client":
			if (txtClientField.isDisplayed()) {
				highlightElement(txtClientField);
				sa.assertTrue(true, "Verified Client Field is displayed");
			}
			break;
		case "LOB":
			if (txtLOBField.isDisplayed()) {
				highlightElement(txtLOBField);
				sa.assertTrue(true, "Verified LOB Field is displayed");
			}
			break;
		case "State":
			if (txtStateField.isDisplayed()) {
				highlightElement(txtStateField);
				sa.assertTrue(true, "Verified State Field is displayed");
			}
			break;

		default:
			OneframeLogger(drugExceptionList + " Drug Exception List fields are not displayed");

		}
	}

	@Step("Page Reload")
	public boolean reloadPage() {
		try {
			oneframeDriver.navigate().refresh();
			WaitForApplicationToLoadCompletely();
			Thread.sleep(5000);
			OneframeLogger("Page reloaded");
			return true;
		} catch (Exception e) {
			OneframeLogger("Unable to reload the page: " + e);
		}
		return false;
	}
	
	@Step("Validate POS DUR is pulled")
	public boolean checkPosDurName(String expectedPosDur) {
		boolean flg = false;
		String actualPosDurName = null;
		try {
			if(WaitForObjectVisibility(posDurName)) {
				highlightElement(posDurName);
				actualPosDurName = posDurName.getText().trim();
				OneframeLogger("Expected Pos DUR: " +expectedPosDur);
				OneframeLogger("Actual Pos DUR: " +actualPosDurName);
				if(actualPosDurName.equals(expectedPosDur)) {
					flg = true;
				}
				else {
					flg = false;
				}
			}
			else {
				OneframeLogger("Expected Pos DUR: " +expectedPosDur);
				OneframeLogger("Actual Pos DUR: " +actualPosDurName);
				flg = false;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to check pos dur name: " +e);
			flg = false;
		}
		
		return flg;
	}

	@Step("Click on Eye Icon")
	public void clickEyeIcon() {
		try {
			if(WaitForObjectVisibility(eyeIcon)) {
				ClickWebObject(eyeIcon);
				OneframeLogger("Clicked on Eye Icon");
				WaitForObjectVisibility(hdrDetails);
				ClickWebObject(hdrDetails);
				ClickWebObject(hdrDetails);
				ClickWebObject(hdrDetails);
			}
			else {
				OneframeLogger("Eye Icon is not visible");
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on eye icon: " +e);
		}
		
		sa.assertAll();
	}
	
	public void verifyElement(String xpath, String header, String expectedValue) {
		
			WebElement ele = FindObjectByLocatorNoWait(By.xpath(xpath));
			String actualValue = null;
			
			if(xpath.contains("input")) {
				actualValue = ele.getAttribute("value").trim();
			}
			else {
				highlightElement(ele);
				actualValue = ele.getText().trim();
			}
			
			OneframeLogger("Expected Value under header "+header+": " +expectedValue);
			OneframeLogger("Actual Value under header "+header+": " +actualValue);
			if(expectedValue.equals(actualValue)) {
				sa.assertTrue(true, "Expected value is displayed");
			}
			else {
				sa.assertTrue(false, "Expected value is not displayed");
			}
		
		
		sa.assertAll();
	}

	@Step("Verify {expectedValue} is displayed under header {header}")
	public void verifyValueUnderHeader(String header, String expectedValue) {
		String xpath = "//mat-label[normalize-space()='"+header+"']/../../..//span[text()]";
		WaitForApplicationToLoadCompletely();

		try {
			verifyElement(xpath, header, expectedValue);
		} 
		catch(JavascriptException | NoSuchElementException e) {
			xpath = "//mat-label[normalize-space()='"+header+"']/../../..//input";
			verifyElement(xpath, header, expectedValue);
		}
		catch (Exception e) {		
			OneframeLogger("Unable to verify value under header "+header);
			OneframeLogger(e.toString());
			sa.assertFalse(true, "Expected value is not displayed");
		}
		
		sa.assertAll();
	}

}

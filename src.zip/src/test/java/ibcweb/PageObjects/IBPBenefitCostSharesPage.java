package ibcweb.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import io.qameta.allure.Step;

public class IBPBenefitCostSharesPage extends OneframeContainer {

	@FindBy(xpath="//div[text()=' Cost Shares ']")
	WebElement tabCostShares;

	@FindBy(xpath="//div[text()='COB']")
	WebElement subtabCOB;

	@FindBy(xpath="//mat-label[text()='Choose a COB package ']")
	WebElement hdrCoBPackageField;

	@FindBy(xpath="//mat-label[text()='Choose a COB processing method']")
	WebElement hdrCOBProcessingMethodField;
	
	@FindBy(xpath="//mat-select[@data-automation-id='costShareCobPackage']")
	WebElement CoBPackageField;

	@FindBy(xpath="//mat-select[@data-automation-id='costShareCobProcessingMethod']")
	WebElement COBProcessingMethodField;

	@FindBy(xpath = "//mat-select[@data-automation-id='costShareCobPackage']//span")
	WebElement COBPackageValue;
	
	@FindBy(xpath = "//mat-select[@data-automation-id='costShareCobProcessingMethod']//span")
	WebElement COBPackageProcessingValue;
	
	@FindBy(xpath="//h3[text()='Cost Shares']")
	WebElement hdrCostShares;

	@FindBy(xpath="//div[text()='DAW']")
	WebElement subtabDAW;

	@FindBy(xpath="//span[text()='NO DAW']")
	WebElement valueNoDaw;

	@FindBy(xpath="//mat-label[text()='Choose a DAW package']")
	WebElement hdrChooseADAWPackage;
	
	@FindBy(xpath="//div[@class='header-text']")
	WebElement hdrCobPackageName;
	
	@FindBy(xpath = "//td[@data-automation-id='costShareCobPackageDetailsNameValue']")
	List<WebElement> lblCob2To8;
	
	@FindBy(xpath = "//mat-select[@data-automation-id='costShareCobPackage']//span/span")
	WebElement txtDefaultDawPackage;

	@FindBy(xpath="//mat-expansion-panel-header[contains(@id,'mat-expansion-panel-header-')]")
    List<WebElement> btnDAW;
	
	@FindBy(xpath="//mat-slide-toggle[@formcontrolname='retailApplies']//input[@type='checkbox' and @aria-checked='true']")
	List<WebElement> tglRetailApplies;
	
	@FindBy(xpath="//mat-slide-toggle[@formcontrolname='homeDeliveryApplies']//input[@type='checkbox' and @aria-checked='true']")
	List<WebElement> tglHomeDeliveryApplies;
	
	@FindBy(xpath="//input[@formcontrolname='retailMax']")
	List<WebElement> txtRetailMax;
	
	@FindBy(xpath="//input[@formcontrolname='homeDeliveryMax']")	
	List<WebElement> txtHomeDeliveryMax;
	
	@FindBy(xpath = "//mat-list-option[@data-automation-id='costSharesNetworksList']/div/div[text()]")
	List<WebElement> networkList;
	
	@FindBy(xpath = "//table[@data-automation-id='costSharesMainTable']/thead/tr")
	List<WebElement> costShareMainTableHeadings;

	@FindBy(xpath = "//input[@formcontrolname='copay']")
	List<WebElement> copayInputBoxes;
	
	@FindBy(xpath = "//input[@formcontrolname='coInsurance']")
	List<WebElement> coInsuranceInputBoxes;
	
	@FindBy(xpath = "//input[@formcontrolname='min']")
	List<WebElement> minInputBoxes;
	
	@FindBy(xpath = "//input[@formcontrolname='max']")
	List<WebElement> maxInputBoxes;
	
	@FindBy(xpath = "")
	WebElement retailTable;

	//	Initializing the Page Objects:
	public IBPBenefitCostSharesPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on Costshares Tab")
	public boolean clickCostSharesTab() {
		boolean flg = false;
		try {
			if(WaitForObjectVisibility(tabCostShares)) {
				ClickWebObject(tabCostShares);
				OneframeLogger("Clicked on Cost Shares Tab");
				flg = true;
			}
		}catch(NoSuchElementException NSE) {
			OneframeLogger("Cost Shares Tab is not clicked");
		}
		return flg;
	}

	@Step("Click on COB SubTab")
	public void clickCOBSubTab() {
		try {
			if(WaitForObjectVisibility(subtabCOB)) {
				ClickWebObject(subtabCOB);
				OneframeLogger("Clicked on COB Sub Tab");
			}
		}catch(NoSuchElementException NSE) {
			OneframeLogger("CoB Sub Tab is not clicked");
		}
	}

	@Step("Click on Costshares header")
	public void clickCostSharesheader() {
		ClickWebObject(hdrCostShares);
		ClickWebObject(hdrCostShares);
		ClickWebObject(hdrCostShares);
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(overlayElement);
	}

	@Step("Select COB Package Dropdown")
	public boolean selectCobPackageDropdown(String cobPackage) {
		boolean blnRC = false;
		try {
			if(WaitForObjectVisibility(CoBPackageField))
				ClickWebObject(CoBPackageField);
			selectDropdownValue(cobPackage);
			Thread.sleep(2000);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
			blnRC = true;
		}catch (NoSuchElementException | AWTException | InterruptedException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select COB Processing Method Dropdown")
	public boolean selectCobProcessingMethodDropdown(String cobMethod) {
		boolean blnRC = false;
		try {
			if(WaitForObjectVisibility(COBProcessingMethodField))
				ClickWebObject(COBProcessingMethodField);
			selectDropdownValue(cobMethod);
			Thread.sleep(2000);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
			blnRC = true;
		}catch (NoSuchElementException | AWTException | InterruptedException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Existing COB Package value displayed in COB Package Dropdown")
	public boolean verifyCOBPackageValue(String cobPackage) {
		boolean blnRC = false;
		WebElement element = oneframeDriver.findElement(By.xpath("//mat-select[@data-automation-id='costShareCobPackage']/div/div/span"));
		String Actual =element.getText();
		try {
			if(WaitForObjectVisibility(element)) {
				highlightElement(element);
				if(Actual.equalsIgnoreCase(cobPackage)) {
					OneframeLogger("The Actual COB Package matched with "+cobPackage+" Expected COB Package "+Actual);
					blnRC = true;
				}
			}			
		}catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;		
	}

	@Step("Verify Existing COB Processing Method value displayed in COB Processing Method Dropdown")
	public boolean verifyCOBProcessingMethodValue(String cobMethod) {
		boolean blnRC = false;
		WebElement element = oneframeDriver.findElement(By.xpath("//mat-select[@data-automation-id='costShareCobProcessingMethod']/div/div/span"));
		String Actual =element.getText();
		try {
			if(WaitForObjectVisibility(element)) {
				highlightElement(element);
				if(Actual.equalsIgnoreCase(cobMethod)) {
					OneframeLogger("The Actual COB Processing Method matched with "+cobMethod+" Expected COB Processing Method "+Actual);
					blnRC = true;
				}
			}			
		}catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;		
	}


	@Step("Click on DAW SubTab")
	public void clickDAWSubTab() {
		try {
			if(WaitForObjectVisibility(subtabDAW)) {
				highlightElement(subtabDAW);
				ClickWebObject(subtabDAW);
				OneframeLogger("Clicked on DAW Sub Tab");
			}
		}catch(NoSuchElementException NSE) {
			OneframeLogger("DAW Sub Tab is not clicked");
		}
	}

	@Step("Verify Choose a DAW Package header is displayed")
	public boolean verifyChooseaDAWPackageHeaderIsDisplayed() {
		boolean flg = false;

		if(WaitForObjectVisibility(hdrChooseADAWPackage)) {
			highlightElement(hdrChooseADAWPackage);
			flg = true;
		}
		else {
			flg = false;
		}
		return flg;
	}

	@Step("Verify value of Choose No DAW Package")
	public boolean verifyNoDaw() {
		boolean flg = false;
		String expectedText = "NO DAW";
		
		if(WaitForObjectVisibility(valueNoDaw)) {
			highlightElement(valueNoDaw);
			String actualText = valueNoDaw.getText();
			if(expectedText.equalsIgnoreCase(actualText)) {
				OneframeLogger("Choose No DAW Package is displayed as: " +actualText);
				flg = true;
			}
			else {
				OneframeLogger("Choose No DAW Package is displayed as: " +actualText);
				flg = false;
			}
		}
		return flg;
	}
	
	@Step("Verify Choose a COB Package header is displayed")
	public boolean verifyChooseaCobPackageHeaderIsDisplayed() {
		boolean flg = false;

		if(WaitForObjectVisibility(hdrCoBPackageField)) {
			highlightElement(hdrCoBPackageField);
			flg = true;
		}
		else {
			flg = false;
		}
		return flg;
	}

	@Step("Verify Choose a COB Package Processing method header is displayed")
	public boolean verifyChooseaCobProcessingHeaderIsDisplayed() {
		boolean flg = false;

		if(WaitForObjectVisibility(hdrCOBProcessingMethodField)) {
			highlightElement(hdrCOBProcessingMethodField);
			flg = true;
		}
		else {
			flg = false;
		}
		return flg;
	}
	
	@Step("Verify value of Create a COB Package")
	public boolean verifyCobPackageValue() {
		boolean flg = false;
		
		if(WaitForObjectVisibility(COBPackageValue)) {
			highlightElement(COBPackageValue);
			String actualText = COBPackageValue.getText();
			if(!actualText.equalsIgnoreCase("Not Applicable")) {
				OneframeLogger("Create a COB Package value is displayed as: " +actualText);
				flg = true;
			}
			else {
				OneframeLogger("Create a COB Package value is displayed as: " +actualText);
				flg = false;
			}
		}
		return flg;
	}
	
	@Step("Verify value of Cob processing method")
	public boolean verifyCobProcessingMethodValue() {
		boolean flg = false;
		
		if(WaitForObjectVisibility(COBPackageProcessingValue)) {
			highlightElement(COBPackageProcessingValue);
			String actualText = COBPackageProcessingValue.getText();
			if(!actualText.equalsIgnoreCase("Not Applicable")) {
				OneframeLogger("Create a COB Package value is displayed as: " +actualText);
				flg = true;
			}
			else {
				OneframeLogger("Create a COB Package value is displayed as: " +actualText);
				flg = false;
			}
		}
		return flg;
	}
	
	@Step("Verify COB Package name header is displayed")
	public boolean verifyCobPackageNameHeaderIsDisplayed() {
		boolean flg = false;

		if(WaitForObjectVisibility(hdrCobPackageName)) {
			highlightElement(hdrCobPackageName);
			flg = true;
		}
		else {
			flg = false;
		}
		return flg;
	}
	
	@Step("Verify COB 2 to 8 labels are displayed")
	public boolean verifyCob2to8LabelsAreDisplayed() {
		boolean flg = false;

		for(int i=2; i<9; i++) {
			highlightElement(lblCob2To8.get(i-2));
			String actualText = lblCob2To8.get(i-2).getText().trim();
			String expectedText = "COB " + i;
			if(expectedText.equalsIgnoreCase(actualText)) {
				OneframeLogger("COB label is displayed as: " +actualText);
				flg = true;
			}
			else {
				return false;
			}
		}
		
		return flg;
	}
	
	@Step("Verify Default Daw Package 'NO DAW' is displayed")
	public boolean verifyDefaultDawPackageIsDisplayed(String expectedtext) {
		boolean flg = false;

		if(WaitForObjectVisibility(txtDefaultDawPackage)) {
			highlightElement(txtDefaultDawPackage);
			if(txtDefaultDawPackage.getText().trim().equalsIgnoreCase(expectedtext))
			{
				flg = true;
			}
			
		}
		else {
			flg = false;
		}
		return flg;
	}

@Step("Click on DAW2 SubTab")
	public void clickDAW2SubTab() {
		ScrollToBottomOfthePage();
		try {
			if(WaitForObjectVisibility(btnDAW.get(2))) {
				highlightElement(btnDAW.get(2));
				ClickWebObject(btnDAW.get(2));
				OneframeLogger("Clicked on DAW2");
			}
		}catch(NoSuchElementException NSE) {
			OneframeLogger("DAW2 Tab is not clicked");
		}
	}
	
	@Step("Verify Retail Toggle is enabled in hidden mode displayed")
	public boolean verifyRetailToggleEnabledHddenDisplayed() {
		ScrollToBottomOfthePage();
		boolean flg = false;
		if(WaitForObjectVisibility(tglRetailApplies.get(1))) {
			highlightElement(tglRetailApplies.get(1));
				flg = true;			
		}else {
			flg = false;
		}
		return flg;
	}
	
	@Step("Verify Retail Max Text is enabled in hidden mode displayed")
	public boolean verifyRetailMaxTextHiddenDisplayed() {
		boolean flg = false;
		if(WaitForObjectVisibility(txtRetailMax.get(2))) {
			highlightElement(txtRetailMax.get(2));
				flg = true;			
		}else {
			flg = false;
		}
		return flg;
	}
	
	@Step("Verify Home Delivery Toggle is enabled in hidden mode displayed")
	public boolean verifyHomeDeliveryToggleEnabledHddenDisplayed() {
		ScrollToBottomOfthePage();
		boolean flg = false;
		if(WaitForObjectVisibility(tglHomeDeliveryApplies.get(1))) {
			highlightElement(tglHomeDeliveryApplies.get(1));
				flg = true;			
		}else {
			flg = false;
		}
		return flg;
	}
	
	@Step("Verify Home Delivery Max Text is enabled in hidden mode displayed")
	public boolean verifyHomeDeliveryMaxTextHiddenDisplayed() {
		boolean flg = false;
		if(WaitForObjectVisibility(txtRetailMax.get(2))) {
			highlightElement(txtRetailMax.get(2));
				flg = true;			
		}else {
			flg = false;
		}
		return flg;
	}
	
	@Step("Select First Value from COB Package dropdown")
	public boolean selectFirstvaluefromCobPackageDropdown() throws Throwable {
		boolean blnRC = false;
		String values = "";
		
		try {
			if (WaitForObjectVisibility(CoBPackageField))
				ClickWebObject(CoBPackageField);
			   List<WebElement> drdvalues = oneframeDriver
					.findElements(By.xpath("//mat-option[@role='option']/span[@class='mat-option-text']"));
			    OneframeLogger("The Size is " +drdvalues.size());
				WaitForObjectVisibility(drdvalues.get(0));
				values = drdvalues.get(0).getText();
				ClickWebObject(drdvalues.get(0));
				OneframeLogger("The Selected Dropdown value is " + values);
				blnRC = true;
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}


	@Step("Select First Value from COB Processing Method dropdown")
	public boolean selectFirstvaluefromCobProcessingMethodDropdown() throws Throwable {
		boolean blnRC = false;
		String values = "";
		try {
			if (WaitForObjectVisibility(COBProcessingMethodField))
				ClickWebObject(COBProcessingMethodField);
				List<WebElement> drdvalues = oneframeDriver
					.findElements(By.xpath("//mat-option[@role='option']/span[@class='mat-option-text']"));
				WaitForObjectVisibility(drdvalues.get(0));
				values = drdvalues.get(0).getText();
				ClickWebObject(drdvalues.get(0));
				OneframeLogger("The Selected Dropdown value is " + values);
				blnRC = true;
		} catch (TimeoutException SEF) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Network List is empty in Cost Shares tab")
	public boolean verifyNetworkListIsEmpty() {
		boolean flg = false;
		
		try {
			if(WaitForObjectVisibility(networkList.get(0))) {
				flg = true;
				OneframeLogger("Network list is not empty in cost shares tab");
			}
		} catch (Exception e) {
			flg = false;
			OneframeLogger("Network List is empty in cost shares tab");
		}
		
		return flg;
	}

	@Step("Verify only Retail table is displayed for all checked Networks")
	public boolean verifyCheckNetworksHasRetailColumn(List<String> networks) {
		boolean flg = false;
		
		try {
			WaitForApplicationToLoadCompletely();
			
			for(WebElement ele: networkList) {
				ClickWebObject(ele);
				
				if(costShareMainTableHeadings.size() == 1) {
					WebElement retailHdr = costShareMainTableHeadings.get(0).findElement(By.xpath("./child::th"));
					if(retailHdr.getText().equalsIgnoreCase("retail")) {
						OneframeLogger("Only Retail table is displayed for network "+ele.getText());
						flg = true;
					}
					
				} 
				else {
					OneframeLogger("Other tables are also displayed along with Retail table");
					flg = false;
				}
			}
			
		} catch (Exception e) {
			OneframeLogger("Error verifying retail table under cost shares tab: " +e);
		}
		
		return flg;
	}
	
	@Step("Verify {table} is displayed for {networks}")
	public boolean verifyGivenTableIsDisplayed(List<String> networks, String table) {
		boolean flg = false;
		String tableName = table.substring(0, 1).toUpperCase() + table.substring(1);
		
		try {
			WaitForApplicationToLoadCompletely();
				for(WebElement ele: networkList) {
					if(ele.getText().equalsIgnoreCase("Out of network") && table.equalsIgnoreCase("home delivery")) {
						continue;
					}
					
					ClickWebObject(ele);
					String xpath = "//tr/th[normalize-space()='"+ tableName +"']";
					WebElement header = oneframeDriver.findElement(By.xpath(xpath));
					
					if(header.getText().equalsIgnoreCase(table)) {
						highlightElement(header);
						OneframeLogger(tableName + " table is displayed for network "+ele.getText());
						flg = true;
					}
					else {
						return false;
					}
						
				}	
			
		} catch (Exception e) {
			OneframeLogger("Error verifying "+ tableName +" table name under cost shares tab: " +e);
		}
		
		return flg;
	}

	
	@Step("Validate Copay Fields are hilighted in Red Color")
	public boolean verifyCopayFieldsAreHilightedInRed() {
		
		if(copayInputBoxes.size() > 0) {
			for(WebElement ele: copayInputBoxes) {
				if(!ele.getCssValue("caret-color").equalsIgnoreCase("rgb(218, 41, 28)")) {
					OneframeLogger(ele.getCssValue("caret-color"));
					return false;
				}
				OneframeLogger(ele.getCssValue("caret-color"));
			}
			return true;
		}
		
		return false;
	}
	
	@Step("Validate CoInsurance Fields are hilighted in Red Color")
	public boolean verifyCoInsuranceFieldsAreHilightedInRed() {
		
		if(coInsuranceInputBoxes.size() > 0) {
			for(WebElement ele: coInsuranceInputBoxes) {
				if(!ele.getCssValue("caret-color").equalsIgnoreCase("rgb(218, 41, 28)")) {
					OneframeLogger(ele.getCssValue("caret-color"));
					return false;
				}
				OneframeLogger(ele.getCssValue("caret-color"));
			}
			return true;
		}
		
		return false;
	}
	
	@Step("Validate Min Fields are hilighted in Red Color")
	public boolean verifyMinFieldsAreHilightedInRed() {
		
		if(minInputBoxes.size() > 0) {
			for(WebElement ele: minInputBoxes) {
				if(!ele.getCssValue("caret-color").equalsIgnoreCase("rgb(218, 41, 28)")) {
					OneframeLogger(ele.getCssValue("caret-color"));
					return false;
				}
				OneframeLogger(ele.getCssValue("caret-color"));
			}
			return true;
		}
		
		return false;
	}
	
	@Step("Validate Max Fields are hilighted in Red Color")
	public boolean verifyMaxFieldsAreHilightedInRed() {
		
		if(maxInputBoxes.size() > 0) {
			for(WebElement ele: maxInputBoxes) {
				if(!ele.getCssValue("caret-color").equalsIgnoreCase("rgb(218, 41, 28)")) {
					OneframeLogger(ele.getCssValue("caret-color"));
					return false;
				}
				OneframeLogger(ele.getCssValue("caret-color"));
			}
			return true;
		}
		
		return false;
	}

	@Step("Click on Network {networkName}")
	public boolean clickNetwork(String networkName) {
		try {
			for(WebElement ele: networkList) {
				if(ele.getText().trim().equalsIgnoreCase(networkName)) {
					ClickWebObject(ele);
					OneframeLogger("Clicked on network: " +ele.getText());
					return true;
				}
				else {
					OneframeLogger("Couldn't find the network: "+networkName);
					return false;
				}
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on network " +e);
		}
		return false;
	}

	
	@Step("Enter {string} into copay fields")
	public boolean enterValueInCopayFields(String string) {
		try {
			if(copayInputBoxes.size() > 0) {
				for(WebElement ele: copayInputBoxes) {
					Thread.sleep(2000);
					if(WaitForObjectVisibility(ele)) {
						EnterText(ele, string);
						OneframeLogger("Entered text: " +ele.getText());
					}	
				}
				return true;
			}
			
		} catch (Exception e) {
			OneframeLogger("Unable to enter data into the field " +e);
			
		}
		return false;
	}

	@Step("Enter {string} into CoInsurance fields")
	public boolean enterValueInCoInsuranceFields(String string) {
		try {
			if(coInsuranceInputBoxes.size() > 0) {
				for(WebElement ele: coInsuranceInputBoxes) {
					Thread.sleep(2000);
					if(WaitForObjectVisibility(ele)) {
						EnterText(ele, string);
						OneframeLogger("Entered text: " +ele.getText());
					}
				}
				return true;
			}
			
		} catch (Exception e) {
			OneframeLogger("Unable to enter data into the field " +e);
			
		}
		return false;
	}
	
	@Step("Enter {string} into Min fields")
	public boolean enterValueInMinFields(String string) {
		try {
			if(minInputBoxes.size() > 0) {
				for(WebElement ele: minInputBoxes) {
					Thread.sleep(2000);
					if(WaitForObjectVisibility(ele)) {
						EnterText(ele, string);
						OneframeLogger("Entered text: " +ele.getText());
					}
				}
				return true;
			}
			
		} catch (Exception e) {
			OneframeLogger("Unable to enter data into the field " +e);
			
		}
		return false;
	}
	
	@Step("Enter {string} into Max fields")
	public boolean enterValueInMaxFields(String string) {
		try {
			if(maxInputBoxes.size() > 0) {
				for(WebElement ele: maxInputBoxes) {
					Thread.sleep(2000);
					if(WaitForObjectVisibility(ele)) {
						EnterText(ele, string);
						OneframeLogger("Entered text: " +ele.getText());
					}
				}
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to enter data into the field " +e);
			
		}
		return false;
	}
	
}

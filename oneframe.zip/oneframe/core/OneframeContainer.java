// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import anthem.irx.oneframe.utilities.ExcelIOStream;
import java.util.Collection;
import java.util.Iterator;
import org.openqa.selenium.Cookie;
import java.net.UnknownHostException;
import java.net.InetAddress;
import com.codoid.products.exception.FilloException;
import java.util.List;
import anthem.irx.oneframe.utilities.ConfigFileReader;
import org.openqa.selenium.support.events.WebDriverEventListener;
import anthem.irx.oneframe.selenium.WebDriverFactory;
import anthem.irx.oneframe.selenium.DriverType;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import anthem.irx.oneframe.utilities.ExcelDB;
import io.qameta.allure.Step;
import org.apache.commons.io.FileUtils;
import anthem.irx.oneframe.utilities.DateTimeProcessor;
import java.io.File;
import anthem.irx.oneframe.utilities.FileOpsHelper;
import java.util.ArrayList;
import java.util.HashMap;
import anthem.irx.oneframe.selenium.WebDriverManager;
import anthem.irx.oneframe.selenium.WebObjectActionListener;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.Listeners;

@Listeners({ OneframeListener.class })
public class OneframeContainer extends OneframeConstants
{
    public static EventFiringWebDriver oneframeDriver;
    public static WebDriver OFWebDriver;
    public static WebObjectActionListener oneframeListener;
    protected static String ApplicationURL;
    protected static WebDriverManager drivermanager;
    protected static boolean ReadyToLaunch;
    public static OneframeReporter ofReporter;
    private static String TSBasicAuthUserName;
    private static String TSBasicAuthPassword;
    private static String TSSiteKeyStorePath;
    private static String TSSiteKeyStorePathPWD;
    private static String TSCaCertPath;
    private static String TSCaCertPathPWD;
    private static boolean TSHttpsValidation;
    private static String TSEnableHttpsValidation;
    private static String TSoAuthToken;
    private static String TSAuthTokenEndPoint;
    private static String TSAuthorizationApiKey;
    private static String TSBaseURI;
    private static String TSPortNumber;
    private static String TSTrustStore;
    private static String TSTrustStorePWD;
    private static String TSJavaTrustStore;
    private static String TSJavaTrustStorePwd;
    private static String TSApiAppBaseURL;
    private static String TSApiEnableSSLHTTPS;
    private static String TSApiPortNumber;
    private static String TSOAuthEndPoint;
    private static String TSAuthApiKey;
    private static String TSAuthType;
    private static String TSBasikAuthUsername;
    private static String TSBasikAuthPassword;
    private static String TSBearerToken;
    public static String TSAppEnvKeyURL;
    public static String TSAngularEnvKey;
    public static String TSCredLoginKey;
    public static String AngularAppStatus;
    public static HashMap<String, HashMap<String, String>> AppConfigDBMap;
    private HashMap<String, String> AppConfigAWSMap;
    public static HashMap<String, String> TSScriptConfigurations;
    public static Object[][] TSTestData;
    public static String NodeUserName;
    public static String NodeIPAddress;
    public static String NodeHostName;
    public static String ofUserEmailID;
    public static String ofUserID;
    public static String ofUserPassword;
    public static boolean ofcqTestEnabled;
    public static boolean ofcqTestResultUpload;
    public static boolean ofcVideoLogEnabled;
    public static String ofcVideloLogQuality;
    public static String ofcLoggerTestLogLevel;
    public static boolean ofcExtentReportEnabled;
    public static String ofcExtentReportLocation;
    public static String ofcAutomationType;
    public static boolean loadedOneframeProperties;
    public static String ofcQTestHost;
    public static String ofcQTestAuthToken;
    public static String ofcQTestRelease;
    public static String ofcQTestTestCycle;
    public static String ofcQTestTestSuite;
    public static boolean loadedqTestProperties;
    public static String glblScreenshotString;
    public static String ofcLoginFrmCredEnabled;
    public static String ofcQTestProjName;
    public static String TestSuiteName;
    public static String TSReleaseName;
    public static boolean TSParallelExec;
    public static int TSThreadCount;
    public static String TestSuiteFile;
    public static String TSScriptConfigSheet;
    public static String TSPackageName;
    public static String TSXMLFileOutput;
    public static String TSListenerClass;
    public static String TestScenarioID;
    public static String TSqTestTCID;
    public static String TSTestScenarioName;
    public static String TSScriptName;
    public static String TSScriptParameters;
    public static String TSTags;
    public static String TSRunFlag;
    public static String TSAutomationType;
    public static String TSAppEnvKey;
    public static String TSExecEnvironment;
    public static String TSTDSDocument;
    public static String TSTDSResultDocument;
    public static String ScriptTDSFileName;
    public static String ScriptTDSFile;
    public static String TSDataSheetKey;
    public static String TSDisable2FA;
    public static String TSBrowser;
    public static String TSExecutionMode;
    public static String TSDriverType;
    public static String ScenarioAppKey;
    public static String ScenarioBrowser;
    public static int MaxWaitTime;
    public static int IntervalTime;
    public static int ScriptRegulatorLvl;
    public static int PageLoadTimeOut;
    public static String gTestResult;
    public static String gTestCaseID;
    public static String gTestScript;
    public static int gTestIteration;
    public static String glblCurrObjDetails;
    public static String glblPrevWindwHndl;
    public static String glblPrevWindwTitle;
    public static String glblcurrWindwHndl;
    public static String glblcurrWindwTitle;
    public static HashMap<String, String> gActualResultsMap;
    public static String ExceptionSubStr;
    public static OneframeSoftAssert sa;
    public static OneframeAssert ha;
    private static int instanceCounter;
    public static ArrayList<String> testLogsArr;
    
    public OneframeContainer() {
        ++OneframeContainer.instanceCounter;
        OneframeLogger("[ONEFRAME] Oneframe Container - Initialized : " + OneframeContainer.instanceCounter);
    }
    
    private void initializeOneframeAssertionObjects() {
        OneframeContainer.sa = new OneframeSoftAssert();
        OneframeContainer.ha = new OneframeAssert();
    }
    
    private void CheckAndSetupFrameworkFolders() {
        if (!FileOpsHelper.checkFolderExist(OneframeContainer.RUNTIME_FOLDER)) {
            final File folder = new File(OneframeContainer.RUNTIME_FOLDER);
            if (folder.mkdir()) {
                OneframeLogger("[ONEFRAME] RUN TIME Folder Created");
            }
        }
        else {
            OneframeLogger("Folder already Exist - [" + FileOpsHelper.checkFolderExist(OneframeContainer.RUNTIME_FOLDER) + "]");
        }
    }
    
    private void BackupResourceAndTestOutputFolders() {
        final String backup = OneframeContainer.RUNTIME_FOLDER + "/" + "Backup_" + DateTimeProcessor.getCurrentDateTime();
        final File dest = new File(backup);
        try {
            final File folder = new File(OneframeContainer.RUNTIME_FOLDER);
            final File[] listFiles;
            final File[] files = listFiles = folder.listFiles();
            for (final File file : listFiles) {
                if (file.isFile()) {
                    FileUtils.moveFileToDirectory(file, dest, true);
                }
            }
        }
        catch (Exception e) {
            e.getStackTrace();
        }
    }
    
    @Step("Initializing Oneframe Components")
    public void InitializeLaunchPad(final String ScenarioID) {
        OneframeContainer.TestScenarioID = ScenarioID;
        OneframeContainer.gTestIteration = 0;
        this.initializeOneframeAssertionObjects();
        this.loadFrameworkConfigurations();
        this.CheckAndSetupFrameworkFolders();
        this.BackupResourceAndTestOutputFolders();
        this.loadLaunchConfigurations();
        if (OneframeContainer.ofcLoginFrmCredEnabled.equalsIgnoreCase("yes")) {
            this.checkUserCredential();
        }
        this.loadHostInformation();
        if (OneframeContainer.TSAutomationType.toLowerCase().contains("web") && this.GetDriverfromtheFactory()) {
            OneframeContainer.ReadyToLaunch = true;
        }
    }
    
    private void checkUserCredential() {
        this.ReadCredentialConfiguration();
        if (OneframeContainer.ofUserEmailID.isEmpty() || OneframeContainer.ofUserID.isEmpty() || OneframeContainer.ofUserPassword.isEmpty()) {
            OneframeErrorLogger("User credential file is not setup....please follow the below steps");
            OneframeErrorLogger("1. Setup the 'Credential.properties' file under '" + OneframeContainer.CONFIG_FOLDER + "' folder");
            OneframeErrorLogger("2. Run 'oneframe.TestLaunchers.EncryptOneframeCredentials.java' to encrypt the password");
            OneframeErrorLogger("Exiting");
            System.exit(1);
        }
        else {
            try {
                OneframeLogger("[ONEFRAME]User ID and Password read from credential properties");
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void CloseExcelDBConnection() {
        ExcelDB.CloseExcelDBConnection();
    }
    
    public void CloseLaunchPad() {
        this.ReturnDriverTotheFactory();
        this.CloseExcelDBConnection();
        WebObjectHandler.ResetWebHandlerObjects();
    }
    
    @Step("Creating WebDriver for execution")
    private boolean GetDriverfromtheFactory() {
        final String lowerCase = OneframeContainer.TSBrowser.toLowerCase();
        switch (lowerCase) {
            case "chrome": {
                OneframeContainer.drivermanager = WebDriverFactory.getDriverManager(DriverType.CHROME);
                break;
            }
            case "chrome_mobile_emulator": {
                OneframeContainer.drivermanager = WebDriverFactory.getDriverManager(DriverType.CHROME_MOB_EMULATOR);
                break;
            }
            case "chrome_headless": {
                OneframeContainer.drivermanager = WebDriverFactory.getDriverManager(DriverType.CHROME_HEADLESS);
                break;
            }
            case "firefox": {
                OneframeContainer.drivermanager = WebDriverFactory.getDriverManager(DriverType.FIREFOX);
                break;
            }
            case "internet_explorer": {
                OneframeContainer.drivermanager = WebDriverFactory.getDriverManager(DriverType.IE);
                break;
            }
            case "edge": {
                OneframeContainer.drivermanager = WebDriverFactory.getDriverManager(DriverType.EDGE);
                break;
            }
            default: {
                OneframeLogger(OneframeContainer.TSBrowser + " is not available in the Driver Factory");
                break;
            }
        }
        OneframeContainer.OFWebDriver = OneframeContainer.drivermanager.getWebDriver();
        OneframeLogger("[ONEFRAME]Oneframe Web Driver Initialized...");
        OneframeContainer.oneframeDriver = new EventFiringWebDriver(OneframeContainer.OFWebDriver);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver wrapped as EventFiringWebDriver...");
        OneframeContainer.oneframeListener = new WebObjectActionListener();
        OneframeContainer.oneframeDriver.register((WebDriverEventListener)OneframeContainer.oneframeListener);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver registered with Action Listener...");
        return true;
    }
    
    private void ReturnDriverTotheFactory() {
        if (OneframeContainer.oneframeDriver != null) {
            OneframeContainer.oneframeDriver.quit();
            OneframeLogger("[ONEFRAME]Quit oneframe EventDriven WebDriver....Done");
        }
        else {
            OneframeErrorLogger("[ONEFRAME][RDTTF] oneframe EventDriven WebDriver object is not initialized");
        }
        if (OneframeContainer.OFWebDriver != null) {
            OneframeContainer.OFWebDriver.quit();
            OneframeLogger("[ONEFRAME]Quit oneframe WebDriver....Done");
        }
        else {
            OneframeErrorLogger("[ONEFRAME][RDTTF] oneframe WebDriver object is not initialized");
        }
        if (OneframeContainer.drivermanager != null) {
            OneframeContainer.drivermanager.quitWebDriver();
            OneframeLogger("[ONEFRAME]Quit Chrome Driver....Done");
        }
        else {
            OneframeErrorLogger("[ONEFRAME][RDTTF] oneframe Driver Manager object is not initialized");
        }
    }
    
    @Step("Starting Application")
    protected boolean StartApplication() {
        OneframeLogger("[ONEFRAME]Ready to Launch : " + OneframeContainer.ReadyToLaunch);
        if (OneframeContainer.ReadyToLaunch) {
            OneframeContainer.oneframeDriver.manage().deleteAllCookies();
            OneframeContainer.oneframeDriver.get(OneframeContainer.ApplicationURL);
        }
        return true;
    }
    
    @Step("Load framework configurations")
    private void loadFrameworkConfigurations() {
        readOneframeConfiguration();
        this.readQtestConfiguration();
    }
    
    @Step("Load script configurations")
    private void loadLaunchConfigurations() {
        this.ReadTestBedConfiguration();
        this.ReadTestSuiteScriptConfiguration();
        this.ReadApplicationConfigurations();
        this.ReadScriptExecutionVariables();
        if (OneframeContainer.TSAutomationType.toLowerCase().contains("api")) {
            this.ReadAPICongurationsFromAPIConfigFile();
        }
    }
    
    private String getEnvironmentFromAppKey(final String AppKey) {
        String environment = "Not Specified";
        if (AppKey.contains("SIT")) {
            environment = "SIT";
        }
        if (AppKey.contains("UAT")) {
            environment = "UAT";
        }
        if (AppKey.contains("PRE-PROD")) {
            environment = "PRE-PROD";
        }
        if (AppKey.contains("PROD")) {
            environment = "PROD";
        }
        if (AppKey.contains("CI")) {
            environment = "CI";
        }
        return environment;
    }
    
    public static void readOneframeConfiguration() {
        if (!OneframeContainer.loadedOneframeProperties) {
            final ConfigFileReader OneframeConfiguration = new ConfigFileReader(OneframeContainer.ONEFRAME_CONFIG_FILE);
            OneframeContainer.ofcqTestEnabled = Boolean.parseBoolean(OneframeConfiguration.getProperty("qTest.Integration.Enable"));
            OneframeContainer.ofcqTestResultUpload = Boolean.parseBoolean(OneframeConfiguration.getProperty("qTest.TestResult.Upload"));
            OneframeContainer.ofcVideoLogEnabled = Boolean.parseBoolean(OneframeConfiguration.getProperty("logger.videolog.Enable"));
            OneframeContainer.ofcVideloLogQuality = OneframeConfiguration.getProperty("logger.videolog.Quality");
            OneframeContainer.ofcLoggerTestLogLevel = OneframeConfiguration.getProperty("logger.testlog.level");
            OneframeContainer.ofcExtentReportEnabled = Boolean.parseBoolean(OneframeConfiguration.getProperty("logger.ExtentReport.Enable"));
            OneframeContainer.ofcExtentReportLocation = OneframeConfiguration.getProperty("logger.ExtentReport.Location");
            OneframeContainer.loadedOneframeProperties = true;
        }
    }
    
    public static String getOneframeTestLogLevel() {
        return OneframeContainer.ofcLoggerTestLogLevel;
    }
    
    public void readQtestConfiguration() {
        final ConfigFileReader QtestConfiguration = new ConfigFileReader(OneframeContainer.QTEST_CONFIG_FILE);
        OneframeContainer.ofcQTestHost = QtestConfiguration.getProperty("qTest.host");
        OneframeContainer.ofcQTestAuthToken = QtestConfiguration.getProperty("qTest.api.auth.Bearertoken");
        OneframeContainer.ofcQTestRelease = QtestConfiguration.getProperty("qTest.Project.Release");
        OneframeContainer.ofcQTestTestCycle = QtestConfiguration.getProperty("qTest.Project.TestCycle");
        OneframeContainer.ofcQTestTestSuite = QtestConfiguration.getProperty("qTest.Project.TestSuite");
        OneframeContainer.loadedqTestProperties = true;
    }
    
    public void ReadCredentialConfiguration() {
        final ConfigFileReader OneframeConfiguration = new ConfigFileReader(OneframeContainer.CREDENTIAL_CONFIG_FILE);
        OneframeContainer.ofUserEmailID = OneframeConfiguration.getProperty("ingeniorx.email.id");
        OneframeContainer.ofUserID = OneframeConfiguration.getProperty("ingeniorx.US.username");
        OneframeContainer.ofUserPassword = OneframeConfiguration.getProperty("ingeniorx.US.password");
    }
    
    public String getUserIDfromCredentialConfiguration(final String CredentialKey) {
        final ConfigFileReader OneframeConfiguration = new ConfigFileReader(OneframeContainer.CREDENTIAL_CONFIG_FILE);
        return OneframeConfiguration.getProperty(CredentialKey.concat(".username"));
    }
    
    public String getUserNamefromCredentialConfiguration(final String CredentialKey) {
        return this.getUserIDfromCredentialConfiguration(CredentialKey);
    }
    
    public String getPasswordfromCredentialConfiguration(final String CredentialKey) {
        final ConfigFileReader OneframeConfiguration = new ConfigFileReader(OneframeContainer.CREDENTIAL_CONFIG_FILE);
        return OneframeConfiguration.getProperty(CredentialKey.concat(".password"));
    }
    
    public static String getPasswordfromCredentialConfiguration(final String CredentialKey, final boolean decyrpt) {
        String decryPass = "";
        final ConfigFileReader OneframeConfiguration = new ConfigFileReader(OneframeContainer.CREDENTIAL_CONFIG_FILE);
        final String encryPass = OneframeConfiguration.getProperty(CredentialKey.concat(".password"));
        if (decyrpt) {
            try {
                decryPass = OneframeCipher.decryptPassword(encryPass);
            }
            catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        return decryPass;
    }
    
    public String getUserIDfromCredentialProperties() {
        if (OneframeContainer.ofUserID.isEmpty()) {
            return null;
        }
        return OneframeContainer.ofUserID;
    }
    
    public String getPwdfromCredentialProperties() {
        if (OneframeContainer.ofUserPassword.isEmpty()) {
            return null;
        }
        try {
            return OneframeCipher.decryptPassword(OneframeContainer.ofUserPassword);
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void ReadTestBedConfiguration() {
        try {
            final ConfigFileReader OneframeConfiguration = new ConfigFileReader(OneframeContainer.TEST_BED_CONFIG_FILE);
            OneframeContainer.TestSuiteName = OneframeConfiguration.getProperty("TestBed.TestSuite.Name");
            OneframeContainer.TSReleaseName = OneframeConfiguration.getProperty("TestBed.TestSuite.Release");
            OneframeContainer.TSParallelExec = Boolean.parseBoolean(OneframeConfiguration.getProperty("TestBed.TestSuite.ParallelExecution"));
            OneframeContainer.TSThreadCount = Integer.parseInt(OneframeConfiguration.getProperty("TestBed.TestSuite.ThreadCount"));
            OneframeContainer.TestSuiteFile = OneframeConfiguration.getProperty("TestBed.TestSuite.File");
            OneframeContainer.TestSuiteFile = getTestSuiteFile();
            OneframeContainer.TSScriptConfigSheet = OneframeConfiguration.getProperty("TestBed.TestSuite.Sheet");
            OneframeContainer.TSPackageName = OneframeConfiguration.getProperty("TestBed.TestSuite.Package");
            OneframeContainer.TSXMLFileOutput = OneframeConfiguration.getProperty("TestBed.TestSuite.XMLOutput");
            OneframeContainer.TSListenerClass = OneframeConfiguration.getProperty("TestBed.TestSuite.TestListener");
            OneframeLogger("[ONEFRAME]Read Test Bed configurations..........Done");
        }
        catch (RuntimeException RTE) {
            OneframeLogger(RTE.getMessage());
        }
    }
    
    public static Object[][] GetTestDatafromTDS(final List<String> TestDataColumns) {
        try {
            OneframeContainer.TSTestData = ExcelDB.getDatafromExcel(OneframeContainer.ScriptTDSFile, OneframeContainer.TSDataSheetKey, OneframeContainer.TestScenarioID, TestDataColumns);
        }
        catch (FilloException E) {
            OneframeLogger(E.getMessage());
        }
        return OneframeContainer.TSTestData;
    }
    
    public static void SetTestRunVariables(final String TestCaseID) {
        OneframeContainer.gTestCaseID = TestCaseID;
        ++OneframeContainer.gTestIteration;
        OneframeLogger("Iteration : " + OneframeContainer.gTestIteration + " | Test Case ID : " + TestCaseID);
        OneframeLogger("[ONEFRAME][TEST RUN VARIABLES ARE SET]");
    }
    
    public static String getCurrentTestScenarioID() {
        return OneframeContainer.TestScenarioID;
    }
    
    public static String getCurrentTestCaseID() {
        return OneframeContainer.gTestCaseID;
    }
    
    public static String getCurrentTestScriptName() {
        return OneframeContainer.gTestScript;
    }
    
    public static void UpdateTestResultsToTDS() {
        ExcelDB.UpdateTestResultToExcel(OneframeContainer.ScriptTDSFile, OneframeContainer.TSDataSheetKey, OneframeContainer.gTestCaseID, OneframeContainer.gTestResult);
        OneframeLogger("Updated test results to TDS");
    }
    
    public static void UpdateActualResultsToTDS(final String[] TDSColumnHeaders, final String[] TDSColumnActualResults) {
        ExcelDB.UpdateActualResultsToExcel(OneframeContainer.ScriptTDSFile, OneframeContainer.TSDataSheetKey, OneframeContainer.gTestCaseID, TDSColumnHeaders, TDSColumnActualResults);
        OneframeLogger("Updated test results to TDS");
    }
    
    public static void ResetTestResults() {
        OneframeContainer.gTestResult = "NOT EXECUTED";
    }
    
    private void ReadAPIConfigurations() {
        final ConfigFileReader OneframeConfiguration1 = new ConfigFileReader(OneframeContainer.API_CONFIG_FILE);
        OneframeContainer.TSSiteKeyStorePath = OneframeConfiguration1.getProperty("siteKeyStore");
        OneframeContainer.TSSiteKeyStorePathPWD = OneframeConfiguration1.getProperty("siteKeyStorePathPWD");
        OneframeContainer.TSCaCertPath = OneframeConfiguration1.getProperty("caCert");
        OneframeContainer.TSCaCertPathPWD = OneframeConfiguration1.getProperty("caCertPathPWD");
        OneframeContainer.TSAuthorizationApiKey = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".ApiKey");
        OneframeContainer.TSBaseURI = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".baseURL");
        OneframeContainer.TSoAuthToken = OneframeConfiguration1.getProperty("oAuthToken");
        OneframeContainer.TSBasicAuthUserName = OneframeConfiguration1.getProperty("UserName");
        OneframeContainer.TSBasicAuthPassword = OneframeConfiguration1.getProperty("Password");
        OneframeContainer.TSAuthTokenEndPoint = OneframeConfiguration1.getProperty("authTokenEndPoint");
        OneframeContainer.TSPortNumber = OneframeConfiguration1.getProperty("portNumber");
    }
    
    private void ReadAPICongurationsFromAPIConfigFile() {
        final ConfigFileReader OneframeConfiguration1 = new ConfigFileReader(OneframeContainer.API_CONFIG_FILE);
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.TrustStore")) {
            OneframeContainer.TSTrustStore = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.TrustStore");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.TrustStore.PWD")) {
            OneframeContainer.TSTrustStorePWD = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.TrustStore.PWD");
        }
        if (OneframeConfiguration1.checkPropertyExists("system.Java.TrustStore")) {
            OneframeContainer.TSJavaTrustStore = OneframeConfiguration1.getProperty("system.Java.TrustStore");
        }
        if (OneframeConfiguration1.checkPropertyExists("system.Java.TrustStorePwd")) {
            OneframeContainer.TSJavaTrustStorePwd = OneframeConfiguration1.getProperty("system.Java.TrustStorePwd");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.baseURL")) {
            OneframeContainer.TSApiAppBaseURL = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.baseURL");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".enableHTTPSValidation")) {
            OneframeContainer.TSEnableHttpsValidation = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".enableHTTPSValidation");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.portNumber")) {
            OneframeContainer.TSApiPortNumber = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.portNumber");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.enableSSLHTTPS")) {
            OneframeContainer.TSApiEnableSSLHTTPS = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.enableSSLHTTPS");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.oauth.EndPoint")) {
            OneframeContainer.TSOAuthEndPoint = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.oauth.EndPoint");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.auth.type")) {
            OneframeContainer.TSAuthType = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.auth.type");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.auth.BasicAuth.Username")) {
            OneframeContainer.TSBasikAuthUsername = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.auth.BasicAuth.Username");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.auth.BasicAuth.Password")) {
            OneframeContainer.TSBasikAuthPassword = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.auth.BasicAuth.Password");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.auth.BearerToken.Token")) {
            OneframeContainer.TSBearerToken = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.auth.BearerToken.Token");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.auth.header.Authorization")) {
            OneframeContainer.TSBearerToken = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.auth.header.Authorization");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.auth.header.ContentType")) {
            OneframeContainer.TSBearerToken = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.auth.header.ContentType");
        }
        if (OneframeConfiguration1.checkPropertyExists(OneframeContainer.TSAppEnvKey + ".api.auth.header.apikey")) {
            OneframeContainer.TSBearerToken = OneframeConfiguration1.getProperty(OneframeContainer.TSAppEnvKey + ".api.auth.header.apikey");
        }
    }
    
    public static String getApiTrustStore() {
        return OneframeContainer.TSTrustStore;
    }
    
    public static String getApiTrustStorePassword() {
        return OneframeContainer.TSTrustStorePWD;
    }
    
    public static String getApiAppBaseURL() {
        return OneframeContainer.TSApiAppBaseURL;
    }
    
    public static boolean getSSLHTTPSflag() {
        return Boolean.parseBoolean(OneframeContainer.TSApiEnableSSLHTTPS);
    }
    
    public static String getApiPortNumber() {
        return OneframeContainer.TSApiPortNumber;
    }
    
    public static String getoAuthEndPoint() {
        return OneframeContainer.TSOAuthEndPoint;
    }
    
    public static String getAuthorizedApiKey() {
        return OneframeContainer.TSAuthApiKey;
    }
    
    public static String getAuthType() {
        return OneframeContainer.TSAuthType;
    }
    
    public static String getBasicAuthUsername() {
        return OneframeContainer.TSBasikAuthUsername;
    }
    
    public static String getBasicAuthPassword() {
        return OneframeContainer.TSBasikAuthPassword;
    }
    
    public static String getBearerToken() {
        return OneframeContainer.TSBearerToken;
    }
    
    private void ReadApplicationConfigurations() {
        OneframeContainer.TSAngularEnvKey = OneframeContainer.TSAppEnvKey + ".angular";
        OneframeContainer.TSAppEnvKeyURL = OneframeContainer.TSAppEnvKey + ".url";
        OneframeContainer.TSCredLoginKey = OneframeContainer.TSAppEnvKey + ".login.use.credfile";
        final ConfigFileReader ApplicationConfiguration = new ConfigFileReader(OneframeContainer.APPLICATION_CONFIG_FILE);
        if (OneframeContainer.TSAutomationType.toLowerCase().contains("web")) {
            if (OneframeContainer.TSDisable2FA.equalsIgnoreCase("no")) {
                OneframeContainer.ApplicationURL = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKeyURL);
            }
            else {
                OneframeContainer.ApplicationURL = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + ".2FA.url");
            }
            OneframeContainer.AngularAppStatus = ApplicationConfiguration.getProperty(OneframeContainer.TSAngularEnvKey);
            OneframeContainer.ofcLoginFrmCredEnabled = ApplicationConfiguration.getProperty(OneframeContainer.TSCredLoginKey);
        }
        if (OneframeContainer.ofcqTestEnabled) {
            OneframeContainer.ofcQTestProjName = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + ".qTest.Project");
        }
        this.ReadDBConfigurationsFromAppConfigFile(ApplicationConfiguration);
        if (ApplicationConfiguration.checkPropertyExists(OneframeContainer.TSAppEnvKey + "." + "aws.url")) {
            this.AppConfigAWSMap = new HashMap<String, String>();
            String tawsval = "";
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.url");
            this.AppConfigAWSMap.put("aws.url", tawsval);
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.displayname");
            this.AppConfigAWSMap.put("aws.displayname", tawsval);
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.role");
            this.AppConfigAWSMap.put("aws.role", tawsval);
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.account");
            this.AppConfigAWSMap.put("aws.account", tawsval);
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.username");
            this.AppConfigAWSMap.put("aws.username", tawsval);
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.password");
            this.AppConfigAWSMap.put("aws.password", tawsval);
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.clipath");
            this.AppConfigAWSMap.put("aws.clipath", tawsval);
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.profile");
            this.AppConfigAWSMap.put("aws.profile", tawsval);
            tawsval = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + "aws.uploadprofile");
            this.AppConfigAWSMap.put("aws.uploadprofile", tawsval);
        }
    }
    
    private void ReadDBConfigurationsFromAppConfigFile(final ConfigFileReader ApplicationConfiguration) {
        final String[] dbRefArray = { "db1", "db2", "db3", "db4", "db5" };
        OneframeContainer.AppConfigDBMap = new HashMap<String, HashMap<String, String>>();
        for (final String dbref : dbRefArray) {
            if (!OneframeContainer.AppConfigDBMap.containsKey(dbref)) {
                OneframeContainer.AppConfigDBMap.put(dbref, new HashMap<String, String>());
            }
        }
        for (final String dbref : dbRefArray) {
            if (ApplicationConfiguration.checkPropertyExists(OneframeContainer.TSAppEnvKey + "." + dbref + ".dburl")) {
                OneframeLogger("[ONEFRAME]Database configuration for " + dbref);
                String tdbref = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + dbref + ".dburl");
                OneframeContainer.AppConfigDBMap.get(dbref).put(".dburl", tdbref);
                tdbref = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + dbref + ".username");
                OneframeContainer.AppConfigDBMap.get(dbref).put(".username", tdbref);
                tdbref = ApplicationConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + dbref + ".password");
                OneframeContainer.AppConfigDBMap.get(dbref).put(".password", tdbref);
            }
        }
    }
    
    private void ReadScriptExecutionVariables() {
        final ConfigFileReader OneframeConfiguration = new ConfigFileReader(OneframeContainer.SCRIPTEXE_CONFIG_FILE);
        OneframeContainer.MaxWaitTime = Integer.parseInt(OneframeConfiguration.getProperty("Action.MaxWaitTime"));
        OneframeContainer.IntervalTime = Integer.parseInt(OneframeConfiguration.getProperty("Action.IntervalTime"));
        OneframeContainer.PageLoadTimeOut = Integer.parseInt(OneframeConfiguration.getProperty("Driver.PageLoadTimeout"));
        OneframeContainer.ScriptRegulatorLvl = Integer.parseInt(OneframeConfiguration.getProperty("Execution.RegulatorLevel"));
    }
    
    public static void loadDBConfigurationFromIEPConfigFile() {
        final String[] dbRefArray = { "db1", "db2", "db3", "db4", "db5" };
        final ConfigFileReader IEPConfiguration = new ConfigFileReader(OneframeContainer.IEP_CONFIG_FILE);
        OneframeContainer.AppConfigDBMap = new HashMap<String, HashMap<String, String>>();
        for (final String dbref : dbRefArray) {
            if (!OneframeContainer.AppConfigDBMap.containsKey(dbref)) {
                OneframeContainer.AppConfigDBMap.put(dbref, new HashMap<String, String>());
            }
        }
        for (final String dbref : dbRefArray) {
            if (IEPConfiguration.checkPropertyExists(OneframeContainer.TSAppEnvKey + "." + dbref + ".dburl")) {
                OneframeLogger("[ONEFRAME]Database configuration for " + dbref);
                String tdbref = IEPConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + dbref + ".dburl");
                OneframeContainer.AppConfigDBMap.get(dbref).put(".dburl", tdbref);
                tdbref = IEPConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + dbref + ".username");
                OneframeContainer.AppConfigDBMap.get(dbref).put(".username", tdbref);
                tdbref = IEPConfiguration.getProperty(OneframeContainer.TSAppEnvKey + "." + dbref + ".password");
                OneframeContainer.AppConfigDBMap.get(dbref).put(".password", tdbref);
            }
        }
    }
    
    public HashMap<String, String> getAWSConfigsFromApplicationPropertyFile() {
        return this.AppConfigAWSMap;
    }
    
    public String getAWSurl() {
        return this.AppConfigAWSMap.get("aws.url");
    }
    
    public String getAWSdisplayName() {
        return this.AppConfigAWSMap.get("aws.displayname");
    }
    
    public String getAWSaccount() {
        return this.AppConfigAWSMap.get("aws.account");
    }
    
    public String getAWSrole() {
        return this.AppConfigAWSMap.get("aws.role");
    }
    
    public String getAWSuserName() {
        return this.AppConfigAWSMap.get("aws.username");
    }
    
    public String getAWSpassword() {
        return this.AppConfigAWSMap.get("aws.password");
    }
    
    public String getAWSclipath() {
        return this.AppConfigAWSMap.get("aws.clipath");
    }
    
    public String getAWSprofile() {
        return this.AppConfigAWSMap.get("aws.profile");
    }
    
    public String getAWSuploadprofile() {
        return this.AppConfigAWSMap.get("aws.uploadprofile");
    }
    
    private void loadHostInformation() {
        OneframeContainer.NodeUserName = System.getProperty("user.name");
        try {
            OneframeContainer.NodeIPAddress = InetAddress.getLocalHost().getHostAddress();
            OneframeContainer.NodeHostName = InetAddress.getLocalHost().getHostName();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
    
    public static void PrintAllDriverCookies() {
        for (final Cookie ck : OneframeContainer.oneframeDriver.manage().getCookies()) {
            OneframeLogger("[ONEFRAME]Name - " + ck.getName() + ";" + ck.getValue() + ";" + ck.getDomain() + ";" + ck.getPath() + ";" + ck.getExpiry() + ";" + ck.isSecure());
        }
    }
    
    public static void DeleteAllDriverCookies() {
        OneframeContainer.oneframeDriver.manage().deleteAllCookies();
    }
    
    public static void DeleteDriverCookiesByName(final String CookieName) {
    }
    
    public static void OneframeLogger(final String LogMessage) {
        if (LogMessage.indexOf(OneframeContainer.ExceptionSubStr) > 0) {
            OneframeLogger.Log(getCondensedExceptionMessage(LogMessage));
        }
        else {
            OneframeLogger.Log(LogMessage);
        }
    }
    
    public static void OneframeErrorLogger(final String ErrorLogMessage) {
        if (ErrorLogMessage.indexOf(OneframeContainer.ExceptionSubStr) > 0) {
            OneframeLogger.ErrorLog(getCondensedExceptionMessage(ErrorLogMessage));
        }
        else {
            OneframeLogger.ErrorLog(ErrorLogMessage);
        }
    }
    
    public static void OneframeLogger(final Collection<String> LogMessage) {
        OneframeLogger.Log(LogMessage.toString());
    }
    
    public static void OneframeLogger(final HashMap<String, String> LogMessage) {
        OneframeLogger.Log(LogMessage.toString());
    }
    
    public static void OneframeLogger(final String[] LogMessages) {
        for (final String logMessage : LogMessages) {
            OneframeLogger(logMessage);
        }
    }
    
    public static void OneframeLogger(final String[] LogMessages1, final String[] LogMessages2) {
        for (int i = 0; i < LogMessages1.length; ++i) {
            OneframeLogger(LogMessages1[i] + " - " + LogMessages2[i]);
        }
    }
    
    public static void OneframeLogger(final String[][] LogMessages) {
        for (int i = 0; i < LogMessages.length; ++i) {
            String arrLog = "";
            for (int j = 0; j < LogMessages[0].length; ++j) {
                arrLog = arrLog.concat(LogMessages[i][j]).concat("|");
            }
            OneframeLogger("|" + arrLog);
        }
    }
    
    public static void OneframeLogger(final int LogMessage) {
        OneframeLogger.Log(Integer.toString(LogMessage));
    }
    
    public static String getCondensedExceptionMessage(final String ExceptionMessage) {
        return ExceptionMessage.substring(0, ExceptionMessage.indexOf(OneframeContainer.ExceptionSubStr) - 2);
    }
    
    private void ReadTestSuiteScriptConfiguration() {
        final ExcelIOStream excelDoc = new ExcelIOStream(OneframeContainer.TestSuiteFile);
        OneframeContainer.TSScriptConfigurations = excelDoc.readScriptConfiguration(OneframeContainer.TestScenarioID);
        OneframeContainer.TSqTestTCID = getqTestTCIDfromScriptConfig();
        OneframeContainer.TSTestScenarioName = getTestScenarioNamefromScriptConfig();
        OneframeContainer.TSScriptName = getScriptNamefromScriptConfig();
        OneframeContainer.TSScriptParameters = getScriptParametersfromScriptConfig();
        OneframeContainer.TSTags = getTagsfromScriptConfig();
        OneframeContainer.TSRunFlag = getRunFlagfromScriptConfig();
        OneframeContainer.TSAutomationType = getAutomationTypefromScriptConfig();
        OneframeContainer.TSAppEnvKey = getAppEnvKeyfromScriptConfig();
        OneframeContainer.TSExecEnvironment = this.getEnvironmentFromAppKey(OneframeContainer.TSAppEnvKey);
        OneframeContainer.TSTDSDocument = getTDSDocumentfromScriptConfig();
        OneframeContainer.ScriptTDSFile = getScriptTDSFile();
        OneframeContainer.TSDataSheetKey = getDataSheetKeyfromScriptConfig();
        if (OneframeContainer.TSAutomationType.toLowerCase().contains("web")) {
            OneframeContainer.TSDisable2FA = getDisable2FAfromScriptConfig();
            OneframeContainer.TSBrowser = getBrowserfromScriptConfig();
            OneframeContainer.TSExecutionMode = getExecutionModefromScriptConfig();
            OneframeContainer.TSDriverType = getDriverTypefromScriptConfig();
        }
        OneframeLogger("[ONEFRAME]Read test suite script configuration..........Done");
    }
    
    public static String getScriptTDSFile() {
        OneframeContainer.ScriptTDSFile = getTDSDocumentfromScriptConfig();
        return OneframeContainer.TESTDATA_FOLDER + OneframeContainer.ScriptTDSFile.trim() + ".xlsx";
    }
    
    public static String getTestSuiteFile() {
        final String ofTestSuiteFile = OneframeContainer.TESTSUITES_FOLDER + OneframeContainer.TestSuiteFile;
        return ofTestSuiteFile;
    }
    
    public static String getqTestTCIDfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("qTestTCID");
    }
    
    public static String getTestScenarioNamefromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("TestScenarioName");
    }
    
    public static String getScriptNamefromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("ScriptName");
    }
    
    public static String getScriptParametersfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("ScriptParameters");
    }
    
    public static String getTagsfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("Tags");
    }
    
    public static String getRunFlagfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("RunFlag");
    }
    
    public static String getAutomationTypefromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("AutomationType");
    }
    
    public static String getAppEnvKeyfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("AppEnvKey");
    }
    
    public static String getTDSDocumentfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("TDSDocument");
    }
    
    public static String getDataSheetKeyfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("DataSheetKey");
    }
    
    public static String getDisable2FAfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("Disable2FA");
    }
    
    public static String getBrowserfromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("Browser");
    }
    
    public static String getExecutionModefromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("ExecutionMode");
    }
    
    public static String getDriverTypefromScriptConfig() {
        return OneframeContainer.TSScriptConfigurations.get("DriverType");
    }
    
    public static WebDriver getOneframeWebDriver() {
        return OneframeContainer.OFWebDriver;
    }
    
    static {
        OneframeContainer.ReadyToLaunch = false;
        OneframeContainer.TSHttpsValidation = false;
        OneframeContainer.ofcLoggerTestLogLevel = "oneframedebugmode";
        OneframeContainer.loadedOneframeProperties = false;
        OneframeContainer.loadedqTestProperties = false;
        OneframeContainer.glblScreenshotString = "";
        OneframeContainer.ofcLoginFrmCredEnabled = "NO";
        OneframeContainer.gTestResult = "NOT EXECUTED";
        OneframeContainer.gTestCaseID = "NOT ASSIGNED";
        OneframeContainer.gTestScript = "NOT ASSIGNED";
        OneframeContainer.glblCurrObjDetails = "NOT ASSIGNED";
        OneframeContainer.glblPrevWindwHndl = "NOT ASSIGNED";
        OneframeContainer.glblPrevWindwTitle = "NOT ASSIGNED";
        OneframeContainer.glblcurrWindwHndl = "NOT ASSIGNED";
        OneframeContainer.glblcurrWindwTitle = "NOT ASSIGNED";
        OneframeContainer.gActualResultsMap = new HashMap<String, String>();
        OneframeContainer.ExceptionSubStr = "(Session info: chrome";
        OneframeContainer.instanceCounter = 0;
        OneframeContainer.testLogsArr = new ArrayList<String>();
    }
}

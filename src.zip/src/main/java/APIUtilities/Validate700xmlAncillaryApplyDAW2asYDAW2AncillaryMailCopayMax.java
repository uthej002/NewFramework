package APIUtilities;

public class Validate700xmlAncillaryApplyDAW2asYDAW2AncillaryMailCopayMax {

}

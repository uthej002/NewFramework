package anthem.irx.oneframe.database;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Properties;

public class OneframeDatabaseDriver {
  protected String ofDBurl;
  
  protected String ofDBMS;
  
  protected String ofDBname;
  
  protected String ofDBusername;
  
  protected String ofDBpassword;
  
  protected String ofDBParameters;
  
  protected ResultSet ofQueryResultSet;
  
  private HashMap<String, String> DBConfigMap;
  
  private Connection ofDBconn = null;
  
  OneframeSoftAssert ofsa;
  
  public OneframeDatabaseDriver OpenDBConnection(String dbReference) {
    this.ofsa = new OneframeSoftAssert();
    if (OneframeContainer.AppConfigDBMap.containsKey(dbReference)) {
      this.DBConfigMap = (HashMap<String, String>)OneframeContainer.AppConfigDBMap.get(dbReference);
      this.ofDBurl = this.DBConfigMap.get(".dburl");
      if (this.ofDBurl == null) {
        OneframeContainer.OneframeLogger("DB URL is missing for configuration -> : " + dbReference);
        System.exit(0);
      } 
      String[] dbURLdetails = this.ofDBurl.split(":");
      if (dbURLdetails.length > 0) {
        this.ofDBMS = dbURLdetails[0].toLowerCase();
      } else {
        OneframeContainer.OneframeLogger("Error found in DB configuration -> : " + this.ofDBurl);
      } 
      this.ofDBusername = this.DBConfigMap.get(".username");
      this.ofDBpassword = this.DBConfigMap.get(".password");
      this.DBConfigMap.forEach((key, value) -> OneframeContainer.OneframeLogger("[ONEFRAME]" + key + " : " + value));
      if (this.ofDBMS.isEmpty() || this.ofDBMS == null || this.ofDBMS.trim() == "") {
        OneframeContainer.OneframeLogger("Database configuration is missing for reference : " + dbReference);
        System.exit(0);
      } 
      Properties connectionProps = new Properties();
      connectionProps.put("user", this.ofDBusername);
      connectionProps.put("password", this.ofDBpassword);
      String ConnURL = "jdbc:" + this.ofDBurl;
      try {
        OneframeContainer.OneframeLogger("Initializing database connection object.........");
        this.ofDBconn = DriverManager.getConnection(ConnURL, connectionProps);
      } catch (SQLException e) {
        e.printStackTrace();
      } 
      if (this.ofDBconn != null)
        OneframeContainer.OneframeLogger("Connection to database......Success"); 
    } else {
      OneframeContainer.OneframeLogger("Database configuration is missing for reference : " + dbReference);
    } 
    return this;
  }
  
  public ResultSet executeSQLQueryAndgetResultSetObject(String sqlQuery) {
    try {
      Statement sqlStatObj = this.ofDBconn.createStatement(1004, 1007);
      this.ofQueryResultSet = sqlStatObj.executeQuery(sqlQuery);
      if (isResultSetEmpty())
        OneframeContainer.OneframeLogger("Total number of records returned by the query : " + getTotalRecordsCount()); 
      this.ofQueryResultSet.beforeFirst();
    } catch (SQLException e) {
      e.printStackTrace();
    } 
    return this.ofQueryResultSet;
  }
  
  public OneframeDatabaseDriver executeSQLQuery(String sqlQuery) {
    try {
      Statement sqlStatObj = this.ofDBconn.createStatement(1004, 1007);
      this.ofQueryResultSet = sqlStatObj.executeQuery(sqlQuery);
      if (isResultSetEmpty())
        OneframeContainer.OneframeLogger("Total number of records returned by the query : " + getTotalRecordsCount()); 
      this.ofQueryResultSet.beforeFirst();
    } catch (SQLException e) {
      e.printStackTrace();
    } 
    return this;
  }
  
  public OneframeDatabaseDriver validateDBColumnValue(String columnName, String expectedValue) {
    String dbActColValue = "";
    try {
      moveCursorPointerToFirstRecord();
      dbActColValue = this.ofQueryResultSet.getString(columnName);
      this.ofsa.assertEquals(dbActColValue, expectedValue, "Database validation on column [" + columnName + "] -> Expected Result : " + expectedValue + " Actual Result : " + dbActColValue);
    } catch (SQLException e) {
      this.ofsa.assertTrue(false, "Get value of column - " + columnName + "| " + e.getLocalizedMessage());
    } 
    return this;
  }
  
  public boolean moveCursorPointerToNextRecord() throws SQLException {
    return this.ofQueryResultSet.next();
  }
  
  public boolean moveCursorPointerToFirstRecord() throws SQLException {
    return this.ofQueryResultSet.first();
  }
  
  public boolean moveCursorPointerToLastRecord() throws SQLException {
    return this.ofQueryResultSet.last();
  }
  
  public void moveCursorPointer(int rowNumber) {
    try {
      this.ofQueryResultSet.beforeFirst();
      for (int i = 0; i < rowNumber; i++)
        this.ofQueryResultSet.next(); 
      OneframeContainer.OneframeLogger("Cursor moved to record -> " + this.ofQueryResultSet.getRow());
    } catch (SQLException e) {
      e.printStackTrace();
    } 
  }
  
  public OneframeDatabaseDriver validateDBColumnValues(String[] columnNames, String[] expectedValues) {
    if (columnNames.length == expectedValues.length) {
      for (int i = 0; i < columnNames.length; i++)
        validateDBColumnValue(columnNames[i], expectedValues[i]); 
    } else {
      OneframeContainer.OneframeErrorLogger("Expected columns and values array size is not equal");
    } 
    return this;
  }
  
  public int getTotalRecordsCount() {
    int recordCount = 0;
    try {
      int currentCursor = this.ofQueryResultSet.getRow();
      this.ofQueryResultSet.last();
      recordCount = this.ofQueryResultSet.getRow();
    } catch (SQLException e) {
      e.printStackTrace();
    } 
    return recordCount;
  }
  
  public boolean isResultSetEmpty() {
    boolean flag = false;
    try {
      flag = this.ofQueryResultSet.first();
    } catch (SQLException e) {
      OneframeContainer.OneframeErrorLogger(e.getLocalizedMessage());
    } 
    if (!flag)
      OneframeContainer.OneframeErrorLogger("Resultset is empty, no records retrieved by the query"); 
    return flag;
  }
  
  public void closeDBConnection() {
    try {
      if (!this.ofDBconn.isClosed())
        this.ofDBconn.close(); 
      OneframeContainer.OneframeLogger("[ONEFRAME]Database connection is closed");
    } catch (SQLException e) {
      e.printStackTrace();
    } 
  }
  
  protected void finalize() {
    closeDBConnection();
  }
}
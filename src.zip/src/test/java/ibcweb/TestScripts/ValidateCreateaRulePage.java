package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreateaRulePage extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for validating Create Rule Page")
	public void setUp() {
		InitializeLaunchPad("IBPW_4");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate Create Rule Page", dataProvider = "TestData")
	@Description("Validate Create Rule Page")
	public void ValidateCreateRuleSectionsDisplay(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {
		
		OneframeAssert ha = new OneframeAssert();
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickStagingLink();          
			rulebuilderstaging.clickAddRuleButton();
			sa.assertTrue(addrulepage.verifyCreateaRuleHeader(), "Verified Create a Rule Title is displayed");
			sa.assertTrue(addrulepage.verifyBackbuttondisplay(), "Verified Back Button is displayed");
			sa.assertTrue(addrulepage.verifyRuleNamedisplay(), "Verified Rule Name is displayed");
			sa.assertTrue(addrulepage.verifyDescriptiondisplay(), "Verified Description is displayed");
			sa.assertTrue(addrulepage.verifyStartandEndDatedisplay(), "Verified Start and End Date is displayed");
			sa.assertTrue(addrulepage.verifyWhenSectiondisplay(), "Verified When Section is displayed");
			sa.assertTrue(addrulepage.verifyThenSectiondisplay(), "Verified Then Section is displayed");
			sa.assertTrue(addrulepage.verifyMessagedisplay(), "Verified Message is displayed");
			sa.assertTrue(addrulepage.verifyVersionNumberdisplay(), "Verified Version Bunber is displayed");
			sa.assertTrue(addrulepage.verifyAddRuleButtonisDisabled(), "Add New Rule is Disabled");
			sa.assertTrue(addrulepage.verifycancelbuttondisplay(), "Verified Cancel Button is displayed");
			homepage.clickRuleBuilder();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Create Rule Page Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate Create Rule Page");
		}	
		
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

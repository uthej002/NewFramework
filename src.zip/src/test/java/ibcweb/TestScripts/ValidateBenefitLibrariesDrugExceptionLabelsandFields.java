package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesDrugExceptionLabelsandFields extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;
	IBPLibrariesBaseFormularies baseFormulary;
	IBPBenefitFormularyPage librariesFormularyPage;

	@BeforeClass
	@Step("Initializing Test Script for Validate Drug Exception List details page labels and field Details")
	public void setUp() {
		InitializeLaunchPad("IBPW_419");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();
		baseFormulary = new IBPLibrariesBaseFormularies();
		librariesFormularyPage = new IBPBenefitFormularyPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Drug Exception List details page labels and field Details", dataProvider = "TestData")
	@Description("Validate Drug Exception List details page labels and field Details")
	public void ValidateBenefitLibrariesDrugExceptionLabelandFields(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesFormularyPage.clickViewButtonofFormularies();
			librariesFormularyPage.clickDrugExceptionsButton();
			librariesFormularyPage.clickonFirstDrugExceptionFormulary();

				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("Drug List ID");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("CVS Code");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("Drug List Name");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("Description");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("Managed By");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("Adj. Sys Status");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("Effective Date");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("Termination Date");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("Client");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("LOB");
				librariesFormularyPage.verifyDrugExceptionListlabelsAreDisplayed("State");

				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("Drug List ID");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("CVS Code");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("Drug List Name");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("Description");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("Managed By");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("Adj. Sys Status");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("Effective Date");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("Termination Date");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("Client");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("LOB");
				librariesFormularyPage.verifyDrugExceptionListFieldsisDisplayed("State");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Drug Exception List details page labels and field Details Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Drug Exception List details page labels and field Details");
		}

		homepage.clickLogout();
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

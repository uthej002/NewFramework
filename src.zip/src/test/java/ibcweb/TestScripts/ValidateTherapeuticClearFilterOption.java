package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBenefitProgramsPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateTherapeuticClearFilterOption extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage programsPage;
	IBPLibrariesControlsPage controls;

	@BeforeClass
	@Step("Initializing Test Script for validating filters in Therapeutic screen are cleared after clicking on Clear Filter button")
	public void setUp() {
		InitializeLaunchPad("IBPW_727");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		programsPage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType", "MarketSegment",
				"ProductType", "Other", "ProgramName", "TerminationDate", "DrugList", "GeneralOverrides", "NetworkOverrides",
				"CostShareOverrides", "AccumOverrides"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate filters in Therapeutic screen are cleared after clicking on Clear Filter button", dataProvider = "TestData")
	@Description("Validate filters in Therapeutic screen are cleared after clicking on Clear Filter button")
	public void ValidateTherapeuticFiltersCleared(String TestCaseID, String TestStatus, String Benefit, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String AutoApply, String BusinessEntity,
			String BusinessUnit, String CDHP, String Formulary, String FundingType, String MarketSegment,
			String ProductType, String Other,String ProgramName, String TerminationDate, String DrugList,
			String GeneralOverrides, String NetworkOverrides, String CostShareOverrides, String AccumOverrides) throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			
			homepage.clickMenuButton();
			homepage.clickLibraries();
			programsPage.clickViewButtonofPrograms();
			sa.assertTrue(programsPage.verifyProgramsHeader(), "Programs header is displayed");
			programsPage.clickFilterButton();
			
			controls.EnterCBEffectiveDate(EffectiveDate);
			controls.EnterTerminationDate(TerminationDate);
			controls.selectAndGetClientValue(ClientId);
			controls.selectAndGetLobValue(LOBId);
			controls.selectAndGetStateValue(StateId);
			
		//	sa.assertTrue(controls.selectDrugList(DrugList), 
		//			"Selected Drug List value as :" +DrugList);
			sa.assertTrue(controls.selectGeneralOverrides(GeneralOverrides), 
					"Selected General Overrides values as :" +GeneralOverrides);
			sa.assertTrue(controls.selectNetworkOverrides(NetworkOverrides), 
					"Selected Network Overrides values as :" +NetworkOverrides);
			sa.assertTrue(controls.selectCostShareOverrides(CostShareOverrides), 
					"Selected CostShare Overrides values as :" +CostShareOverrides);
			sa.assertTrue(controls.selectAccumOverrides(AccumOverrides), 
					"Selected Accum Overrides values as :" +AccumOverrides);			
			sa.assertTrue(controls.selectAutoApplyFilterDropdown(AutoApply),
					"Verified and Selected 'Auto Apply' Filter dropdown");
			sa.assertTrue(controls.selectBusinessEntityFilterDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' Filter dropdown");
			sa.assertTrue(controls.selectBusinessUnitFilterDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' Filter dropdown");
			sa.assertTrue(controls.selectCDHPTypeFilterDropdown(CDHP),
					"Verified and Selected 'CDHP Type' Filter dropdown");
			sa.assertTrue(controls.selectFormularyFilterDropdown(Formulary),
					"Verified and Selected 'Formulary' Filter dropdown");
			sa.assertTrue(controls.selectFundingTypeFilterDropdown(FundingType),
					"Verified and Selected 'Funding Type' Filter dropdown");
			sa.assertTrue(controls.selectMarketSegmentFilterDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' Filter dropdown");
			sa.assertTrue(controls.selectProductTypeFilterDropdown(ProductType),
					"Verified and Selected 'Product Type' Filter dropdown");
//			sa.assertTrue(controls.selectOtherFilterDropdown(Other), 
//					"Verified and Selected 'Others' Filter dropdown");
			
			programsPage.clickApplyFilterButton();
			programsPage.clickClearFilterButton();
			
			sa.assertTrue(controls.verifyFiltersAreCleared() , "Verified that all filters are cleared");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated filters in Therapeutic screen are cleared after clicking on Clear Filter button Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate filters in Therapeutic screen are cleared after clicking on Clear Filter button"
					+ "");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}
}

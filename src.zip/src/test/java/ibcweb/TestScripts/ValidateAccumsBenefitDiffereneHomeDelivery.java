package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumsBenefitDiffereneHomeDelivery extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for Edit the Different Home Delivery Toggle values in Accums Tab on th Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_701");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "NewBenefitID", "INDINNRetail", "INDHomeDelivery", "INDOONRetail","FamINNRetail","FamINNHomeDelivery","FamOONRetail" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit the Different Home Delivery Toggle values in Accums Tab on th Benefit", dataProvider = "TestData")
	@Description("Validate Edit the Different Home Delivery Toggle values in Accums Tab on th Benefit")
	public void ValidateCDHPFieldValuesinAccumsTab(String TestCaseID, String TestStatus, String NewBenefitID,String INDINNRetail,String INDHomeDelivery,String INDOONRetail,String FamINNRetail,String FamINNHomeDelivery,String FamOONRetail )
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitID);
			sa.assertTrue(createbenefitpage.verifyBenefitCreatedHeader(NewBenefitID),
					"Verified 'Benefit' header is same as expected");
			
			accumsbenefitpage.clickOnAccumsTab();
			createbenefitpage.ClickEditButtoninWFE();	
			sa.assertTrue(accumsbenefitpage.verifyAccumsContentDisplay(), "Verified Accums Content is Displayed");
			accumsbenefitpage.clickOnDeductibleTab();
			accumsbenefitpage.clickDifferentHomeDeliveryToggle();
			sa.assertTrue(accumsbenefitpage.EditDifferentHomeDeliveryIndividualValues(INDINNRetail, INDHomeDelivery, INDOONRetail), "Verified The Individual Member values are edited when Different Home Delivery Toggle is enabled");
			sa.assertTrue(accumsbenefitpage.EditDifferentHomeDeliveryFamilyValues(FamINNRetail,FamINNHomeDelivery,FamOONRetail), "Verified The Family Member values are edited when Different Home Delivery Toggle is enabled");
			createbenefitpage.ClickWFECloseButton();
			createbenefitpage.ClickWFEExitAndSaveButton();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit the Different Home Delivery Toggle values in Accums Tab on the Benefit Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Edit the Different Home Delivery Toggle values in Accums Tab on the Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

	
	

}

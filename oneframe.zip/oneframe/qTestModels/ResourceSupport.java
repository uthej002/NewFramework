// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class ResourceSupport
{
    @JsonProperty("links")
    private List<Link> links;
    
    public ResourceSupport() {
        this.links = new ArrayList<Link>();
    }
    
    public ResourceSupport links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public ResourceSupport addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ResourceSupport resourceSupport = (ResourceSupport)o;
        return Objects.equals(this.links, resourceSupport.links);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class ResourceSupport {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

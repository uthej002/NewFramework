package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderProduction;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidatePreviousVersionIdinProductionArea  extends OneframeContainer{
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderProduction rulebuilderproduction;
	IBPRuleIDPage ruleid;

	@BeforeClass
	@Step("Initializing Test Script for validating Previous Version Id In Production Area")
	public void setUp() {
		InitializeLaunchPad("IBPW_32");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderproduction = new IBPRuleBuilderProduction();
		ruleid = new IBPRuleIDPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "LibraryName","RuleName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate Previous Version Id In Production Area", dataProvider = "TestData")
	@Description("validate Previous Version Id In Production Area")
	public void ValidatePreviousVersionIdProductionArea(String TestCaseID, String TestStatus, String LibraryName,String RuleName) throws AWTException, InterruptedException, IOException {
		
	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickProductionLink();
            //sa.assertTrue(rulebuilderproduction.verifyRuleEngineHeaderdisplay(), "Verified Benefit Validation Rules Engine");
			sa.assertTrue(rulebuilderproduction.verifyProductionHeaderdisplay(), "Verified PRODUCTION Header is displayed");
			rulebuilderproduction.clickRuleName(LibraryName, RuleName);
			ruleid.clickPreviousVersionofRuleID();
			sa.assertTrue(!ruleid.verifyRuleNamedisplay(), "Verified Rule Name field is disabled");
			sa.assertTrue(!ruleid.verifyDescriptiondisplay(), "Verified Description field is disabled");
			sa.assertTrue(!ruleid.verifyStartandEndDatedisplay(), "Verified Start and End Date field is disabled");
			sa.assertTrue(!ruleid.verifyMessagedisplay(), "Verified Message field is disabled");
			gTestResult = RESULT_PASS;
			OneframeLogger("Previous Version Id Validation is successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Previous Version Id Validation is unsuccessful");
		}
		sa.assertAll();
	}


	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}


}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateTherapeuticAddProgramCostShareTabDropdownDetails extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validating Therapeutic Add Program Cost Share Tab dropdown details")
	public void setUp() {
		InitializeLaunchPad("IBPW_540");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "CostShareOverride", "DropDownValues" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Therapeutic Add Program Cost Share Tab dropdown details", dataProvider = "TestData")
	@Description("Validate Therapeutic Add Program Cost Share Tab dropdown details")
	public void ValidateCOBDefaultDynamicLayer(String TestCaseID, String TestStatus, String CostShareOverride,
			String DropDownValues) throws AWTException, InterruptedException, IOException, ParseException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickAddProgramofPrograms();
			sa.assertTrue(librariesprogramspage.verifyAddNewProgramHeader(),
					"The Add New Program Section Page is displayed");
			sa.assertTrue(mandate.selectCostShareOverrideDropdown(CostShareOverride),
					"Verified and Selected 'CostShare OverRide' dropdown as 'Yes'");
			librariesprogramspage.clickCostShareTab();
			librariesprogramspage.clickCustomSteppingToggle();
			sa.assertTrue(librariesprogramspage.verifyCostShareTabINNRetailDropdownValue(DropDownValues),
					"Validated  INN Retail Dropdown values is same as expected");
			sa.assertTrue(librariesprogramspage.verifyCostShareTabINNHomeDeliveryDropdownValue(DropDownValues),
					"Validated INN Home Delivery Dropdown values is same as expected");
			sa.assertTrue(librariesprogramspage.verifyCostShareTabONNRetailDropdownValue(DropDownValues),
					"Validated ONN Retail Dropdown values is same as expected");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Therapeutic Add Program Cost Share Tab dropdown details is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Therapeutic Add Program Cost Share Tab dropdown details");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPAddRulePage extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//div[@class='content__heading' and text()='Create a Rule']")
	WebElement hdrCreateARule;

	@FindBy(xpath = "//*[@class='button-group']//button//span[text()=' Cancel ']")
	WebElement btnCancel;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Logout ']")
	WebElement btnLogout;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()=' Back ']")
	WebElement btnBack;

	@FindBy(xpath = "//input[@placeholder='Enter Name']")
	WebElement txtEnterName;

	@FindBy(xpath = "//input[@placeholder='Enter Description(optional)']")
	WebElement txtDescription;

	@FindBy(xpath = "//input[@placeholder='Start Date']")
	WebElement txtStartDate;

	@FindBy(xpath = "//input[@placeholder='End Date']")
	WebElement txtEndDate;

	@FindBy(xpath = "//input[@placeholder='Enter Message']")
	WebElement txtEnterMessage;

	@FindBy(xpath = "//*[@id='clientId']/div/div/span")
	WebElement btnClientId;

	@FindBy(xpath = "//div[@class='mat-select-panel-wrap ng-tns-c165-354 ng-trigger ng-trigger-transformPanelWrap ng-star-inserted']/div/mat-option")
	List<WebElement> btnClientdropdownFields;

	@FindBy(xpath = "//*[@id='stateId']/div/div/span")
	WebElement btnStateId;

	@FindBy(xpath = "//mat-select[@data-automation-id='addRuleBuilderDecision']")
	WebElement btnDecisionTypeDropdown;

	@FindBy(xpath = "//span[contains(@class, 'mat-select-placeholder ng-tns-c165-32') and text()='Select']")
	WebElement btnDecisionType;

	@FindBy(xpath = "//*[@id='lobId']/div/div/span")
	WebElement btnLOBId;

	@FindBy(xpath = "//span[contains(text(), 'Version: ')]")
	WebElement txtVersionNumber;

	@FindBy(xpath = "//span[@class='mat-option-text' and text()='Medicaid']")
	WebElement btnMedicaid;

	@FindBy(xpath = "//span[@class='mat-option-text' and text()='AK']")
	WebElement btnAK;

	@FindBy(xpath = "//mat-error[@id='mat-error-3']")
	WebElement hdrRuleNameError;

	@FindBy(xpath = "//mat-error[@id='mat-error-4']")
	WebElement hdrMessageError;

	@FindBy(xpath = "//mat-error[@id='mat-error-5']")
	WebElement hdrDateError;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and text() = ' Add Rule ']")
	WebElement btnAddRule;

	@FindBy(xpath = "//*[@placeholder='Select']/div/div/span")
	List<WebElement> btnDropDowns;

	@FindBy(xpath = "//mat-select[@id='clientId']")
	WebElement btnClientDropdown;

	@FindBy(xpath = "//mat-select[@id='lobId']")
	WebElement btnLobDropdown;

	@FindBy(xpath = "//mat-select[@id='stateId']")
	WebElement btnStateDropdown;

	@FindBy(xpath = "//mat-select[@id='library']")
	WebElement btnLibraryDropdown;

	@FindBy(xpath = "//mat-select[@id='conditionalOperator']")
	WebElement btnConditionalOperatorDropdown;

	@FindBy(xpath = "//mat-select[@id='property']")
	WebElement btnPropertyDropdown;

	@FindBy(xpath = "//mat-select[@id='rhs']")
	WebElement btnRHSDropdown;

	@FindBy(xpath = "//mat-select[@id='clientId']//div/div/span/span]")
	WebElement drdClient;

	@FindBy(xpath = "//*[@id='clientId']/div/div[1]/span/span")
	WebElement btnDropDown1;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option/span")
	List<WebElement> drdClientId;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option")
	List<WebElement> drdLOBId;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option")
	List<WebElement> drdStateId;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option")
	List<WebElement> drdDecisionType;

	@FindBy(xpath = "//mat-icon[@svgicon='add']")
	WebElement btnAdd;

	@FindBy(xpath = "//mat-icon[@svgicon='remove']")
	WebElement btnRemove;

	@FindBy(xpath = "//span[text()='AND']")
	WebElement operatorAND;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option/span")
	List<WebElement> lstFirstValue;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div")
	WebElement operatorsANDOR;

	@FindBy(xpath = "//mat-select[@id='logicalOperator']")
	List<WebElement> lstOperators;
	
	@FindBy(xpath="//*[@class='mat-focus-indicator button-group__add mat-raised-button mat-button-base mat-primary ng-star-inserted' and @disabled = 'true']")
	WebElement btnAddRuleDisabled;
	
	
	
	@FindBy(xpath="//*[text()='* Rule cannot be created with only Client/ LOB/ State']")
	WebElement txtRuleCannotbeCreated;
	
	@FindBy(xpath="//*[text()='* Dynamic layer to be always selected after BOB while creating a rule']")
	WebElement txtDynamicRule;

	
	@FindBy(xpath="//*[@aria-label='Select' and @aria-disabled ='true']")
	WebElement btnSelectDisabled;
	

	// Initializing the Page Objects:
	public IBPAddRulePage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	public void clickAddButton() {
		try {
			if (ObjectExist(btnAdd)) {
				ClickWebObject(btnAdd);
				OneframeLogger("Add Row clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Row not clicked");
		}
	}

	public void clickRemoveButton() {
		try {
			if (ObjectExist(btnRemove)) {
				ClickWebObject(btnRemove);
				OneframeLogger("Remove Row clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Remove Row not clicked");
		}
	}

	@Step("Verify 'AND' Operator in Add Rule Page")
	public boolean verifyANDOperator() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(operatorAND);
		try {
			if (operatorAND.isDisplayed()) {
				highlightElement(operatorAND);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	public boolean verifyAddNewURL() {
		String currentURl = oneframeDriver.getCurrentUrl();
		OneframeLogger("URL is " + currentURl);
		ha.assertTrue(currentURl.contains("https://sit.ibp.ingenio-rx.com/admin/ruleBuilder/staging/new"),
				"Butterscotch Url is matching");
		return true;
	}

	@Step("Verify 'Create a Rule' header in Page")
	public boolean verifyCreateaRuleHeader() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrCreateARule);
		try {
			if (hdrCreateARule.isDisplayed()) {
				highlightElement(hdrCreateARule);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Create A Rule")
	public void clickCreateaRule() {
		try {
			if (ObjectExist(hdrCreateARule)) {
				ClickWebObject(hdrCreateARule);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Create A Rule clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Create A rule is not clicked");
		}
	}

	@Step("Verify Cancel Button is displayed")
	public boolean verifycancelbuttondisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(btnCancel);
		try {
			if (btnCancel.isDisplayed()) {
				highlightElement(btnCancel);
				// OneframeLogger("Cancel Button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("Cancel Button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Back Button is displayed")
	public boolean verifyBackbuttondisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(btnBack);
		try {
			if (btnBack.isDisplayed()) {
				highlightElement(btnBack);
				// OneframeLogger("Back Button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("Back Button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Cancel Button")
	public void clickCancelbutton() {
		try {
			if (ObjectExist(btnCancel)) {
				ClickWebObject(btnCancel);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Cancel Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cancel button not clicked");
		}
	}

	@Step("Click on Back Button")
	public void clickBackbutton() {
		try {
			if (ObjectExist(btnBack)) {
				ClickWebObject(btnBack);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Back Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Back button not clicked");
		}
	}

	@Step("Close the Butterscotch App")
	public void closeApp() {
		oneframeDriver.close();
		OneframeLogger("Butterscotch App is closed");
	}

	@Step("Verify Rule Name textbox is displayed")
	public boolean verifyRuleNamedisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(txtEnterName);
		try {
			if (txtEnterName.isDisplayed()) {
				highlightElement(txtEnterName);
				// OneframeLogger("Rule Name Textbox is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("Rule Name Textbox is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Rule Name Text Box")
	public void clickRulenametextbox() throws InterruptedException {
		try {
			if (ObjectExist(txtEnterName)) {
				ClickWebObject(txtEnterName);

				OneframeLogger("Rule Name Text Box is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Rule Name Text Box is not Clicked");
		}

	}

	@Step("Verify Description textbox is displayed")
	public boolean verifyDescriptiondisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(txtDescription);
		try {
			if (txtDescription.isDisplayed()) {
				highlightElement(txtDescription);
				// OneframeLogger("Description Textbox is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("Description Textbox is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on ClientId Type Textbox")
	public void clickCIdTextbox() {
		try {
			if (ObjectExist(btnClientId)) {
				ClickWebObject(btnClientId);
				WaitForApplicationToLoadCompletely();
				OneframeLogger(" Client IdTextbox clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Client Textbox not clicked");
		}
	}

	@Step("Click on Values in Client Textbox")
	public void clickValuesinClientTextbox() {
		try {

			if (ObjectExist(btnClientdropdownFields.get(0))) {
				ClickWebObject(btnClientdropdownFields.get(0));
				WaitForApplicationToLoadCompletely();
				OneframeLogger(" LOB Textbox clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Lob Textbox not clicked");
		}
	}

	@Step("Click on LOB Type Textbox")
	public void clickLIdTextbox() {
		try {
			if (ObjectExist(btnLOBId)) {
				ClickWebObject(btnLOBId);
				WaitForApplicationToLoadCompletely();
				OneframeLogger(" LOB Textbox clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Lob Textbox not clicked");
		}
	}

	@Step("Verify Start and End Date textbox is displayed")
	public boolean verifyStartandEndDatedisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(txtStartDate);
		try {
			if (txtStartDate.isDisplayed()) {
				highlightElement(txtStartDate);
				highlightElement(txtEndDate);
				// OneframeLogger("Start Date and End Date Textbox is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("Start Date and End Date Textbox is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Message textbox is displayed")
	public boolean verifyMessagedisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(txtEnterMessage);
		try {
			if (txtEnterMessage.isDisplayed()) {
				highlightElement(txtEnterMessage);
				// OneframeLogger("Message Textbox is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("Message Textbox is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Version Number is displayed")
	public boolean verifyVersionNumberdisplay() throws InterruptedException {
		boolean blnRC = false;
		WebObjectHandler.WaitForObjectVisibility(txtVersionNumber);
		try {
			if (txtVersionNumber.isDisplayed()) {
				highlightElement(txtVersionNumber);
				OneframeLogger("Version Number is " + txtVersionNumber.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("Version Number is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Decision Type Textbox")
	public void clickDecisionTypeTextbox() {
		try {
			if (ObjectExist(btnDecisionType)) {
				ClickWebObject(btnDecisionType);
				WaitForApplicationToLoadCompletely();
				OneframeLogger(" Decision Type Textbox clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Decision Type Textbox not clicked");
		}
	}

	@Step("Verify RuleName Error")
	public boolean VerifyRuleNameError() throws InterruptedException {
		boolean flag = false;

		if (ObjectExist(hdrRuleNameError)) {
			highlightElement(hdrRuleNameError);
			ClickWebObject(hdrRuleNameError);
			WaitForApplicationToLoadCompletely();
			OneframeLogger("The Error Message is  " + hdrRuleNameError.getText());
			flag = true;
		}
		return flag;
	}

	@Step("Verify Message Error")
	public boolean VerifyMessageError() throws InterruptedException {
		boolean flag = false;

		if (ObjectExist(hdrMessageError)) {
			highlightElement(hdrMessageError);

			WaitForApplicationToLoadCompletely();
			OneframeLogger("The Error Message is " + hdrMessageError.getText());
			flag = true;
		}
		return flag;
	}

	@Step("Verify Add Rule Button")
	public boolean VerifyAddRuleButton() throws InterruptedException {

		if (btnAddRule.isEnabled()) {
			highlightElement(btnAddRule);
			OneframeLogger("Add Rule Button is Enabled and it Should be  Clickable");
			return true;
		} else {
			highlightElement(btnAddRule);
			OneframeLogger("Add Rule Button is disabled and it Should not be Clickable");
			return false;

		}
	}

	@Step("Verify Add Rule Button is Disabled")
	public boolean verifyAddRuleButtonisDisabled() throws InterruptedException {
		if (WaitForObjectVisibility(btnAddRule)) {
			highlightElement(btnAddRule);
			// OneframeLogger("Add Rule Button is disabled and it Should not be Clickable");
			btnAddRule.isEnabled();
			return true;
		} else {
			return false;
		}
	}

	@Step("Click Add Rule Button")
	public boolean ClickAddRuleButton() throws InterruptedException {
		boolean blnRC = false;
		try {
			if (ObjectExist(btnAddRule)) {
				ClickWebObject(btnAddRule);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Add Rule Button clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Rule button not clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Date Error")
	public boolean VerifyDateError() throws InterruptedException {
		boolean flag = false;

		if (ObjectExist(hdrDateError)) {
			highlightElement(hdrDateError);

			WaitForApplicationToLoadCompletely();
			OneframeLogger("The Error Message is " + hdrMessageError.getText());
			flag = true;
		}
		return flag;
	}

	@Step("Enter Rule Name")
	public boolean EnterRuleName(String RuleName) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtEnterName)) {
				EnterText(txtEnterName, RuleName);
				OneframeLogger(" Rule Name is Entered");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger(" Rule Name is not Entered");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Enter Message")
	public boolean EnterMessage(String Message) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtEnterMessage)) {
				EnterText(txtEnterMessage, Message);
				OneframeLogger(" Message is Entered");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger(" Message is not Entered");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Enter Description")
	public boolean EnterDescription(String Description) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtDescription)) {
				EnterText(txtDescription, Description);
				OneframeLogger(" Description is Entered");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Description is not Entered");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Enter Start Date")
	public boolean EnterStartDate(String StartDate) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtStartDate)) {
				ClickWebObject(txtStartDate);
				EnterText(txtStartDate, StartDate);
				OneframeLogger("Start Date is Entered");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("StartDate is not Entered");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Enter End Date")
	public boolean EnterEndDate(String EndDate) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtEndDate)) {
				EnterText(txtEndDate, EndDate);
				OneframeLogger("End Date is Entered");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("End Date is not Entered");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify When Section is displayed")
	public boolean verifyWhenSectiondisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(btnDropDowns.get(0));
		try {
			if (btnDropDowns.get(0).isEnabled()) {
				highlightElement(btnDropDowns.get(0));
				highlightElement(btnDropDowns.get(1));
				highlightElement(btnDropDowns.get(2));
				// OneframeLogger("When Section is enabled");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("When Section is disabled");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Then Section is displayed")
	public boolean verifyThenSectiondisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(btnDropDowns.get(3));
		try {
			if (btnDropDowns.get(3).isEnabled()) {
				highlightElement(btnDropDowns.get(3));
				// OneframeLogger("Then Section is enabled");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			// OneframeLogger("Then Section is disabled");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify AND,OR Operators are displayed")
	public boolean verifyBothOperatorsdisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(lstOperators.get(1));
		ClickWebObject(lstOperators.get(1));
		WaitForObjectVisibility(operatorsANDOR);
		try {
			if (operatorsANDOR.isDisplayed()) {
				highlightElement(operatorsANDOR);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		ClickWebObject(operatorsANDOR);
		return blnRC;
	}

	@Step("Get first value in dropdowns")
	public String getFirstRecordValue() {
		WaitForObjectVisibility(lstFirstValue.get(0));
		highlightElement(lstFirstValue.get(0));
		return lstFirstValue.get(0).getText();
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValues(String values) {
		
		String element = String.format("//div[@class='cdk-overlay-pane']/div/div/mat-option/span[text()='%s']", values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
	}

	@Step("Select Client id Value from client dropdown")
	public boolean selectClientIdDropdown(String clientValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnClientDropdown)) {
				ClickWebObject(btnClientDropdown);
				selectDropdownValues(clientValue);
				//btnClientDropdown.sendKeys(Keys.TAB);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (NoSuchElementException | AWTException toException) {
			OneframeLogger("The Client Value has not been Selected from Client ID dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Lob id Value from LOB dropdown")
	public boolean selectLobIdDropdown(String lobValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnLobDropdown)) {
				ClickWebObject(btnLobDropdown);
				selectDropdownValues(lobValue);
				btnLobDropdown.sendKeys(Keys.TAB);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (NoSuchElementException | AWTException toException) {
			OneframeLogger("The Lob Value has not been Selected from Lob dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select State id Value from LOB dropdown")
	public boolean selectStateIdDropdown(String stateValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnStateDropdown)) {
				ClickWebObject(btnStateDropdown);
				selectDropdownValues(stateValue);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (NoSuchElementException | AWTException toException) {
			OneframeLogger("The State Value has not been Selected from State dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Library Value from Library dropdown")
	public boolean selectLibraryDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnLibraryDropdown)) {
				ClickWebObject(btnLibraryDropdown);
				String library = getFirstRecordValue();
				String element = String
						.format("//div[@class='cdk-overlay-pane']/div/div/mat-option/span[text()=' %s ']", library);
				WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
				OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
				WaitForObjectVisibility(dropdownvalue);
				ClickWebObject(dropdownvalue);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Library Value has not been Selected from Library dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Property Value from property dropdown")
	public boolean selectPropertyDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnPropertyDropdown)) {
				ClickWebObject(btnPropertyDropdown);
				String property = getFirstRecordValue();
				String element = String
						.format("//div[@class='cdk-overlay-pane']/div/div/mat-option/span[text()=' %s ']", property);
				WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
				OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
				WaitForObjectVisibility(dropdownvalue);
				ClickWebObject(dropdownvalue);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Property Value has not been Selected from Property dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Operator Value from property dropdown")
	public boolean selectOperatorDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnConditionalOperatorDropdown)) {
				ClickWebObject(btnConditionalOperatorDropdown);
				String operator = getFirstRecordValue();
				String element = String
						.format("//div[@class='cdk-overlay-pane']/div/div/mat-option/span[text()=' %s ']", operator);
				WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
				OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
				WaitForObjectVisibility(dropdownvalue);
				ClickWebObject(dropdownvalue);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Operator Value has not been Selected from Operator dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select RHS Value from property dropdown")
	public boolean selectRHSDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnRHSDropdown)) {
				ClickWebObject(btnRHSDropdown);
				String rhs = getFirstRecordValue();
				String element = String
						.format("//div[@class='cdk-overlay-pane']/div/div/mat-option/span[text()=' %s ']", rhs);
				WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
				OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
				WaitForObjectVisibility(dropdownvalue);
				ClickWebObject(dropdownvalue);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The RHS Value has not been Selected from RHS dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Decision Type Value from Decision Type dropdown")
	public boolean selectDecisionTypeDropdown(String decisionValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnDecisionTypeDropdown)) {
				ClickWebObject(btnDecisionTypeDropdown);
				String element = String.format(
						"//div[@class='cdk-overlay-pane']/div/div/mat-option/span[text()=' %s ']", decisionValue);
				WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
				WaitForObjectVisibility(dropdownvalue);
				OneframeLogger("The Selected Decision value is " + dropdownvalue.getText());
				ClickWebObject(dropdownvalue);
				btnDecisionTypeDropdown.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Decision Value has not been Selected from dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	
	public boolean clickAddRuleDisbaledButton() {
		ScrollWebPageByPixel(1000);

			if (ObjectExist(btnAddRuleDisabled)) {
				highlightElement(btnAddRuleDisabled);
				//ClickWebObject(btnAddRuleDisabled);
				OneframeLogger("Add Rule Button is Disbaled");
				return true;
			}
			return false;
		} 
	
	public boolean verifyAddRuleText() {
		
		if (ObjectExist(txtRuleCannotbeCreated) && txtRuleCannotbeCreated.getText().equalsIgnoreCase("* Rule cannot be created with only Client/ LOB/ State") ) {
			highlightElement(txtRuleCannotbeCreated);
			ClickWebObject(txtRuleCannotbeCreated);
			OneframeLogger("* Rule cannot be created with only Client/ LOB/ State is displayed");
			return true;
		}
		return false;
	} 
	
	
	public boolean verifyDynamicRuleText() {
		
		if (ObjectExist(txtDynamicRule) && txtDynamicRule.getText().equalsIgnoreCase("* Dynamic layer to be always selected after BOB while creating a rule") ) {
			highlightElement(txtDynamicRule);
			ClickWebObject(txtDynamicRule);
			OneframeLogger("* Dynamic layer to be always selected after BOB while creating a rule");
			return true;
		}
		return false;
	} 
	
	
	
	
	
	
	public boolean clickSelectDisbaledButton() {
		
		if (ObjectExist(btnSelectDisabled)) {
			
			highlightElement(btnSelectDisabled);
			//ClickWebObject(btnSelectDisabled);
			OneframeLogger("Select Button is Disbaled");
			return true;
		}
		return false;
	} 
	
	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(overlayElement);
	}
	

//	@Step("Select Client id Value in Ist dropdown")
//	public boolean selectClientId() {
//		boolean blnRC = false;
//		try {
//			if (WaitForObjectVisibility(btnDropDowns.get(0))) {
//				ClickWebObject(btnDropDowns.get(0));
//				WaitForObjectVisibility(drdClientId.get(1));
//				ClickWebObject(drdClientId.get(1));
//				//SelectDropDownListByValue(drdClientId, ClientId);
//				
//				drdClientId.get(1).sendKeys(Keys.TAB);
//				OneframeLogger("The Given Value has  been Selected from Client ID dropdown");
//				//OneframeLogger("Selected Value form the CLient Id Dropdown is :" +drdClientId.get(1).getText() );
//				blnRC = true;
//			}
//		} catch (NoSuchElementException toException) {
//			OneframeLogger("The Given Value has not been Selected from Client ID dropdown");
//			blnRC = false;
//		}
//		return blnRC;
//	}
//
//	@Step("Select Lob id Value in 2nd drop down")
//	public boolean selectLOBId() {
//		boolean blnRC = false;
//		try {
//			if (WaitForObjectVisibility(btnDropDowns.get(1))) {
//				ClickWebObject(btnDropDowns.get(1));
//				WaitForObjectVisibility(drdLOBId.get(2));
//				ClickWebObject(drdLOBId.get(2));
//				// SelectDropDownListByValue(drdLOBId, LOBId);
//				drdLOBId.get(2).sendKeys(Keys.TAB);
//				OneframeLogger("The Given Value has been Selected  from LOB dropdown");
//				blnRC = true;
//			}
//		} catch (NoSuchElementException toException) {
//			OneframeLogger("The Given Value has not been Selected from LOB dropdown");
//			blnRC = false;
//		}
//		return blnRC;
//	}
//
//	@Step("Select State id Value in 3rd drop down")
//	public boolean selectStateId() {
//		boolean blnRC = false;
//		try {
//			if (WaitForObjectVisibility(btnDropDowns.get(2))) {
//				ClickWebObject(btnDropDowns.get(2));
//				WaitForObjectVisibility(drdStateId.get(5));
//				ClickWebObject(drdStateId.get(5));
//				// SelectDropDownListByValue(drdStateId, StateId);
//				drdStateId.get(5).sendKeys(Keys.TAB);
//				OneframeLogger("The Given Value has been Selected from State Id dropdown");
//				blnRC = true;
//			}
//		} catch (NoSuchElementException toException) {
//			OneframeLogger("The Given Value has not been Selected from State Id dropdown");
//			blnRC = false;
//		}
//		return blnRC;
//	}
//
//	@Step("Select State id Value in 4th drop down")
//	public boolean selectDecisionType() {
//		boolean blnRC = false;
//		try {
//			if (WaitForObjectVisibility(btnDropDowns.get(3))) {
//				ClickWebObject(btnDropDowns.get(3));
//				WaitForObjectVisibility(drdDecisionType.get(1));
//				ClickWebObject(drdDecisionType.get(1));
//				// SelectDropDownListByValue(drdDecisionType, DType);
//
//				OneframeLogger("The Given Value has been Selected from Decision Type dropdown");
//				blnRC = true;
//			}
//		} catch (NoSuchElementException toException) {
//			OneframeLogger("The Given Value has not been Selected from Decision Type dropdown");
//			blnRC = false;
//		}
//		return blnRC;
//	}

}

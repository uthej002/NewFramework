// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import anthem.irx.oneframe.core.OneframeConstants;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.firefox.FirefoxOptions;

public class FireFoxWebDriverManager extends WebDriverManager
{
    public void createWebDriver() {
        final FirefoxOptions foxOptions = new FirefoxOptions();
        foxOptions.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        foxOptions.setAcceptInsecureCerts(true);
        foxOptions.addPreference("browser.download.folderList", 2);
        foxOptions.addPreference("browser.download.dir", OneframeConstants.RUNTIME_FOLDER);
        foxOptions.addPreference("browser.helperApps.neverAsk.saveToDisk", "text/csv");
        System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/src/main/resources/DriverBinaries/geckodriver_win64/geckodriver.exe");
        this.driver = (WebDriver)new FirefoxDriver(foxOptions);
        this.driver.manage().window().maximize();
    }
}

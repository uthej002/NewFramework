package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesDAWPage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreateDAWPackage extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesBaseFormularies baseFormulary;
	IBPLibrariesDAWPage daw;

	@BeforeClass
	@Step("Initializing Test Script for Validate Create DAW Package")
	public void setUp() {
		InitializeLaunchPad("IBPW_361");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		baseFormulary = new IBPLibrariesBaseFormularies();
		daw = new IBPLibrariesDAWPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Create DAW Package", dataProvider = "TestData")
	@Description("Validate Create DAW Package")
	public void ValidateDAWPackage(String TestCaseID, String TestStatus, String ClientId, String LOBId, String StateId)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			controls.clickViewButtonofControls();

			controls.clickControlsHeader();

			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'Controls' header is displayed");

			controls.clickControlsHeader();
			daw.clickDAWTab();
			daw.clickCreateADawPackageButton();

			daw.verifyDAWPackageUrl();

			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Create a Dispense as Written Package");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Package name");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Description");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Stop sale date");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Client");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Line of Business");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("States");

			daw.enterPackageName();
			daw.enterDescription();
			daw.enterCurrentStopSaleDate();
			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId),
					"The ClientID dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectLobdropdown(LOBId), "The LOB dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectStatedropdown(StateId), "The State dropdown has been selected");

			daw.enableAllDAWToggles();
			daw.enterDAWValues();

			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Cancel");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Add Daw package");
			
			daw.clickAddDawPackageButton();
			daw.verifyTextSuccesffulyCreatedDAW();

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Create DAW Package is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Create DAW Package");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

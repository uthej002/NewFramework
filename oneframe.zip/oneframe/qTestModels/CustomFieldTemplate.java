// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CustomFieldTemplate
{
    @JsonProperty("id")
    private Long id;
    @JsonProperty("clientId")
    private Long clientId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("default")
    private Boolean _default;
    
    public CustomFieldTemplate() {
        this.id = null;
        this.clientId = null;
        this.name = null;
        this._default = false;
    }
    
    public CustomFieldTemplate id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public CustomFieldTemplate clientId(final Long clientId) {
        this.clientId = clientId;
        return this;
    }
    
    public Long getClientId() {
        return this.clientId;
    }
    
    public void setClientId(final Long clientId) {
        this.clientId = clientId;
    }
    
    public CustomFieldTemplate name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public CustomFieldTemplate _default(final Boolean _default) {
        this._default = _default;
        return this;
    }
    
    public Boolean getDefault() {
        return this._default;
    }
    
    public void setDefault(final Boolean _default) {
        this._default = _default;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final CustomFieldTemplate customFieldTemplate = (CustomFieldTemplate)o;
        return Objects.equals(this.id, customFieldTemplate.id) && Objects.equals(this.clientId, customFieldTemplate.clientId) && Objects.equals(this.name, customFieldTemplate.name) && Objects.equals(this._default, customFieldTemplate._default);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.clientId, this.name, this._default);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class CustomFieldTemplate {\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    clientId: ").append(this.toIndentedString(this.clientId)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    _default: ").append(this.toIndentedString(this._default)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

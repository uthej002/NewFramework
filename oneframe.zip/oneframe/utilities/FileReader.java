// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import java.io.IOException;
import anthem.irx.oneframe.core.OneframeContainer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.BufferedReader;

public class FileReader
{
    StringBuilder strBuild;
    BufferedReader bufRead;
    
    public FileReader(final String FilePathAndName) {
        this.strBuild = new StringBuilder();
        try {
            this.bufRead = Files.newBufferedReader(Paths.get(FilePathAndName, new String[0]));
        }
        catch (IOException e) {
            OneframeContainer.OneframeErrorLogger("IO Exception : " + e);
        }
    }
    
    public String readFileContentAsString() {
        try {
            String line;
            while ((line = this.bufRead.readLine()) != null) {
                this.strBuild.append(line).append("\n");
            }
        }
        catch (IOException e) {
            OneframeContainer.OneframeErrorLogger("IO Exception : " + e);
        }
        return this.strBuild.toString();
    }
}

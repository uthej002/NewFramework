package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitCostSharesPage;
import ibcweb.PageObjects.IBPBenefitMandatePage;
import ibcweb.PageObjects.IBPBenefitNetworksPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBenefitProgramsPage;
import ibcweb.PageObjects.IBPBenefitSpecialityPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitsInProd extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitNetworksPage benefitNetworksPage;
	IBPBenefitCostSharesPage benefitCostsPage;
	IBPBenefitSpecialityPage benefitSpecialtyPage;
	IBPBenefitProgramsPage benefitProgramsPage;
	IBPBenefitMandatePage benefitMandatePage;
	
	@BeforeClass
	@Step("Initializing Test Script for validating Benefits in prod")
	public void setUp() {
		InitializeLaunchPad("IBPW_X1003");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		benefitNetworksPage = new IBPBenefitNetworksPage();
		benefitCostsPage = new IBPBenefitCostSharesPage();
		benefitSpecialtyPage = new IBPBenefitSpecialityPage();
		benefitProgramsPage = new IBPBenefitProgramsPage();
		benefitMandatePage = new IBPBenefitMandatePage();
	}
	
	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "BenefitID"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefits in Prod", dataProvider = "TestData")
	@Description("Validate Benefits in Prod")
	public void validBenefitsInProduction(String TestCaseID, String TestStatus, String BenefitID)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		OneframeAssert ha = new OneframeAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(BenefitID);
			sa.assertTrue(benefitpage.verifySearchResults(), 
					"Verified Benefit Results is displayed");
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), 
					"Verified Benefit header is displayed");
			ha.assertTrue(createbenefitpage.verifyVerStatus(), 
					"Verified Version Status  is displayed");
			
			benefitNetworksPage.clickNetworksTab();
			sa.assertTrue(benefitNetworksPage.verifyIncludeHeaderIsDisplayed() , 
					"Verified Include header is displayed");
			sa.assertTrue(benefitNetworksPage.verifyMaxDaySupplyHeaderIsDisplayed() , 
					"Verified Max Day Supply Header is displayed");
			sa.assertTrue(benefitNetworksPage.verifyRefillToSoonHeaderIsDisplayed() , 
					"Verified Refill To Soon Header is displayed");
			sa.assertTrue(benefitNetworksPage.verifyQuantityHeaderIsDisplayed() , 
					"Verified Quantity Header is displayed");
			
			benefitCostsPage.clickCostSharesTab();
			
			benefitCostsPage.clickDAWSubTab();
			sa.assertTrue(benefitCostsPage.verifyChooseaDAWPackageHeaderIsDisplayed() , 
					"Verified Choose a DAW Package header is displayed");
			sa.assertTrue(benefitCostsPage.verifyNoDaw() , 
					"Verified Choose a DAW Package is selected as NO DAW");
			
			benefitCostsPage.clickCOBSubTab();
			sa.assertTrue(benefitCostsPage.verifyChooseaCobPackageHeaderIsDisplayed() , 
					"Verified Choose a COB Package header is displayed");
			sa.assertTrue(benefitCostsPage.verifyChooseaCobProcessingHeaderIsDisplayed() , 
					"Verified Choose a Processing Method header is displayed");
			sa.assertTrue(benefitCostsPage.verifyCobPackageValue() , 
					"Verified Choose a COB Package is not selected as Not Applicable");
			sa.assertTrue(benefitCostsPage.verifyCobProcessingMethodValue() , 
					"Verified Choose a COB Processing Method is not selected as Not Applicable");
			sa.assertTrue(benefitCostsPage.verifyCobPackageNameHeaderIsDisplayed() , 
					"Verified COB Package Name header is displayed");
			sa.assertTrue(benefitCostsPage.verifyCob2to8LabelsAreDisplayed() , 
					"Verified COB 2 to COB 8 labels are displayed");
			
			benefitSpecialtyPage.clickSpecialtyTab();			
			
			benefitSpecialtyPage.clickSpecialtyPlanSubTab();
			sa.assertTrue(benefitSpecialtyPage.verifyProgramDescriptionHeaderIsDisplayed() , 
					"Verified Program Description header is displayed under Specialty Plan tab");
			
			benefitProgramsPage.clickProgramTab();
			sa.assertTrue(benefitSpecialtyPage.verifyProgramDescriptionHeaderIsDisplayed() , 
					"Verified Program Description header is displayed under Program tab");
			
			benefitProgramsPage.clickCostofCareSubTab();
			sa.assertTrue(benefitSpecialtyPage.verifyProgramDescriptionHeaderIsDisplayed() , 
					"Verified Program Description header is displayed under Cost of Care tab");
			
			benefitMandatePage.clickMandatesTab();
			sa.assertTrue(benefitMandatePage.verifyModifiedStrategyHeaderIsDisplayed() , 
					"Verified Modified Strategy header is displayed");

			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Benefits in Prod Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Benefits in Prod");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

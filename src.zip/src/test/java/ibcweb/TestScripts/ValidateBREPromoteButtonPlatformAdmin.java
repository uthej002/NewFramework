package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccountsPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBREPromoteButtonPlatformAdmin extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;
	IBPAccountsPage accountspage;

	@BeforeClass
	@Step("Initializing Test Script for validating the Promote Functionality for Platform Admin BRE")
	public void setUp() {
		InitializeLaunchPad("IBPW_40");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
		accountspage = new IBPAccountsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","LibraryName","RuleName","UserName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate the Promote Functionality for Platform Admin BRE", dataProvider = "TestData")
	@Description("Validate the Promote Functionality for Platform Admin BRE")
	public void ValidatePromoteButtonPlatformAdmin(String TestCaseID, String TestStatus,String LibraryName,String RuleName,String UserName) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			/*
			 * homepage.clickAccounts(); accountspage.EnterUserName(UserName);
			 * accountspage.clickonDomainID();
			 * sa.assertTrue(accountspage.verifyUserDetailsHeaderdisplay(),
			 * "Verified User Details Header is displayed");
			 * sa.assertTrue(accountspage.verifyPlatformAdminToggleButton(),
			 * "Verified Logged user have Platform Admin Role"); accountspage.clickonBack();
			 */
			homepage.clickRuleBuilder();
            homepage.clickStagingLink();          
            rulebuilderstaging.clickLibrary(LibraryName);
          //ruleid.getLatestVersionID(LibraryName, RuleName);
            String versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
			ruleid.clickLatestVersionofRuleID(versionId);
			ruleid.clickPromoteButton();
			sa.assertTrue(ruleid.verifyProductionTitleDisplay(), "Rule is moved from Stagging to Production");
			sa.assertTrue(!ruleid.verifyRuleNamedisplay(), "Rule Name is disabled");
			sa.assertTrue(!ruleid.verifyDescriptiondisplay(), "Description is disabled");
			sa.assertTrue(!ruleid.verifyStartandEndDatedisplay(), "Start and End Date is disabled");
			sa.assertTrue(!ruleid.verifyMessagedisplay(), "Message is disabled");
			ruleid.clickBackbutton();
			ruleid.clickBackbutton();
			sa.assertTrue(rulebuilderstaging.verifyStagingHeaderdisplay(), "Stagging header is displayed");
			homepage.clickProductionLink();    
			rulebuilderstaging.clickLibrary(LibraryName);
			versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
			
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate the Promote Functionality for Platform Admin BRE successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate the Promote Functionality for Platform Admin BRE unsuccessful");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}


}

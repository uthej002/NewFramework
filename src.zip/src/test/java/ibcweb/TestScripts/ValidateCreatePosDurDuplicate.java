package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreatePosDurDuplicate extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;

	@BeforeClass
	@Step("Initializing Test Script for Validate Create Pos Dur Duplicate")
	public void setUp() {
		InitializeLaunchPad("IBPW_992");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId", "EffectiveDate",
				"StopSaleDate", "TermDate", "AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary",
				"FundingType", "MarketSegment", "ProductType", "StandardStepTherapy", "StandardSafetyEdits",
				"QuantityEdits", "StandardPriorAuth", "DoseComboApplies", "DoseOptimizationApplies", "DGPI",
				"DurPackage", "StepTherapy", "ProgramName" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Create Pos Dur Duplicate", dataProvider = "TestData")
	@Description("Validate Create Pos Dur Duplicate")
	public void ValidatePosDurFilter(String TestCaseID, String TestStatus, String ClientId, String LOBId,
			String StateId, String EffectiveDate, String StopSaleDate, String TermDate, String AutoApply,
			String BusinessEntity, String BusinessUnit, String CDHP, String Formulary, String FundingType,
			String MarketSegment, String ProductType, String StandardStepTherapy, String StandardSafetyEdits,
			String QuantityEdits, String StandardPriorAuth, String DoseComboApplies, String DoseOptimizationApplies,
			String DGPI, String DurPackage, String StepTherapy, String ProgramName)
			throws AWTException, InterruptedException, IOException, ParseException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			netFormulary.clickFormularyViewButton();
			sa.assertTrue(netFormulary.verifyFormularyHeader(), "Verified 'Formularies' header is displayed");

			posdur.verifyPosDurTab();
			posdur.clickPosDurTab();

			posdur.clickOnCreateAPosDur();

			posdur.verifyPosDurHeader();
			posdur.enterPosDurNameDuplicate(ProgramName);
			netFormulary.EnterEffectiveDate(EffectiveDate);
			netFormulary.EnterStopSaleDate(StopSaleDate);
			netFormulary.EnterTermDate(TermDate);

			sa.assertTrue(posdur.selLobdropdown(LOBId), "Verified and selected 'LOB dropdown'");
			sa.assertTrue(posdur.selectStatedropdown(StateId), "Verified and Selected 'State dropdown'");

			sa.assertTrue(posdur.selectClientropdown(ClientId), "Verified and selected 'ClientID dropdown'");
			posdur.clickDynamicLayer();

			sa.assertTrue(mandate.selectFederalAutoApplyDropdown(AutoApply),
					"Verified and Selected 'Auto Apply' dropdown");
			sa.assertTrue(mandate.selectBusinessEntityDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(mandate.selectBusinessUnitDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' dropdown");
			sa.assertTrue(mandate.selectCDHPTypeDropdown(CDHP), "Verified and Selected 'CDHP Type' dropdown");
			sa.assertTrue(mandate.selectFormularyDropdown(Formulary), "Verified and Selected 'Formulary' dropdown");
			sa.assertTrue(mandate.selectFundingTypeDropdown(FundingType),
					"Verified and Selected 'Funding Type' dropdown");
			sa.assertTrue(mandate.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' dropdown");
			sa.assertTrue(mandate.selectProductTypeDropdown(ProductType),
					"Verified and Selected 'Product Type' dropdown");

			sa.assertTrue(posdur.selectStandardStepTherapyDropdown(StandardStepTherapy),
					"Verified and Selected 'Standard Step Therapy' dropdown");
			sa.assertTrue(posdur.selectStandardSafetyEditsDropdown(StandardSafetyEdits),
					"Verified and Selected 'Standard Safety Edit' dropdown");
			sa.assertTrue(posdur.selectQuantityEditsDropdown(QuantityEdits),
					"Verified and Selected 'Quantity Edits' dropdown");
			sa.assertTrue(posdur.selectStandardPriorAuthDropdown(StandardPriorAuth),
					"Verified and Selected 'Standard Prior Auth' dropdown");
			sa.assertTrue(posdur.selectDoseComboAppliesDropdown(DoseComboApplies),
					"Verified and Selected 'Dose Combo Applies' dropdown");
			sa.assertTrue(posdur.selectDoseOptimizationAppliesDropdown(DoseOptimizationApplies),
					"Verified and Selected 'Dose Optimization Applies' dropdown");
			sa.assertTrue(posdur.selectDGPIDropdown(DGPI), "Verified and Selected 'DGPI' dropdown");
			sa.assertTrue(posdur.selectDurPackageDropdown(DurPackage), "Verified and Selected 'Dur Package' dropdown");
			sa.assertTrue(posdur.selectStepTherapyDropdown(StepTherapy),
					"Verified and Selected 'Step Therapy' dropdown");
			posdur.clickAddPosDurButton();
			posdur.verifyErrorTextMessageDuplicate();

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Create Pos Dur Duplicate is  Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Create Pos Dur Duplicate");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

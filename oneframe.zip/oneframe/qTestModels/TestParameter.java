// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TestParameter
{
    @JsonProperty("id")
    private String id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("active")
    private Boolean active;
    @JsonProperty("deleted")
    private Boolean deleted;
    @JsonProperty("clientId")
    private Long clientId;
    @JsonProperty("projectId")
    private Long projectId;
    
    public TestParameter() {
        this.id = null;
        this.name = null;
        this.active = false;
        this.deleted = false;
        this.clientId = null;
        this.projectId = null;
    }
    
    public TestParameter id(final String id) {
        this.id = id;
        return this;
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public TestParameter name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public TestParameter active(final Boolean active) {
        this.active = active;
        return this;
    }
    
    public Boolean getActive() {
        return this.active;
    }
    
    public void setActive(final Boolean active) {
        this.active = active;
    }
    
    public TestParameter deleted(final Boolean deleted) {
        this.deleted = deleted;
        return this;
    }
    
    public Boolean getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(final Boolean deleted) {
        this.deleted = deleted;
    }
    
    public TestParameter clientId(final Long clientId) {
        this.clientId = clientId;
        return this;
    }
    
    public Long getClientId() {
        return this.clientId;
    }
    
    public void setClientId(final Long clientId) {
        this.clientId = clientId;
    }
    
    public TestParameter projectId(final Long projectId) {
        this.projectId = projectId;
        return this;
    }
    
    public Long getProjectId() {
        return this.projectId;
    }
    
    public void setProjectId(final Long projectId) {
        this.projectId = projectId;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final TestParameter testParameter = (TestParameter)o;
        return Objects.equals(this.id, testParameter.id) && Objects.equals(this.name, testParameter.name) && Objects.equals(this.active, testParameter.active) && Objects.equals(this.deleted, testParameter.deleted) && Objects.equals(this.clientId, testParameter.clientId) && Objects.equals(this.projectId, testParameter.projectId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.name, this.active, this.deleted, this.clientId, this.projectId);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class TestParameter {\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    active: ").append(this.toIndentedString(this.active)).append("\n");
        sb.append("    deleted: ").append(this.toIndentedString(this.deleted)).append("\n");
        sb.append("    clientId: ").append(this.toIndentedString(this.clientId)).append("\n");
        sb.append("    projectId: ").append(this.toIndentedString(this.projectId)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

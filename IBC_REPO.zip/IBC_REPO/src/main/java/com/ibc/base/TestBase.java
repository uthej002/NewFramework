package com.ibc.base;

public class TestBase {

}

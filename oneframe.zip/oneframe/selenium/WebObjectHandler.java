// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.Select;
import java.util.Iterator;
import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;
import java.time.Duration;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.By;
import java.util.function.Function;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.WebElement;
import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.JavascriptExecutor;
import anthem.irx.oneframe.core.OneframeContainer;

public class WebObjectHandler extends OneframeContainer
{
    static JavascriptExecutor JSExecutor;
    static Wait<WebDriver> FluentWait;
    static WebDriverWait driverWait;
    
    public static WebDriver getOneframeEventFiringWebDriver() {
        return (WebDriver)WebObjectHandler.oneframeDriver;
    }
    
    @Attachment("Screenshot on demand")
    public static byte[] makeScreenshotOnDemand() {
        if (WebObjectHandler.oneframeDriver == null) {
            return null;
        }
        return (byte[])((TakesScreenshot)WebObjectHandler.oneframeDriver).getScreenshotAs(OutputType.BYTES);
    }
    
    @Attachment("{LogMessage}")
    public static byte[] AttachScreenshotOnDemand(final String LogMessage) {
        if (WebObjectHandler.oneframeDriver == null) {
            return null;
        }
        return (byte[])((TakesScreenshot)WebObjectHandler.oneframeDriver).getScreenshotAs(OutputType.BYTES);
    }
    
    public static String takeScreenshotOnDemand() {
        if (WebObjectHandler.oneframeDriver == null) {
            return "";
        }
        return (String)((TakesScreenshot)WebObjectHandler.oneframeDriver).getScreenshotAs(OutputType.BASE64);
    }
    
    public static WebElement CheckObjectExistence(final WebElement webObject) {
        return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(webObject)));
    }
    
    public static void WaitForObjectToBeInvisible(final By byLocator) {
        GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.invisibilityOfElementLocated(byLocator)));
    }
    
    public static WebElement WaitForObjectToBeClickable(final WebElement webObject) {
        if (GetWebDriverWait().until((Function)ExpectedConditions.not(ExpectedConditions.stalenessOf(webObject))) == null) {
            OneframeContainer.OneframeLogger("[ONEFRAME][CLICK] - Object is stale, script execution may fail");
        }
        try {
            return (WebElement)GetWebDriverWait().until((Function)ExpectedConditions.elementToBeClickable(webObject));
        }
        catch (Throwable TException) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Waiting for object to be clickable> Exception> " + GetObjectInformation(webObject));
            return webObject;
        }
    }
    
    public static WebElement WaitForObjectToBeClickable(final By byLocator) {
        try {
            return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(byLocator)));
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Wait for Clickable>Exception> ");
            return null;
        }
    }
    
    public static boolean ObjectExist(final WebElement webObject) {
        return GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(webObject))) != null;
    }
    
    public static boolean WaitForObject(final WebElement webObject) {
        try {
            if (GetWebDriverWait().until((Function)ExpectedConditions.visibilityOf(webObject)) != null) {
                return true;
            }
        }
        catch (Exception ExcObj) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]FIND-WARNING> Unable to find " + GetObjectInformation(webObject));
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]FIND-EXCEPTION>" + ExcObj.getMessage());
        }
        return false;
    }
    
    public static void WaitForApplicationToLoadCompletely() {
        try {
            GetFluentWebDriverWait().until((Function)ExpectedConditions.invisibilityOfElementLocated(By.id("loading-spinner")));
            GetFluentWebDriverWait().until((Function)IsPageLoadComplete());
            GetFluentWebDriverWait().until((Function)IsJavaScriptProcessingComplete());
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Exception occurred while waiting for Application to complete processing");
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Exception " + E.getMessage());
        }
    }
    
    public static boolean WaitForObjectVisibility(final WebElement webObject) {
        return GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(webObject))) != null;
    }
    
    private static WebDriverWait GetWebDriverWait() {
        if (WebObjectHandler.driverWait == null) {
            WebObjectHandler.driverWait = new WebDriverWait(OneframeContainer.getOneframeWebDriver(), (long)WebObjectHandler.MaxWaitTime, (long)WebObjectHandler.IntervalTime);
        }
        return WebObjectHandler.driverWait;
    }
    
    private static Wait<WebDriver> GetFluentWebDriverWait() {
        if (WebObjectHandler.FluentWait == null) {
            WebObjectHandler.FluentWait = (Wait<WebDriver>)new FluentWait((Object)OneframeContainer.getOneframeWebDriver()).withTimeout(Duration.ofSeconds(WebObjectHandler.MaxWaitTime)).pollingEvery(Duration.ofMillis(WebObjectHandler.IntervalTime)).ignoring((Class)NoSuchElementException.class).ignoring((Class)StaleElementReferenceException.class).ignoring((Class)ElementNotInteractableException.class).ignoring((Class)ElementClickInterceptedException.class).ignoring((Class)UnhandledAlertException.class);
        }
        return WebObjectHandler.FluentWait;
    }
    
    public static ExpectedCondition<Boolean> IsPageLoadComplete() {
        return (ExpectedCondition<Boolean>)(oneframeDriver -> (Boolean)GetJavaScriptExecutorObject().executeScript("return (window.show===false) || (window.show===undefined);", new Object[0]));
    }
    
    public static ExpectedCondition<Boolean> IsJavaScriptProcessingComplete() {
        return (ExpectedCondition<Boolean>)(oneframeDriver -> GetJavaScriptExecutorObject().executeScript("return document.readyState", new Object[0]).equals("complete"));
    }
    
    public static WebElement FindObjectByXpath(final String ObjectKey) {
        try {
            return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.xpath(ObjectKey))));
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
            return null;
        }
    }
    
    public static WebElement FindObjectByClass(final String ObjectKey) {
        try {
            return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.className(ObjectKey))));
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
            return null;
        }
    }
    
    public static WebElement FindObjectByID(final String ObjectKey) {
        try {
            return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.id(ObjectKey))));
        }
        catch (Throwable TException) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + TException.getMessage());
            return null;
        }
    }
    
    public static WebElement FindObjectByLocator(final By byLocator) {
        try {
            return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(byLocator)));
        }
        catch (Throwable TException) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Find by Locator> " + TException.getMessage());
            return null;
        }
    }
    
    public static WebElement FindObjectByLocatorNoWait(final By byLocator) {
        try {
            return WebObjectHandler.oneframeDriver.findElement(byLocator);
        }
        catch (NoSuchElementException E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Find-Exception> No element found");
            return null;
        }
    }
    
    public static boolean elementIsDisplayed(final WebElement ele) {
        try {
            synchronized (WebObjectHandler.oneframeDriver) {
                WebObjectHandler.oneframeDriver.wait(WebObjectHandler.MaxWaitTime);
            }
            return ele.isDisplayed();
        }
        catch (NoSuchElementException e2) {
            return false;
        }
        catch (InterruptedException e) {
            e.printStackTrace();
            return ele.isDisplayed();
        }
    }
    
    public static String ReadTextFromTextBox(final WebElement webObject) {
        String objText = "null";
        if (CheckObjectExistence(webObject) != null) {
            objText = webObject.getAttribute("value");
        }
        return objText;
    }
    
    public static String GetInnerHTML(final WebElement webObject) {
        if (WaitForObject(webObject)) {
            return webObject.getAttribute("innerHTML");
        }
        return "Not Found";
    }
    
    public static void ScrollToElement(final WebElement webObject) {
        WebObjectHandler.glblCurrObjDetails = GetObjectInformation(webObject);
        GetJavaScriptExecutorObject().executeScript("arguments[0].scrollIntoView();", new Object[] { webObject });
        OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Page Scrolling to - " + WebObjectHandler.glblCurrObjDetails);
        OneframeContainer.OneframeLogger("Scrolled to web element -> [" + WebObjectHandler.glblCurrObjDetails + "]");
    }
    
    public static void ScrollToBottomOfthePage() {
        GetJavaScriptExecutorObject().executeScript("window.scrollTo(0, document.body.scrollHeight)", new Object[0]);
    }
    
    public static void ScrollWebPageByPixel(final int pixelCount) {
        GetJavaScriptExecutorObject().executeScript("window.scrollBy(0," + pixelCount + ")", new Object[0]);
        OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Wep page scrolled by " + pixelCount + " pixels");
    }
    
    public static void DragDropWebObject(final WebElement SourceObject, final WebElement TargetObject) {
        final Actions action = new Actions(OneframeContainer.getOneframeWebDriver());
        action.dragAndDrop(SourceObject, TargetObject).build().perform();
    }
    
    public static void EnterTextandTabOut(final WebElement webObject, final String strText) {
        EnterText(webObject, strText);
        webObject.sendKeys(new CharSequence[] { (CharSequence)Keys.TAB });
    }
    
    public static void ClearAndEnterText(final WebElement webObject, final String strText) {
        ClearTextOnInputElement(webObject);
        EnterText(webObject, strText);
    }
    
    public static void ClearTextOnInputElement(final WebElement webObject) {
        CheckObjectExistence(webObject).click();
        try {
            webObject.clear();
        }
        catch (Exception e) {
            OneframeContainer.OneframeLogger("[ONEFRAME][CTPOE] Exception occurred while clearing the text on input field");
            webObject.sendKeys(new CharSequence[] { (CharSequence)Keys.HOME, Keys.chord(new CharSequence[] { (CharSequence)Keys.SHIFT, (CharSequence)Keys.END }), (CharSequence)Keys.DELETE });
        }
        if (!webObject.getAttribute("value").equals("")) {
            webObject.sendKeys(new CharSequence[] { Keys.CONTROL + "a" });
            webObject.sendKeys(new CharSequence[] { (CharSequence)Keys.DELETE });
        }
        while (!webObject.getAttribute("value").equals("")) {
            webObject.sendKeys(new CharSequence[] { (CharSequence)Keys.BACK_SPACE });
        }
    }
    
    public static void EnterText(final WebElement webObject, final String strText) {
        try {
            OneFrameScriptRegulator();
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
        }
        try {
            WebObjectHandler.glblCurrObjDetails = GetObjectInformation(webObject);
            CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
            if (ReadTextFromTextBox(webObject).toLowerCase().equals(strText.toLowerCase())) {
                OneframeContainer.OneframeLogger("Entered text : " + strText);
            }
            else {
                webObject.clear();
                CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
                OneframeContainer.OneframeLogger("RE-Entered text : " + strText);
            }
            OneframeContainer.OneframeLogger("Entered text on Text Field -> [" + WebObjectHandler.glblCurrObjDetails + "]");
        }
        catch (ElementNotInteractableException exception2) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]ENTER-WARNING> Unable to interact with : " + WebObjectHandler.glblCurrObjDetails);
            HandleUnexpectedWindowPopUp();
            try {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH]ENTER-WARNING> Retrying enter action on : " + WebObjectHandler.glblCurrObjDetails);
                CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
                if (ReadTextFromTextBox(webObject).toLowerCase().equals(strText.toLowerCase())) {
                    OneframeContainer.OneframeLogger("Entered text : " + strText);
                }
                else {
                    webObject.clear();
                    CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
                    OneframeContainer.OneframeLogger("RE-Entered text : " + strText);
                }
            }
            catch (Throwable exception3) {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH]ENTER-EXCEPTION> Enter action failed at retry : " + WebObjectHandler.glblCurrObjDetails);
            }
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Exception while entering text : " + exception.getMessage());
        }
    }
    
    public static void EnterPasswordText(final WebElement webObject, final String strText) {
        try {
            OneFrameScriptRegulator();
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
        }
        try {
            CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
            if (webObject.getAttribute("value").toLowerCase().equals(strText.toLowerCase())) {
                OneframeContainer.OneframeLogger("Entered text : Pass*****");
            }
            else {
                webObject.clear();
                CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
                OneframeContainer.OneframeLogger("RE-Entered text : Pass******");
            }
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
        }
    }
    
    public static void EnterTextOnTextArea(final WebElement webObject, final String strText) {
        try {
            OneFrameScriptRegulator();
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
        }
        try {
            WebObjectHandler.glblCurrObjDetails = GetObjectInformation(webObject);
            CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
            if (webObject.getText().toLowerCase().equals(strText.toLowerCase())) {
                OneframeContainer.OneframeLogger("Entered text on Text Area : " + strText);
            }
            else {
                webObject.clear();
                CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
                OneframeContainer.OneframeLogger("RE-Entered text on Text Area : " + strText);
            }
            OneframeContainer.OneframeLogger("Entered text on Text Area Field -> [" + WebObjectHandler.glblCurrObjDetails + "]");
        }
        catch (ElementNotInteractableException exception2) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]ENTER-WARNING> Unable to interact with : " + WebObjectHandler.glblCurrObjDetails);
            HandleUnexpectedWindowPopUp();
            try {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH]ENTER-WARNING> Retrying enter action on : " + WebObjectHandler.glblCurrObjDetails);
                CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
                if (webObject.getText().toLowerCase().equals(strText.toLowerCase())) {
                    OneframeContainer.OneframeLogger("Entered text on Text Area : " + strText);
                }
                else {
                    webObject.clear();
                    CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
                    OneframeContainer.OneframeLogger("RE-Entered text : " + strText);
                }
            }
            catch (Throwable exception3) {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH]ENTER-EXCEPTION> Enter action failed at retry : " + WebObjectHandler.glblCurrObjDetails);
            }
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Exception while entering text : " + exception.getMessage());
        }
    }
    
    public static void ClickWebObject(final WebElement webObject) {
        try {
            OneFrameScriptRegulator();
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH] Regulator Issue : " + E.getMessage());
        }
        WebObjectHandler.glblCurrObjDetails = GetObjectInformation(webObject);
        try {
            if (WebObjectHandler.AngularAppStatus.equalsIgnoreCase("yes")) {
                WaitForAngularJSQueryToComplete();
            }
            WaitForApplicationToLoadCompletely();
            WaitForObjectToBeClickable(webObject).click();
            OneframeContainer.OneframeLogger("Clicked on web element -> [" + WebObjectHandler.glblCurrObjDetails + "]");
        }
        catch (ElementClickInterceptedException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-WARNING> Unable to Click : " + WebObjectHandler.glblCurrObjDetails);
            HandleUnexpectedWindowPopUp();
            try {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-WARNING> Retrying click on : " + WebObjectHandler.glblCurrObjDetails);
                WaitForApplicationToLoadCompletely();
                WaitForObjectToBeClickable(webObject).click();
            }
            catch (Throwable exception2) {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-EXCEPTION> Click action failed at retry : " + WebObjectHandler.glblCurrObjDetails);
            }
        }
        catch (StaleElementReferenceException stException) {
            boolean ClickRetry = true;
            for (int i = 0; i < 3; ++i) {
                if (ClickRetry) {
                    try {
                        OneframeContainer.OneframeLogger("[ONEFRAME][WOH][CLICK] > STALE ELEMENT EXCEPTION > Retry attempt [" + (i + 1) + "]");
                        OneFrameWait(100L);
                        WaitForApplicationToLoadCompletely();
                        WaitForObjectToBeClickable(webObject).click();
                        OneframeContainer.OneframeLogger("Clicked on web element -> [" + WebObjectHandler.glblCurrObjDetails + "]");
                        ClickRetry = false;
                        break;
                    }
                    catch (Throwable exception3) {
                        ClickRetry = true;
                    }
                }
            }
            if (ClickRetry) {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-EXCEPTION> Retry Click action failed after 3 attempts");
            }
        }
    }
    
    private static void RetryClickWebObject(final WebElement webObject) {
    }
    
    public static void ClickWebObject(final By byLocator) {
        try {
            final WebElement webObject = FindObjectByLocator(byLocator);
            WebObjectHandler.glblCurrObjDetails = GetObjectInformation(webObject);
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH] Click-bylocator...found object ->" + WebObjectHandler.glblCurrObjDetails);
            ClickWebObject(webObject);
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-byLocator - Exception>" + E.getMessage());
        }
    }
    
    public static void ClickWebObjectJSE(final WebElement webObject) {
        try {
            OneFrameScriptRegulator();
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH] Regulator Issue : " + E.getMessage());
        }
        WebObjectHandler.glblCurrObjDetails = GetObjectInformation(webObject);
        try {
            if (WebObjectHandler.AngularAppStatus.equalsIgnoreCase("yes")) {
                WaitForAngularJSQueryToComplete();
            }
            WaitForApplicationToLoadCompletely();
            GetJavaScriptExecutorObject().executeScript("arguments[0].click();", new Object[] { webObject });
            OneframeContainer.OneframeLogger("Clicked on web element -> [" + WebObjectHandler.glblCurrObjDetails + "]");
        }
        catch (ElementClickInterceptedException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-WARNING> Unable to Click : " + WebObjectHandler.glblCurrObjDetails);
            HandleUnexpectedWindowPopUp();
            try {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-WARNING> Retrying click on : " + WebObjectHandler.glblCurrObjDetails);
                WaitForApplicationToLoadCompletely();
                GetJavaScriptExecutorObject().executeScript("arguments[0].click();", new Object[] { webObject });
            }
            catch (Throwable exception2) {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-EXCEPTION> Click action failed at retry : " + WebObjectHandler.glblCurrObjDetails);
            }
        }
        catch (StaleElementReferenceException stException) {
            boolean ClickRetry = true;
            for (int i = 0; i < 3; ++i) {
                if (ClickRetry) {
                    try {
                        OneframeContainer.OneframeLogger("[ONEFRAME][WOH][CLICK] > STALE ELEMENT EXCEPTION > Retry attempt [" + (i + 1) + "]");
                        OneFrameWait(100L);
                        WaitForApplicationToLoadCompletely();
                        GetJavaScriptExecutorObject().executeScript("arguments[0].click();", new Object[] { webObject });
                        OneframeContainer.OneframeLogger("Clicked on web element -> [" + WebObjectHandler.glblCurrObjDetails + "]");
                        ClickRetry = false;
                        break;
                    }
                    catch (Throwable exception3) {
                        ClickRetry = true;
                    }
                }
            }
            if (ClickRetry) {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-EXCEPTION> Retry Click action failed after 3 attempts");
            }
        }
    }
    
    public static void ClickWebObjectJSE(final By byLocator) {
        try {
            final WebElement webObject = FindObjectByLocator(byLocator);
            ClickWebObjectJSE(webObject);
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH] CLICK-byLocator - Exception>" + E.getMessage());
        }
    }
    
    public static String GetObjectInformation(final WebElement webObject) {
        if (webObject != null) {
            try {
                String ObjectInformation = "WebElement : {" + webObject.getTagName() + "} | ";
                final List<String> ObjectProperties = new ArrayList<String>(Arrays.asList("id", "name", "class", "type", "text", "value"));
                for (final String ObjectProperty : ObjectProperties) {
                    final String PropertyValue = webObject.getAttribute(ObjectProperty);
                    if (PropertyValue != null && !PropertyValue.isEmpty()) {
                        ObjectInformation = ObjectInformation + "[" + ObjectProperty + "='" + PropertyValue + "'] ";
                    }
                }
                return ObjectInformation;
            }
            catch (Throwable TException) {
                if (!(TException instanceof StaleElementReferenceException)) {
                    OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Get Object Information> Exception> " + TException.getMessage());
                }
                return "Object information not available due to page transition/refresh";
            }
        }
        OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Object is NULL, who called it?");
        return "Object is NULL";
    }
    
    public static void MouseOverToWebElement(final WebElement webObject) {
        WebObjectHandler.glblCurrObjDetails = GetObjectInformation(webObject);
        try {
            if (WaitForObjectVisibility(webObject)) {
                final Actions action = new Actions((WebDriver)WebObjectHandler.oneframeDriver);
                action.moveToElement(webObject).build().perform();
                OneframeContainer.OneframeLogger("Mouse over at " + WebObjectHandler.glblCurrObjDetails);
            }
            else {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH]WARNING> Object not found - " + WebObjectHandler.glblCurrObjDetails);
            }
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]MouseOver > WARNING" + exception.getMessage());
        }
    }
    
    public static void MouseOverAndClickOnWebElement(final WebElement webObject) {
        WebObjectHandler.glblCurrObjDetails = GetObjectInformation(webObject);
        try {
            final Actions action = new Actions((WebDriver)WebObjectHandler.oneframeDriver);
            action.moveToElement(webObject).click().build().perform();
            OneframeContainer.OneframeLogger("Mouse over and Clicked at " + WebObjectHandler.glblCurrObjDetails);
        }
        catch (Throwable TException) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]MouseOver Click> WARNING>" + TException.getMessage());
        }
    }
    
    public static void SelectDropDownListByValue(final WebElement DropDownSelectObject, final String ListValue) {
        ClickWebObject(DropDownSelectObject);
        try {
            final Select dropdownList = new Select(DropDownSelectObject);
            dropdownList.selectByValue(ListValue);
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
        }
    }
    
    public static void SelectDropDownListByValue(final WebElement DropDownObject, final WebElement ULElement, final String LiValue) {
        ClickWebObject(DropDownObject);
        try {
            final List<WebElement> listValues = (List<WebElement>)ULElement.findElements(By.tagName("li"));
            for (final WebElement listValue : listValues) {
                if (listValue.getText().equalsIgnoreCase(LiValue)) {
                    ClickWebObject(listValue);
                }
            }
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
        }
    }
    
    public static void SelectDropDownListByTagName(final WebElement DropDownObject, final WebElement ULElement, final String ElementTagName, final String LiValue) {
        ClickWebObject(DropDownObject);
        try {
            final List<WebElement> listValues = (List<WebElement>)ULElement.findElements(By.tagName(ElementTagName));
            for (final WebElement listValue : listValues) {
                if (listValue.getText().equalsIgnoreCase(LiValue)) {
                    ClickWebObject(listValue);
                }
            }
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
        }
    }
    
    public static void SelectDropDownListByVisibleText(final WebElement DropDownSelectObject, final String ListVisibleText) {
        ClickWebObject(DropDownSelectObject);
        try {
            final Select dropdownList = new Select(DropDownSelectObject);
            dropdownList.selectByVisibleText(ListVisibleText);
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
        }
    }
    
    public static void SelectDropDownListByIndex(final WebElement DropDownSelectObject, final int ListIndex) {
        ClickWebObject(DropDownSelectObject);
        try {
            final Select dropdownList = new Select(DropDownSelectObject);
            dropdownList.selectByIndex(ListIndex);
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
        }
    }
    
    public static void SelectDropDownListByObject(final WebElement DropDownObject, final WebElement ListObject) {
        try {
            ClickWebObject(DropDownObject);
            ClickWebObject(ListObject);
        }
        catch (WebDriverException exception) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
        }
    }
    
    public static String ReadObjectProperty(final WebElement webObject, final String PropertyName) {
        return CheckObjectExistence(webObject).getAttribute(PropertyName);
    }
    
    private static void OneFrameWait(final long WaitTimeMillis) {
        try {
            Thread.sleep(WaitTimeMillis);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    private static void OneFrameScriptRegulator() throws InterruptedException {
        switch (WebObjectHandler.ScriptRegulatorLvl) {
            case 1: {
                Thread.sleep(5L);
                break;
            }
            case 2: {
                Thread.sleep(50L);
                break;
            }
            case 3: {
                Thread.sleep(100L);
                break;
            }
            case 4: {
                Thread.sleep(500L);
                break;
            }
            case 5: {
                Thread.sleep(1000L);
                break;
            }
            default: {
                Thread.sleep(15L);
                break;
            }
        }
    }
    
    public static String getObjectType(String ObjTagTypeName) {
        ObjTagTypeName = ObjTagTypeName.toLowerCase().trim();
        String ObjectType = "UN-IDENTIFIED";
        final String s = ObjTagTypeName;
        switch (s) {
            case "a": {
                ObjectType = "link";
                return ObjectType;
            }
            case "text": {
                ObjectType = "Textbox";
                return ObjectType;
            }
            case "submit": {
                ObjectType = "Submit button";
                return ObjectType;
            }
            default: {
                ObjectType = ObjTagTypeName;
                return ObjectType;
            }
        }
    }
    
    public static void WaitForAngularJSQueryToComplete() {
        AngularJSWait.setDriver(OneframeContainer.getOneframeWebDriver());
        AngularJSWait.waitJQueryAngular();
    }
    
    private static JavascriptExecutor GetJavaScriptExecutorObject() {
        if (WebObjectHandler.JSExecutor == null) {
            WebObjectHandler.JSExecutor = (JavascriptExecutor)OneframeContainer.getOneframeWebDriver();
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Initializing JavaScript Executor Object...");
        }
        return WebObjectHandler.JSExecutor;
    }
    
    private static void HandleUnexpectedWindowPopUp() {
        final String ApplicationKey = OneframeContainer.TSAppEnvKey.substring(0, 6);
        OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Attempting to resolve unexpected popup or blocking web element...");
        if (ApplicationKey.equalsIgnoreCase("RCPWEB") && ObjectExist(FindObjectByXpath("//*[@id='fsrInvite']"))) {
            ClickWebObject(FindObjectByXpath("//*[@id='fsrFocusFirst']"));
            OneframeContainer.OneframeLogger("Closed RCP Customer Feedback popup window");
        }
        if (ApplicationKey.equalsIgnoreCase("IRXWEB")) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Application detected - IngenioRx Member Portal...");
            if (FindObjectByLocatorNoWait(By.className("fsrBanner")) != null) {
                OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Popup/window detected - IngenioRx Customer feedback popup window...");
                if (FindObjectByLocator(By.xpath("//button[@id='fsrFocusFirst']")) != null) {
                    MouseOverAndClickOnWebElement(FindObjectByLocator(By.xpath("//button[@id='fsrFocusFirst']")));
                    OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Closed IngenioRx Customer Feedback popup window");
                }
                else {
                    OneframeContainer.OneframeLogger("Unable to close the target popup/window, script execution may fail");
                }
            }
            else {
                OneframeContainer.OneframeLogger("Uknown popup appeared on the page or unable to click on the object");
            }
        }
    }
    
    public static void closePopupWindow(final String WindowHndlOrString) {
        WebObjectHandler.OFWebDriver.switchTo().window(WindowHndlOrString);
        OneframeContainer.OneframeLogger("Page title of popup window: " + WebObjectHandler.oneframeDriver.getTitle());
        WebObjectHandler.OFWebDriver.close();
        WebObjectHandler.OFWebDriver.switchTo().window(WebObjectHandler.glblcurrWindwHndl);
        OneframeContainer.OneframeLogger("Page title of parent window: " + WebObjectHandler.oneframeDriver.getTitle());
    }
    
    public static void SwitchToWindow(final String WindowTitleOrHandle) {
        WebObjectHandler.OFWebDriver.switchTo().window(WindowTitleOrHandle);
        OneframeContainer.OneframeLogger("Switched to Window with Title: " + WebObjectHandler.OFWebDriver.getTitle());
    }
    
    public static void SwitchToWindowByTitle(final String WindowTitle) {
        WebObjectHandler.OFWebDriver.switchTo().window(WindowTitle);
        OneframeContainer.OneframeLogger("Switched to Window with Title: " + WebObjectHandler.OFWebDriver.getTitle());
    }
    
    public static void SwitchToPreviousWindow() {
    }
    
    public static void PrintCurrentWindowTitleHandle() {
    }
    
    public static void closeUnexpectedPopupWindow() {
        String LastwinHandle = "";
        for (final String winHandle : WebObjectHandler.OFWebDriver.getWindowHandles()) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH][POP_WIND] Available window Handles - " + winHandle);
            LastwinHandle = winHandle;
        }
        try {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH][POP_WIND] Trying to close the unexpected window with Winhandle - " + LastwinHandle);
            WebObjectHandler.OFWebDriver.switchTo().window(LastwinHandle);
            WebObjectHandler.OFWebDriver.close();
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH][POP_WIND]Unexpected popup Window is closed");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        String LastPrevWinHandle = "";
        for (final String winHandle2 : WebObjectHandler.OFWebDriver.getWindowHandles()) {
            OneframeContainer.OneframeLogger("[ONEFRAME][WOH][POP_WIND] Available window Handles after closing the popup window" + winHandle2);
            LastPrevWinHandle = winHandle2;
        }
        try {
            WebObjectHandler.OFWebDriver.switchTo().window(LastPrevWinHandle);
            OneframeContainer.OneframeLogger("Unexpected popup window closed successfully");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static void ResetWebHandlerObjects() {
        WebObjectHandler.JSExecutor = null;
        WebObjectHandler.FluentWait = null;
        WebObjectHandler.driverWait = null;
    }
}

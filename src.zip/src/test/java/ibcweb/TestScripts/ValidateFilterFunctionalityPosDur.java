package ibcweb.TestScripts;
//Naaz 22.2.7

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateFilterFunctionalityPosDur extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;

	@BeforeClass
	@Step("Initializing Test Script for Validating Filter Functionality of Pos Dur")
	public void setUp() {
		InitializeLaunchPad("IBPW_389");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Filter Functionality of Pos Dur", dataProvider = "TestData")
	@Description("Validate Filter Functionality of Pos Dur")
	public void ValidatePosDurFilter(String TestCaseID, String TestStatus, String ClientId, String LOBId,
			String StateId) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			netFormulary.clickFormularyViewButton();
			sa.assertTrue(netFormulary.verifyFormularyHeader(), "Verified 'Formularies' header is displayed");

			posdur.verifyPosDurTab();
			posdur.clickPosDurTab();
			controls.clickFilterButton();
			netFormulary.clickFormulariesHeader();

			String clientId = posdur.selectAndGetClientDropdownValue(ClientId);
			String lobId = posdur.selectAndGetLobFilterDropdownValue(LOBId);
			String stateId = posdur.selectAndGetStateFilterDropdownValue(StateId);

			controls.clickApplyFilterButton();
			netFormulary.clickFormulariesHeader();

			posdur.verifyClientFilteredList(clientId);
			posdur.verifyLobFilteredList(lobId);
			posdur.verifyStateFilteredList(stateId);

			posdur.clickClearFilterButton();
			netFormulary.clickFormulariesHeader();

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Filter Functionality of Pos Dur is  Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Filter Functionality of Pos Dur");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

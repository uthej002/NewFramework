// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import org.joda.time.DateTime;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TestSuite
{
    @JsonProperty("creatorId")
    private Long creatorId;
    @JsonProperty("createdDate")
    private DateTime createdDate;
    @JsonProperty("lastModifiedUserId")
    private Long lastModifiedUserId;
    @JsonProperty("lastModifiedDate")
    private DateTime lastModifiedDate;
    @JsonProperty("displayName")
    private String displayName;
    @JsonProperty("displayDescription")
    private String displayDescription;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("pid")
    private Long pid;
    @JsonProperty("clientId")
    private Long clientId;
    @JsonProperty("projectId")
    private Long projectId;
    @JsonProperty("objOrder")
    private Long objOrder;
    @JsonProperty("name")
    private String name;
    @JsonProperty("testDataSetId")
    private Long testDataSetId;
    @JsonProperty("userId")
    private Long userId;
    @JsonProperty("testBedId")
    private Long testBedId;
    @JsonProperty("projectTestTypeId")
    private Long projectTestTypeId;
    @JsonProperty("plannedStartDate")
    private DateTime plannedStartDate;
    @JsonProperty("plannedEndDate")
    private DateTime plannedEndDate;
    @JsonProperty("description")
    private String description;
    @JsonProperty("releaseId")
    private Long releaseId;
    @JsonProperty("buildId")
    private Long buildId;
    @JsonProperty("testCycleId")
    private Long testCycleId;
    @JsonProperty("testCycle")
    private TestCycle testCycle;
    @JsonProperty("deleted")
    private Boolean deleted;
    @JsonProperty("typeName")
    private String typeName;
    @JsonProperty("objectType")
    private Long objectType;
    @JsonProperty("artifactType")
    private Integer artifactType;
    @JsonProperty("resultDescription")
    private String resultDescription;
    @JsonProperty("shortResultType")
    private String shortResultType;
    @JsonProperty("parentArtifactId")
    private Long parentArtifactId;
    @JsonProperty("resultType")
    private String resultType;
    @JsonProperty("fullId")
    private String fullId;
    @JsonProperty("resultName")
    private String resultName;
    @JsonProperty("parentObjectType")
    private Long parentObjectType;
    @JsonProperty("statusId")
    private Long statusId;
    @JsonProperty("pidWithPrefix")
    private String pidWithPrefix;
    @JsonProperty("longId")
    private Long longId;
    @JsonProperty("customFieldValue")
    private String customFieldValue;
    @JsonProperty("approved")
    private Boolean approved;
    @JsonProperty("automation")
    private Boolean automation;
    
    public TestSuite() {
        this.creatorId = null;
        this.createdDate = null;
        this.lastModifiedUserId = null;
        this.lastModifiedDate = null;
        this.displayName = null;
        this.displayDescription = null;
        this.id = null;
        this.pid = null;
        this.clientId = null;
        this.projectId = null;
        this.objOrder = null;
        this.name = null;
        this.testDataSetId = null;
        this.userId = null;
        this.testBedId = null;
        this.projectTestTypeId = null;
        this.plannedStartDate = null;
        this.plannedEndDate = null;
        this.description = null;
        this.releaseId = null;
        this.buildId = null;
        this.testCycleId = null;
        this.testCycle = null;
        this.deleted = false;
        this.typeName = null;
        this.objectType = null;
        this.artifactType = null;
        this.resultDescription = null;
        this.shortResultType = null;
        this.parentArtifactId = null;
        this.resultType = null;
        this.fullId = null;
        this.resultName = null;
        this.parentObjectType = null;
        this.statusId = null;
        this.pidWithPrefix = null;
        this.longId = null;
        this.customFieldValue = null;
        this.approved = false;
        this.automation = false;
    }
    
    public TestSuite creatorId(final Long creatorId) {
        this.creatorId = creatorId;
        return this;
    }
    
    public Long getCreatorId() {
        return this.creatorId;
    }
    
    public void setCreatorId(final Long creatorId) {
        this.creatorId = creatorId;
    }
    
    public TestSuite createdDate(final DateTime createdDate) {
        this.createdDate = createdDate;
        return this;
    }
    
    public DateTime getCreatedDate() {
        return this.createdDate;
    }
    
    public void setCreatedDate(final DateTime createdDate) {
        this.createdDate = createdDate;
    }
    
    public TestSuite lastModifiedUserId(final Long lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
        return this;
    }
    
    public Long getLastModifiedUserId() {
        return this.lastModifiedUserId;
    }
    
    public void setLastModifiedUserId(final Long lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }
    
    public TestSuite lastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
        return this;
    }
    
    public DateTime getLastModifiedDate() {
        return this.lastModifiedDate;
    }
    
    public void setLastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
    
    public TestSuite displayName(final String displayName) {
        this.displayName = displayName;
        return this;
    }
    
    public String getDisplayName() {
        return this.displayName;
    }
    
    public void setDisplayName(final String displayName) {
        this.displayName = displayName;
    }
    
    public TestSuite displayDescription(final String displayDescription) {
        this.displayDescription = displayDescription;
        return this;
    }
    
    public String getDisplayDescription() {
        return this.displayDescription;
    }
    
    public void setDisplayDescription(final String displayDescription) {
        this.displayDescription = displayDescription;
    }
    
    public TestSuite id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public TestSuite pid(final Long pid) {
        this.pid = pid;
        return this;
    }
    
    public Long getPid() {
        return this.pid;
    }
    
    public void setPid(final Long pid) {
        this.pid = pid;
    }
    
    public TestSuite clientId(final Long clientId) {
        this.clientId = clientId;
        return this;
    }
    
    public Long getClientId() {
        return this.clientId;
    }
    
    public void setClientId(final Long clientId) {
        this.clientId = clientId;
    }
    
    public TestSuite projectId(final Long projectId) {
        this.projectId = projectId;
        return this;
    }
    
    public Long getProjectId() {
        return this.projectId;
    }
    
    public void setProjectId(final Long projectId) {
        this.projectId = projectId;
    }
    
    public TestSuite objOrder(final Long objOrder) {
        this.objOrder = objOrder;
        return this;
    }
    
    public Long getObjOrder() {
        return this.objOrder;
    }
    
    public void setObjOrder(final Long objOrder) {
        this.objOrder = objOrder;
    }
    
    public TestSuite name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public TestSuite testDataSetId(final Long testDataSetId) {
        this.testDataSetId = testDataSetId;
        return this;
    }
    
    public Long getTestDataSetId() {
        return this.testDataSetId;
    }
    
    public void setTestDataSetId(final Long testDataSetId) {
        this.testDataSetId = testDataSetId;
    }
    
    public TestSuite userId(final Long userId) {
        this.userId = userId;
        return this;
    }
    
    public Long getUserId() {
        return this.userId;
    }
    
    public void setUserId(final Long userId) {
        this.userId = userId;
    }
    
    public TestSuite testBedId(final Long testBedId) {
        this.testBedId = testBedId;
        return this;
    }
    
    public Long getTestBedId() {
        return this.testBedId;
    }
    
    public void setTestBedId(final Long testBedId) {
        this.testBedId = testBedId;
    }
    
    public TestSuite projectTestTypeId(final Long projectTestTypeId) {
        this.projectTestTypeId = projectTestTypeId;
        return this;
    }
    
    public Long getProjectTestTypeId() {
        return this.projectTestTypeId;
    }
    
    public void setProjectTestTypeId(final Long projectTestTypeId) {
        this.projectTestTypeId = projectTestTypeId;
    }
    
    public TestSuite plannedStartDate(final DateTime plannedStartDate) {
        this.plannedStartDate = plannedStartDate;
        return this;
    }
    
    public DateTime getPlannedStartDate() {
        return this.plannedStartDate;
    }
    
    public void setPlannedStartDate(final DateTime plannedStartDate) {
        this.plannedStartDate = plannedStartDate;
    }
    
    public TestSuite plannedEndDate(final DateTime plannedEndDate) {
        this.plannedEndDate = plannedEndDate;
        return this;
    }
    
    public DateTime getPlannedEndDate() {
        return this.plannedEndDate;
    }
    
    public void setPlannedEndDate(final DateTime plannedEndDate) {
        this.plannedEndDate = plannedEndDate;
    }
    
    public TestSuite description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public TestSuite releaseId(final Long releaseId) {
        this.releaseId = releaseId;
        return this;
    }
    
    public Long getReleaseId() {
        return this.releaseId;
    }
    
    public void setReleaseId(final Long releaseId) {
        this.releaseId = releaseId;
    }
    
    public TestSuite buildId(final Long buildId) {
        this.buildId = buildId;
        return this;
    }
    
    public Long getBuildId() {
        return this.buildId;
    }
    
    public void setBuildId(final Long buildId) {
        this.buildId = buildId;
    }
    
    public TestSuite testCycleId(final Long testCycleId) {
        this.testCycleId = testCycleId;
        return this;
    }
    
    public Long getTestCycleId() {
        return this.testCycleId;
    }
    
    public void setTestCycleId(final Long testCycleId) {
        this.testCycleId = testCycleId;
    }
    
    public TestSuite testCycle(final TestCycle testCycle) {
        this.testCycle = testCycle;
        return this;
    }
    
    public TestCycle getTestCycle() {
        return this.testCycle;
    }
    
    public void setTestCycle(final TestCycle testCycle) {
        this.testCycle = testCycle;
    }
    
    public TestSuite deleted(final Boolean deleted) {
        this.deleted = deleted;
        return this;
    }
    
    public Boolean getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(final Boolean deleted) {
        this.deleted = deleted;
    }
    
    public TestSuite typeName(final String typeName) {
        this.typeName = typeName;
        return this;
    }
    
    public String getTypeName() {
        return this.typeName;
    }
    
    public void setTypeName(final String typeName) {
        this.typeName = typeName;
    }
    
    public TestSuite objectType(final Long objectType) {
        this.objectType = objectType;
        return this;
    }
    
    public Long getObjectType() {
        return this.objectType;
    }
    
    public void setObjectType(final Long objectType) {
        this.objectType = objectType;
    }
    
    public TestSuite artifactType(final Integer artifactType) {
        this.artifactType = artifactType;
        return this;
    }
    
    public Integer getArtifactType() {
        return this.artifactType;
    }
    
    public void setArtifactType(final Integer artifactType) {
        this.artifactType = artifactType;
    }
    
    public TestSuite resultDescription(final String resultDescription) {
        this.resultDescription = resultDescription;
        return this;
    }
    
    public String getResultDescription() {
        return this.resultDescription;
    }
    
    public void setResultDescription(final String resultDescription) {
        this.resultDescription = resultDescription;
    }
    
    public TestSuite shortResultType(final String shortResultType) {
        this.shortResultType = shortResultType;
        return this;
    }
    
    public String getShortResultType() {
        return this.shortResultType;
    }
    
    public void setShortResultType(final String shortResultType) {
        this.shortResultType = shortResultType;
    }
    
    public TestSuite parentArtifactId(final Long parentArtifactId) {
        this.parentArtifactId = parentArtifactId;
        return this;
    }
    
    public Long getParentArtifactId() {
        return this.parentArtifactId;
    }
    
    public void setParentArtifactId(final Long parentArtifactId) {
        this.parentArtifactId = parentArtifactId;
    }
    
    public TestSuite resultType(final String resultType) {
        this.resultType = resultType;
        return this;
    }
    
    public String getResultType() {
        return this.resultType;
    }
    
    public void setResultType(final String resultType) {
        this.resultType = resultType;
    }
    
    public TestSuite fullId(final String fullId) {
        this.fullId = fullId;
        return this;
    }
    
    public String getFullId() {
        return this.fullId;
    }
    
    public void setFullId(final String fullId) {
        this.fullId = fullId;
    }
    
    public TestSuite resultName(final String resultName) {
        this.resultName = resultName;
        return this;
    }
    
    public String getResultName() {
        return this.resultName;
    }
    
    public void setResultName(final String resultName) {
        this.resultName = resultName;
    }
    
    public TestSuite parentObjectType(final Long parentObjectType) {
        this.parentObjectType = parentObjectType;
        return this;
    }
    
    public Long getParentObjectType() {
        return this.parentObjectType;
    }
    
    public void setParentObjectType(final Long parentObjectType) {
        this.parentObjectType = parentObjectType;
    }
    
    public TestSuite statusId(final Long statusId) {
        this.statusId = statusId;
        return this;
    }
    
    public Long getStatusId() {
        return this.statusId;
    }
    
    public void setStatusId(final Long statusId) {
        this.statusId = statusId;
    }
    
    public TestSuite pidWithPrefix(final String pidWithPrefix) {
        this.pidWithPrefix = pidWithPrefix;
        return this;
    }
    
    public String getPidWithPrefix() {
        return this.pidWithPrefix;
    }
    
    public void setPidWithPrefix(final String pidWithPrefix) {
        this.pidWithPrefix = pidWithPrefix;
    }
    
    public TestSuite longId(final Long longId) {
        this.longId = longId;
        return this;
    }
    
    public Long getLongId() {
        return this.longId;
    }
    
    public void setLongId(final Long longId) {
        this.longId = longId;
    }
    
    public TestSuite customFieldValue(final String customFieldValue) {
        this.customFieldValue = customFieldValue;
        return this;
    }
    
    public String getCustomFieldValue() {
        return this.customFieldValue;
    }
    
    public void setCustomFieldValue(final String customFieldValue) {
        this.customFieldValue = customFieldValue;
    }
    
    public TestSuite approved(final Boolean approved) {
        this.approved = approved;
        return this;
    }
    
    public Boolean getApproved() {
        return this.approved;
    }
    
    public void setApproved(final Boolean approved) {
        this.approved = approved;
    }
    
    public TestSuite automation(final Boolean automation) {
        this.automation = automation;
        return this;
    }
    
    public Boolean getAutomation() {
        return this.automation;
    }
    
    public void setAutomation(final Boolean automation) {
        this.automation = automation;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final TestSuite testSuite = (TestSuite)o;
        return Objects.equals(this.creatorId, testSuite.creatorId) && Objects.equals(this.createdDate, testSuite.createdDate) && Objects.equals(this.lastModifiedUserId, testSuite.lastModifiedUserId) && Objects.equals(this.lastModifiedDate, testSuite.lastModifiedDate) && Objects.equals(this.displayName, testSuite.displayName) && Objects.equals(this.displayDescription, testSuite.displayDescription) && Objects.equals(this.id, testSuite.id) && Objects.equals(this.pid, testSuite.pid) && Objects.equals(this.clientId, testSuite.clientId) && Objects.equals(this.projectId, testSuite.projectId) && Objects.equals(this.objOrder, testSuite.objOrder) && Objects.equals(this.name, testSuite.name) && Objects.equals(this.testDataSetId, testSuite.testDataSetId) && Objects.equals(this.userId, testSuite.userId) && Objects.equals(this.testBedId, testSuite.testBedId) && Objects.equals(this.projectTestTypeId, testSuite.projectTestTypeId) && Objects.equals(this.plannedStartDate, testSuite.plannedStartDate) && Objects.equals(this.plannedEndDate, testSuite.plannedEndDate) && Objects.equals(this.description, testSuite.description) && Objects.equals(this.releaseId, testSuite.releaseId) && Objects.equals(this.buildId, testSuite.buildId) && Objects.equals(this.testCycleId, testSuite.testCycleId) && Objects.equals(this.testCycle, testSuite.testCycle) && Objects.equals(this.deleted, testSuite.deleted) && Objects.equals(this.typeName, testSuite.typeName) && Objects.equals(this.objectType, testSuite.objectType) && Objects.equals(this.artifactType, testSuite.artifactType) && Objects.equals(this.resultDescription, testSuite.resultDescription) && Objects.equals(this.shortResultType, testSuite.shortResultType) && Objects.equals(this.parentArtifactId, testSuite.parentArtifactId) && Objects.equals(this.resultType, testSuite.resultType) && Objects.equals(this.fullId, testSuite.fullId) && Objects.equals(this.resultName, testSuite.resultName) && Objects.equals(this.parentObjectType, testSuite.parentObjectType) && Objects.equals(this.statusId, testSuite.statusId) && Objects.equals(this.pidWithPrefix, testSuite.pidWithPrefix) && Objects.equals(this.longId, testSuite.longId) && Objects.equals(this.customFieldValue, testSuite.customFieldValue) && Objects.equals(this.approved, testSuite.approved) && Objects.equals(this.automation, testSuite.automation);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.creatorId, this.createdDate, this.lastModifiedUserId, this.lastModifiedDate, this.displayName, this.displayDescription, this.id, this.pid, this.clientId, this.projectId, this.objOrder, this.name, this.testDataSetId, this.userId, this.testBedId, this.projectTestTypeId, this.plannedStartDate, this.plannedEndDate, this.description, this.releaseId, this.buildId, this.testCycleId, this.testCycle, this.deleted, this.typeName, this.objectType, this.artifactType, this.resultDescription, this.shortResultType, this.parentArtifactId, this.resultType, this.fullId, this.resultName, this.parentObjectType, this.statusId, this.pidWithPrefix, this.longId, this.customFieldValue, this.approved, this.automation);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class TestSuite {\n");
        sb.append("    creatorId: ").append(this.toIndentedString(this.creatorId)).append("\n");
        sb.append("    createdDate: ").append(this.toIndentedString(this.createdDate)).append("\n");
        sb.append("    lastModifiedUserId: ").append(this.toIndentedString(this.lastModifiedUserId)).append("\n");
        sb.append("    lastModifiedDate: ").append(this.toIndentedString(this.lastModifiedDate)).append("\n");
        sb.append("    displayName: ").append(this.toIndentedString(this.displayName)).append("\n");
        sb.append("    displayDescription: ").append(this.toIndentedString(this.displayDescription)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    pid: ").append(this.toIndentedString(this.pid)).append("\n");
        sb.append("    clientId: ").append(this.toIndentedString(this.clientId)).append("\n");
        sb.append("    projectId: ").append(this.toIndentedString(this.projectId)).append("\n");
        sb.append("    objOrder: ").append(this.toIndentedString(this.objOrder)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    testDataSetId: ").append(this.toIndentedString(this.testDataSetId)).append("\n");
        sb.append("    userId: ").append(this.toIndentedString(this.userId)).append("\n");
        sb.append("    testBedId: ").append(this.toIndentedString(this.testBedId)).append("\n");
        sb.append("    projectTestTypeId: ").append(this.toIndentedString(this.projectTestTypeId)).append("\n");
        sb.append("    plannedStartDate: ").append(this.toIndentedString(this.plannedStartDate)).append("\n");
        sb.append("    plannedEndDate: ").append(this.toIndentedString(this.plannedEndDate)).append("\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("    releaseId: ").append(this.toIndentedString(this.releaseId)).append("\n");
        sb.append("    buildId: ").append(this.toIndentedString(this.buildId)).append("\n");
        sb.append("    testCycleId: ").append(this.toIndentedString(this.testCycleId)).append("\n");
        sb.append("    testCycle: ").append(this.toIndentedString(this.testCycle)).append("\n");
        sb.append("    deleted: ").append(this.toIndentedString(this.deleted)).append("\n");
        sb.append("    typeName: ").append(this.toIndentedString(this.typeName)).append("\n");
        sb.append("    objectType: ").append(this.toIndentedString(this.objectType)).append("\n");
        sb.append("    artifactType: ").append(this.toIndentedString(this.artifactType)).append("\n");
        sb.append("    resultDescription: ").append(this.toIndentedString(this.resultDescription)).append("\n");
        sb.append("    shortResultType: ").append(this.toIndentedString(this.shortResultType)).append("\n");
        sb.append("    parentArtifactId: ").append(this.toIndentedString(this.parentArtifactId)).append("\n");
        sb.append("    resultType: ").append(this.toIndentedString(this.resultType)).append("\n");
        sb.append("    fullId: ").append(this.toIndentedString(this.fullId)).append("\n");
        sb.append("    resultName: ").append(this.toIndentedString(this.resultName)).append("\n");
        sb.append("    parentObjectType: ").append(this.toIndentedString(this.parentObjectType)).append("\n");
        sb.append("    statusId: ").append(this.toIndentedString(this.statusId)).append("\n");
        sb.append("    pidWithPrefix: ").append(this.toIndentedString(this.pidWithPrefix)).append("\n");
        sb.append("    longId: ").append(this.toIndentedString(this.longId)).append("\n");
        sb.append("    customFieldValue: ").append(this.toIndentedString(this.customFieldValue)).append("\n");
        sb.append("    approved: ").append(this.toIndentedString(this.approved)).append("\n");
        sb.append("    automation: ").append(this.toIndentedString(this.automation)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

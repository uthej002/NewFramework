// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.By;
import anthem.irx.oneframe.core.OneframeContainer;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.AbstractWebDriverEventListener;

public class WebObjectActionListener extends AbstractWebDriverEventListener
{
    public static WebElement CurrentWebElement;
    public static String CurrentAction;
    public static String CurrentActionValue;
    public static int ErrorHandlerFlag;
    public static int ALCounter;
    
    public void beforeAlertAccept(final WebDriver driver) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Alert Displayed" + driver.toString());
    }
    
    public void afterAlertAccept(final WebDriver driver) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Alert accepted" + driver.toString());
    }
    
    public void afterAlertDismiss(final WebDriver driver) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Alert dismissed" + driver.toString());
    }
    
    public void beforeAlertDismiss(final WebDriver driver) {
    }
    
    public void beforeNavigateTo(final String url, final WebDriver driver) {
        if (driver.getTitle() == null) {
            final String PageTitleOrURL = driver.getCurrentUrl();
        }
        else {
            final String PageTitleOrURL = driver.getTitle();
        }
        OneframeContainer.OneframeLogger("Navigating to [ " + url + " ]");
    }
    
    public void afterNavigateTo(final String url, final WebDriver driver) {
        String PageTitleOrURL;
        if (driver.getTitle() == null) {
            PageTitleOrURL = driver.getCurrentUrl();
        }
        else {
            PageTitleOrURL = driver.getTitle();
        }
        OneframeContainer.OneframeLogger(PageTitleOrURL + " Page is displayed");
        WebObjectHandler.AttachScreenshotOnDemand(PageTitleOrURL);
    }
    
    public void beforeNavigateBack(final WebDriver driver) {
        OneframeContainer.OneframeLogger(" Navigating back to - " + driver.getTitle());
    }
    
    public void afterNavigateBack(final WebDriver driver) {
        OneframeContainer.OneframeLogger(driver.getTitle() + " page is displayed");
    }
    
    public void beforeNavigateForward(final WebDriver driver) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] - before Navigate forward ] - " + driver.toString());
    }
    
    public void afterNavigateForward(final WebDriver driver) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] - after Navigate forward ] - " + driver.toString());
    }
    
    public void beforeNavigateRefresh(final WebDriver driver) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] - before page refresh ] - " + driver.toString());
    }
    
    public void afterNavigateRefresh(final WebDriver driver) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] - After page refresh ] - " + driver.toString());
    }
    
    public void beforeFindBy(final By by, final WebElement element, final WebDriver driver) {
        this.StoreCurrentElementAndAction(element, "FIND");
    }
    
    public void afterFindBy(final By by, final WebElement element, final WebDriver driver) {
        this.StoreCurrentElementAndAction(element, "FIND");
    }
    
    public void beforeClickOn(final WebElement element, final WebDriver driver) {
        highlightElement(element);
        this.StoreCurrentElementAndAction(element, "CLICK");
    }
    
    public void afterClickOn(final WebElement element, final WebDriver driver) {
        this.StoreCurrentElementAndAction(element, "CLICK");
    }
    
    public void beforeChangeValueOf(final WebElement element, final WebDriver driver, final CharSequence[] keysToSend) {
        this.StoreCurrentElementAndAction(element, "ENTER");
        WebObjectActionListener.CurrentActionValue = keysToSend.toString();
    }
    
    public void afterChangeValueOf(final WebElement element, final WebDriver driver, final CharSequence[] keysToSend) {
        highlightElement(element);
        this.StoreCurrentElementAndAction(element, "ENTER");
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener][Text Entered] = '" + element.getAttribute("value") + "' on " + element.getAttribute("type") + " field > " + element.getAttribute("id"));
    }
    
    public void beforeScript(final String script, final WebDriver driver) {
    }
    
    public void afterScript(final String script, final WebDriver driver) {
    }
    
    public void beforeSwitchToWindow(final String windowName, final WebDriver driver) {
        OneframeContainer.glblPrevWindwHndl = driver.getWindowHandle();
    }
    
    public void afterSwitchToWindow(final String windowName, final WebDriver driver) {
        OneframeContainer.glblcurrWindwHndl = driver.getWindowHandle();
    }
    
    public <X> void beforeGetScreenshotAs(final OutputType<X> target) {
    }
    
    public <X> void afterGetScreenshotAs(final OutputType<X> target, final X screenshot) {
    }
    
    public void beforeGetText(final WebElement element, final WebDriver driver) {
        this.StoreCurrentElementAndAction(element, "GetText");
    }
    
    public void afterGetText(final WebElement element, final WebDriver driver, final String text) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Read text from web element ID : [" + WebObjectHandler.GetObjectInformation(element) + "] Text : " + text);
    }
    
    public void onException(final Throwable throwable, final WebDriver driver) {
        if (throwable instanceof NoSuchElementException) {}
        if (throwable instanceof StaleElementReferenceException) {}
        if (throwable instanceof TimeoutException) {}
        if (throwable instanceof WebDriverException) {}
        if (throwable instanceof UnhandledAlertException) {
            OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] An Alert box poped up and was not handled by the script");
        }
        if (throwable instanceof ElementClickInterceptedException) {
            OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Click Intercepted> " + throwable.getMessage());
        }
        if (throwable instanceof ElementNotInteractableException) {
            OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Element Not Interactable> " + throwable.getMessage());
        }
        if (throwable instanceof Exception) {}
    }
    
    private void StoreCurrentElementAndAction(final WebElement webObject, final String WebAction) {
        WebObjectActionListener.CurrentWebElement = webObject;
        WebObjectActionListener.CurrentAction = WebAction;
    }
    
    private void HandleUnexpectedWindowPopUp() {
        final String ApplicationKey = OneframeContainer.TSAppEnvKey.substring(0, 6);
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Attempting to resolve unexpected popup or blocking web element...");
        if (ApplicationKey.equalsIgnoreCase("RCPWEB") && WebObjectHandler.ObjectExist(WebObjectHandler.FindObjectByXpath("//*[@id='fsrInvite']"))) {
            WebObjectHandler.ClickWebObject(WebObjectHandler.FindObjectByXpath("//*[@id='fsrFocusFirst']"));
            OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Closed RCP Customer Feedback popup window");
        }
        if (ApplicationKey.equalsIgnoreCase("IRXWEB")) {
            OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Application detected - IngenioRx Member Portal...");
            if (WebObjectHandler.FindObjectByLocatorNoWait(By.className("fsrBanner")) != null) {
                OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Popup/window detected - IngenioRx Customer feedback popup window...");
                if (WebObjectHandler.FindObjectByLocator(By.xpath("//button[@id='fsrFocusFirst']")) != null) {
                    WebObjectHandler.MouseOverAndClickOnWebElement(WebObjectHandler.FindObjectByLocatorNoWait(By.xpath("//button[@id='fsrFocusFirst']")));
                    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Closed IngenioRx Customer Feedback popup window");
                }
                else {
                    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Unable to close the target popup/window, script execution may fail");
                }
            }
            else {
                OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Uknown popup appeared on the page or unable to click on the object");
            }
        }
    }
    
    private void DismissAlertOnWebBrowser() {
        final Dimension window = OneframeContainer.oneframeDriver.manage().window().getSize();
        new Actions((WebDriver)OneframeContainer.oneframeDriver).moveByOffset(window.getHeight() / 2, window.getWidth() / 2).click().sendKeys(new CharSequence[] { (CharSequence)Keys.ESCAPE }).build().perform();
    }
    
    private void ClickOnIRXApplicationTopBanner() {
        WebObjectHandler.ClickWebObject(WebObjectHandler.FindObjectByXpath("//*[@id='mbr-page-wrapper']/data-top-of-page-cmp/div/div[1]/div/div[2]"));
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Avoided the popup window...");
    }
    
    public static void highlightElement(final WebElement webObject) {
        final String originalStyle = webObject.getAttribute("style");
        try {
            final JavascriptExecutor js = (JavascriptExecutor)OneframeContainer.oneframeDriver;
            js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])", new Object[] { webObject, "style", originalStyle + "border: 2px solid red;" });
            WebObjectHandler.makeScreenshotOnDemand();
            js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])", new Object[] { webObject, "style", originalStyle });
        }
        catch (Throwable t) {
            OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Exception occurred while highighting : " + t.getMessage());
        }
    }
    
    static {
        WebObjectActionListener.ErrorHandlerFlag = 0;
        WebObjectActionListener.ALCounter = 0;
    }
}

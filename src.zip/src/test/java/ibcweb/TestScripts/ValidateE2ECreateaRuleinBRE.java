package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateE2ECreateaRuleinBRE extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Add Rule Button")
	public void setUp() {
		InitializeLaunchPad("IBPW_17");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "RuleName", "Description", "Message", "StartDate",
				"EndDate", "ClientId", "LOBId", "StateId", "DType" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate Add Rule Button", dataProvider = "TestData")
	@Description("Validate Add Rule Button")
	public void ValidateCreateaRuleinBRE(String TestCaseID, String TestStatus, String RuleName, String Description,
			String Message, String StartDate, String EndDate,String ClientId, String LOBId, String StateId, String DType) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();
			sa.assertTrue(addrulepage.verifyCreateaRuleHeader(),"Verified Create a Rule Header is displayed");
			addrulepage.EnterRuleName(RuleName);
			addrulepage.EnterDescription(Description);
			addrulepage.EnterMessage(Message);
			addrulepage.EnterStartDate(StartDate);
			addrulepage.EnterEndDate(EndDate);			
			addrulepage.selectClientIdDropdown(ClientId);
			addrulepage.selectLobIdDropdown(LOBId);
			addrulepage.selectStateIdDropdown(StateId);
			addrulepage.clickAddButton();
			sa.assertTrue(addrulepage.selectLibraryDropdown(), "Library Dropdown has been selected");
			sa.assertTrue(addrulepage.selectPropertyDropdown(), "Property Dropdown has been selected");
			sa.assertTrue(addrulepage.selectOperatorDropdown(), "Operator Dropdown has been selected");
			sa.assertTrue(addrulepage.selectRHSDropdown(), "RHS Dropdown has been selected");	
			addrulepage.selectDecisionTypeDropdown(DType);		
			addrulepage.VerifyAddRuleButton();
			addrulepage.ClickAddRuleButton();
			sa.assertTrue(rulebuilderstaging.verifyRuleIDTitleDisplay(), "Verified Rule ID Title is displayed");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger(" Create a Rule validation is successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Create a rule Validation is unsuccessful");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

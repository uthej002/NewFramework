// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
import org.joda.time.DateTime;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TestCycle
{
    @JsonProperty("creatorId")
    private Long creatorId;
    @JsonProperty("createdDate")
    private DateTime createdDate;
    @JsonProperty("lastModifiedUserId")
    private Long lastModifiedUserId;
    @JsonProperty("lastModifiedDate")
    private DateTime lastModifiedDate;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("pid")
    private Long pid;
    @JsonProperty("parentTestCycleId")
    private Long parentTestCycleId;
    @JsonProperty("objOrder")
    private Long objOrder;
    @JsonProperty("name")
    private String name;
    @JsonProperty("clientId")
    private Long clientId;
    @JsonProperty("testCycleType")
    private Integer testCycleType;
    @JsonProperty("releaseId")
    private Long releaseId;
    @JsonProperty("buildId")
    private Long buildId;
    @JsonProperty("projectId")
    private Long projectId;
    @JsonProperty("deleted")
    private Boolean deleted;
    @JsonProperty("description")
    private String description;
    @JsonProperty("startDate")
    private DateTime startDate;
    @JsonProperty("endDate")
    private DateTime endDate;
    @JsonProperty("subCycles")
    private List<TestCycle> subCycles;
    @JsonProperty("objectType")
    private Long objectType;
    @JsonProperty("longId")
    private Long longId;
    @JsonProperty("artifactType")
    private Integer artifactType;
    @JsonProperty("parentArtifactId")
    private Long parentArtifactId;
    @JsonProperty("parentObjectType")
    private Long parentObjectType;
    @JsonProperty("statusId")
    private Long statusId;
    @JsonProperty("pidWithPrefix")
    private String pidWithPrefix;
    
    public TestCycle() {
        this.creatorId = null;
        this.createdDate = null;
        this.lastModifiedUserId = null;
        this.lastModifiedDate = null;
        this.id = null;
        this.pid = null;
        this.parentTestCycleId = null;
        this.objOrder = null;
        this.name = null;
        this.clientId = null;
        this.testCycleType = null;
        this.releaseId = null;
        this.buildId = null;
        this.projectId = null;
        this.deleted = false;
        this.description = null;
        this.startDate = null;
        this.endDate = null;
        this.subCycles = new ArrayList<TestCycle>();
        this.objectType = null;
        this.longId = null;
        this.artifactType = null;
        this.parentArtifactId = null;
        this.parentObjectType = null;
        this.statusId = null;
        this.pidWithPrefix = null;
    }
    
    public TestCycle creatorId(final Long creatorId) {
        this.creatorId = creatorId;
        return this;
    }
    
    public Long getCreatorId() {
        return this.creatorId;
    }
    
    public void setCreatorId(final Long creatorId) {
        this.creatorId = creatorId;
    }
    
    public TestCycle createdDate(final DateTime createdDate) {
        this.createdDate = createdDate;
        return this;
    }
    
    public DateTime getCreatedDate() {
        return this.createdDate;
    }
    
    public void setCreatedDate(final DateTime createdDate) {
        this.createdDate = createdDate;
    }
    
    public TestCycle lastModifiedUserId(final Long lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
        return this;
    }
    
    public Long getLastModifiedUserId() {
        return this.lastModifiedUserId;
    }
    
    public void setLastModifiedUserId(final Long lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }
    
    public TestCycle lastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
        return this;
    }
    
    public DateTime getLastModifiedDate() {
        return this.lastModifiedDate;
    }
    
    public void setLastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
    
    public TestCycle id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public TestCycle pid(final Long pid) {
        this.pid = pid;
        return this;
    }
    
    public Long getPid() {
        return this.pid;
    }
    
    public void setPid(final Long pid) {
        this.pid = pid;
    }
    
    public TestCycle parentTestCycleId(final Long parentTestCycleId) {
        this.parentTestCycleId = parentTestCycleId;
        return this;
    }
    
    public Long getParentTestCycleId() {
        return this.parentTestCycleId;
    }
    
    public void setParentTestCycleId(final Long parentTestCycleId) {
        this.parentTestCycleId = parentTestCycleId;
    }
    
    public TestCycle objOrder(final Long objOrder) {
        this.objOrder = objOrder;
        return this;
    }
    
    public Long getObjOrder() {
        return this.objOrder;
    }
    
    public void setObjOrder(final Long objOrder) {
        this.objOrder = objOrder;
    }
    
    public TestCycle name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public TestCycle clientId(final Long clientId) {
        this.clientId = clientId;
        return this;
    }
    
    public Long getClientId() {
        return this.clientId;
    }
    
    public void setClientId(final Long clientId) {
        this.clientId = clientId;
    }
    
    public TestCycle testCycleType(final Integer testCycleType) {
        this.testCycleType = testCycleType;
        return this;
    }
    
    public Integer getTestCycleType() {
        return this.testCycleType;
    }
    
    public void setTestCycleType(final Integer testCycleType) {
        this.testCycleType = testCycleType;
    }
    
    public TestCycle releaseId(final Long releaseId) {
        this.releaseId = releaseId;
        return this;
    }
    
    public Long getReleaseId() {
        return this.releaseId;
    }
    
    public void setReleaseId(final Long releaseId) {
        this.releaseId = releaseId;
    }
    
    public TestCycle buildId(final Long buildId) {
        this.buildId = buildId;
        return this;
    }
    
    public Long getBuildId() {
        return this.buildId;
    }
    
    public void setBuildId(final Long buildId) {
        this.buildId = buildId;
    }
    
    public TestCycle projectId(final Long projectId) {
        this.projectId = projectId;
        return this;
    }
    
    public Long getProjectId() {
        return this.projectId;
    }
    
    public void setProjectId(final Long projectId) {
        this.projectId = projectId;
    }
    
    public TestCycle deleted(final Boolean deleted) {
        this.deleted = deleted;
        return this;
    }
    
    public Boolean getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(final Boolean deleted) {
        this.deleted = deleted;
    }
    
    public TestCycle description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public TestCycle startDate(final DateTime startDate) {
        this.startDate = startDate;
        return this;
    }
    
    public DateTime getStartDate() {
        return this.startDate;
    }
    
    public void setStartDate(final DateTime startDate) {
        this.startDate = startDate;
    }
    
    public TestCycle endDate(final DateTime endDate) {
        this.endDate = endDate;
        return this;
    }
    
    public DateTime getEndDate() {
        return this.endDate;
    }
    
    public void setEndDate(final DateTime endDate) {
        this.endDate = endDate;
    }
    
    public TestCycle subCycles(final List<TestCycle> subCycles) {
        this.subCycles = subCycles;
        return this;
    }
    
    public TestCycle addSubCyclesItem(final TestCycle subCyclesItem) {
        this.subCycles.add(subCyclesItem);
        return this;
    }
    
    public List<TestCycle> getSubCycles() {
        return this.subCycles;
    }
    
    public void setSubCycles(final List<TestCycle> subCycles) {
        this.subCycles = subCycles;
    }
    
    public TestCycle objectType(final Long objectType) {
        this.objectType = objectType;
        return this;
    }
    
    public Long getObjectType() {
        return this.objectType;
    }
    
    public void setObjectType(final Long objectType) {
        this.objectType = objectType;
    }
    
    public TestCycle longId(final Long longId) {
        this.longId = longId;
        return this;
    }
    
    public Long getLongId() {
        return this.longId;
    }
    
    public void setLongId(final Long longId) {
        this.longId = longId;
    }
    
    public TestCycle artifactType(final Integer artifactType) {
        this.artifactType = artifactType;
        return this;
    }
    
    public Integer getArtifactType() {
        return this.artifactType;
    }
    
    public void setArtifactType(final Integer artifactType) {
        this.artifactType = artifactType;
    }
    
    public TestCycle parentArtifactId(final Long parentArtifactId) {
        this.parentArtifactId = parentArtifactId;
        return this;
    }
    
    public Long getParentArtifactId() {
        return this.parentArtifactId;
    }
    
    public void setParentArtifactId(final Long parentArtifactId) {
        this.parentArtifactId = parentArtifactId;
    }
    
    public TestCycle parentObjectType(final Long parentObjectType) {
        this.parentObjectType = parentObjectType;
        return this;
    }
    
    public Long getParentObjectType() {
        return this.parentObjectType;
    }
    
    public void setParentObjectType(final Long parentObjectType) {
        this.parentObjectType = parentObjectType;
    }
    
    public TestCycle statusId(final Long statusId) {
        this.statusId = statusId;
        return this;
    }
    
    public Long getStatusId() {
        return this.statusId;
    }
    
    public void setStatusId(final Long statusId) {
        this.statusId = statusId;
    }
    
    public TestCycle pidWithPrefix(final String pidWithPrefix) {
        this.pidWithPrefix = pidWithPrefix;
        return this;
    }
    
    public String getPidWithPrefix() {
        return this.pidWithPrefix;
    }
    
    public void setPidWithPrefix(final String pidWithPrefix) {
        this.pidWithPrefix = pidWithPrefix;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final TestCycle testCycle = (TestCycle)o;
        return Objects.equals(this.creatorId, testCycle.creatorId) && Objects.equals(this.createdDate, testCycle.createdDate) && Objects.equals(this.lastModifiedUserId, testCycle.lastModifiedUserId) && Objects.equals(this.lastModifiedDate, testCycle.lastModifiedDate) && Objects.equals(this.id, testCycle.id) && Objects.equals(this.pid, testCycle.pid) && Objects.equals(this.parentTestCycleId, testCycle.parentTestCycleId) && Objects.equals(this.objOrder, testCycle.objOrder) && Objects.equals(this.name, testCycle.name) && Objects.equals(this.clientId, testCycle.clientId) && Objects.equals(this.testCycleType, testCycle.testCycleType) && Objects.equals(this.releaseId, testCycle.releaseId) && Objects.equals(this.buildId, testCycle.buildId) && Objects.equals(this.projectId, testCycle.projectId) && Objects.equals(this.deleted, testCycle.deleted) && Objects.equals(this.description, testCycle.description) && Objects.equals(this.startDate, testCycle.startDate) && Objects.equals(this.endDate, testCycle.endDate) && Objects.equals(this.subCycles, testCycle.subCycles) && Objects.equals(this.objectType, testCycle.objectType) && Objects.equals(this.longId, testCycle.longId) && Objects.equals(this.artifactType, testCycle.artifactType) && Objects.equals(this.parentArtifactId, testCycle.parentArtifactId) && Objects.equals(this.parentObjectType, testCycle.parentObjectType) && Objects.equals(this.statusId, testCycle.statusId) && Objects.equals(this.pidWithPrefix, testCycle.pidWithPrefix);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.creatorId, this.createdDate, this.lastModifiedUserId, this.lastModifiedDate, this.id, this.pid, this.parentTestCycleId, this.objOrder, this.name, this.clientId, this.testCycleType, this.releaseId, this.buildId, this.projectId, this.deleted, this.description, this.startDate, this.endDate, this.subCycles, this.objectType, this.longId, this.artifactType, this.parentArtifactId, this.parentObjectType, this.statusId, this.pidWithPrefix);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class TestCycle {\n");
        sb.append("    creatorId: ").append(this.toIndentedString(this.creatorId)).append("\n");
        sb.append("    createdDate: ").append(this.toIndentedString(this.createdDate)).append("\n");
        sb.append("    lastModifiedUserId: ").append(this.toIndentedString(this.lastModifiedUserId)).append("\n");
        sb.append("    lastModifiedDate: ").append(this.toIndentedString(this.lastModifiedDate)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    pid: ").append(this.toIndentedString(this.pid)).append("\n");
        sb.append("    parentTestCycleId: ").append(this.toIndentedString(this.parentTestCycleId)).append("\n");
        sb.append("    objOrder: ").append(this.toIndentedString(this.objOrder)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    clientId: ").append(this.toIndentedString(this.clientId)).append("\n");
        sb.append("    testCycleType: ").append(this.toIndentedString(this.testCycleType)).append("\n");
        sb.append("    releaseId: ").append(this.toIndentedString(this.releaseId)).append("\n");
        sb.append("    buildId: ").append(this.toIndentedString(this.buildId)).append("\n");
        sb.append("    projectId: ").append(this.toIndentedString(this.projectId)).append("\n");
        sb.append("    deleted: ").append(this.toIndentedString(this.deleted)).append("\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("    startDate: ").append(this.toIndentedString(this.startDate)).append("\n");
        sb.append("    endDate: ").append(this.toIndentedString(this.endDate)).append("\n");
        sb.append("    subCycles: ").append(this.toIndentedString(this.subCycles)).append("\n");
        sb.append("    objectType: ").append(this.toIndentedString(this.objectType)).append("\n");
        sb.append("    longId: ").append(this.toIndentedString(this.longId)).append("\n");
        sb.append("    artifactType: ").append(this.toIndentedString(this.artifactType)).append("\n");
        sb.append("    parentArtifactId: ").append(this.toIndentedString(this.parentArtifactId)).append("\n");
        sb.append("    parentObjectType: ").append(this.toIndentedString(this.parentObjectType)).append("\n");
        sb.append("    statusId: ").append(this.toIndentedString(this.statusId)).append("\n");
        sb.append("    pidWithPrefix: ").append(this.toIndentedString(this.pidWithPrefix)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

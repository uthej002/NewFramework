package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPBenefitDetailsPage;
import ibcweb.PageObjects.IBPContractCodePage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitsContractCodeFilterBy extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitDetailsPage benefitDetailspage;
	IBPContractCodePage contractCodepage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Filter By using Contract code")
	public void setUp() {
		InitializeLaunchPad("IBPW_907");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		benefitDetailspage = new IBPBenefitDetailsPage();
		contractCodepage = new IBPContractCodePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "ContractCode"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Filter By using Contract code for the benefit", dataProvider = "TestData")
	@Description("Validate Filter By using Contract code for the benefit")
	public void ValidateBenefitsFilterByContractCode(String TestCaseID, String TestStatus, String ContractCode )
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			contractCodepage.clickonContractCode();
			contractCodepage.clickonFilterBtn();
			sa.assertTrue(contractCodepage.enterContractCode(ContractCode),"Verified contract code is entered");
			contractCodepage.clickonApplyFilterBtn();
			sa.assertTrue(contractCodepage.filterResults(),"Verified Filter Results are displayed");
				
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Filter By Contract code for the benefit Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate Filter By Contract code for the benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

	
	

}

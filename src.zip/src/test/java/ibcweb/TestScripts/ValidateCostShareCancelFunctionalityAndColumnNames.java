package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCostShareCancelFunctionalityAndColumnNames extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesBaseFormularies baseFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validating libraries Cancel Cost share structure Functionality and column Names")
	public void setUp() {
		InitializeLaunchPad("IBPW_381");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		baseFormulary = new IBPLibrariesBaseFormularies();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate libraries Cancel Cost share structure Functionality and column Names", dataProvider = "TestData")
	@Description("Validate libraries Cancel Cost share structure Functionality and column Names")
	public void ValidateLibrariesCostShareStructureEditFunctionality(String TestCaseID, String TestStatus)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on Libraries Section");
			librariesCostShareStructurePage.clickViewButtonOfCostShareStructure();
			sa.assertTrue(librariesCostShareStructurePage.verifyCostShareStructureHeader(),
					"Cost Share Structure header is verified");

			librariesCostShareStructurePage.verifyFilterButtonIsDisplayed();
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("STRUCTURE TYPE");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("NAME");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("COST SHARE ROWS");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("CONTENT");

			librariesCostShareStructurePage.verifyCostShareStructureListColor();

			librariesCostShareStructurePage.clickCreateCostShareStructure();

			librariesCostShareStructurePage.verifyCostShareTierStructureUrl();

			librariesCostShareStructurePage.clickCancelButton();

			sa.assertTrue(librariesCostShareStructurePage.verifyCostShareStructureHeader(),
					"Cost Share Structure header is verified");

			sa.assertAll();

			gTestResult = RESULT_PASS;
			OneframeLogger(
					"Validated libraries Cancel Cost share structure Functionality and column Names successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate libraries Cancel Cost share structure Functionality and column Names");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ParameterTestStepResource
{
    @JsonProperty("step_id")
    private Long stepId;
    @JsonProperty("parameter_values")
    private List<String> parameterValues;
    
    public ParameterTestStepResource() {
        this.stepId = null;
        this.parameterValues = new ArrayList<String>();
    }
    
    public ParameterTestStepResource stepId(final Long stepId) {
        this.stepId = stepId;
        return this;
    }
    
    public Long getStepId() {
        return this.stepId;
    }
    
    public void setStepId(final Long stepId) {
        this.stepId = stepId;
    }
    
    public ParameterTestStepResource parameterValues(final List<String> parameterValues) {
        this.parameterValues = parameterValues;
        return this;
    }
    
    public ParameterTestStepResource addParameterValuesItem(final String parameterValuesItem) {
        this.parameterValues.add(parameterValuesItem);
        return this;
    }
    
    public List<String> getParameterValues() {
        return this.parameterValues;
    }
    
    public void setParameterValues(final List<String> parameterValues) {
        this.parameterValues = parameterValues;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ParameterTestStepResource parameterTestStepResource = (ParameterTestStepResource)o;
        return Objects.equals(this.stepId, parameterTestStepResource.stepId) && Objects.equals(this.parameterValues, parameterTestStepResource.parameterValues);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.stepId, this.parameterValues);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class ParameterTestStepResource {\n");
        sb.append("    stepId: ").append(this.toIndentedString(this.stepId)).append("\n");
        sb.append("    parameterValues: ").append(this.toIndentedString(this.parameterValues)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

package anthem.irx.oneframe.selenium;

public class EdgeWebDriverManager extends WebDriverManager {
  protected void createWebDriver() {}
}

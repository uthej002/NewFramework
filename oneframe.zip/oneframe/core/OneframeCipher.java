// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import java.nio.charset.StandardCharsets;
import anthem.irx.oneframe.utilities.ConfigFileReader;
import javax.crypto.SecretKey;
import java.util.Base64;
import java.nio.ByteBuffer;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.Cipher;
import anthem.irx.oneframe.utilities.CryptoBox;
import java.nio.charset.Charset;

public class OneframeCipher
{
    private static final String ENCRYPT_ALGO = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 12;
    private static final int SALT_LENGTH_BYTE = 16;
    private static final Charset UTF_8;
    private static final String OUTPUT_FORMAT = "%-30s:%s";
    public static final String ENCRYPTION_PASS = "1framPa$$4&crypt";
    
    private static String encrypt(final byte[] passwordText) throws Exception {
        final byte[] salt = CryptoBox.getRandomBytes(16);
        final byte[] iv = CryptoBox.getRandomBytes(12);
        final SecretKey aesKeyFromPassword = CryptoBox.getAESKeyFromPassword("1framPa$$4&crypt".toCharArray(), salt);
        final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(1, aesKeyFromPassword, new GCMParameterSpec(128, iv));
        final byte[] cipherText = cipher.doFinal(passwordText);
        final byte[] cipherTextWithIvSalt = ByteBuffer.allocate(iv.length + salt.length + cipherText.length).put(iv).put(salt).put(cipherText).array();
        return Base64.getEncoder().encodeToString(cipherTextWithIvSalt);
    }
    
    private static String decrypt(final String encryptedText) throws Exception {
        final byte[] decode = Base64.getDecoder().decode(encryptedText.getBytes(OneframeCipher.UTF_8));
        final ByteBuffer bb = ByteBuffer.wrap(decode);
        final byte[] iv = new byte[12];
        bb.get(iv);
        final byte[] salt = new byte[16];
        bb.get(salt);
        final byte[] cipherText = new byte[bb.remaining()];
        bb.get(cipherText);
        final SecretKey aesKeyFromPassword = CryptoBox.getAESKeyFromPassword("1framPa$$4&crypt".toCharArray(), salt);
        final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(2, aesKeyFromPassword, new GCMParameterSpec(128, iv));
        final byte[] plainText = cipher.doFinal(cipherText);
        return new String(plainText, OneframeCipher.UTF_8);
    }
    
    public static String encryptPassword(final String plainPass) throws Exception {
        final String encryptedText = encrypt(plainPass.getBytes(OneframeCipher.UTF_8));
        OneframeContainer.OneframeLogger(encryptedText);
        return encryptedText;
    }
    
    public static String decryptPassword(final String encryptedPass) throws Exception {
        final String decryptedText = decrypt(encryptedPass);
        return decryptedText;
    }
    
    public static void encryptCredentialFilePasswords() {
        final String credPwdKey = "ingeniorx.US.password";
        final ConfigFileReader credentialFile = new ConfigFileReader(OneframeConstants.CREDENTIAL_CONFIG_FILE);
        try {
            final String credPwdValue = credentialFile.getProperty(credPwdKey).trim();
            final String credEncryPwd = encryptPassword(credPwdValue);
            credentialFile.setProperty(credPwdKey, credEncryPwd);
            OneframeContainer.OneframeLogger("Password encrypted successfully");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void encryptPasswordInCredentialFile(String passwordkey) {
        final ConfigFileReader credentialFile = new ConfigFileReader(OneframeConstants.CREDENTIAL_CONFIG_FILE);
        passwordkey = passwordkey.concat(".password");
        try {
            final String credPwdValue = credentialFile.getProperty(passwordkey).trim();
            final String credEncryPwd = encryptPassword(credPwdValue);
            credentialFile.setProperty(passwordkey, credEncryPwd);
            OneframeContainer.OneframeLogger("Password encrypted successfully for key : [" + passwordkey + "]");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    static {
        UTF_8 = StandardCharsets.UTF_8;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import org.joda.time.DateTime;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AutomationRequest
{
    @JsonProperty("testSuiteModel")
    private TestSuite testSuiteModel;
    @JsonProperty("parentModuleModel")
    private ProjectModule parentModuleModel;
    @JsonProperty("parentTestCycleModel")
    private TestCycle parentTestCycleModel;
    @JsonProperty("skipCreatingAutomationModule")
    private Boolean skipCreatingAutomationModule;
    @JsonProperty("shouldCheckUnlinkRequirement")
    private Boolean shouldCheckUnlinkRequirement;
    @JsonProperty("test_suite")
    private String testSuite;
    @JsonProperty("parent_module")
    private String parentModule;
    @JsonProperty("test_logs")
    private List<AutomationTestLogResource> testLogs;
    @JsonProperty("execution_date")
    private DateTime executionDate;
    @JsonProperty("test_cycle")
    private String testCycle;
    
    public AutomationRequest() {
        this.testSuiteModel = null;
        this.parentModuleModel = null;
        this.parentTestCycleModel = null;
        this.skipCreatingAutomationModule = false;
        this.shouldCheckUnlinkRequirement = false;
        this.testSuite = null;
        this.parentModule = null;
        this.testLogs = new ArrayList<AutomationTestLogResource>();
        this.executionDate = null;
        this.testCycle = null;
    }
    
    public AutomationRequest testSuiteModel(final TestSuite testSuiteModel) {
        this.testSuiteModel = testSuiteModel;
        return this;
    }
    
    public TestSuite getTestSuiteModel() {
        return this.testSuiteModel;
    }
    
    public void setTestSuiteModel(final TestSuite testSuiteModel) {
        this.testSuiteModel = testSuiteModel;
    }
    
    public AutomationRequest parentModuleModel(final ProjectModule parentModuleModel) {
        this.parentModuleModel = parentModuleModel;
        return this;
    }
    
    public ProjectModule getParentModuleModel() {
        return this.parentModuleModel;
    }
    
    public void setParentModuleModel(final ProjectModule parentModuleModel) {
        this.parentModuleModel = parentModuleModel;
    }
    
    public AutomationRequest parentTestCycleModel(final TestCycle parentTestCycleModel) {
        this.parentTestCycleModel = parentTestCycleModel;
        return this;
    }
    
    public TestCycle getParentTestCycleModel() {
        return this.parentTestCycleModel;
    }
    
    public void setParentTestCycleModel(final TestCycle parentTestCycleModel) {
        this.parentTestCycleModel = parentTestCycleModel;
    }
    
    public AutomationRequest skipCreatingAutomationModule(final Boolean skipCreatingAutomationModule) {
        this.skipCreatingAutomationModule = skipCreatingAutomationModule;
        return this;
    }
    
    public Boolean getSkipCreatingAutomationModule() {
        return this.skipCreatingAutomationModule;
    }
    
    public void setSkipCreatingAutomationModule(final Boolean skipCreatingAutomationModule) {
        this.skipCreatingAutomationModule = skipCreatingAutomationModule;
    }
    
    public AutomationRequest shouldCheckUnlinkRequirement(final Boolean shouldCheckUnlinkRequirement) {
        this.shouldCheckUnlinkRequirement = shouldCheckUnlinkRequirement;
        return this;
    }
    
    public Boolean getShouldCheckUnlinkRequirement() {
        return this.shouldCheckUnlinkRequirement;
    }
    
    public void setShouldCheckUnlinkRequirement(final Boolean shouldCheckUnlinkRequirement) {
        this.shouldCheckUnlinkRequirement = shouldCheckUnlinkRequirement;
    }
    
    public AutomationRequest testSuite(final String testSuite) {
        this.testSuite = testSuite;
        return this;
    }
    
    public String getTestSuite() {
        return this.testSuite;
    }
    
    public void setTestSuite(final String testSuite) {
        this.testSuite = testSuite;
    }
    
    public AutomationRequest parentModule(final String parentModule) {
        this.parentModule = parentModule;
        return this;
    }
    
    public String getParentModule() {
        return this.parentModule;
    }
    
    public void setParentModule(final String parentModule) {
        this.parentModule = parentModule;
    }
    
    public AutomationRequest testLogs(final List<AutomationTestLogResource> testLogs) {
        this.testLogs = testLogs;
        return this;
    }
    
    public AutomationRequest addTestLogsItem(final AutomationTestLogResource testLogsItem) {
        this.testLogs.add(testLogsItem);
        return this;
    }
    
    public List<AutomationTestLogResource> getTestLogs() {
        return this.testLogs;
    }
    
    public void setTestLogs(final List<AutomationTestLogResource> testLogs) {
        this.testLogs = testLogs;
    }
    
    public AutomationRequest executionDate(final DateTime executionDate) {
        this.executionDate = executionDate;
        return this;
    }
    
    public DateTime getExecutionDate() {
        return this.executionDate;
    }
    
    public void setExecutionDate(final DateTime executionDate) {
        this.executionDate = executionDate;
    }
    
    public AutomationRequest testCycle(final String testCycle) {
        this.testCycle = testCycle;
        return this;
    }
    
    public String getTestCycle() {
        return this.testCycle;
    }
    
    public void setTestCycle(final String testCycle) {
        this.testCycle = testCycle;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final AutomationRequest automationRequest = (AutomationRequest)o;
        return Objects.equals(this.testSuiteModel, automationRequest.testSuiteModel) && Objects.equals(this.parentModuleModel, automationRequest.parentModuleModel) && Objects.equals(this.parentTestCycleModel, automationRequest.parentTestCycleModel) && Objects.equals(this.skipCreatingAutomationModule, automationRequest.skipCreatingAutomationModule) && Objects.equals(this.shouldCheckUnlinkRequirement, automationRequest.shouldCheckUnlinkRequirement) && Objects.equals(this.testSuite, automationRequest.testSuite) && Objects.equals(this.parentModule, automationRequest.parentModule) && Objects.equals(this.testLogs, automationRequest.testLogs) && Objects.equals(this.executionDate, automationRequest.executionDate) && Objects.equals(this.testCycle, automationRequest.testCycle);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.testSuiteModel, this.parentModuleModel, this.parentTestCycleModel, this.skipCreatingAutomationModule, this.shouldCheckUnlinkRequirement, this.testSuite, this.parentModule, this.testLogs, this.executionDate, this.testCycle);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class AutomationRequest {\n");
        sb.append("    testSuiteModel: ").append(this.toIndentedString(this.testSuiteModel)).append("\n");
        sb.append("    parentModuleModel: ").append(this.toIndentedString(this.parentModuleModel)).append("\n");
        sb.append("    parentTestCycleModel: ").append(this.toIndentedString(this.parentTestCycleModel)).append("\n");
        sb.append("    skipCreatingAutomationModule: ").append(this.toIndentedString(this.skipCreatingAutomationModule)).append("\n");
        sb.append("    shouldCheckUnlinkRequirement: ").append(this.toIndentedString(this.shouldCheckUnlinkRequirement)).append("\n");
        sb.append("    testSuite: ").append(this.toIndentedString(this.testSuite)).append("\n");
        sb.append("    parentModule: ").append(this.toIndentedString(this.parentModule)).append("\n");
        sb.append("    testLogs: ").append(this.toIndentedString(this.testLogs)).append("\n");
        sb.append("    executionDate: ").append(this.toIndentedString(this.executionDate)).append("\n");
        sb.append("    testCycle: ").append(this.toIndentedString(this.testCycle)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

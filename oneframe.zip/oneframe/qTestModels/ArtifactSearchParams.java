// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ArtifactSearchParams
{
    @JsonProperty("object_type")
    private String objectType;
    @JsonProperty("fields")
    private List<String> fields;
    @JsonProperty("query")
    private String query;
    
    public ArtifactSearchParams() {
        this.objectType = null;
        this.fields = new ArrayList<String>();
        this.query = null;
    }
    
    public ArtifactSearchParams objectType(final String objectType) {
        this.objectType = objectType;
        return this;
    }
    
    public String getObjectType() {
        return this.objectType;
    }
    
    public void setObjectType(final String objectType) {
        this.objectType = objectType;
    }
    
    public ArtifactSearchParams fields(final List<String> fields) {
        this.fields = fields;
        return this;
    }
    
    public ArtifactSearchParams addFieldsItem(final String fieldsItem) {
        this.fields.add(fieldsItem);
        return this;
    }
    
    public List<String> getFields() {
        return this.fields;
    }
    
    public void setFields(final List<String> fields) {
        this.fields = fields;
    }
    
    public ArtifactSearchParams query(final String query) {
        this.query = query;
        return this;
    }
    
    public String getQuery() {
        return this.query;
    }
    
    public void setQuery(final String query) {
        this.query = query;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ArtifactSearchParams artifactSearchParams = (ArtifactSearchParams)o;
        return Objects.equals(this.objectType, artifactSearchParams.objectType) && Objects.equals(this.fields, artifactSearchParams.fields) && Objects.equals(this.query, artifactSearchParams.query);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.objectType, this.fields, this.query);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class ArtifactSearchParams {\n");
        sb.append("    objectType: ").append(this.toIndentedString(this.objectType)).append("\n");
        sb.append("    fields: ").append(this.toIndentedString(this.fields)).append("\n");
        sb.append("    query: ").append(this.toIndentedString(this.query)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

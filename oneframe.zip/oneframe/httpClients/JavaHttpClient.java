// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.httpClients;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ProtocolException;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;

public class JavaHttpClient
{
    HttpURLConnection connection;
    URL url;
    
    public JavaHttpClient OpenConnection(final String HttpURL) {
        try {
            this.url = new URL(HttpURL.trim());
            this.connection = (HttpURLConnection)this.url.openConnection();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return this;
    }
    
    public void Post(final String joPayLoad) {
        final String ContentLength = String.valueOf(joPayLoad.length());
        try {
            this.connection.setRequestMethod("POST");
            this.connection.setRequestProperty("Accept", "application/json");
            this.connection.setRequestProperty("Content-Type", "application/json");
            this.connection.setRequestProperty("Accept-Charset", "UTF-8");
            this.connection.setReadTimeout(15000);
            this.connection.setConnectTimeout(15000);
            this.connection.setDoOutput(true);
            this.connection.setRequestProperty("Content-Length", ContentLength);
        }
        catch (ProtocolException e1) {
            e1.printStackTrace();
        }
        try {
            final OutputStream outStream = this.connection.getOutputStream();
            outStream.write(joPayLoad.getBytes());
        }
        catch (IOException e2) {
            e2.printStackTrace();
        }
        try {
            final InputStream inputStream = this.connection.getInputStream();
            final BufferedReader br1 = new BufferedReader(new InputStreamReader(inputStream));
            System.out.println("Connection Status - " + this.connection.getResponseCode());
            System.out.println("Server Error - " + this.connection.getErrorStream().toString());
            final StringBuilder response = new StringBuilder();
            String responseSingle = null;
            while ((responseSingle = br1.readLine()) != null) {
                response.append(responseSingle);
            }
            final String xx = response.toString();
            System.out.println(xx);
        }
        catch (IOException e2) {
            e2.printStackTrace();
        }
    }
    
    public String Get() {
        InputStream responseStream = null;
        try {
            responseStream = this.connection.getInputStream();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return responseStream.toString();
    }
}

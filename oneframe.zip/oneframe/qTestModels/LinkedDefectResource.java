// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class LinkedDefectResource
{
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("external_defect_id")
    private String externalDefectId;
    @JsonProperty("connection_id")
    private Long connectionId;
    @JsonProperty("external_project_id")
    private String externalProjectId;
    @JsonProperty("summary")
    private String summary;
    @JsonProperty("status")
    private String status;
    @JsonProperty("pid")
    private String pid;
    @JsonProperty("web_url")
    private String webUrl;
    @JsonProperty("description")
    private String description;
    
    public LinkedDefectResource() {
        this.links = new ArrayList<Link>();
        this.id = null;
        this.externalDefectId = null;
        this.connectionId = null;
        this.externalProjectId = null;
        this.summary = null;
        this.status = null;
        this.pid = null;
        this.webUrl = null;
        this.description = null;
    }
    
    public LinkedDefectResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public LinkedDefectResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public LinkedDefectResource id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public LinkedDefectResource externalDefectId(final String externalDefectId) {
        this.externalDefectId = externalDefectId;
        return this;
    }
    
    public String getExternalDefectId() {
        return this.externalDefectId;
    }
    
    public void setExternalDefectId(final String externalDefectId) {
        this.externalDefectId = externalDefectId;
    }
    
    public LinkedDefectResource connectionId(final Long connectionId) {
        this.connectionId = connectionId;
        return this;
    }
    
    public Long getConnectionId() {
        return this.connectionId;
    }
    
    public void setConnectionId(final Long connectionId) {
        this.connectionId = connectionId;
    }
    
    public LinkedDefectResource externalProjectId(final String externalProjectId) {
        this.externalProjectId = externalProjectId;
        return this;
    }
    
    public String getExternalProjectId() {
        return this.externalProjectId;
    }
    
    public void setExternalProjectId(final String externalProjectId) {
        this.externalProjectId = externalProjectId;
    }
    
    public LinkedDefectResource summary(final String summary) {
        this.summary = summary;
        return this;
    }
    
    public String getSummary() {
        return this.summary;
    }
    
    public void setSummary(final String summary) {
        this.summary = summary;
    }
    
    public LinkedDefectResource status(final String status) {
        this.status = status;
        return this;
    }
    
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(final String status) {
        this.status = status;
    }
    
    public LinkedDefectResource pid(final String pid) {
        this.pid = pid;
        return this;
    }
    
    public String getPid() {
        return this.pid;
    }
    
    public void setPid(final String pid) {
        this.pid = pid;
    }
    
    public String getWebUrl() {
        return this.webUrl;
    }
    
    public LinkedDefectResource description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final LinkedDefectResource linkedDefectResource = (LinkedDefectResource)o;
        return Objects.equals(this.links, linkedDefectResource.links) && Objects.equals(this.id, linkedDefectResource.id) && Objects.equals(this.externalDefectId, linkedDefectResource.externalDefectId) && Objects.equals(this.connectionId, linkedDefectResource.connectionId) && Objects.equals(this.externalProjectId, linkedDefectResource.externalProjectId) && Objects.equals(this.summary, linkedDefectResource.summary) && Objects.equals(this.status, linkedDefectResource.status) && Objects.equals(this.pid, linkedDefectResource.pid) && Objects.equals(this.webUrl, linkedDefectResource.webUrl) && Objects.equals(this.description, linkedDefectResource.description);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links, this.id, this.externalDefectId, this.connectionId, this.externalProjectId, this.summary, this.status, this.pid, this.webUrl, this.description);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class LinkedDefectResource {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    externalDefectId: ").append(this.toIndentedString(this.externalDefectId)).append("\n");
        sb.append("    connectionId: ").append(this.toIndentedString(this.connectionId)).append("\n");
        sb.append("    externalProjectId: ").append(this.toIndentedString(this.externalProjectId)).append("\n");
        sb.append("    summary: ").append(this.toIndentedString(this.summary)).append("\n");
        sb.append("    status: ").append(this.toIndentedString(this.status)).append("\n");
        sb.append("    pid: ").append(this.toIndentedString(this.pid)).append("\n");
        sb.append("    webUrl: ").append(this.toIndentedString(this.webUrl)).append("\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

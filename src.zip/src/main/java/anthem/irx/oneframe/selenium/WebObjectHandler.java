package anthem.irx.oneframe.selenium;

import anthem.irx.oneframe.core.OneframeContainer;
import io.qameta.allure.Attachment;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebObjectHandler extends OneframeContainer {
  static JavascriptExecutor JSExecutor;
  
  static Wait<WebDriver> FluentWait;
  
  static WebDriverWait driverWait;
  
  public static WebDriver getOneframeWebDriver() {
    return (WebDriver)oneframeDriver;
  }
  
  @Attachment("Screenshot on demand")
  public static byte[] makeScreenshotOnDemand() {
    if (oneframeDriver == null)
      return null; 
    return (byte[])oneframeDriver.getScreenshotAs(OutputType.BYTES);
  }
  
  @Attachment("{LogMessage}")
  public static byte[] AttachScreenshotOnDemand(String LogMessage) {
    return (byte[])oneframeDriver.getScreenshotAs(OutputType.BYTES);
  }
  
  public static String takeScreenshotOnDemand() {
    if (oneframeDriver == null)
      return ""; 
    return (String)oneframeDriver.getScreenshotAs(OutputType.BASE64);
  }
  
  public static WebElement CheckObjectExistence(WebElement webObject) {
    return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(webObject)));
  }
  
  public static void WaitForObjectToBeInvisible(By byLocator) {
    GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.invisibilityOfElementLocated(byLocator)));
  }
  
  public static WebElement WaitForObjectToBeClickable(WebElement webObject) {
    if (GetWebDriverWait().until((Function)ExpectedConditions.not(ExpectedConditions.stalenessOf(webObject))) == null)
      OneframeLogger("[ONEFRAME][CLICK] - Object is stale, script execution may fail"); 
    try {
      return (WebElement)GetWebDriverWait().until((Function)ExpectedConditions.elementToBeClickable(webObject));
    } catch (Throwable TException) {
      OneframeLogger("[ONEFRAME][WOH]Waiting for object to be clickable> Exception> " + GetObjectInformation(webObject));
      return webObject;
    } 
  }
  
  public static WebElement WaitForObjectToBeClickable(By byLocator) {
    try {
      return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(byLocator)));
    } catch (Exception E) {
      OneframeLogger("[ONEFRAME][WOH]Wait for Clickable>Exception> ");
      return null;
    } 
  }
  
  public static boolean ObjectExist(WebElement webObject) {
    if (GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(webObject))) != null)
      return true; 
    return false;
  }
  
  public static boolean WaitForObject(WebElement webObject) {
    try {
      if (GetWebDriverWait().until((Function)ExpectedConditions.visibilityOf(webObject)) != null)
        return true; 
    } catch (Exception ExcObj) {
      OneframeLogger("[ONEFRAME][WOH]FIND-WARNING> Unable to find " + GetObjectInformation(webObject));
      OneframeLogger("[ONEFRAME][WOH]FIND-EXCEPTION>" + ExcObj.getMessage());
    } 
    return false;
  }
  
  public static void WaitForApplicationToLoadCompletely() {
    try {
      GetFluentWebDriverWait().until((Function)ExpectedConditions.invisibilityOfElementLocated(By.id("loading-spinner")));
      GetFluentWebDriverWait().until((Function)IsPageLoadComplete());
      GetFluentWebDriverWait().until((Function)IsJavaScriptProcessingComplete());
    } catch (Exception E) {
      OneframeLogger("[ONEFRAME][WOH]Exception occurred while waiting for Application to complete processing");
      OneframeLogger("[ONEFRAME][WOH]Exception " + E.getMessage());
    } 
  }
  
  public static boolean WaitForObjectVisibility(WebElement webObject) {
    if (GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(webObject))) != null)
      return true; 
    return false;
  }
  
  private static WebDriverWait GetWebDriverWait() {
    if (driverWait == null)
      driverWait = new WebDriverWait(getOneframeWebDriver(), MaxWaitTime, IntervalTime); 
    return driverWait;
  }
  
  private static Wait<WebDriver> GetFluentWebDriverWait() {
    if (FluentWait == null)
      FluentWait = (Wait<WebDriver>)(new FluentWait(getOneframeWebDriver())).withTimeout(Duration.ofSeconds(MaxWaitTime)).pollingEvery(Duration.ofMillis(IntervalTime)).ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class).ignoring(ElementNotInteractableException.class).ignoring(ElementClickInterceptedException.class).ignoring(UnhandledAlertException.class); 
    return FluentWait;
  }
  
  public static ExpectedCondition<Boolean> IsPageLoadComplete() {
    return oneframeDriver -> (Boolean)GetJavaScriptExecutorObject().executeScript("return (window.show===false) || (window.show===undefined);", new Object[0]);
  }
  
  public static ExpectedCondition<Boolean> IsJavaScriptProcessingComplete() {
    return oneframeDriver -> Boolean.valueOf(GetJavaScriptExecutorObject().executeScript("return document.readyState", new Object[0]).equals("complete"));
  }
  
  public static WebElement FindObjectByXpath(String ObjectKey) {
    try {
      return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.xpath(ObjectKey))));
    } catch (Exception E) {
      OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
      return null;
    } 
  }
  
  public static WebElement FindObjectByClass(String ObjectKey) {
    try {
      return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.className(ObjectKey))));
    } catch (Exception E) {
      OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
      return null;
    } 
  }
  
  public static WebElement FindObjectByID(String ObjectKey) {
    try {
      return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.id(ObjectKey))));
    } catch (Throwable TException) {
      OneframeLogger("[ONEFRAME][WOH]" + TException.getMessage());
      return null;
    } 
  }
  
  public static WebElement FindObjectByLocator(By byLocator) {
    try {
      return (WebElement)GetFluentWebDriverWait().until((Function)ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(byLocator)));
    } catch (Throwable TException) {
      OneframeLogger("[ONEFRAME][WOH]Find by Locator> " + TException.getMessage());
      return null;
    } 
  }
  
  public static WebElement FindObjectByLocatorNoWait(By byLocator) {
    try {
      return oneframeDriver.findElement(byLocator);
    } catch (NoSuchElementException E) {
      OneframeLogger("[ONEFRAME][WOH]Find-Exception> No element found");
      return null;
    } 
  }
  
  public static boolean elementIsDisplayed(WebElement ele) {
    try {
      synchronized (oneframeDriver) {
        oneframeDriver.wait(MaxWaitTime);
      } 
      ele.isDisplayed();
    } catch (NoSuchElementException e) {
      return false;
    } catch (InterruptedException e) {
      e.printStackTrace();
    } 
    return true;
  }
  
  public static String ReadTextFromTextBox(WebElement webObject) {
    String objText = "null";
    if (CheckObjectExistence(webObject) != null)
      objText = webObject.getAttribute("value"); 
    return objText;
  }
  
  public static String GetInnerHTML(WebElement webObject) {
    if (WaitForObject(webObject))
      return webObject.getAttribute("innerHTML"); 
    return "Not Found";
  }
  
  public static void ScrollToElement(WebElement webObject) {
    GetJavaScriptExecutorObject().executeScript("arguments[0].scrollIntoView();", new Object[] { webObject });
    OneframeLogger("[ONEFRAME][WOH]Page Scrolling to - " + GetObjectInformation(webObject));
  }
  
  public static void ScrollToBottomOfthePage() {
    GetJavaScriptExecutorObject().executeScript("window.scrollTo(0, document.body.scrollHeight)", new Object[0]);
  }
  
  public static void ScrollWebPageByPixel(int pixelCount) {
    GetJavaScriptExecutorObject().executeScript("window.scrollBy(0," + pixelCount + ")", new Object[0]);
    OneframeLogger("[ONEFRAME][WOH]Wep page scrolled by " + pixelCount + " pixels");
  }
  
  public static void DragDropWebObject(WebElement SourceObject, WebElement TargetObject) {
    Actions action = new Actions(getOneframeWebDriver());
    action.dragAndDrop(SourceObject, TargetObject).build().perform();
  }
  
  public static void EnterTextandTabOut(WebElement webObject, String strText) {
    EnterText(webObject, strText);
    webObject.sendKeys(new CharSequence[] { (CharSequence)Keys.TAB });
  }
  
  public static void ClearAndEnterText(WebElement webObject, String strText) {
    ClearTextOnInputElement(webObject);
    EnterText(webObject, strText);
  }
  
  public static void ClearTextOnInputElement(WebElement webObject) {
    CheckObjectExistence(webObject).click();
    webObject.clear();
    if (webObject.getAttribute("value").equals("")) {
      webObject.sendKeys(new CharSequence[] { Keys.CONTROL + "a" });
      webObject.sendKeys(new CharSequence[] { (CharSequence)Keys.DELETE });
    } 
    while (!webObject.getAttribute("value").equals("")) {
      webObject.sendKeys(new CharSequence[] { (CharSequence)Keys.BACK_SPACE });
    } 
  }
  
  public static void EnterText(WebElement webObject, String strText) {
    try {
      OneFrameScriptRegulator();
    } catch (Exception E) {
      OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
    } 
    try {
      CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
      if (ReadTextFromTextBox(webObject).toLowerCase().equals(strText.toLowerCase())) {
        OneframeLogger("Entered text : " + strText);
      } else {
        webObject.clear();
        CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
        OneframeLogger("RE-Entered text : " + strText);
      } 
    } catch (ElementNotInteractableException exception) {
      OneframeLogger("[ONEFRAME][WOH]ENTER-WARNING> Unable to interact with : " + GetObjectInformation(webObject));
      HandleUnexpectedWindowPopUp();
      try {
        OneframeLogger("[ONEFRAME][WOH]ENTER-WARNING> Retrying enter action on : " + GetObjectInformation(webObject));
        CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
        if (ReadTextFromTextBox(webObject).toLowerCase().equals(strText.toLowerCase())) {
          OneframeLogger("Entered text : " + strText);
        } else {
          webObject.clear();
          CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
          OneframeLogger("RE-Entered text : " + strText);
        } 
      } catch (Throwable exception2) {
        OneframeLogger("[ONEFRAME][WOH]ENTER-EXCEPTION> Enter action failed at retry : " + GetObjectInformation(webObject));
      } 
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]Exception while entering text : " + exception.getMessage());
    } 
  }
  
  public static void EnterPasswordText(WebElement webObject, String strText) {
    try {
      OneFrameScriptRegulator();
    } catch (Exception E) {
      OneframeLogger("[ONEFRAME][WOH]" + E.getMessage());
    } 
    try {
      CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
      if (webObject.getAttribute("value").toLowerCase().equals(strText.toLowerCase())) {
        OneframeLogger("Entered text : Pass*****");
      } else {
        webObject.clear();
        CheckObjectExistence(webObject).sendKeys(new CharSequence[] { strText });
        OneframeLogger("RE-Entered text : Pass******");
      } 
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
    } 
  }
  
  public static void ClickWebObject(WebElement webObject) {
    try {
      OneFrameScriptRegulator();
    } catch (Exception E) {
      OneframeLogger("[ONEFRAME][WOH] Regulator Issue : " + E.getMessage());
    } 
    glblCurrObjDetails = GetObjectInformation(webObject);
    try {
      WaitForAngularJSQueryToComplete();
      WaitForObjectToBeClickable(webObject).click();
      OneframeLogger("[ONEFRAME][WOH][Object Clicked] -> [" + glblCurrObjDetails + "]");
      WaitForApplicationToLoadCompletely();
    } catch (ElementClickInterceptedException exception) {
      OneframeLogger("[ONEFRAME][WOH] CLICK-WARNING> Unable to Click : " + glblCurrObjDetails);
      HandleUnexpectedWindowPopUp();
      try {
        OneframeLogger("[ONEFRAME][WOH] CLICK-WARNING> Retrying click on : " + glblCurrObjDetails);
        WaitForObjectToBeClickable(webObject).click();
        WaitForApplicationToLoadCompletely();
      } catch (Throwable exception2) {
        OneframeLogger("[ONEFRAME][WOH] CLICK-EXCEPTION> Click action failed at retry : " + glblCurrObjDetails);
      } 
    } 
  }
  
  public static void ClickWebObject(By byLocator) {
    try {
      WebElement webObject = FindObjectByLocator(byLocator);
      glblCurrObjDetails = GetObjectInformation(webObject);
      OneframeContainer.OneframeLogger("[ONEFRAME][WOH] Click-bylocator...found object ->" + glblCurrObjDetails);
      ClickWebObject(webObject);
    } catch (Exception E) {
      OneframeLogger("[ONEFRAME][WOH] CLICK-byLocator - Exception>" + E.getMessage());
    } 
  }
  
  public static String GetObjectInformation(WebElement webObject) {
    if (webObject != null)
      try {
        String ObjectInformation = "WebElement : {" + webObject.getTagName() + "} | ";
        List<String> ObjectProperties = new ArrayList<>(Arrays.asList(new String[] { "id", "name", "class", "type", "text", "value" }));
        for (String ObjectProperty : ObjectProperties) {
          String PropertyValue = webObject.getAttribute(ObjectProperty);
          if (PropertyValue != null && 
            !PropertyValue.isEmpty())
            ObjectInformation = ObjectInformation + "[" + ObjectProperty + "='" + PropertyValue + "'] "; 
        } 
        return ObjectInformation;
      } catch (Throwable TException) {
        if (!(TException instanceof StaleElementReferenceException))
          OneframeLogger("[ONEFRAME][WOH]Get Object Information> Exception> " + TException.getMessage()); 
        return "Object information not available due to page transition/refresh";
      }  
    OneframeLogger("[ONEFRAME][WOH]Object is NULL, who called it?");
    return "Object is NULL";
  }
  
  public static void MouseOverToWebElement(WebElement webObject) {
    glblCurrObjDetails = GetObjectInformation(webObject);
    try {
      if (WaitForObjectVisibility(webObject)) {
        Actions action = new Actions((WebDriver)oneframeDriver);
        action.moveToElement(webObject).build().perform();
        OneframeLogger("Mouse over at " + glblCurrObjDetails);
      } else {
        OneframeLogger("[ONEFRAME][WOH]WARNING> Object not found - " + glblCurrObjDetails);
      } 
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]MouseOver > WARNING" + exception.getMessage());
    } 
  }
  
  public static void MouseOverAndClickOnWebElement(WebElement webObject) {
    glblCurrObjDetails = GetObjectInformation(webObject);
    try {
      Actions action = new Actions((WebDriver)oneframeDriver);
      action.moveToElement(webObject).click().build().perform();
      OneframeLogger("Mouse over and Clicked at " + glblCurrObjDetails);
    } catch (Throwable TException) {
      OneframeLogger("[ONEFRAME][WOH]MouseOver Click> WARNING>" + TException.getMessage());
    } 
  }
  
  public static void SelectDropDownListByValue(WebElement DropDownSelectObject, String ListValue) {
    ClickWebObject(DropDownSelectObject);
    try {
      Select dropdownList = new Select(DropDownSelectObject);
      dropdownList.selectByValue(ListValue);
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
    } 
  }
  
  public static void SelectDropDownListByValue(WebElement DropDownObject, WebElement ULElement, String LiValue) {
    ClickWebObject(DropDownObject);
    try {
      List<WebElement> listValues = ULElement.findElements(By.tagName("li"));
      for (WebElement listValue : listValues) {
        if (listValue.getText().equalsIgnoreCase(LiValue))
          ClickWebObject(listValue); 
      } 
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
    } 
  }
  
  public static void SelectDropDownListByTagName(WebElement DropDownObject, WebElement ULElement, String ElementTagName, String LiValue) {
    ClickWebObject(DropDownObject);
    try {
      List<WebElement> listValues = ULElement.findElements(By.tagName(ElementTagName));
      for (WebElement listValue : listValues) {
        if (listValue.getText().equalsIgnoreCase(LiValue))
          ClickWebObject(listValue); 
      } 
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
    } 
  }
  
  public static void SelectDropDownListByVisibleText(WebElement DropDownSelectObject, String ListVisibleText) {
    ClickWebObject(DropDownSelectObject);
    try {
      Select dropdownList = new Select(DropDownSelectObject);
      dropdownList.selectByVisibleText(ListVisibleText);
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
    } 
  }
  
  public static void SelectDropDownListByIndex(WebElement DropDownSelectObject, int ListIndex) {
    ClickWebObject(DropDownSelectObject);
    try {
      Select dropdownList = new Select(DropDownSelectObject);
      dropdownList.selectByIndex(ListIndex);
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
    } 
  }
  
  public static void SelectDropDownListByObject(WebElement DropDownObject, WebElement ListObject) {
    try {
      ClickWebObject(DropDownObject);
      ClickWebObject(ListObject);
    } catch (WebDriverException exception) {
      OneframeLogger("[ONEFRAME][WOH]" + exception.getMessage());
    } 
  }
  
  public static String ReadObjectProperty(WebElement webObject, String PropertyName) {
    return CheckObjectExistence(webObject).getAttribute(PropertyName);
  }
  
  private static void OneFrameScriptRegulator() throws InterruptedException {
    switch (ScriptRegulatorLvl) {
      case 1:
        Thread.sleep(5L);
        return;
      case 2:
        Thread.sleep(50L);
        return;
      case 3:
        Thread.sleep(100L);
        return;
      case 4:
        Thread.sleep(500L);
        return;
      case 5:
        Thread.sleep(1000L);
        return;
    } 
    Thread.sleep(15L);
  }
  
  public static String getObjectType(String ObjTagTypeName) {
    ObjTagTypeName = ObjTagTypeName.toLowerCase().trim();
    String ObjectType = "UN-IDENTIFIED";
    switch (ObjTagTypeName) {
      case "a":
        ObjectType = "link";
        return ObjectType;
      case "text":
        ObjectType = "Textbox";
        return ObjectType;
      case "submit":
        ObjectType = "Submit button";
        return ObjectType;
    } 
    ObjectType = ObjTagTypeName;
    return ObjectType;
  }
  
  public static void WaitForAngularJSQueryToComplete() {
    AngularJSWait.setDriver(getOneframeWebDriver());
    AngularJSWait.waitJQueryAngular();
  }
  
  private static JavascriptExecutor GetJavaScriptExecutorObject() {
    if (JSExecutor == null) {
      JSExecutor = (JavascriptExecutor)getOneframeWebDriver();
      OneframeLogger("[ONEFRAME][WOH]Initializing JavaScript Executor Object...");
    } 
    return JSExecutor;
  }
  
  private static void HandleUnexpectedWindowPopUp() {
    String ApplicationKey = OneframeContainer.TSAppEnvKey.substring(0, 6);
    OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Attempting to resolve unexpected popup or blocking web element...");
    if (ApplicationKey.equalsIgnoreCase("RCPWEB") && 
      ObjectExist(FindObjectByXpath("//*[@id='fsrInvite']"))) {
      ClickWebObject(FindObjectByXpath("//*[@id='fsrFocusFirst']"));
      OneframeContainer.OneframeLogger("Closed RCP Customer Feedback popup window");
    } 
    if (ApplicationKey.equalsIgnoreCase("IRXWEB")) {
      OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Application detected - IngenioRx Member Portal...");
      if (FindObjectByLocatorNoWait(By.className("fsrBanner")) != null) {
        OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Popup/window detected - IngenioRx Customer feedback popup window...");
        if (FindObjectByLocator(By.xpath("//button[@id='fsrFocusFirst']")) != null) {
          MouseOverAndClickOnWebElement(FindObjectByLocator(By.xpath("//button[@id='fsrFocusFirst']")));
          OneframeContainer.OneframeLogger("[ONEFRAME][WOH]Closed IngenioRx Customer Feedback popup window");
        } else {
          OneframeContainer.OneframeLogger("Unable to close the target popup/window, script execution may fail");
        } 
      } else {
        OneframeContainer.OneframeLogger("Uknown popup appeared on the page or unable to click on the object");
      } 
    } 
  }
  
  public static void ResetWebHandlerObjects() {
    JSExecutor = null;
    FluentWait = null;
    driverWait = null;
  }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccountsPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBREPromoteButtonContentManager extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;
	IBPAccountsPage accountspage;

	@BeforeClass
	@Step("Initializing Test Script for validating the Promote Functionality for Content Manager BRE")
	public void setUp() {
		InitializeLaunchPad("IBPW_41");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
		accountspage = new IBPAccountsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","LibraryName","RuleName","UserName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate the Promote Functionality for Content Manager BRE", dataProvider = "TestData")
	@Description("Validate the Promote Functionality for Content Manager BRE")
	public void ValidatePromoteButtonContentManager(String TestCaseID, String TestStatus,String LibraryName,String RuleName,String UserName) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(!homepage.verifyNoAccountsSection(),"Verified Accounts Section is not displayed");
			homepage.clickRuleBuilder();
            homepage.clickStagingLink();          
            rulebuilderstaging.clickLibrary(LibraryName);
          //ruleid.getLatestVersionID(LibraryName, RuleName);
            String versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
			ruleid.clickLatestVersionofRuleID(versionId);
			ruleid.clickPromoteButton();
			sa.assertTrue(ruleid.verifyProductionTitleDisplay(), "Rule is moved from Stagging to Production");
			sa.assertTrue(!ruleid.verifyRuleNamedisplay(), "Rule Name is disabled");
			sa.assertTrue(!ruleid.verifyDescriptiondisplay(), "Description is disabled");
			sa.assertTrue(!ruleid.verifyStartandEndDatedisplay(), "Start and End Date is disabled");
			sa.assertTrue(!ruleid.verifyMessagedisplay(), "Message is disabled");
			ruleid.clickBackbutton();
			sa.assertTrue(!rulebuilderstaging.verifyStagingHeaderdisplay(), "Stagging header is displayed");
			homepage.clickProductionLink();      
			rulebuilderstaging.clickRuleName(LibraryName, RuleName);
			sa.assertTrue(ruleid.verifyRuleIDTitleDisplay(), "RuleId is promoted to production");
			//sa.assertTrue(!ruleid.verifyVersionIDPromoted(), "The latest version of given RuleID is moved from stagging to production");
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate the Promote Functionality for Content Manager BRE successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate the Promote Functionality for Content Manager BRE unsuccessful");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}



}

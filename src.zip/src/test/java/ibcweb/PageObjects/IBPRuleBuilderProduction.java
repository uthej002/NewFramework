package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ScrollWebPageByPixel;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForApplicationToLoadCompletely;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectToBeClickable;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;

import java.util.List;

import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPRuleBuilderProduction extends OneframeContainer {
	
	@FindBy(xpath="//h2[text()='Benefit Validation Rules Engine']")
	WebElement hdrBenefitRuleEngine;
	
	@FindBy (xpath="//h3[text()='PRODUCTION']")
	WebElement hdrProduction;
	
	@FindBy(xpath="//mat-expansion-panel-header[contains(.,' Block of Business ')]")
	WebElement lnkBlockofBusiness;
	
	@FindBy(xpath="//mat-expansion-panel-header[contains(.,'Base Formulary')]")
	WebElement lnkBaseFormulary;
	
	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Logout ']")
	WebElement btnLogout;
	
	@FindBy(xpath="//mat-expansion-panel-header[contains(.,' Net Formulary ')]")
	WebElement lnkNetFormulary;
	
	@FindBy(xpath="//mat-expansion-panel-header[contains(.,' General Defaults ')]")
	WebElement lnkGD;
	
	@FindBy(xpath="//mat-expansion-panel-header[contains(.,' Cost Shares ')]")
	WebElement lnkCS;
	
//	@FindBy(xpath="//td[@class='mat-cell cdk-cell cdk-column-id mat-column-id ng-star-inserted']//a")
//	List<WebElement> lstRuleIDS;
	
	@FindBy(xpath="//*[@class='mat-cell cdk-cell cdk-column-id mat-column-id ng-star-inserted']/a")
	WebElement lstRuleIDS;
	
	@FindBy(xpath="//div[contains(@id, 'cdk-accordion-child-')]/div//table/thead/tr")
	List<WebElement> hdrLibraries;
	
	@FindBy(xpath = "xpath=//*[@class='mat-cell cdk-cell cdk-column-version mat-column-version ng-star-inserted']/a")
	WebElement lnkVersionIds;
	
    @FindBy(xpath = "//div[@class='mat-title title']")
    WebElement txtRuleIDTitle;	
    
    @FindBy(xpath = "//*[@class='mat-title title']")
    WebElement txtRuleID;

   
    @FindBy(xpath="//mat-expansion-panel[contains(@class, 'mat-expanded')]//button[@aria-label='Previous page']")
    WebElement btnPreviousPage;
    
    @FindBy(xpath="//mat-expansion-panel[contains(@class, 'mat-expanded')]//button[@aria-label='Next page']")
    WebElement btnNextPage;
    
    @FindBy(xpath="//mat-expansion-panel[contains(@class, 'mat-expanded')]//div[@class='mat-paginator-range-label']")
    WebElement txtrecordscount;
	
    @FindBy(xpath = "//mat-expansion-panel[contains(@class, 'mat-expanded')]//tbody/tr")
    WebElement tableRecords;
	
	// Initializing the Page Objects:
	public IBPRuleBuilderProduction() {
		
		PageFactory.initElements(oneframeDriver, this);
	}
	
	// Actions	
	
	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}
	
	@Step("Verify RuleEngine Header is displayed")
    public boolean verifyRuleEngineHeaderdisplay()  {
	  WaitForObjectVisibility(hdrBenefitRuleEngine);
        boolean blnRC = false;
        WaitForApplicationToLoadCompletely();
        try {
            if (hdrBenefitRuleEngine.isDisplayed()) {
            	highlightElement(hdrBenefitRuleEngine);
                OneframeLogger("Benefit Rule Engine Header is displayed");
                blnRC = true;
            }
        } catch (NoSuchElementException toException) {
            OneframeLogger("Benefit Rule Engine Header is not displayed");
            blnRC = false;
        }
        return blnRC;
    }
	
	
	@Step("Verify Production Header is displayed")
    public boolean verifyProductionHeaderdisplay() throws InterruptedException{
		boolean blnRC = false;
		
        try {
            if (WaitForObjectVisibility(hdrProduction)) {
            	ClickWebObject(hdrProduction);
                blnRC = true;
            }
        } catch (NoSuchElementException toException) {
            blnRC = false;
        }

        
        return blnRC;
    }
	
	@Step("Verify Staging Header is displayed")
    public boolean verifyStagingHeaderdisplay() {
        boolean blnRC = false;
        WaitForApplicationToLoadCompletely();
        try {
            if (hdrProduction.isDisplayed()) {
            	highlightElement(hdrProduction);
                OneframeLogger("Production Header is displayed");
                blnRC = true;
            }
        } catch (NoSuchElementException toException) {
            OneframeLogger("Production Header is not displayed");
            blnRC = false;
        }
        return blnRC;
    }
	
       
    	@Step("Click Block of Business Button")
    	public void clickBlockofbusinessLink() {
    		try {
    			if (ObjectExist(lnkBlockofBusiness)) {
    				ClickWebObject(lnkBlockofBusiness);
    				OneframeLogger("Block of Business link clicked");
    			}
    		} catch (TimeoutException e) {
    			OneframeLogger("Block Of Business link not displayed");
    		}
    	}
        
        @Step("Close the Butterscotch App")
    	public void closeApp() {
    		oneframeDriver.close();
    		OneframeLogger("Butterscotch App is closed");
    	}
        
        @Step("Click on BaseFormulary")
    	public void clickBaseFormualry() {
    		try {
    			if (ObjectExist(lnkBaseFormulary)) {
    				ClickWebObject(lnkBaseFormulary);
    				OneframeLogger("Base Formulary link is clicked");
    			}
    		} catch (TimeoutException e) {
    			OneframeLogger("Base Formulary link is not clicked");
    		}
        }
        @Step("Click on NetFormulary")
    	public void clickNetFormualry() {
    		try {
    			if (ObjectExist(lnkNetFormulary)) {
    				ClickWebObject(lnkNetFormulary);
    				OneframeLogger("Net Formulary link is clicked");
    			}
    		} catch (TimeoutException e) {
    			OneframeLogger("Net Formulary link is not clicked");
    		}
        } @Step("Click on General Defaults")
    	public void clickGDFormualry() {
    		try {
    			if (ObjectExist(lnkGD)) {
    				ClickWebObject(lnkGD);
    				OneframeLogger("General Defaults link is clicked");
    			}
    		} catch (TimeoutException e) {
    			OneframeLogger("General Defaults link is not clicked");
    		}
}
        
	@Step("Click on First Rule ID")
	public void clickRuleID() throws InterruptedException {
	WaitForApplicationToLoadCompletely();
		
		try {
			if (WaitForObjectVisibility(lstRuleIDS)) {				
				ClickWebObject(lstRuleIDS);
				OneframeLogger("First Rule ID link is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("First Rule ID link is not clicked");
		}
	}
	
	
	
	@Step("Verify Block of Business Data is displayed")
    public boolean verifyBlockofBusinessDatadisplay() throws InterruptedException{
	    boolean blnRC = false;
        WaitForApplicationToLoadCompletely();
        WaitForObjectVisibility(hdrLibraries.get(0));
        try {
            if (hdrLibraries.get(0).isDisplayed()) {
            	highlightElement(hdrLibraries.get(0));
                OneframeLogger("Block of Business Data is displayed");
                blnRC = true;
            }
        } catch (NoSuchElementException toException) {
            OneframeLogger("Block of Business is not displayed");
            blnRC = false;
        }
        return blnRC;
	}
	@Step("Verify Base Formulary Data is displayed")
    public boolean verifyBaseFormualryDatadisplay() throws InterruptedException{
	    boolean blnRC = false;
        WaitForApplicationToLoadCompletely();
        WaitForObjectVisibility(tableRecords);
        try {
            if (tableRecords.isDisplayed()) {
            	highlightElement(tableRecords);
                OneframeLogger("Base Formulary data is displayed");
                OneframeLogger("Data under Base Formulary: " +tableRecords.getText());
                blnRC = true;
            }
        } catch (NoSuchElementException toException) {
            OneframeLogger("Base Formulary data is not displayed");
            blnRC = false;
        }
        return blnRC;
	}
	@Step("Verify Net Formulary Data is displayed")
    public boolean verifyNetFormualryDatadisplay() throws InterruptedException{
	    boolean blnRC = false;
        WaitForApplicationToLoadCompletely();
        WaitForObjectVisibility(hdrLibraries.get(2));
        try {
            if (hdrLibraries.get(1).isDisplayed()) {
            	highlightElement(hdrLibraries.get(2));
                OneframeLogger("Net Formulary Data is displayed");
                blnRC = true;
            }
        } catch (NoSuchElementException toException) {
            OneframeLogger("Net Formulary is not displayed");
            blnRC = false;
        }
        return blnRC;
	}
	@Step("Verify General Defaults is Displayed")
    public boolean verifyGeneralDefaultsdisplay() throws InterruptedException{
	    boolean blnRC = false;
        WaitForApplicationToLoadCompletely();
        WaitForObjectVisibility(hdrLibraries.get(4));
        try {
            if (hdrLibraries.get(4).isDisplayed()) {
            	highlightElement(hdrLibraries.get(4));
                OneframeLogger("General Defaults Data is displayed");
                blnRC = true;
            }
        } catch (NoSuchElementException toException) {
            OneframeLogger("General Defaults is not displayed");
            blnRC = false;
        }
        return blnRC;
	}
	@Step("Verify Cost Shares is Displayed")
    public boolean verifyCostSharesDatadisplay() throws InterruptedException{
	    boolean blnRC = false;
        WaitForApplicationToLoadCompletely();
        WaitForObjectVisibility(hdrLibraries.get(5));
        try {
            if (hdrLibraries.get(5).isDisplayed()) {
            	highlightElement(hdrLibraries.get(5));
                OneframeLogger("General Defaults Data is displayed");
                blnRC = true;
            }
        } catch (NoSuchElementException toException) {
            OneframeLogger("General Defaults is not displayed");
            blnRC = false;
        }
        return blnRC;
	}
	
	@Step("Click on Rule Version ID")
	public void clickRuleVersionID() {
		try {
			if (ObjectExist(lnkVersionIds)) {
				highlightElement(lnkVersionIds);
				ClickWebObject(lnkVersionIds);
				OneframeLogger("First Rule Version ID link is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("First Rule Version ID link is not clicked");
		}
	}
	
	@Step("Verify RuleID Title is Displayed")
	public boolean verifyRuleIDTitleDisplay() {
		WaitForObjectVisibility(txtRuleID);
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (txtRuleID.isDisplayed()) {
				highlightElement(txtRuleID);
				OneframeLogger("RuleID Title is Displayed : " + txtRuleID.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("RuleID Title is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	
	
	@Step("Verify Pagination Buttons are disabled when the records are less than 10")
	public boolean verifyPaginationwhenlessthan10records() {
		
		boolean flg = false;
		
		try {
			
			WaitForApplicationToLoadCompletely();	
			WaitForObjectVisibility(txtrecordscount);
			highlightElement(txtrecordscount);
			OneframeLogger("The Records Count is "+txtrecordscount.getText());
			highlightElement(btnPreviousPage);
			highlightElement(btnNextPage);
			
			String nextBtnStatus = btnNextPage.getAttribute("disabled");
			String prvBtnStatus = btnNextPage.getAttribute("disabled");
			OneframeLogger("Next Button is disabled: " +nextBtnStatus);
			OneframeLogger("Previous Button is disabled: " +prvBtnStatus);
			
			if(nextBtnStatus.equalsIgnoreCase("true") && prvBtnStatus.equalsIgnoreCase("true")) {
				return true;
			}
			
		} catch (Exception e) {
			OneframeLogger("Previous & Next Buttons are Disabled");
			flg = false;
		}

		return flg;
	}
	
	
	@Step("Verify Pagination Buttons are Enabled when the records are more than 10")
	public boolean verifyPaginationwhenmorethan10records() {
		ScrollWebPageByPixel(100);
		ClickWebObject(hdrLibraries.get(0));
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(txtrecordscount);
		highlightElement(txtrecordscount);
		OneframeLogger("The Records Count is "+txtrecordscount.getText());
		highlightElement(btnPreviousPage);
		highlightElement(btnNextPage);
			return btnPreviousPage.isEnabled() && btnNextPage.isEnabled();		
	}

	@Step("Click on Next Button")
	public void clickNextButton() {
		try {
			if (ObjectExist(btnNextPage)) {				
				ClickWebObject(btnNextPage);
				OneframeLogger("Next Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Next Button is not clicked");
		}
	}
	@Step("Click on Previous Button")
	public void clickPreviousButton() {
		try {
			if (ObjectExist(btnPreviousPage)) {				
				ClickWebObject(btnPreviousPage);
				OneframeLogger("Previous Page is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Previous Page is not clicked");
		}
	}
	@Step("Click on required RuleName in any Library")
	public void clickRuleName(String libraryname, String ruleID) throws InterruptedException {
		//Thread.sleep(5000);
       try {
    	   ClickWebObject(hdrBenefitRuleEngine);
    	   ClickWebObject(hdrBenefitRuleEngine);
    	   ClickWebObject(hdrBenefitRuleEngine);
    	   ClickWebObject(hdrBenefitRuleEngine);
		String element = String.format("//mat-expansion-panel-header[contains(.,' %s ')]", libraryname);
		WebElement LibraryName = oneframeDriver.findElement(By.xpath(element));	
		String elementthree = String.format(
				"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/table/thead[@role='rowgroup']",
				libraryname);
		WebElement ruleHeader = oneframeDriver.findElement(By.xpath(elementthree));
		if (ObjectExist(LibraryName)) {
			ClickWebObject(LibraryName);
			OneframeLogger("Library Name is clicked " + LibraryName.getText());
			ClickWebObject(ruleHeader);
			OneframeLogger("Library Name headers are clicked ");
			String elementTwo = String.format(
					"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/div/mat-paginator/div/div/di"
							+ "v/div[@class='mat-paginator-range-label']",
					libraryname);
			WebElement RecordsCount = oneframeDriver.findElement(By.xpath(elementTwo));
			String records = RecordsCount.getText();
			OneframeLogger("The Total No of Records are " + records);

			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			boolean ruleIdClicked = false;
			while (recordsPerPage <= totalRecords) {
				String elementOne = String.format(
						"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/table/tbody/tr/td/a",
						libraryname);
				List<WebElement> listofRules = oneframeDriver.findElements(By.xpath(elementOne));
				for (int i = 0; i < listofRules.size(); i++) {
					if (listofRules.get(i).getText().equals(ruleID)) {
						WaitForObjectToBeClickable(listofRules.get(i));
						OneframeLogger("The Selected Rule Name is  " + listofRules.get(i).getText());
						listofRules.get(i).click();
						OneframeLogger("The Selected Rule Name is Clicked ");
						ruleIdClicked = true;					
					}
				}

				if (!ruleIdClicked) {
					ScrollWebPageByPixel(200);
					WaitForObjectVisibility(btnNextPage);
					btnNextPage.click();
					OneframeLogger("Next Page is clicked");
					ClickWebObject(ruleHeader);
					elementTwo = String.format(
							"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/div/mat-paginator/div/div/di"
									+ "v/div[@class='mat-paginator-range-label']",
							libraryname);
					RecordsCount = oneframeDriver.findElement(By.xpath(elementTwo));
					records = RecordsCount.getText();
					OneframeLogger("The Total No of Records are " + records);
					recordCnt = records.split("–");
					totalRecordCnt = recordCnt[1].split("of");
					totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
					recordsPerPage = Integer.parseInt(totalRecordCnt[0].trim());
					
				}
			}
		}
       }catch (StaleElementReferenceException sef) {}   	   
	}
	
	@Step("Verify Next button is Enabled when the records are more than 10")
	public boolean verifyNextBtnWhenRecordsMoreThan10() {
		
		boolean flg = false;
		WaitForApplicationToLoadCompletely();
		ClickWebObject(hdrBenefitRuleEngine);
		ClickWebObject(hdrBenefitRuleEngine);
		ClickWebObject(hdrBenefitRuleEngine);
		
		try {	
			WaitForObjectVisibility(btnNextPage);
			highlightElement(txtrecordscount);
			OneframeLogger("The Records Count is "+txtrecordscount.getText());
			highlightElement(btnNextPage);
			
			String nextBtnStatus = btnNextPage.getAttribute("disabled");
			
			if(nextBtnStatus == null) {
				return true;
			}
			
		} catch (Exception e) {
			OneframeLogger("Next Buttons is Disabled");
			OneframeLogger(e.toString());
			flg = false;
		}

		return flg;
	}
	
	@Step("Verify Previous button is Enabled when the records are more than 10")
	public boolean verifyPrvBtnWhenRecordsMoreThan10() {
		
		boolean flg = false;
		WaitForApplicationToLoadCompletely();
		ClickWebObject(hdrBenefitRuleEngine);
		ClickWebObject(hdrBenefitRuleEngine);
		ClickWebObject(hdrBenefitRuleEngine);
		
		try {	
			WaitForObjectVisibility(btnNextPage);
			highlightElement(txtrecordscount);
			OneframeLogger("The Records Count is "+txtrecordscount.getText());
			highlightElement(btnPreviousPage);
			
			String nextBtnStatus = btnPreviousPage.getAttribute("disabled");
			
			if(nextBtnStatus == null) {
				return true;
			}
			
		} catch (Exception e) {
			OneframeLogger("Previous Buttons is Disabled");
			OneframeLogger(e.toString());
			flg = false;
		}

		return flg;
	}

}
    	
	

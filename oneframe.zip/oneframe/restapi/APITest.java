// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.restapi;

import io.restassured.path.json.JsonPath;
import anthem.irx.oneframe.utilities.FileOpsHelper;
import io.restassured.http.Method;
import io.restassured.http.Cookie;
import java.util.Map;
import java.util.HashMap;
import io.restassured.RestAssured;
import anthem.irx.oneframe.core.OneframeContainer;
import io.restassured.response.Response;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;

public class APITest
{
    private RequestSpecification ofReqSpecification;
    private RequestSpecBuilder ofReqSpecBuilder;
    private Response ofResponse;
    private String hostBaseURI;
    private int hostPortNumber;
    
    public APITest() {
        this.hostBaseURI = "";
        this.hostPortNumber = 0;
        this.setRestAssuredConfiguration(OneframeContainer.getApiAppBaseURL(), Integer.valueOf(OneframeContainer.getApiPortNumber()));
    }
    
    public APITest(final String hostBaseURI, final int hostPortNumber) {
        this.hostBaseURI = "";
        this.hostPortNumber = 0;
        this.setRestAssuredConfiguration(hostBaseURI, hostPortNumber);
    }
    
    private void setRestAssuredConfiguration(final String hostBaseURI, final int hostPortNumber) {
        (this.ofReqSpecBuilder = new RequestSpecBuilder()).setBaseUri(hostBaseURI);
        if (hostPortNumber > 0) {
            this.ofReqSpecBuilder.setPort(hostPortNumber);
        }
        if (OneframeContainer.getSSLHTTPSflag()) {
            if (this.checkTrustKeyStoreFileExists()) {
                this.setupRAtrustStore();
            }
            else {
                OneframeContainer.OneframeErrorLogger("TrustStore JKS file [" + OneframeContainer.getApiTrustStore() + "] doesnt exist");
                OneframeContainer.OneframeErrorLogger("1. Export certificates from the application site using your browser");
                OneframeContainer.OneframeErrorLogger("2. Import certificates into Java KeyStore File using the below command");
                OneframeContainer.OneframeErrorLogger("\t keytool -importcert -alias < alias name> -file <certificatefile>.crt -keystore <application.truststore> -storepass changeit");
            }
        }
        else {
            RestAssured.useRelaxedHTTPSValidation();
        }
    }
    
    public APITest build() {
        return this;
    }
    
    public APITest build(final HashMap<String, String> requestHeaders) {
        this.ofReqSpecBuilder.addHeaders((Map)requestHeaders);
        return this;
    }
    
    public APITest build(final HashMap<String, String> requestHeaders, final Object requestBody) {
        this.ofReqSpecBuilder.addHeaders((Map)requestHeaders);
        this.ofReqSpecBuilder.setBody(requestBody);
        return this;
    }
    
    public APITest build(final HashMap<String, String> requestHeaders, final String requestBody) {
        this.ofReqSpecBuilder.addHeaders((Map)requestHeaders);
        this.ofReqSpecBuilder.setBody(requestBody);
        return this;
    }
    
    public APITest build(final HashMap<String, String> requestHeaders, final HashMap<String, ?> queryParams, final String requestBody) {
        this.ofReqSpecBuilder.addHeaders((Map)requestHeaders);
        this.ofReqSpecBuilder.addQueryParams((Map)queryParams);
        this.ofReqSpecBuilder.setBody(requestBody);
        return this;
    }
    
    public APITest build(final HashMap<String, String> requestHeaders, final HashMap<String, ?> queryParams) {
        this.ofReqSpecBuilder.addHeaders((Map)requestHeaders);
        this.ofReqSpecBuilder.addQueryParams((Map)queryParams);
        return this;
    }
    
    public APITest build(final HashMap<String, String> requestHeaders, final HashMap<String, ?> queryParams, final Cookie reqCookie) {
        this.ofReqSpecBuilder.addHeaders((Map)requestHeaders);
        this.ofReqSpecBuilder.addQueryParams((Map)queryParams);
        this.ofReqSpecBuilder.addCookie(reqCookie);
        return this;
    }
    
    public APITest addQueryParams(final HashMap<String, ?> queryParams) {
        this.ofReqSpecBuilder.addQueryParams((Map)queryParams);
        return this;
    }
    
    public APITest addQueryParam(final String paramName, final String paramValue) {
        this.ofReqSpecBuilder.addQueryParam(paramValue, new Object[] { paramValue });
        return this;
    }
    
    public APITest setBasePath(final String basePath) {
        this.ofReqSpecBuilder.setBasePath(basePath);
        return this;
    }
    
    public APITest setBasePathAndParameter(final String basePath, final String pathParam, final String paramValue) {
        this.ofReqSpecBuilder.setBasePath(basePath);
        this.ofReqSpecBuilder.addParam(pathParam, new Object[] { paramValue });
        return this;
    }
    
    public APITest setBasePathAndParameters(final String basePath, final HashMap<String, ?> pathParamValues) {
        this.ofReqSpecBuilder.setBasePath(basePath);
        this.ofReqSpecBuilder.addParams((Map)pathParamValues);
        return this;
    }
    
    public APITest setPathParameter(final String pathParam, final String paramValue) {
        this.ofReqSpecBuilder.addParam(pathParam, new Object[] { paramValue });
        return this;
    }
    
    public APITest setPathParameters(final HashMap<String, ?> pathParamValues) {
        this.ofReqSpecBuilder.addParams((Map)pathParamValues);
        return this;
    }
    
    public HashMap<String, String> getDefaultRequestHeaders() {
        final HashMap<String, String> defaultHeaders = new HashMap<String, String>();
        return defaultHeaders;
    }
    
    private void setupRAtrustStore() {
        final String trustStoreJKS = OneframeContainer.getApiTrustStore();
        final String trustStoreJKSPWD = OneframeContainer.getApiTrustStorePassword();
        RestAssured.trustStore(trustStoreJKS, trustStoreJKSPWD);
    }
    
    public void setPortNumber(final int racPortNumber) {
        RestAssured.port = racPortNumber;
    }
    
    public APITest httpPOST() {
        this.executeHttpRequest("", Method.POST);
        return this;
    }
    
    public APITest httpPOST(final String BasePath) {
        this.executeHttpRequest(BasePath, Method.POST);
        return this;
    }
    
    public APITest httpGET() {
        this.executeHttpRequest("", Method.GET);
        return this;
    }
    
    public APITest httpGET(final String BasePath) {
        this.executeHttpRequest(BasePath, Method.GET);
        return this;
    }
    
    public APITest httpDELETE() {
        this.executeHttpRequest("", Method.DELETE);
        return this;
    }
    
    public APITest httpPUT() {
        this.executeHttpRequest("", Method.PUT);
        return this;
    }
    
    public APITest httpPATCH() {
        this.executeHttpRequest("", Method.PATCH);
        return this;
    }
    
    public APITest httpOPTIONS() {
        this.executeHttpRequest("", Method.OPTIONS);
        return this;
    }
    
    public Response returnResponse() {
        return this.ofResponse;
    }
    
    private void executeHttpRequest(final String BasePath, final Method requestMethod) {
        this.ofReqSpecification = this.ofReqSpecBuilder.build();
        OneframeContainer.OneframeLogger("\t API_REQUEST \n" + ((RequestSpecification)this.ofReqSpecification.log().everything()).toString());
        if (BasePath == "") {
            this.ofResponse = (Response)RestAssured.given(this.ofReqSpecification).request(requestMethod);
        }
        else {
            this.ofResponse = (Response)RestAssured.given(this.ofReqSpecification).request(requestMethod, BasePath, new Object[0]);
        }
        OneframeContainer.OneframeLogger("\t API_RESPONSE \n" + this.ofResponse.prettyPrint());
    }
    
    private boolean checkTrustKeyStoreFileExists() {
        return FileOpsHelper.checkFileExist(OneframeContainer.getApiTrustStore());
    }
    
    public HashMap<String, String> getBenefitCentralAccessTokenDetails() {
        final HashMap<String, String> accessTokenHdrs = new HashMap<String, String>();
        final HashMap<String, String> accessTokenDetails = new HashMap<String, String>();
        accessTokenHdrs.put("Content-Type", "application/x-www-form-urlencoded");
        accessTokenHdrs.put("authorization", "Basic aXJ4Om5raG9DQWxRRWxhZzAwM2czTVAyRXNVUTJOMWtXSUZ3ZjBRdkZFNFhlRjQ2SGtnUm5kRmNxZzJ4VVBZRUJXbA==");
        final RequestSpecBuilder accessTokenRequest = new RequestSpecBuilder();
        accessTokenRequest.setBaseUri(OneframeContainer.getApiAppBaseURL());
        accessTokenRequest.setBasePath(OneframeContainer.getoAuthEndPoint());
        accessTokenRequest.addHeaders((Map)accessTokenHdrs);
        accessTokenRequest.addFormParam("grant_type", new Object[] { "automation" });
        accessTokenRequest.addFormParam("automation_id", new Object[] { "automation" });
        accessTokenRequest.addFormParam("automation_secret", new Object[] { "automation1234!" });
        final RequestSpecification accessTokenSpec = accessTokenRequest.build();
        final Response accessTokResponse = (Response)RestAssured.given(accessTokenSpec).post();
        if (accessTokResponse.getStatusCode() == 200) {
            OneframeContainer.OneframeLogger("Access token received to access Benefits Central - APIs");
            final JsonPath respBody = accessTokResponse.jsonPath();
            accessTokenDetails.put("access_token", (String)respBody.get("access_token"));
            accessTokenDetails.put("token_type", (String)respBody.get("token_type"));
            accessTokenDetails.put("refresh_token", (String)respBody.get("refresh_token"));
            accessTokenDetails.put("expires_in", respBody.get("expires_in").toString());
        }
        else {
            OneframeContainer.OneframeErrorLogger("Unable to retrieve access token");
            OneframeContainer.OneframeErrorLogger(accessTokResponse.jsonPath().prettyPrint());
        }
        return accessTokenDetails;
    }
    
    public String getBenefitCentralAccessToken() {
        final HashMap<String, String> accessTokenDetails = this.getBenefitCentralAccessTokenDetails();
        return "Bearer " + accessTokenDetails.get("access_token");
    }
    
    private void ResetAPITest() {
        RestAssured.reset();
    }
}

package com.ibc.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibc.base.PageBase;

public class HomePage extends PageBase {
	// Page Elements
	@FindBy(xpath = "//button[@id='openSide']")
	WebElement btnMenu;

	@FindBy(xpath = "//div[@class='search-container__filter']/button")
	WebElement btnSearch;

	@FindBy(xpath = "//input[@placeholder='Search benefit']")
	WebElement txtSearchBenefit;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Logout ']")
	WebElement btnLogout;

	public HomePage(){
		super();
		PageFactory.initElements(driver, this);
	}

	public void searchBenefit(String searchTerm) {
		waitForElementToBeClickable(btnSearch);
		clickElement(btnSearch);
		clickElement(txtSearchBenefit);
		sendKeys(txtSearchBenefit, searchTerm);
		pressEnterOnElement(txtSearchBenefit, Keys.ENTER);
	}

	public void logout() {
		waitForElementToBeClickable(btnLogout);
		clickElement(btnLogout);
		clearCache();
		clearCookies();
		clearLocalStorage();
	}

	
	public void waitForSpinnerToDisappear() {
		waitForElementToDisappear(By.cssSelector("span.spinner"));
	}

}


package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibrariesFederalMandateDynamicLayer extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Libraries Federal Mandate Dynamic Layer Auto apply field is displayed")
	public void setUp() {
		InitializeLaunchPad("IBPW_666");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "EffectiveDate", "LOBId" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Libraries Federal Mandate Dynamic Layer Auto apply field is displayed", dataProvider = "TestData")
	@Description("Validate Libraries Federal Mandate Dynamic Layer Auto apply field is displayed")
	public void ValidateStateMandateDynamicLayer(String TestCaseID, String TestStatus, String ClientId,
			String EffectiveDate, String LOBId) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			mandate.clickViewButtonofMandates();
			sa.assertTrue(mandate.verifyMandatesHeader(), "Verified 'Mandates header' is displayed");
			mandate.clickAddFederalMandate();
			sa.assertTrue(mandate.verifyAddNewMandateHeader(), "Verified 'Add New Mandate' is displayed");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId),
					"Verified and selected 'ClientID dropdown'");
			sa.assertTrue(librariesprogramspage.selectLobdropdown(LOBId), "Verified and selected 'LOB dropdown'");
			sa.assertTrue(mandate.verifyFederalAutoApplyDropdown(), "Verified 'Auto Apply dropdown' is displayed");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger(
					"Validate Libraries Federal Mandate Dynamic Layer Auto apply field is displayed Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Libraries Federal Mandate Dynamic Layer Auto apply field");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLegacyBenefitPlanIDandVersionID extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating Benefit Legacy Benefit PlanID and VersionID values")
	public void setUp() {
		InitializeLaunchPad("IBPW_660");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "Benefit", "ClientId","EffectiveDate", "PlanID",
				"LOBId", "StateId", "Mandates","VersionID"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefit Legacy Plan ID and Version ID values", dataProvider = "TestData")
	@Description("Validate Benefit Legacy Plan ID and Version ID values")
	public void ValidateVersionIDandPlanID(String TestCaseID, String TestStatus, String Benefit,
			String ClientId, String EffectiveDate,String PlanID,String LOBId, String StateId, String Mandates,String VersionID)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();	 
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			benefitpage.verifyCreateaBenefitButtonDisplay();
			benefitpage.clickCreateaBenefitButton();
			sa.assertTrue(createbenefitpage.verifyCreateBenefit(), "Verified Create Benefit is displayed");
			sa.assertTrue(createbenefitpage.verifyBenefitHeader(), "Verified Benefit Header is displayed");
			
			createbenefitpage.selectClientId(ClientId);
			createbenefitpage.selectLOBId(LOBId);
			createbenefitpage.selectStateId(StateId);
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);		
			createbenefitpage.selectMandates(Mandates);
			String benefitID = createbenefitpage.clickRequestBenefitIDButtonGetBenefitID();
			createbenefitpage.removeAndEnterBenefit(benefitID);
			//createbenefitpage.EnterCBNewBenefitId();	
			createbenefitpage.ClickCBCreateButton();
			
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Created Benefit header is displayed");
			sa.assertTrue(createbenefitpage.verifyVerStatus(), "Verified Version Status  is displayed");
			sa.assertTrue(createbenefitpage.verifyVersionValue(), "Verified Version Value is displayed");
			sa.assertTrue(createbenefitpage.CheckVerifyButtonisDisplayed(), "Verified the Verify Button is displayed");
			sa.assertTrue(createbenefitpage.CheckCloseButtonisDisplayed(), "Verified Close Button is displayed");
			sa.assertTrue(createbenefitpage.CheckSaveButtonisDisplayed(), "Verified Save Button is displayed");
			benefitpage.clickDetailsTab();
			benefitpage.clickDetailsSubTab();
			benefitpage.EnterLegacyPlanID(PlanID);
			benefitpage.EnterLegacyPlanVersion(VersionID);
			benefitpage.clickCloseButton();
			benefitpage.clickSaveandExitButton();
			sa.assertTrue(benefitpage.verifyLegacyBenefitPlanID(PlanID), "Verified Actual PlanID is matched with Expected PlanID");
			sa.assertTrue(benefitpage.verifyLegacyBenefitPlanVersionID(VersionID), "Verified Actual VersionID is matched with Expected VersionID");		
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Benefit Version Effective date and End Date values are updated Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Update Benefit Version Effective date and End Date values");
		}
		
//		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

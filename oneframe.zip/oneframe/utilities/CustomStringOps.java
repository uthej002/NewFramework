// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

public class CustomStringOps
{
    public static String ofStringTrim(final String toBeTrimmed) {
        String trimmedString = "";
        if (toBeTrimmed == null || toBeTrimmed.isEmpty()) {
            trimmedString = "";
        }
        else {
            trimmedString = toBeTrimmed.trim();
        }
        return trimmedString;
    }
    
    public static String ofStringToLowercase(final String toLowerCase) {
        String caseLowered = "";
        if (toLowerCase == null || toLowerCase.isEmpty()) {
            caseLowered = "";
        }
        else {
            caseLowered = toLowerCase.toLowerCase();
        }
        return caseLowered;
    }
    
    public static String ofStringTrimmedAndLowerCase(final String toTrimAndLower) {
        String TrimmedCaseLowered = "";
        if (toTrimAndLower == null || toTrimAndLower.isEmpty()) {
            TrimmedCaseLowered = "";
        }
        else {
            TrimmedCaseLowered = toTrimAndLower.toLowerCase().trim();
        }
        return TrimmedCaseLowered;
    }
}

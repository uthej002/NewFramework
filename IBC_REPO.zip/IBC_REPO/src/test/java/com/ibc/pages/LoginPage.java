package com.ibc.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibc.base.PageBase;

public class LoginPage extends PageBase {
    // Page Elements
	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()=' Login with CarelonRx ID ']")
	WebElement btnLogin;
	
	@FindBy(xpath = "//input[@id='username']")
	WebElement txtUsername;

	@FindBy(xpath = "//input[@id='password']")
	WebElement txtPassword;
	
	@FindBy(xpath = "//a[@title='Submit']")
	WebElement btnLogin2;
    
    public LoginPage(){
        super();
        PageFactory.initElements(driver, this);
    }

    public void login(String username, String password) {
    	waitForPageLoad();
    	waitForElementToBeClickable(btnLogin);
    	clickElement(btnLogin);
    	waitForPageLoad();
    	refreshBrowser();
    	waitForPageTitleToBe("Associate Login");
    	sendKeys(txtUsername, username);
    	sendKeys(txtPassword, password);
    	clickElement(btnLogin2);
    }
}


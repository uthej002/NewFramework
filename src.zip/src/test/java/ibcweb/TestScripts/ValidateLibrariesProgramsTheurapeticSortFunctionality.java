package ibcweb.TestScripts;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.*;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.testng.annotations.*;

import com.google.common.collect.Ordering;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class ValidateLibrariesProgramsTheurapeticSortFunctionality extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;

	FileIngestionDbValidations db;

	@BeforeClass
	@Step("Initializing Test Script for validating sort functionality Libraries -> Programs -> Theurapetic")
	public void setUp() {
		InitializeLaunchPad("IBPW_527");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		db = new FileIngestionDbValidations();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus",};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate sort functionality on program name column for Libraries -> Programs -> Theurapetic", dataProvider = "TestData")
	@Description("Validate sort functionality on program name column for Libraries -> Programs -> Theurapetic")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus)throws AWTException, InterruptedException, IOException {
		
		List<String>  expectedProgramNameAsc = db.getColumnAsList("program", "name", "where type='Therapeutic'", "ASC");
		java.util.Collections.sort(expectedProgramNameAsc);
		//List<String>  ProgramNameDesc = db.getPrograms("Cost-Of-Care", "name", "DESC");
		//java.util.Collections.sort(expectedProgramNameDesc);
		List<String> expectedProgramNameDesc = Ordering.natural().reverse().sortedCopy(expectedProgramNameAsc);
		
		List<String>  expectedEffectiveDateAsc = db.getColumnAsList("program", "EFFECTIVE_DATE", "where type='Therapeutic'", "ASC");
		List<String>  expectedEffectiveDateDesc = db.getColumnAsList("program", "EFFECTIVE_DATE", "where type='Therapeutic'", "DESC");
		
		List<String>  expectedTerminationDateAsc = db.getColumnAsList("program", "TERMINATION_DATE", "where type='Therapeutic'", "ASC");
		List<String>  expectedTerminationDateDesc = db.getColumnAsList("program", "TERMINATION_DATE", "where type='Therapeutic'", "DESC");

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "Verified Programs Section Page is displayed");
			
			
			//PROGRAM NAMES - Ascending order
			librariesprogramspage.getValuesFromColumn("program name", "before sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("program name"), "Clicked on Program Name column header");
			List<String> actualProgramNames = librariesprogramspage.getValuesFromColumn("program name", "after sorting in Ascending Order");
			//getValuesFromColumn("column name");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedProgramNameAsc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//PROGRAM NAMES - Descending order
			librariesprogramspage.getValuesFromColumn("program name", "before sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("program name"), "Clicked on Program Name column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("program name", "after sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedProgramNameDesc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//TERMINATION DATE - Ascending order
			librariesprogramspage.getValuesFromColumn("termination date", "before sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("termination date"), "Clicked on Termination Date column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("termination date", "after sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedTerminationDateAsc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//TERMINATION DATE - Descending order
			librariesprogramspage.getValuesFromColumn("termination date", "before sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("termination date"), "Clicked on Termination Date column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("termination date", "after sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedTerminationDateDesc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//EFFECTIVE DATE - Ascending order
			librariesprogramspage.getValuesFromColumn("effective date", "before sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("effective date"), "Clicked on Effective Date column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("effective date", "after sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedEffectiveDateAsc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//EFFECTIVE DATE - Descending order
			librariesprogramspage.getValuesFromColumn("effective date", "before sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("effective date"), "Clicked on Effective Date column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("effective date", "after sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedEffectiveDateDesc, actualProgramNames), "Expected Text matches with the Actual Text");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Add Program Button is Disabled without Mandatory fields under Cost of Care Program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Add Program Button is Disabled without Mandatory fields under Cost of Care Program");
		}

//		homepage.clickLogout();  
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

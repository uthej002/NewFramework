package ibcweb.PageObjects;

import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class BulkProcessExcelValidation extends OneframeContainer {

	@FindBy(xpath = "//*[@id='tbody']/tr[1] | //a[@class=\"file\"]")
	WebElement nmeFileName;

	@FindBy(xpath = "//*[@id='dateColumnHeader']  | //a[text()='Last Modified']")
	WebElement hdrDateColumn;

	// Initializing the Page Objects:
	public BulkProcessExcelValidation() {
		PageFactory.initElements(oneframeDriver, this);
	}

	@Step("Verify downloaded file")
	public boolean verifyDownloadedFile(String filetype) throws InterruptedException {
		// Thread.sleep(40000);
		boolean blnRC = false;

		if (TSBrowser.equals("Chrome")) {
			JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
			js.executeScript("window.open();");
			ArrayList<String> tabs = new ArrayList<String>(oneframeDriver.getWindowHandles());
			oneframeDriver.switchTo().window(tabs.get(1));
			oneframeDriver.get(System.getProperty("user.dir") + "\\src\\test\\resources\\RunTime");
			WebObjectHandler.ClickWebObject(hdrDateColumn);
			String text = nmeFileName.getText();
			if (text.contains("BulkUpdate") && filetype.equalsIgnoreCase("csv")) {
				OneframeLogger("File downloaded in csv format -" + nmeFileName.getText());
				blnRC = true;

			} else {
				OneframeLogger("File not found in correct format: " + text);
			}
			// oneframeDriver.switchTo().window(tabs.get(0)); // switch back to main screen
		}
		return blnRC;
	}

	@Step("Get File name")
	public String getFileName() {
		return nmeFileName.getText().split(" ")[0].trim();
	}

	@Step("Switch Tabs")
	public void switchTabs() {
		ArrayList<String> tabs = new ArrayList<String>(oneframeDriver.getWindowHandles());
		oneframeDriver.switchTo().window(tabs.get(0));
	}
}

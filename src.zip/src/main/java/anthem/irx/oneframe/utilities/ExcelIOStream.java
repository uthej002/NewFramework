package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeLogger;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelIOStream extends OneframeContainer {
  private String tsExceldoc;
  
  private XSSFWorkbook tsxlsxWorkBook;
  
  private XSSFSheet tsxlsxSheet;
  
  FileOutputStream fileOut;
  
  FileInputStream iStream;
  
  public ExcelIOStream(String tsExceldoc) {
    this.tsExceldoc = tsExceldoc;
    this.tsxlsxWorkBook = openExcelxWorkbook(this.tsExceldoc);
    OneframeLogger("[ONEFRAME]Open Excel file : " + this.tsExceldoc);
  }
  
  public ExcelIOStream() {}
  
  private void writeToExcelSheet(String SheetName, String RowIdentifier, String ColumnName, String OutputData) {
    int totalRows = 0;
    this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(SheetName);
    totalRows = this.tsxlsxSheet.getPhysicalNumberOfRows() + 1;
    for (int i = this.tsxlsxSheet.getFirstRowNum() + 1; i < this.tsxlsxSheet.getPhysicalNumberOfRows(); i++) {
      XSSFRow row = this.tsxlsxSheet.getRow(i);
      for (int j = row.getFirstCellNum(); j < row.getPhysicalNumberOfCells(); j++);
    } 
  }
  
  public void closeWorkbook() throws IOException {
    this.tsxlsxWorkBook.close();
  }
  
  private synchronized XSSFWorkbook openExcelxWorkbook(String xlsxDoc) {
    try {
      this.iStream = new FileInputStream(xlsxDoc);
      XSSFWorkbook wb = new XSSFWorkbook(this.iStream);
      return wb;
    } catch (IOException IOE) {
      OneframeLogger("[ONEFRAME]" + IOE.getMessage());
      return null;
    } 
  }
  
  public synchronized HashMap<String, String> readScriptConfiguration(String scenarioID) {
    HashMap<String, String> scriptConfigs = new HashMap<>();
    int scFound = 0;
    this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(TSScriptConfigSheet);
    int frow = this.tsxlsxSheet.getFirstRowNum();
    XSSFRow xSSFRow = this.tsxlsxSheet.getRow(frow);
    Iterator<Cell> KeyCellIterator = xSSFRow.iterator();
    Iterator<Row> rowIterator = this.tsxlsxSheet.iterator();
    while (rowIterator.hasNext()) {
      Row valueRow = rowIterator.next();
      if (valueRow.getCell(0).getStringCellValue().equalsIgnoreCase(scenarioID)) {
        scFound = 1;
        Iterator<Cell> cellIterator = valueRow.iterator();
        while (cellIterator.hasNext()) {
          Cell keyCell = KeyCellIterator.next();
          Cell rowCell = cellIterator.next();
          if (keyCell.getStringCellValue().equalsIgnoreCase("RunFlag") && 
            rowCell.getStringCellValue().equalsIgnoreCase("no")) {
            OneframeLogger.throwException("The RunFlag for Test Scenario - " + scenarioID + " is 'No', update it to 'Yes' to enable execution");
            break;
          } 
          scriptConfigs.put(keyCell.getStringCellValue(), rowCell.getStringCellValue());
        } 
        break;
      } 
    } 
    if (scFound == 0)
      OneframeLogger.throwException("Script configurations not found for test scenario [" + scenarioID + "]"); 
    return scriptConfigs;
  }
  
  public synchronized String[][] readScriptConfiguration() {
    this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(TSScriptConfigSheet);
    int runflagIndex = getColumnIndex("RunFlag");
    int oftotrows = XlsXgetRowCount();
    int oftotcols = XlsXgetColumnCount();
    int runRows = 0;
    int irow = 0, icol = 0, curRowNo = 0, curColNo = 0;
    String[][] ScriptConfigurations = new String[oftotrows][oftotcols];
    try {
      for (irow = 0; irow < oftotrows; irow++) {
        XSSFRow xSSFRow = this.tsxlsxSheet.getRow(irow);
        if (irow == 0 || getCellValue((Row)xSSFRow, runflagIndex).equalsIgnoreCase("Yes")) {
          curRowNo = xSSFRow.getRowNum();
          OneframeLogger("[ONEFRAME] Reading configuration at Row [" + (curRowNo + 1) + "]");
          for (icol = 0; icol < oftotcols; icol++) {
            curColNo = icol;
            ScriptConfigurations[runRows][icol] = xSSFRow.getCell(icol).getStringCellValue();
          } 
          runRows++;
        } 
      } 
    } catch (NullPointerException NE) {
      OneframeLogger("[ONEFRAME]Script configuration spreadsheet contains cell format issues, review cell contents at row - " + (curRowNo + 1) + " : column - " + (curColNo + 1));
      OneframeLogger("[ONEFRAME]Guidelines: ");
      OneframeLogger("[ONEFRAME]1) Make sure there are no empty rows in between Script configurations");
      OneframeLogger("[ONEFRAME]2) Remove unused rows at the bottom of the script configuration");
      NE.printStackTrace();
      System.exit(1);
    } 
    runRows--;
    OneframeLogger("[ONEFRAME]Number of script configurations : " + runRows);
    return ScriptConfigurations;
  }
  
  public int getColumnIndex(String ColumnName) {
    int colIndex = 0;
    XSSFRow xSSFRow = this.tsxlsxSheet.getRow(0);
    for (int icol = 0; icol < XlsXgetColumnCount(); icol++) {
      if (xSSFRow.getCell(icol).getStringCellValue().equalsIgnoreCase(ColumnName)) {
        colIndex = icol;
        break;
      } 
    } 
    return colIndex;
  }
  
  public List<HashMap<String, String>> readScriptConfigurationValue() {
    this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(TSDataSheetKey);
    int lastRowNum = this.tsxlsxSheet.getLastRowNum();
    int lastCellNum = this.tsxlsxSheet.getRow(0).getLastCellNum();
    List<HashMap<String, String>> li = new ArrayList<>();
    for (int i = 0; i < lastRowNum; i++) {
      HashMap<String, String> datamap = new HashMap<>();
      for (int j = 0; j < lastCellNum; j++) {
        if (this.tsxlsxSheet.getRow(i + 1).getCell(j) != null)
          datamap.put(this.tsxlsxSheet.getRow(0).getCell(j).toString(), this.tsxlsxSheet
              .getRow(i + 1).getCell(j).toString()); 
      } 
      li.add(datamap);
    } 
    return li;
  }
  
  public HashMap<String, String> writeScriptConfigurationValue(String columnName, String columnValue) throws IOException {
    System.out.println(this.tsExceldoc);
    System.out.println(this.tsxlsxWorkBook);
    System.out.println(TSDataSheetKey);
    System.out.println(this.tsxlsxSheet);
    HashMap<String, String> datamap = null;
    this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(TSDataSheetKey);
    int lastRowNum = this.tsxlsxSheet.getLastRowNum();
    int lastCellNum = this.tsxlsxSheet.getRow(0).getLastCellNum();
    for (int i = 0; i < lastRowNum; i++) {
      datamap = new HashMap<>();
      for (int j = 0; j < lastCellNum; j++) {
        if (this.tsxlsxSheet.getRow(i + 1).getCell(j) != null) {
          if (this.tsxlsxSheet.getRow(0).getCell(j).toString().equalsIgnoreCase(columnName))
            this.tsxlsxSheet.getRow(i + 1).getCell(j).setCellValue(columnValue); 
          this.fileOut = new FileOutputStream(this.tsExceldoc);
          this.tsxlsxWorkBook.write(this.fileOut);
        } 
      } 
    } 
    return datamap;
  }
  
  public void UpdateTestDataToExcel(String TestCaseID, String Expected, String DB, String Status, String ColumnName) throws IOException {
    System.out.println(this.tsExceldoc);
    System.out.println(this.tsxlsxWorkBook);
    this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(TSTDSResultDocument);
    XSSFRow xSSFRow = this.tsxlsxSheet.createRow(0);
    xSSFRow.createCell(0).setCellValue("TestCaseID");
    xSSFRow.createCell(1).setCellValue("ColumnName");
    xSSFRow.createCell(2).setCellValue("ExpectedResults");
    xSSFRow.createCell(3).setCellValue("ActualResults");
    xSSFRow.createCell(4).setCellValue("TestResult");
    xSSFRow.createCell(5).setCellValue("ExecutionDateAndTime");
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH:mm:ss");
    LocalDateTime now = LocalDateTime.now();
    xSSFRow = this.tsxlsxSheet.createRow(this.tsxlsxSheet.getLastRowNum() + 1);
    xSSFRow.createCell(0).setCellValue(TestCaseID);
    xSSFRow.createCell(1).setCellValue(ColumnName);
    xSSFRow.createCell(2).setCellValue(Expected);
    xSSFRow.createCell(3).setCellValue(DB);
    xSSFRow.createCell(4).setCellValue(Status);
    xSSFRow.createCell(5).setCellValue(dtf.format(now));
    this.fileOut = new FileOutputStream(this.tsExceldoc);
    this.tsxlsxWorkBook.write(this.fileOut);
  }
  
  public void DeleteData(String SheetName) {
    int numberOfRows = this.tsxlsxSheet.getPhysicalNumberOfRows();
    if (numberOfRows > 0) {
      for (int i = this.tsxlsxSheet.getFirstRowNum(); i <= this.tsxlsxSheet.getLastRowNum(); i++) {
        if (this.tsxlsxSheet.getRow(i) != null) {
          this.tsxlsxSheet.removeRow((Row)this.tsxlsxSheet.getRow(i));
        } else {
          System.out.println("Info: clean sheet='" + this.tsxlsxSheet.getSheetName() + "' ... skip line: " + i);
        } 
      } 
    } else {
      System.out.println("Info: clean sheet='" + this.tsxlsxSheet.getSheetName() + "' ... is empty");
    } 
  }
  
  private String getCellValue(Row currRow, int cellIndex) {
    return currRow.getCell(cellIndex).getStringCellValue();
  }
  
  public int XlsXgetRowCount() {
    return this.tsxlsxSheet.getLastRowNum() + 1;
  }
  
  public int XlsXgetColumnCount() {
    return this.tsxlsxSheet.getRow(0).getLastCellNum();
  }
  
  public String[][] readDataFromReports() {
    this.tsxlsxSheet = this.tsxlsxWorkBook.getSheetAt(0);
    int lastRowNum = this.tsxlsxSheet.getLastRowNum();
    int lastCellNum = this.tsxlsxSheet.getRow(0).getLastCellNum();
    String[][] testData = new String[lastRowNum][lastCellNum];
    for (int i = 0; i <= lastRowNum; i++) {
      XSSFRow xSSFRow = this.tsxlsxSheet.getRow(i);
      for (int j = 0; j < lastCellNum; j++)
        testData[i][j] = xSSFRow.getCell(j).getStringCellValue(); 
    } 
    return testData;
  }
}

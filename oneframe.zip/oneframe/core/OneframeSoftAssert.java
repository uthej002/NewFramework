// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import org.testng.asserts.IAssert;
import org.testng.asserts.SoftAssert;

public class OneframeSoftAssert extends SoftAssert
{
    public void onAssertSuccess(final IAssert<?> assertCommand) {
        OneframeContainer.gTestResult = "PASS";
        String suffix = "";
        String expRes = "NOT NULL";
        String actRes = "null";
        if (assertCommand.getExpected() != null) {
            expRes = assertCommand.getExpected().toString();
        }
        if (assertCommand.getActual() != null) {
            actRes = assertCommand.getActual().toString();
        }
        suffix = String.format("Expected = '%s' | Actual = '%s'", expRes, actRes);
        OneframeContainer.OneframeLogger(assertCommand.getMessage() + " | Test Step Status -> PASSED | " + suffix);
    }
    
    public void onAssertFailure(final IAssert<?> assertCommand, final AssertionError ex) {
        OneframeContainer.gTestResult = "FAIL";
        String suffix = "";
        String expRes = "null";
        String actRes = "null";
        String errDetail = "";
        if (assertCommand.getExpected() != null) {
            expRes = assertCommand.getExpected().toString();
        }
        if (assertCommand.getActual() != null) {
            actRes = assertCommand.getActual().toString();
        }
        if (ex != null) {
            errDetail = ex.getMessage();
        }
        suffix = String.format(" Expected = '%s' but Actual = '%s'", expRes, actRes);
        OneframeContainer.OneframeErrorLogger(assertCommand.getMessage() + " | Test Step Status -> FAILED | " + suffix);
        OneframeContainer.OneframeErrorLogger("[ONEFRAME] Assertion failed due to " + errDetail);
    }
}

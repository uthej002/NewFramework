package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class Validatearulewithinvaliddata extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Rule with Invalid Data")
	public void setUp() {
		InitializeLaunchPad("IBPW_7");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "RuleName", "Description", "Message", "StartDate",
				"EndDate" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate A Rule With Invalid Data", dataProvider = "TestData")
	@Description("Validate a Rule with Invalid Data")
	public void ValidateRulewithInvalidData(String TestCaseID, String TestStatus, String RuleName, String Description,
			String Message, String StartDate, String EndDate) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();
			sa.assertTrue(addrulepage.verifyCreateaRuleHeader(), "Verified Create a Rule Header is displayed");
			addrulepage.EnterRuleName(RuleName);
			addrulepage.EnterDescription(Description);
			addrulepage.EnterMessage(Message);
			addrulepage.EnterStartDate(StartDate);
			addrulepage.EnterEndDate(EndDate);
			sa.assertTrue(addrulepage.VerifyRuleNameError(), "Verified RuleName Error message is displayed");
			sa.assertTrue(addrulepage.VerifyMessageError(), "Verified Message Error message is displayed");
			sa.assertTrue(addrulepage.VerifyDateError(), "Verified Date Error message is displayed");
			sa.assertTrue(addrulepage.VerifyAddRuleButton(), "Verified Add Rule Button is Disabled");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validating A Rule with Invalid Data is successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Validating A rule With Invalid Data is unsuccessful");
		}
		
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

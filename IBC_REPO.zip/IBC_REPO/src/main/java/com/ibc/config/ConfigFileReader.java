package com.ibc.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileReader {

    private Properties properties;
    private final String propertyFilePath= System.getProperty("user.dir") + "/src/test/resources/configurations/config.properties";

    private static ConfigFileReader configFileReader;

    public ConfigFileReader(){
        try {
            FileInputStream input = new FileInputStream(propertyFilePath);
            properties = new Properties();
            properties.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ConfigFileReader getInstance(){
        if(configFileReader == null) configFileReader = new ConfigFileReader();
        return configFileReader;
    }

    public String getBaseURL(){
        String baseURL = properties.getProperty("baseURL");
        if(baseURL != null) return baseURL;
        else throw new RuntimeException("baseURL not specified in the config.properties file.");
    }

    public String getBrowser(){
        String browser = properties.getProperty("browser");
        if(browser != null) return browser;
        else throw new RuntimeException("browser not specified in the config.properties file.");
    }

    public long getTimeout(){
        String timeout = properties.getProperty("timeout");
        if(timeout != null) return Long.parseLong(timeout);
        else throw new RuntimeException("timeout not specified in the config.properties file.");
    }
    
    public String getBrowserPath(){
        String browserPath = properties.getProperty("browserPath");
        if(browserPath != null) return browserPath;
        else throw new RuntimeException("browser path not specified in the config.properties file.");
    }
    
    public String getUserName(){
        String username = properties.getProperty("username");
        if(username != null) return username;
        else throw new RuntimeException("username not specified in the config.properties file.");
    }
    
    public String getPassword(){
        String password = properties.getProperty("password");
        if(password != null) return password;
        else throw new RuntimeException("password not specified in the config.properties file.");
    }
    
}

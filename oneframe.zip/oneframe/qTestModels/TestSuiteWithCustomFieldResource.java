// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import org.joda.time.DateTime;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TestSuiteWithCustomFieldResource
{
    @JsonProperty("parentId")
    private Long parentId;
    @JsonProperty("parentType")
    private ParentTypeEnum parentType;
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("order")
    private Integer order;
    @JsonProperty("pid")
    private String pid;
    @JsonProperty("created_date")
    private DateTime createdDate;
    @JsonProperty("last_modified_date")
    private DateTime lastModifiedDate;
    @JsonProperty("properties")
    private List<PropertyResource> properties;
    @JsonProperty("web_url")
    private String webUrl;
    @JsonProperty("target_release_id")
    private Long targetReleaseId;
    @JsonProperty("target_build_id")
    private Long targetBuildId;
    
    public TestSuiteWithCustomFieldResource() {
        this.parentId = null;
        this.parentType = null;
        this.links = new ArrayList<Link>();
        this.id = null;
        this.name = null;
        this.order = null;
        this.pid = null;
        this.createdDate = null;
        this.lastModifiedDate = null;
        this.properties = new ArrayList<PropertyResource>();
        this.webUrl = null;
        this.targetReleaseId = null;
        this.targetBuildId = null;
    }
    
    public TestSuiteWithCustomFieldResource parentId(final Long parentId) {
        this.parentId = parentId;
        return this;
    }
    
    public Long getParentId() {
        return this.parentId;
    }
    
    public void setParentId(final Long parentId) {
        this.parentId = parentId;
    }
    
    public TestSuiteWithCustomFieldResource parentType(final ParentTypeEnum parentType) {
        this.parentType = parentType;
        return this;
    }
    
    public ParentTypeEnum getParentType() {
        return this.parentType;
    }
    
    public void setParentType(final ParentTypeEnum parentType) {
        this.parentType = parentType;
    }
    
    public TestSuiteWithCustomFieldResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public TestSuiteWithCustomFieldResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public TestSuiteWithCustomFieldResource id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public TestSuiteWithCustomFieldResource name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public TestSuiteWithCustomFieldResource order(final Integer order) {
        this.order = order;
        return this;
    }
    
    public Integer getOrder() {
        return this.order;
    }
    
    public void setOrder(final Integer order) {
        this.order = order;
    }
    
    public TestSuiteWithCustomFieldResource pid(final String pid) {
        this.pid = pid;
        return this;
    }
    
    public String getPid() {
        return this.pid;
    }
    
    public void setPid(final String pid) {
        this.pid = pid;
    }
    
    public TestSuiteWithCustomFieldResource createdDate(final DateTime createdDate) {
        this.createdDate = createdDate;
        return this;
    }
    
    public DateTime getCreatedDate() {
        return this.createdDate;
    }
    
    public void setCreatedDate(final DateTime createdDate) {
        this.createdDate = createdDate;
    }
    
    public TestSuiteWithCustomFieldResource lastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
        return this;
    }
    
    public DateTime getLastModifiedDate() {
        return this.lastModifiedDate;
    }
    
    public void setLastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
    
    public TestSuiteWithCustomFieldResource properties(final List<PropertyResource> properties) {
        this.properties = properties;
        return this;
    }
    
    public TestSuiteWithCustomFieldResource addPropertiesItem(final PropertyResource propertiesItem) {
        this.properties.add(propertiesItem);
        return this;
    }
    
    public List<PropertyResource> getProperties() {
        return this.properties;
    }
    
    public void setProperties(final List<PropertyResource> properties) {
        this.properties = properties;
    }
    
    public String getWebUrl() {
        return this.webUrl;
    }
    
    public TestSuiteWithCustomFieldResource targetReleaseId(final Long targetReleaseId) {
        this.targetReleaseId = targetReleaseId;
        return this;
    }
    
    public Long getTargetReleaseId() {
        return this.targetReleaseId;
    }
    
    public void setTargetReleaseId(final Long targetReleaseId) {
        this.targetReleaseId = targetReleaseId;
    }
    
    public TestSuiteWithCustomFieldResource targetBuildId(final Long targetBuildId) {
        this.targetBuildId = targetBuildId;
        return this;
    }
    
    public Long getTargetBuildId() {
        return this.targetBuildId;
    }
    
    public void setTargetBuildId(final Long targetBuildId) {
        this.targetBuildId = targetBuildId;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final TestSuiteWithCustomFieldResource testSuiteWithCustomFieldResource = (TestSuiteWithCustomFieldResource)o;
        return Objects.equals(this.parentId, testSuiteWithCustomFieldResource.parentId) && Objects.equals(this.parentType, testSuiteWithCustomFieldResource.parentType) && Objects.equals(this.links, testSuiteWithCustomFieldResource.links) && Objects.equals(this.id, testSuiteWithCustomFieldResource.id) && Objects.equals(this.name, testSuiteWithCustomFieldResource.name) && Objects.equals(this.order, testSuiteWithCustomFieldResource.order) && Objects.equals(this.pid, testSuiteWithCustomFieldResource.pid) && Objects.equals(this.createdDate, testSuiteWithCustomFieldResource.createdDate) && Objects.equals(this.lastModifiedDate, testSuiteWithCustomFieldResource.lastModifiedDate) && Objects.equals(this.properties, testSuiteWithCustomFieldResource.properties) && Objects.equals(this.webUrl, testSuiteWithCustomFieldResource.webUrl) && Objects.equals(this.targetReleaseId, testSuiteWithCustomFieldResource.targetReleaseId) && Objects.equals(this.targetBuildId, testSuiteWithCustomFieldResource.targetBuildId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.parentId, this.parentType, this.links, this.id, this.name, this.order, this.pid, this.createdDate, this.lastModifiedDate, this.properties, this.webUrl, this.targetReleaseId, this.targetBuildId);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class TestSuiteWithCustomFieldResource {\n");
        sb.append("    parentId: ").append(this.toIndentedString(this.parentId)).append("\n");
        sb.append("    parentType: ").append(this.toIndentedString(this.parentType)).append("\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    order: ").append(this.toIndentedString(this.order)).append("\n");
        sb.append("    pid: ").append(this.toIndentedString(this.pid)).append("\n");
        sb.append("    createdDate: ").append(this.toIndentedString(this.createdDate)).append("\n");
        sb.append("    lastModifiedDate: ").append(this.toIndentedString(this.lastModifiedDate)).append("\n");
        sb.append("    properties: ").append(this.toIndentedString(this.properties)).append("\n");
        sb.append("    webUrl: ").append(this.toIndentedString(this.webUrl)).append("\n");
        sb.append("    targetReleaseId: ").append(this.toIndentedString(this.targetReleaseId)).append("\n");
        sb.append("    targetBuildId: ").append(this.toIndentedString(this.targetBuildId)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
    
    public enum ParentTypeEnum
    {
        @JsonProperty("root")
        ROOT("root"), 
        @JsonProperty("release")
        RELEASE("release"), 
        @JsonProperty("test-cycle")
        TEST_CYCLE("test-cycle");
        
        private String value;
        
        private ParentTypeEnum(final String value) {
            this.value = value;
        }
        
        @Override
        public String toString() {
            return String.valueOf(this.value);
        }
    }
}

package ibcweb.PageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPLibrariesDAWPage extends OneframeContainer {
	OneframeSoftAssert sa = new OneframeSoftAssert();
	OneframeAssert ha = new OneframeAssert();

	@FindBy(xpath = " //*[text()=' Dispense As Written (DAW) ']")
	WebElement hdrDAW;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted']")
	List<WebElement> lstPackageName;

	@FindBy(xpath = "//*[@formcontrolname='name']")
	WebElement txtPackageNameField;

	@FindBy(xpath = "//*[@formcontrolname='description']")
	WebElement txtDescriptionField;

	@FindBy(xpath = "//*[@formcontrolname='stopSaleDate']")
	WebElement txtStopSaleDateField;

	@FindBy(xpath = "//*[@formcontrolname='clients']")
	WebElement txtClientField;

	@FindBy(xpath = "//*[@formcontrolname='lobs']")
	WebElement txtLOBField;

	@FindBy(xpath = "//*[@formcontrolname='states']")
	WebElement txtStateField;

	@FindBy(xpath = "//*[text() and normalize-space()=\"Dispense as Written Package\"]")
	WebElement hdrDAWDetails;

	@FindBy(xpath = "//*[text()=' Create a DAW Package ']")
	WebElement btnCreateDAWPackage;

	@FindBy(xpath = "//span[@class='mat-expansion-indicator ng-tns-c161-580 ng-trigger ng-trigger-indicatorRotate ng-star-inserted']")
	WebElement btnDAW0;

	@FindBy(xpath = "//*[@class=\"row row--expander ng-star-inserted\"]")
	List<WebElement> lstDAWS;

	@FindBy(xpath = "//*[@formcontrolname=\"enabled\"]")
	List<WebElement> lstDawToggle;

	@FindBy(xpath = "//mat-slide-toggle[@formcontrolname=\"retailApplies\"]")
	List<WebElement> retailToggle;

	@FindBy(xpath = "//*[@formcontrolname=\"retailMax\"]")
	List<WebElement> txtRetailMax;

	@FindBy(xpath = "//mat-slide-toggle[@formcontrolname=\"homeDeliveryApplies\"]")
	List<WebElement> homeDeliveryToggle;

	@FindBy(xpath = "//*[@formcontrolname=\"homeDeliveryMax\"]")
	List<WebElement> txthomeDeliveryMax;

	@FindBy(xpath = "//mat-select[@formcontrolname=\"costShare\"]")
	List<WebElement> drdCostShare;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> dropdownValues;

	@FindBy(xpath = "//*[@formcontrolname=\"pct\"]")
	List<WebElement> txtApplied;

	@FindBy(xpath = "//span[text()=' Add Daw package ']")
	WebElement btnAddDawPackage;

	@FindBy(xpath = "//span[text()='Successfully created a new daw']")
	WebElement txtSuccessMessage;

	public IBPLibrariesDAWPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on DAW tab")
	public void clickDAWTab() {
		WaitForObjectVisibility(hdrDAW);
		hdrDAW.click();
		OneframeLogger("Clicked on DAW tab");
	}

	@Step("Click on first Record of Daw list")
	public void clickFirstRecordDaw() {
		WaitForObjectVisibility(lstPackageName.get(0));
		lstPackageName.get(0).click();
		OneframeLogger("Clicked on first Record of Daw list");
	}

	@Step("Verify {daw} field are displayed")
	public void verifyDAWFieldsisDisplayed(String daw) {
		switch (daw) {
		case "Package name":
			if (txtPackageNameField.isDisplayed()) {
				highlightElement(txtPackageNameField);
				sa.assertTrue(true, "Verified Package name Field is displayed");
			}
			break;

		case "Description":
			if (txtDescriptionField.isDisplayed()) {
				highlightElement(txtDescriptionField);
				sa.assertTrue(true, "Verified Description Field is displayed");
			}
			break;
		case "Stop sale date":
			if (txtStopSaleDateField.isDisplayed()) {
				highlightElement(txtStopSaleDateField);
				sa.assertTrue(true, "Verified Stop sale date Field is displayed");
			}
			break;
		case "Client":
			if (txtClientField.isDisplayed()) {
				highlightElement(txtClientField);
				sa.assertTrue(true, "Verified Client Field is displayed");
			}
			break;
		case "Line of Business":
			if (txtLOBField.isDisplayed()) {
				highlightElement(txtLOBField);
				sa.assertTrue(true, "Verified LOB Field is displayed");
			}
			break;
		case "States":
			if (txtStateField.isDisplayed()) {
				highlightElement(txtStateField);
				sa.assertTrue(true, "Verified State Field is displayed");
			}
			break;
		default:
			OneframeLogger(daw + " Daw field is not displayed");

		}
	}

	@Step("Click on Daw header")
	public void clickDawHeader() {
		WaitForObjectVisibility(hdrDAWDetails);
		hdrDAWDetails.click();
		hdrDAWDetails.click();
		hdrDAWDetails.click();
	}

	@Step("Click on Create a Daw Package button")
	public void clickCreateADawPackageButton() {
		WaitForObjectVisibility(btnCreateDAWPackage);
		btnCreateDAWPackage.click();
		OneframeLogger("Clicked on Create a Daw Package button");
	}

	@Step("Verify DAW Package url")
	public void verifyDAWPackageUrl() {
		String currentURl = oneframeDriver.getCurrentUrl();
		ha.assertTrue(currentURl.contains("admin/library/controls/daw/new"),
				"Validated DAW package url is as expected");
	}

	@Step("Enter Package Name")
	public void enterPackageName() {
		if (WaitForObjectVisibility(txtPackageNameField)) {
			String val = "TESTDAW";
			int randomNumber = getRandomNumber();
			String PackageName = val + randomNumber;
			EnterText(txtPackageNameField, PackageName);
			String packageName = txtPackageNameField.getAttribute("value");
			OneframeLogger("The Entered packageName is : " + packageName);
		}
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 1;
		int max = 10;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Enter Description")
	public void enterDescription() {
		if (WaitForObjectVisibility(txtDescriptionField)) {
			String val = "TESTDAWDESC";
			int randomNumber = getRandomNumber();
			String desc = val + randomNumber;
			EnterText(txtDescriptionField, desc);
			String description = txtDescriptionField.getAttribute("value");
			OneframeLogger("The Entered packageName is : " + description);
		}
	}

	@Step("Enable All Daw Toggles")
	public void enableAllDAWToggles() {
		WaitForObjectVisibility(lstDAWS.get(0));
		for (int i = 0; i < lstDAWS.size()-1; i++) {
			lstDawToggle.get(i).click();
		}
	}

	@Step("Enter Daw Values")
	public void enterDAWValues() {
		WaitForObjectVisibility(lstDAWS.get(0));
		for (int i = 0; i < lstDAWS.size(); i++) {
			lstDAWS.get(i).click();

			retailToggle.get(i).click();
			int retailMax = getRandomNumber();
			String txtRetMax = String.valueOf(retailMax);
			EnterText(txtRetailMax.get(i), txtRetMax);

			homeDeliveryToggle.get(i).click();
			EnterText(txthomeDeliveryMax.get(i), txtRetMax);

			drdCostShare.get(i).click();
			dropdownValues.get(0).click();
			EnterText(txtApplied.get(i), txtRetMax);

		}
	}

	@Step("Click on Add Daw package button")
	public void clickAddDawPackageButton() {
		WaitForObjectVisibility(btnAddDawPackage);
		btnAddDawPackage.click();
		OneframeLogger("Clicked on Add Daw package button ");
	}

	@Step("Enter Current Date as Stop Sale date")
	public void enterCurrentStopSaleDate() throws ParseException {
		WaitForApplicationToLoadCompletely();
		if (WaitForObjectVisibility(txtStopSaleDateField)) {
			ClickWebObject(txtStopSaleDateField);
			String StopSaleDate = verifyStopSaleDate();
			DateFormat userDateFormat = new SimpleDateFormat("yyyy-mm-dd");
			DateFormat dateFormatNeeded = new SimpleDateFormat("mm/dd/yyyy");
			Date date = userDateFormat.parse(StopSaleDate);
			String convertedDate = dateFormatNeeded.format(date);

			EnterText(txtStopSaleDateField, convertedDate);
			OneframeLogger(
					"Current Date as Stop sale Date has been Entered : " + txtStopSaleDateField.getAttribute("value"));
		}
	}

	public String verifyStopSaleDate() {
		LocalDate stopSaleDate = LocalDate.now();
		String StopSaleDate = stopSaleDate.toString();
		return StopSaleDate;
	}

	@Step("Verify Text Successfully Created Daw is displayed")
	public void verifyTextSuccesffulyCreatedDAW() {
		WaitForObjectVisibility(txtSuccessMessage);
		if (txtSuccessMessage.isDisplayed()) {
			highlightElement(txtSuccessMessage);
			sa.assertEquals(txtSuccessMessage.getText(), "Successfully created a new daw",
					"Verified Successfully Created Daw is displayed");
			sa.assertAll();
		}
	}

}

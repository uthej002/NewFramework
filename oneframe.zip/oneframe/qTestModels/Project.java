// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import org.joda.time.DateTime;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Project
{
    @JsonProperty("id")
    private Long id;
    @JsonProperty("clientId")
    private Long clientId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("startDate")
    private DateTime startDate;
    @JsonProperty("endDate")
    private DateTime endDate;
    @JsonProperty("description")
    private String description;
    @JsonProperty("projectStatusId")
    private Long projectStatusId;
    @JsonProperty("patchIncidentStatus")
    private Integer patchIncidentStatus;
    @JsonProperty("automation")
    private Boolean automation;
    @JsonProperty("defectworkflow")
    private Boolean defectworkflow;
    @JsonProperty("uuid")
    private String uuid;
    @JsonProperty("cloneStatus")
    private Integer cloneStatus;
    @JsonProperty("sourceProjectId")
    private Long sourceProjectId;
    @JsonProperty("trxId")
    private DateTime trxId;
    @JsonProperty("customFieldTemplateId")
    private Long customFieldTemplateId;
    @JsonProperty("internally")
    private Boolean internally;
    @JsonProperty("customFieldTemplate")
    private CustomFieldTemplate customFieldTemplate;
    @JsonProperty("indexingStatus")
    private Boolean indexingStatus;
    @JsonProperty("active")
    private Boolean active;
    @JsonProperty("longId")
    private Long longId;
    @JsonProperty("sampleProject")
    private Boolean sampleProject;
    @JsonProperty("patchedIncidents")
    private Boolean patchedIncidents;
    @JsonProperty("cloning")
    private Boolean cloning;
    @JsonProperty("cloned")
    private Boolean cloned;
    @JsonProperty("newStyleSample")
    private Boolean newStyleSample;
    
    public Project() {
        this.id = null;
        this.clientId = null;
        this.name = null;
        this.startDate = null;
        this.endDate = null;
        this.description = null;
        this.projectStatusId = null;
        this.patchIncidentStatus = null;
        this.automation = false;
        this.defectworkflow = false;
        this.uuid = null;
        this.cloneStatus = null;
        this.sourceProjectId = null;
        this.trxId = null;
        this.customFieldTemplateId = null;
        this.internally = false;
        this.customFieldTemplate = null;
        this.indexingStatus = false;
        this.active = false;
        this.longId = null;
        this.sampleProject = false;
        this.patchedIncidents = false;
        this.cloning = false;
        this.cloned = false;
        this.newStyleSample = false;
    }
    
    public Project id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public Project clientId(final Long clientId) {
        this.clientId = clientId;
        return this;
    }
    
    public Long getClientId() {
        return this.clientId;
    }
    
    public void setClientId(final Long clientId) {
        this.clientId = clientId;
    }
    
    public Project name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public Project startDate(final DateTime startDate) {
        this.startDate = startDate;
        return this;
    }
    
    public DateTime getStartDate() {
        return this.startDate;
    }
    
    public void setStartDate(final DateTime startDate) {
        this.startDate = startDate;
    }
    
    public Project endDate(final DateTime endDate) {
        this.endDate = endDate;
        return this;
    }
    
    public DateTime getEndDate() {
        return this.endDate;
    }
    
    public void setEndDate(final DateTime endDate) {
        this.endDate = endDate;
    }
    
    public Project description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public Project projectStatusId(final Long projectStatusId) {
        this.projectStatusId = projectStatusId;
        return this;
    }
    
    public Long getProjectStatusId() {
        return this.projectStatusId;
    }
    
    public void setProjectStatusId(final Long projectStatusId) {
        this.projectStatusId = projectStatusId;
    }
    
    public Project patchIncidentStatus(final Integer patchIncidentStatus) {
        this.patchIncidentStatus = patchIncidentStatus;
        return this;
    }
    
    public Integer getPatchIncidentStatus() {
        return this.patchIncidentStatus;
    }
    
    public void setPatchIncidentStatus(final Integer patchIncidentStatus) {
        this.patchIncidentStatus = patchIncidentStatus;
    }
    
    public Project automation(final Boolean automation) {
        this.automation = automation;
        return this;
    }
    
    public Boolean getAutomation() {
        return this.automation;
    }
    
    public void setAutomation(final Boolean automation) {
        this.automation = automation;
    }
    
    public Project defectworkflow(final Boolean defectworkflow) {
        this.defectworkflow = defectworkflow;
        return this;
    }
    
    public Boolean getDefectworkflow() {
        return this.defectworkflow;
    }
    
    public void setDefectworkflow(final Boolean defectworkflow) {
        this.defectworkflow = defectworkflow;
    }
    
    public Project uuid(final String uuid) {
        this.uuid = uuid;
        return this;
    }
    
    public String getUuid() {
        return this.uuid;
    }
    
    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }
    
    public Project cloneStatus(final Integer cloneStatus) {
        this.cloneStatus = cloneStatus;
        return this;
    }
    
    public Integer getCloneStatus() {
        return this.cloneStatus;
    }
    
    public void setCloneStatus(final Integer cloneStatus) {
        this.cloneStatus = cloneStatus;
    }
    
    public Project sourceProjectId(final Long sourceProjectId) {
        this.sourceProjectId = sourceProjectId;
        return this;
    }
    
    public Long getSourceProjectId() {
        return this.sourceProjectId;
    }
    
    public void setSourceProjectId(final Long sourceProjectId) {
        this.sourceProjectId = sourceProjectId;
    }
    
    public DateTime getTrxId() {
        return this.trxId;
    }
    
    public void setTrxId(final DateTime trxId) {
        this.trxId = trxId;
    }
    
    public Project customFieldTemplateId(final Long customFieldTemplateId) {
        this.customFieldTemplateId = customFieldTemplateId;
        return this;
    }
    
    public Long getCustomFieldTemplateId() {
        return this.customFieldTemplateId;
    }
    
    public void setCustomFieldTemplateId(final Long customFieldTemplateId) {
        this.customFieldTemplateId = customFieldTemplateId;
    }
    
    public Project internally(final Boolean internally) {
        this.internally = internally;
        return this;
    }
    
    public Boolean getInternally() {
        return this.internally;
    }
    
    public void setInternally(final Boolean internally) {
        this.internally = internally;
    }
    
    public Project customFieldTemplate(final CustomFieldTemplate customFieldTemplate) {
        this.customFieldTemplate = customFieldTemplate;
        return this;
    }
    
    public CustomFieldTemplate getCustomFieldTemplate() {
        return this.customFieldTemplate;
    }
    
    public void setCustomFieldTemplate(final CustomFieldTemplate customFieldTemplate) {
        this.customFieldTemplate = customFieldTemplate;
    }
    
    public Project indexingStatus(final Boolean indexingStatus) {
        this.indexingStatus = indexingStatus;
        return this;
    }
    
    public Boolean getIndexingStatus() {
        return this.indexingStatus;
    }
    
    public void setIndexingStatus(final Boolean indexingStatus) {
        this.indexingStatus = indexingStatus;
    }
    
    public Project active(final Boolean active) {
        this.active = active;
        return this;
    }
    
    public Boolean getActive() {
        return this.active;
    }
    
    public void setActive(final Boolean active) {
        this.active = active;
    }
    
    public Project longId(final Long longId) {
        this.longId = longId;
        return this;
    }
    
    public Long getLongId() {
        return this.longId;
    }
    
    public void setLongId(final Long longId) {
        this.longId = longId;
    }
    
    public Project sampleProject(final Boolean sampleProject) {
        this.sampleProject = sampleProject;
        return this;
    }
    
    public Boolean getSampleProject() {
        return this.sampleProject;
    }
    
    public void setSampleProject(final Boolean sampleProject) {
        this.sampleProject = sampleProject;
    }
    
    public Project patchedIncidents(final Boolean patchedIncidents) {
        this.patchedIncidents = patchedIncidents;
        return this;
    }
    
    public Boolean getPatchedIncidents() {
        return this.patchedIncidents;
    }
    
    public void setPatchedIncidents(final Boolean patchedIncidents) {
        this.patchedIncidents = patchedIncidents;
    }
    
    public Project cloning(final Boolean cloning) {
        this.cloning = cloning;
        return this;
    }
    
    public Boolean getCloning() {
        return this.cloning;
    }
    
    public void setCloning(final Boolean cloning) {
        this.cloning = cloning;
    }
    
    public Project cloned(final Boolean cloned) {
        this.cloned = cloned;
        return this;
    }
    
    public Boolean getCloned() {
        return this.cloned;
    }
    
    public void setCloned(final Boolean cloned) {
        this.cloned = cloned;
    }
    
    public Project newStyleSample(final Boolean newStyleSample) {
        this.newStyleSample = newStyleSample;
        return this;
    }
    
    public Boolean getNewStyleSample() {
        return this.newStyleSample;
    }
    
    public void setNewStyleSample(final Boolean newStyleSample) {
        this.newStyleSample = newStyleSample;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final Project project = (Project)o;
        return Objects.equals(this.id, project.id) && Objects.equals(this.clientId, project.clientId) && Objects.equals(this.name, project.name) && Objects.equals(this.startDate, project.startDate) && Objects.equals(this.endDate, project.endDate) && Objects.equals(this.description, project.description) && Objects.equals(this.projectStatusId, project.projectStatusId) && Objects.equals(this.patchIncidentStatus, project.patchIncidentStatus) && Objects.equals(this.automation, project.automation) && Objects.equals(this.defectworkflow, project.defectworkflow) && Objects.equals(this.uuid, project.uuid) && Objects.equals(this.cloneStatus, project.cloneStatus) && Objects.equals(this.sourceProjectId, project.sourceProjectId) && Objects.equals(this.trxId, project.trxId) && Objects.equals(this.customFieldTemplateId, project.customFieldTemplateId) && Objects.equals(this.internally, project.internally) && Objects.equals(this.customFieldTemplate, project.customFieldTemplate) && Objects.equals(this.indexingStatus, project.indexingStatus) && Objects.equals(this.active, project.active) && Objects.equals(this.longId, project.longId) && Objects.equals(this.sampleProject, project.sampleProject) && Objects.equals(this.patchedIncidents, project.patchedIncidents) && Objects.equals(this.cloning, project.cloning) && Objects.equals(this.cloned, project.cloned) && Objects.equals(this.newStyleSample, project.newStyleSample);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.clientId, this.name, this.startDate, this.endDate, this.description, this.projectStatusId, this.patchIncidentStatus, this.automation, this.defectworkflow, this.uuid, this.cloneStatus, this.sourceProjectId, this.trxId, this.customFieldTemplateId, this.internally, this.customFieldTemplate, this.indexingStatus, this.active, this.longId, this.sampleProject, this.patchedIncidents, this.cloning, this.cloned, this.newStyleSample);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class Project {\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    clientId: ").append(this.toIndentedString(this.clientId)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    startDate: ").append(this.toIndentedString(this.startDate)).append("\n");
        sb.append("    endDate: ").append(this.toIndentedString(this.endDate)).append("\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("    projectStatusId: ").append(this.toIndentedString(this.projectStatusId)).append("\n");
        sb.append("    patchIncidentStatus: ").append(this.toIndentedString(this.patchIncidentStatus)).append("\n");
        sb.append("    automation: ").append(this.toIndentedString(this.automation)).append("\n");
        sb.append("    defectworkflow: ").append(this.toIndentedString(this.defectworkflow)).append("\n");
        sb.append("    uuid: ").append(this.toIndentedString(this.uuid)).append("\n");
        sb.append("    cloneStatus: ").append(this.toIndentedString(this.cloneStatus)).append("\n");
        sb.append("    sourceProjectId: ").append(this.toIndentedString(this.sourceProjectId)).append("\n");
        sb.append("    trxId: ").append(this.toIndentedString(this.trxId)).append("\n");
        sb.append("    customFieldTemplateId: ").append(this.toIndentedString(this.customFieldTemplateId)).append("\n");
        sb.append("    internally: ").append(this.toIndentedString(this.internally)).append("\n");
        sb.append("    customFieldTemplate: ").append(this.toIndentedString(this.customFieldTemplate)).append("\n");
        sb.append("    indexingStatus: ").append(this.toIndentedString(this.indexingStatus)).append("\n");
        sb.append("    active: ").append(this.toIndentedString(this.active)).append("\n");
        sb.append("    longId: ").append(this.toIndentedString(this.longId)).append("\n");
        sb.append("    sampleProject: ").append(this.toIndentedString(this.sampleProject)).append("\n");
        sb.append("    patchedIncidents: ").append(this.toIndentedString(this.patchedIncidents)).append("\n");
        sb.append("    cloning: ").append(this.toIndentedString(this.cloning)).append("\n");
        sb.append("    cloned: ").append(this.toIndentedString(this.cloned)).append("\n");
        sb.append("    newStyleSample: ").append(this.toIndentedString(this.newStyleSample)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBulkUpdateBulkUpdatedPage;
import ibcweb.PageObjects.IBPBulkUpdatePage;
import ibcweb.PageObjects.IBPBulkUpdateReviewPage;
import ibcweb.PageObjects.IBPBulkUpdateWorkInProgressPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class ValidateBulkUpdateCancelFlow extends OneframeContainer {
	
		IBPWelcomePage welcomePage;
		IBPLoginPage   loginpage;
		IBPHomePage homepage;
		IBPBulkUpdatePage bulkUpdatePage;

	@BeforeClass
	@Step("Initializing Test Script for validating Butterscotch App Login")
	public void setUp() {
		InitializeLaunchPad("IBPW_807");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		bulkUpdatePage = new IBPBulkUpdatePage();
	}

	@DataProvider(name = "LoginTestData")
	public Object[][] getLoginTestDataTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Bulk Update Cancel flow", dataProvider = "LoginTestData")
	@Description("Validate Bulk Update Cancel flow")
	public void ValidateCancelFlowInBulkUpdate(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			bulkUpdatePage.clickBulkProcess();
			bulkUpdatePage.clickBulkUpdate();
			
			bulkUpdatePage.clickOnCreateAProjectButton();
			sa.assertTrue(bulkUpdatePage.verifyCreateProjectHilightedInProgressBar(), "'Create Project' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatePage.verifyCreateAProjectHeader(), "'Create a Project' heading is displayed");
			sa.assertTrue(!bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is disabled");
			sa.assertTrue(bulkUpdatePage.verifyProjectDataHeading(), "'Project Data' heading is displayed");	
			sa.assertTrue(bulkUpdatePage.verifyProjectIDHeading(), "'Project ID' heading is displayed");
			sa.assertTrue(bulkUpdatePage.verifyProjectDescriptionHeading(), "'Description' heading is displayed");
			
			bulkUpdatePage.clickCancelButton();
			sa.assertTrue(bulkUpdatePage.verifyProjectIDHeaderInLandingPage() , "'Project ID' heading is displayed in Landing Page");
			sa.assertTrue(bulkUpdatePage.verifyDescriptionHeaderInLandingPage() , "'Description' heading is displayed in Landing Page");
			sa.assertTrue(bulkUpdatePage.verifyAsigneeHeaderInLandingPage() , "'Asignee' heading is displayed in Landing Page");
			sa.assertTrue(bulkUpdatePage.verifyStatusHeaderInLandingPage() , "'Status' heading is displayed in Landing Page");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			
			OneframeLogger("Validated Bulk Update Cancel flow Succseefully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Bulk Update Cancel flow");
		}
		
		homepage.clickLogout();
		
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}
	
	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

package anthem.irx.oneframe.utilities;

import java.awt.AWTException;
import java.awt.GraphicsConfiguration;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import org.monte.media.Format;
import org.monte.media.Registry;
import org.monte.screenrecorder.ScreenRecorder;

public class MonteScreenRecorder extends ScreenRecorder {
  private String testScenarioID;
  
  private String testScriptName;
  
  public MonteScreenRecorder(GraphicsConfiguration cfg, Rectangle captureArea, Format fileFormat, Format screenFormat, Format mouseFormat, Format audioFormat, File movieFolder) throws IOException, AWTException {
    super(cfg, captureArea, fileFormat, screenFormat, mouseFormat, audioFormat, movieFolder);
  }
  
  public void setTestScenarioID(String testScenarioID) {
    this.testScenarioID = testScenarioID;
  }
  
  public void setScriptName(String testScriptName) {
    this.testScriptName = testScriptName;
  }
  
  protected File createMovieFile(Format fileFormat) throws IOException {
    if (!this.movieFolder.exists()) {
      this.movieFolder.mkdirs();
    } else if (!this.movieFolder.isDirectory()) {
      throw new IOException("\"" + this.movieFolder + "\" is not a directory.");
    } 
    File dateFolder = new File(this.movieFolder + "\\" + DateTimeProcessor.getCurrentDate());
    if (!dateFolder.exists()) {
      dateFolder.mkdirs();
    } else if (!dateFolder.isDirectory()) {
      throw new IOException("\"" + dateFolder + "\" is not a directory.");
    } 
    if (this.testScriptName.length() > 35)
      this.testScriptName = this.testScriptName.substring(0, 35); 
    File f = new File(dateFolder, this.testScenarioID + "_" + this.testScriptName + "_" + DateTimeProcessor.getCurrentDateTime("MMdd_HHmmss") + "." + Registry.getInstance().getExtension(fileFormat));
    return f;
  }
}

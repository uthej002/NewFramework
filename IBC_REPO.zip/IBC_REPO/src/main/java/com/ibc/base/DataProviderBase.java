package com.ibc.base;

import org.testng.annotations.DataProvider;

public class DataProviderBase {
	
    @DataProvider(name = "loginData")
    public static Object[][] loginData() {
        return new Object[][] {
            {"ah91660", "Qwe123$$"}
        };
    }
}


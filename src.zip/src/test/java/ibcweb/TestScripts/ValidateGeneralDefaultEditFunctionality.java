package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateGeneralDefaultEditFunctionality extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesBaseFormularies baseFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validate General default Edit Functionality")
	public void setUp() {
		InitializeLaunchPad("IBPW_570");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		baseFormulary = new IBPLibrariesBaseFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ProgramName", "DropDownValues" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate General default Edit Functionality", dataProvider = "TestData")
	@Description("Validate General default Edit Functionality")
	public void ValidateGeneralDefaultEdit(String TestCaseID, String TestStatus, String ProgramName,
			String DropDownValues) throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");

			controls.clickViewButtonofControls();
			
			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'Controls' header is displayed");
			controls.clickControlsHeader();
			controls.clickControlsHeader();

			
			controls.verifyNameCreatedIsDisplayedInList(ProgramName);

			controls.verifyAndClickEditButton();

			sa.assertTrue(controls.verifyGeneralDefaultStructureDetailsHeader(), "Verified 'General Default Structure' header is displayed");
			controls.verifyLabelsAreDisplayed("Name");
			controls.verifyIDLabelsAreDisplayed("ID");
			controls.verifyLabelsAreDisplayed("ID");

			controls.verifyLabelsAreDisplayed("Time Filling");
			controls.verifyLabelsAreDisplayed("High $ Limit Retail");
			controls.verifyLabelsAreDisplayed("High $ Limit Home Delivery");
			controls.verifyLabelsAreDisplayed("Veterans Admin. High $ Limit");
			controls.verifyLabelsAreDisplayed("Paper Claims in Network");
			controls.verifyLabelsAreDisplayed("Paper Claims Out of Network");
			controls.verifyLabelsAreDisplayed("Follow Me Logic Applies");
			controls.verifyLabelsAreDisplayed("Client");
			controls.verifyIDLabelsAreDisplayed("LOB");
			controls.verifyLabelsAreDisplayed("LOB");

			controls.verifyLabelsAreDisplayed("State");
			controls.verifyLabelsAreDisplayed("Effective Date");
			controls.verifyLabelsAreDisplayed("Stop Sale Date");
			controls.verifyLabelsAreDisplayed("Term Date");
			controls.verifyLabelsAreDisplayed("Foreign Claims");
			controls.verifyLabelsAreDisplayed("Rebate Strategy");
			controls.verifyLabelsAreDisplayed("PENCD");
			controls.verifyLabelsAreDisplayed("Description");

			String stopSale = controls.EnterCurrentStopSaleDate();
			controls.verifyForeignClaimsDropdownValue(DropDownValues);
			controls.clickSaveChangesButton();
			controls.verifyChangesSavedText();
			controls.verifyEditButton();
			controls.verifyStopSaleDt(stopSale);

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated General default Edit Functionality is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate General default Edit Functionality");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

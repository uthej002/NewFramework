package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateWFESubmittheBenefitForClientApproval extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating the Submit the Benefit for Client Approval")
	public void setUp() {
		InitializeLaunchPad("IBPW_52");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {
           String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit", "ClientId", "EffectiveDate",
				"LOBId", "StateId", "Mandates" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate Submit the Benefit for Client Approval", dataProvider = "TestData")
	@Description("validate Submit the Benefit for Client Approval")
	public void ValidateSubmittheBenefitForClientApproval(String TestCaseID, String TestStatus, String Benefit,
			String ClientId, String EffectiveDate, String LOBId, String StateId, String Mandates)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			benefitpage.verifyCreateaBenefitButtonDisplay();
			benefitpage.clickCreateaBenefitButton();
			sa.assertTrue(createbenefitpage.verifyCreateBenefit(), "Verified Create Benefit is displayed");
			sa.assertTrue(createbenefitpage.verifyBenefitHeader(), " Verified Benefit Header is displayed");
			createbenefitpage.selectClientId(ClientId);
			createbenefitpage.selectLOBId(LOBId);
			createbenefitpage.selectStateId(StateId);
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			String NewBenefitId = createbenefitpage.EnterCBNewBenefitId();
			createbenefitpage.selectMandates(Mandates);
			createbenefitpage.ClickCBCreateButton();
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Created Benefit header is displayed");
			sa.assertTrue(createbenefitpage.verifyVerStatus(), "Verified Version Status  is displayed");
			sa.assertTrue(createbenefitpage.verifyVersionValue(), "Verified Version Value is displayed");
			createbenefitpage.ClickVerifyButtonforCreatedBenefit();
			sa.assertTrue(createbenefitpage.verifyVerStatus(), "Verified Version Status  is displayed");
			sa.assertTrue(createbenefitpage.verifyVersionValue(), "Verified Version Value is displayed");
			sa.assertTrue(createbenefitpage.VerifySubmiforCLientApprovalButtonisDisplayed(),"Verified Submit For Client Approval Button is displayed");
			createbenefitpage.ClickSubmiforCLientApprovalButton();
	        sa.assertTrue( benefitpage.verifyNotificationMsgSubmitforClientApprovalBenefit(),"Verified Notification for Client Review is Displayed");

			gTestResult = RESULT_PASS;
			OneframeLogger("Submit for Client Approval Button is validated Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Submit for Client Approval Button is validated UnSuccessfully");
		}
         sa.assertAll();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();

		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

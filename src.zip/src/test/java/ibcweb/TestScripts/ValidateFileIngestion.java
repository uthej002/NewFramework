package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import APIUtilities.IBCAWSHelper;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class ValidateFileIngestion extends OneframeContainer {
	
	IBCAWSHelper utilAWS;
    
    @BeforeClass
	@Step("Initializing Test Script for validate File Ingestion process through AWS")
	public void setUp() {
		InitializeLaunchPad("IBPW_658");
		utilAWS = new IBCAWSHelper();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate File Ingestion process through AWS", dataProvider = "TestData")
	@Description("validate File Ingestion process through AWS")
	public void verifyFileIngestionProcess(String TestCaseID, String TestStatus) throws Throwable {	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		try {
			sa.assertTrue(utilAWS.loginToAWS(), "AWS Login and Switching role and region done!");
			utilAWS.navigateToS3Folder("irxbp-talend-lambda-qa-ingestion");
			sa.assertTrue(utilAWS.clickuploadFilebutton(), "Upload button is clicked");
			sa.assertTrue(utilAWS.uploadFileFromSystem("PMT-20210930-0007 - Copy.xlsx"), "File Upload has been completed");
			sa.assertTrue(utilAWS.clickonProperties(), "Properties button is clicked");
			sa.assertTrue(utilAWS.clickonserversideencryptionsettings(), "Server side encryption settings has been selected");
			sa.assertTrue(utilAWS.clickonUpload(), "Clicked on final upload button");
			sa.assertTrue(utilAWS.verifyuploadcompleted(), "Uploaded has been successfully");
			sa.assertTrue(utilAWS.clickonDestination(), "Clicked on Destination button");
			sa.assertTrue(!utilAWS.verifyFileIngestionProcess("PMT-20210930-0007 - Copy.xlsx"), "File Ingestion process has been completed");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();	
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

	

}

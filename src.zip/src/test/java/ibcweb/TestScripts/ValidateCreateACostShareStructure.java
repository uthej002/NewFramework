package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitDetailsPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreateACostShareStructure extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesBaseFormularies baseFormulary;
    IBPCreateBenefitPage createbenefitpage;
    IBPBenefitDetailsPage details;
    IBPLibrariesNetFormularies netFormulary;
    
    
	@BeforeClass
	@Step("Initializing Test Script for Validating libraries Create Cost share structure")
	public void setUp() {
		InitializeLaunchPad("IBPW_381");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		baseFormulary = new IBPLibrariesBaseFormularies();
		createbenefitpage = new IBPCreateBenefitPage();
		details = new IBPBenefitDetailsPage();
		netFormulary = new IBPLibrariesNetFormularies();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId", "EffectiveDate", "TermDate" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate libraries Create Cost share structure", dataProvider = "TestData")
	@Description("Validate libraries Create Cost share structure")
	public void ValidateLibrariesCostShareStructureEditFunctionality(String TestCaseID, String TestStatus, String ClientId,
			String LOBId, String StateId, String EffectiveDate, String TermDate)
			throws AWTException, InterruptedException, IOException, ParseException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on Libraries Section");
			librariesCostShareStructurePage.clickViewButtonOfCostShareStructure();
			sa.assertTrue(librariesCostShareStructurePage.verifyCostShareStructureHeader(),
					"Cost Share Structure header is verified");

			librariesCostShareStructurePage.clickCreateCostShareStructure();

			librariesCostShareStructurePage.verifyCostShareTierStructureUrl();

			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Create a Cost Share Structure");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Structure Type");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Structure Name");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Cost Share Rows");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Structure Content");

			librariesCostShareStructurePage.enterAndGetTextStructureType();
			librariesCostShareStructurePage.enterAndGetTextStructureName();
			librariesCostShareStructurePage.enterAndGetCostShareRows();
			librariesCostShareStructurePage.enterAndGetStructureContent();
			sa.assertTrue(createbenefitpage.selectClientDropdown(ClientId), "Verified and selected 'Client dropdown'");
			sa.assertTrue(createbenefitpage.selectLOBDropdown(LOBId), "Verified and selected 'LOB dropdown' ");
			sa.assertTrue(createbenefitpage.selectStateDropdown(StateId), "Verified and selected 'State dropdown'"); 
			netFormulary.EnterEffectiveDate(EffectiveDate);
			netFormulary.EnterTermDate(TermDate);
			librariesCostShareStructurePage.clickCreateStructureButton();
			librariesCostShareStructurePage.verifyCostShareStructureCreatedMessage();

			sa.assertAll();

			gTestResult = RESULT_PASS;
			OneframeLogger("Validated libraries Create Cost share structure successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate libraries Create Cost share structure");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.TestScripts;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.*;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.testng.annotations.*;

import com.google.common.collect.Ordering;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class ValidateLibrariesControlsGeneralDefaultsSortFunctionality extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;

	FileIngestionDbValidations db;

	@BeforeClass
	@Step("Initializing Test Script for validating sort functionality Libraries -> Controls -> General Defaults")
	public void setUp() {
		InitializeLaunchPad("IBPW_555");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		db = new FileIngestionDbValidations();
		controls = new IBPLibrariesControlsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus",};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate sort functionality on program name column for Libraries -> Controls -> General Defaults", dataProvider = "TestData")
	@Description("Validate sort functionality on program name column for Libraries -> Controls -> General Defaults")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus)throws AWTException, InterruptedException, IOException {
		
		List<String>  expectedProgramNameAsc = db.getColumnAsList("bob_default", "name", "", "ASC");
		java.util.Collections.sort(expectedProgramNameAsc);
		//List<String>  ProgramNameDesc = db.getPrograms("Cost-Of-Care", "name", "DESC");
		//java.util.Collections.sort(expectedProgramNameDesc);
		List<String> expectedProgramNameDesc = Ordering.natural().reverse().sortedCopy(expectedProgramNameAsc);
		
		List<String>  expectedTimelyFilingAsc = db.getColumnAsList("bob_default", "timely_filing", "", "ASC");
		List<String>  expectedTimelyFilingDesc = db.getColumnAsList("bob_default", "timely_filing", "", "DESC");
		
		List<String>  expectedPaperClaimsINNAsc = db.getColumnAsList("bob_default", "paper_claims_inn", "", "ASC");
		List<String>  expectedPaperClaimsINNDesc = db.getColumnAsList("bob_default", "paper_claims_inn", "", "DESC");
		
		List<String>  expectedPaperClaimsONNAsc = db.getColumnAsList("bob_default", "paper_claims_oon", "", "ASC");
		List<String>  expectedPaperClaimsONNDesc = db.getColumnAsList("bob_default", "paper_claims_oon", "", "DESC");
		
		List<String>  expectedFollowMeLogicAsc = db.getColumnAsList("bob_default", "follow_me_logic", "", "ASC");
		List<String>  expectedFollowMeLogicDesc = db.getColumnAsList("bob_default", "follow_me_logic", "", "DESC");
		

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			
			sa.assertTrue(controls.clickViewButtonofControls(), "CLicked on Controls view button");		
			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'Controls' header is displayed");
			
			//GENERAL DEFAULT NAMES - Ascending order
			librariesprogramspage.getValuesFromColumn("name", "before sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("name"), "Clicked on Name column header");
			List<String> actualProgramNames = librariesprogramspage.getValuesFromColumn("name", "after sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedProgramNameAsc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT NAMES - Descending order
			librariesprogramspage.getValuesFromColumn("name", "before sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("name"), "Clicked on Name column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("name", "after sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedProgramNameDesc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT TIMELY FILLING - Ascending order
			librariesprogramspage.getValuesFromColumn("TIME FILLING", "before sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("TIME FILLING"), "Clicked on TIME FILLING column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("TIME FILLING", "after sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedTimelyFilingAsc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT TIMELY FILLING - Descending order
			librariesprogramspage.getValuesFromColumn("TIME FILLING", "before sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("TIME FILLING"), "Clicked on TIME FILLING column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("TIME FILLING", "after sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedTimelyFilingDesc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT PAPER CLAIMS INN - Ascending order
			librariesprogramspage.getValuesFromColumn("PAPER CLAIMS IN NETWORK", "before sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("PAPER CLAIMS IN NETWORK"), "Clicked on PAPER CLAIMS IN NETWORK column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("PAPER CLAIMS IN NETWORK", "after sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedPaperClaimsINNAsc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT PAPER CLAIMS INN - Descending order
			librariesprogramspage.getValuesFromColumn("PAPER CLAIMS IN NETWORK", "before sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("PAPER CLAIMS IN NETWORK"), "Clicked on PAPER CLAIMS IN NETWORK column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("PAPER CLAIMS IN NETWORK", "after sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedPaperClaimsINNDesc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT PAPER CLAIMS ONN - Ascending order
			librariesprogramspage.getValuesFromColumn("PAPER CLAIMS OUT OF NETWORK", "before sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("PAPER CLAIMS OUT OF NETWORK"), "Clicked on PAPER CLAIMS OUT OF NETWORK column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("PAPER CLAIMS OUT OF NETWORK", "after sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedPaperClaimsONNAsc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT PAPER CLAIMS ONN - Descending order
			librariesprogramspage.getValuesFromColumn("PAPER CLAIMS OUT OF NETWORK", "before sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("PAPER CLAIMS OUT OF NETWORK"), "Clicked on PAPER CLAIMS OUT OF NETWORK column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("PAPER CLAIMS OUT OF NETWORK", "after sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedPaperClaimsONNDesc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT FOLLOW ME LOGIC - Ascending order
			librariesprogramspage.getValuesFromColumn("FOLLOW ME LOGIC APPLIES", "before sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("FOLLOW ME LOGIC APPLIES"), "Clicked on FOLLOW ME LOGIC APPLIES column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("FOLLOW ME LOGIC APPLIES", "after sorting in Ascending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedFollowMeLogicAsc, actualProgramNames), "Expected Text matches with the Actual Text");
			
			//GENERAL DEFAULT FOLLOW ME LOGIC - Descending order
			librariesprogramspage.getValuesFromColumn("FOLLOW ME LOGIC APPLIES", "before sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.clickColumnHeader("FOLLOW ME LOGIC APPLIES"), "Clicked on FOLLOW ME LOGIC APPLIES column header");
			actualProgramNames = librariesprogramspage.getValuesFromColumn("FOLLOW ME LOGIC APPLIES", "after sorting in Descending Order");
			sa.assertTrue(librariesprogramspage.verifyElementsAreSorted(expectedFollowMeLogicDesc, actualProgramNames), "Expected Text matches with the Actual Text");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated sort functionality on program name column for Libraries -> Controls -> General Defaults Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate sort functionality on program name column for Libraries -> Controls -> General Defaults");
		}

//		homepage.clickLogout();  
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

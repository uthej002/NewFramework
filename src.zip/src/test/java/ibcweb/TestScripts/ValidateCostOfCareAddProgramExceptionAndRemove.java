package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCostOfCareAddProgramExceptionAndRemove extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validate Create Program and Add and Remove Exception in Networks Tab of Cost of care")
	public void setUp() {
		InitializeLaunchPad("IBPW_768");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ProgramName", "EffectiveDate", "ClientId", "LOBId",
				"StateId", "ProgramDescription" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Create Program and Add and Remove Exception in Networks Tab of Cost of care", dataProvider = "TestData")
	@Description("Validate Create Program and Add and Remove Exception in Networks Tab of Cost of care")
	public void ValidateCostOfCareEditAndCancelFunctionality(String TestCaseID, String TestStatus, String ProgramName,
			String EffectiveDate, String ClientId, String LOBId, String StateId, String ProgramDescription)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			librariesprogramspage.clickViewButtonofPrograms();
			librariesprogramspage.clickCostofCareofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "Verified 'Programs' header");
			librariesprogramspage.clickProgramsHeader();
			librariesprogramspage.clickAddProgramofPrograms();
			sa.assertTrue(librariesprogramspage.verifyAddNewProgramHeader(),
					"Verified 'Add New Program' Section Page is displayed");
			sa.assertTrue(librariesprogramspage.enterProgramName(ProgramName), "Verified and Entered 'Program Name'");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId), "Verified 'ClientID dropdown' selected");
			sa.assertTrue(librariesprogramspage.selectLobdropdown(LOBId), "Verified 'LOB dropdown' selected");
			sa.assertTrue(librariesprogramspage.selectStatedropdown(StateId), "Verified 'State dropdown' selected");
			sa.assertTrue(librariesprogramspage.enterProgramDescription(ProgramDescription),
					"Verified and Entered 'Program Description'");
			sa.assertTrue(librariesprogramspage.verifyNetworkTabIsEnabledAndClicked(),
					"Verified Network tab is Enabled and clicked");
			sa.assertTrue(librariesprogramspage.verifyMaxDaySupplyFieldIsDisplayed(),
					"Verified Max day Supply field is displayed");
			sa.assertTrue(librariesprogramspage.verifyRefillTooSoonFieldIsDisplayed(),
					"Verified Refill Too Soon field is displayed");
			sa.assertTrue(librariesprogramspage.verifyNumberOfGraceFillsFieldIsDisplayed(),
					"Verified Number of Grace fills field is displayed");
			sa.assertTrue(librariesprogramspage.verifyNumberOfFillsDropdownIsDisplayed(),
					"Verified Number of fills dropdown is displayed");
			String networkName = librariesprogramspage.verifyAndAddException();
			sa.assertTrue(librariesprogramspage.verifyNetworkNameIsAddedInAddExceptionsNetwork(networkName),
					"Verified Network Name is added in Add Exceptions network list");
			sa.assertTrue(librariesprogramspage.clickRemoveException(), "Verified and clicked Remove button");
			sa.assertTrue(!librariesprogramspage.verifyExceptionIsRemoved(), "Verified Exception is removed");
//			sa.assertTrue(librariesprogramspage.clickAddTherapeuticProgram(), "Clicked on Add Program Button");
//			sa.assertTrue(librariesprogramspage.verifyTherapeuticCreateSuccess(),
//					"Verified the 'Therapeutic was Created Successfully'");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger(
					"Validated Create Program and Add and Remove Exception in Networks Tab of Cost of care is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger(
					"Unable to Validate Create Program and Add and Remove Exception in Networks Tab of Cost of care Functionality");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

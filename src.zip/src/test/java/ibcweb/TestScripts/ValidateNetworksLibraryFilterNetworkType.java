package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesNetworksChannelsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateNetworksLibraryFilterNetworkType extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesNetworksChannelsPage librariesnetworkspage;

	@BeforeClass
	@Step("Initializing Test Script for Validating user is able to filter the networks by network type")
	public void setUp() {
		InitializeLaunchPad("IBPW_824");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesnetworkspage = new IBPLibrariesNetworksChannelsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate user is able to filter the networks by network type", dataProvider = "TestData")
	@Description("Validate user is able to filter the networks by network type")
	public void ValidateLibrariesNetworkFilter(String TestCaseID, String TestStatus) throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesnetworkspage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			librariesnetworkspage.clickViewButtonOfNetworksandChannels();
			sa.assertTrue(librariesnetworkspage.verifyNetworksHeader(),
					"Verified 'Networks and Channels header' is displayed");
			librariesnetworkspage.clickFilterButton();
			sa.assertTrue(librariesnetworkspage.verifyFilterText(), "Verified 'Filter By' is displayed");
			String networkType = librariesnetworkspage.selectNetworkType();
			librariesnetworkspage.clickApplyFilterButton();
			librariesnetworkspage.verifySelectedNetworkTypeDisplayed(networkType);
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate user is able to filter the networks by network type Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to user is able to filter the networks by network type");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

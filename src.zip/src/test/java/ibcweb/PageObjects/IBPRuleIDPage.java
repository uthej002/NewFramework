package ibcweb.PageObjects;

import java.lang.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;
import io.qameta.allure.Step;

public class IBPRuleIDPage extends OneframeContainer {

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-version mat-column-version ng-star-inserted']//a")
	List<WebElement> lstlnkVersionIds;

	@FindBy(xpath = "//thead[@role='rowgroup']")
	WebElement hdrRule;
	
	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Logout ']")
	WebElement btnLogout;

	@FindBy(xpath = "//div[contains(text(), 'Rule ID: ')]")
	WebElement txtRuleIDTitle;

	@FindBy(xpath = "//div[@class='heading']/div")
	WebElement txtRuleIDTitleOne;

	@FindBy(xpath = "//*[@class='button-group']//button//span[text()=' Cancel ']")
	WebElement btnCancel;

	@FindBy(css = "input[placeholder='Enter Name']:disabled")
	WebElement txtEnterNamedisabled;

	@FindBy(xpath = "//input[@placeholder='Enter Name']")
	WebElement txtEnterName;

	@FindBy(css = "input[placeholder='Enter Description(optional)']:disabled")
	WebElement txtDescription;

	@FindBy(css = "input[placeholder='Start Date']:disabled")
	WebElement txtStartDate;

	@FindBy(css = "input[placeholder='End Date']:disabled")
	WebElement txtEndDate;

	@FindBy(css = "input[placeholder='Enter Message']:disabled")
	WebElement txtEnterMessage;

	@FindBy(xpath = "//*[@placeholder='Select']/div/div/span")
	List<WebElement> btnDropDowns;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option")
	List<WebElement> drdClientId;
	
	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option")
	List<WebElement> drdLOBId;
	
	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option")
	List<WebElement> drdStateId;
	
	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option")
	List<WebElement> drdDecisionType;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-verCreatedOn mat-column-verCreatedOn ng-star-inserted']")
	List<WebElement> lstVersionCreatedon;

	@FindBy(xpath = "//span[text()=' Impact Analysis ']")
	WebElement btnImpactAnalysis;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()= ' Edit ']")
	WebElement btnEdit;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()=' Update Rule '] ")
	WebElement btnUpdateRule;

	@FindBy(xpath = "//span[contains(.,'Back ')]")
	WebElement btnBack;

	@FindBy(xpath = "//span[text()=' Impact analysis is in-progress... ']")
	WebElement txtImpactProgress;

	@FindBy(xpath = "//button[@color='accent']/span[text()=' Promote ']")
	WebElement btnPromote;

	@FindBy(xpath = "//div[@class='card__grey']//h1")
	WebElement txtBenefitsgrid;

	@FindBy(xpath = "//div[@class='card__red']//h1")
	WebElement txtImpactgrid;

	@FindBy(xpath = "//div[@class='card__green']//h1")
	WebElement txtNoImpactgrid;

	@FindBy(xpath = "//div[@class='card__orange']//h1")
	WebElement txtSkippedgird;

	@FindBy(xpath = "//h3[@class='sub-title production-subtitle']")
	WebElement hdrProductionTitle;

	@FindBy(css = ".card__red svg")
	WebElement btnDownloadRed;

	@FindBy(css = ".card__green svg")
	WebElement btnDownloadGreen;

	@FindBy(xpath = "//mat-icon[@svgicon= 'add']")
	List<WebElement> btnEditAddRow;

	@FindBy(xpath = "//mat-icon[@svgicon= 'remove']")
	List<WebElement> btnEditRemoveRow;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text() = ' Back ']")
	WebElement btnEditBack;
	
	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text() = ' Cancel ']")
	WebElement btnEditCancel;
	
	@FindBy(xpath = "//div/span[@class='content__group__label' and text() = 'Lob']")
	WebElement txtLOB;
	
	@FindBy(xpath = "//div[@class='mat-paginator-range-label']")
	WebElement txtPageNumber;
	
	@FindBy(xpath = "//*[@class='mat-paginator-icon']")
	List<WebElement> lstPageTraverseChevronButton;
	
	@FindBy(xpath = "//h2[text()='Benefit Validation Rules Engine']")
	WebElement hdrBenefitRuleEngine;

	// SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");

	// Initializing the Page Objects:
	public IBPRuleIDPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify RuleID Title is Displayed")
	public boolean verifyRuleIDTitleDisplay() throws InterruptedException {
		
		Thread.sleep(3000);
		WaitForObjectVisibility(txtRuleIDTitleOne);
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (txtRuleIDTitleOne.isDisplayed()) {
				highlightElement(txtRuleIDTitleOne);
				OneframeLogger("RuleID Title is "+ txtRuleIDTitleOne.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("RuleID Title is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Previous Version ID")
	public void clickPreviousVersionofRuleID() throws InterruptedException {
		ClickWebObject(hdrRule);
		try {
			//OneframeLogger(lstlnkVersionIds.size());
			if (lstlnkVersionIds.size() > 1 && WaitForObjectVisibility(lstlnkVersionIds.get(0))) {
				ClickWebObject(lstlnkVersionIds.get(0));
				OneframeLogger("Previous Version ID clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Previous Version ID not clicked");
		}
	}
	
	public String getLatestVersionID(String libraryName, String ruleId) {
		String xpath = "//*[contains(text(), '"+libraryName+"')]/../../following-sibling::div//td/a[normalize-space()='"+ruleId+"']/../../td[6]";
		String versionId = "";
		try {
			WaitForApplicationToLoadCompletely();
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
			highlightElement(ele);
			versionId = ele.getText();
			OneframeLogger("Latest version id: "+versionId);
		}
		catch(NoSuchElementException e) {
			OneframeLogger("Unable to get Latest version ID");
		}
		
		return versionId;
	}
	
	@Step("Click on Latest Version ID")
	public void clickLatestVersionofRuleID(String versionId) throws InterruptedException {
		Thread.sleep(3000);
		WaitForApplicationToLoadCompletely();
		ClickWebObject(txtRuleIDTitle);
		ClickWebObject(txtRuleIDTitle);
		ClickWebObject(txtRuleIDTitle);
		ClickWebObject(txtRuleIDTitle);
		
		try {
			String xpath = "//td/a[normalize-space()='"+versionId+"']";
			String records = null;
			WaitForObjectVisibility(txtPageNumber);
			if(WaitForObject(txtPageNumber)) {
				records = txtPageNumber.getText();
			}
		//	String records = txtPageNumber.getText();
			String[] recordCnt = records.split(" ");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());
			
			// Dividing totalRecords by 5 because there are only 10 records per page
			int numberOfPages = Math.round(totalRecords/10) + 1;
			
			if(numberOfPages != 0) {
				for(int i=0; i<numberOfPages; i++) {
					try {
						WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
						OneframeLogger("Latest Version is CLicked : " +ele.getText());
						if(WaitForObjectVisibility(ele)) {
							ClickWebObject(ele);
							break;
						}
					}
					catch (NoSuchElementException e) {
						 ClickWebObject(lstPageTraverseChevronButton.get(1));
						 ClickWebObject(txtPageNumber); 
						 ClickWebObject(txtPageNumber);
						 WaitForApplicationToLoadCompletely();
					}
					
				}
			}
			
		} catch (TimeoutException e) {
			OneframeLogger("Latest Version ID not clicked");
		}
	}

	@Step("Verify whether the Version ID is promoted")
	public boolean verifyVersionIDPromoted() {
		boolean blnRC = false;
		String allVersions = lstlnkVersionIds.get(lstlnkVersionIds.size()).getText();
		List<String> versionNumbers = new ArrayList<String>();
		for (int i = 0; i <= lstlnkVersionIds.size(); i++) {
			versionNumbers.add(allVersions);
		}
		if (versionNumbers != null && !versionNumbers.contains(".")) {
			OneframeLogger("The Version Number is " + versionNumbers);
			OneframeLogger("The VersionID is moved into Production");
			blnRC = true;
		} else {
			OneframeLogger("The VersionID is not moved into Production");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Click on Cancel Button")
	public void clickCancelbutton() {
		try {
			if (ObjectExist(btnCancel)) {
				ClickWebObject(btnCancel);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Cancel Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cancel button not clicked");
		}
	}

	@Step("Verify Impact Analysis button is displayed")
	public boolean verifyImpactAnalysisbuttondisplay() {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(btnImpactAnalysis);
		try {
			if (btnImpactAnalysis.isDisplayed()) {
				highlightElement(btnImpactAnalysis);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("verify Impact Analysis button is not displayed")
	public boolean verifyNoImpactAnalysisButton() {
		if (FindObjectByLocatorNoWait(By.xpath("//span[text()=' Impact Analysis ']")) != null) {
			return true;
		} else {
			return false;
		}

	}

	@Step("Verify Edit button is displayed")
	public boolean verifyEditbuttondisplay() {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(btnEdit);
		try {
			if (btnEdit.isDisplayed()) {
				highlightElement(btnEdit);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

//	@Step("Click on Latest Version ID")
//	public void clickLatestVersionofRuleID() throws InterruptedException {
//		try {
//			Date currentDate = dateFormat.parse(dateFormat.format(new Date()));
//			for (int i = 0; i <= lstVersionCreatedon.size(); i++) {
//
//				WaitForObjectVisibility(lstVersionCreatedon.get(i));
//				Date versionCreatedDate = dateFormat.parse(lstVersionCreatedon.get(i).getText());
//				OneframeLogger("The Version create date is " + versionCreatedDate);
//				if (versionCreatedDate.equals(currentDate)) {
//					ClickWebObject(lstlnkVersionIds.get(i));
//					OneframeLogger("Previous Version ID clicked");
//					break;
//				}
//			}
//		} catch (TimeoutException | ParseException e) {
//			OneframeLogger("Previous Version ID not clicked");
//		}
//	}

	@Step("Verify Rule Name textbox is displayed")
	public boolean verifyRuleNamedisplay() throws InterruptedException {
		WaitForObjectVisibility(txtEnterNamedisabled);
		return txtEnterNamedisabled.isEnabled();
	} 	

	@Step("Verify Description textbox is displayed")
	public boolean verifyDescriptiondisplay() throws InterruptedException {
		WaitForObjectVisibility(txtDescription);
		return txtDescription.isEnabled();
	}

	@Step("Verify When Section is displayed")
	public boolean verifyWhenSectiondisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(btnDropDowns.get(0));
		try {
			if (btnDropDowns.get(0).isEnabled()) {
				highlightElement(btnDropDowns.get(0));
				highlightElement(btnDropDowns.get(1));
				highlightElement(btnDropDowns.get(2));
				OneframeLogger("When Section is enabled");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("When Section is disabled");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Then Section is displayed")
	public boolean verifyThenSectiondisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(btnDropDowns.get(3));
		try {
			if (btnDropDowns.get(3).isEnabled()) {
				highlightElement(btnDropDowns.get(3));
				OneframeLogger("Then Section is enabled");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Then Section is disabled");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Client id Value in Ist drop down")
	public boolean selectClientId() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(0))) {
				ClickWebObject(btnDropDowns.get(0));
				WaitForObjectVisibility(drdClientId.get(1));
				//SelectDropDownListByValue(drdClientId.get(1));
				drdClientId.get(1).sendKeys(Keys.TAB);
				OneframeLogger("Selected Value from the Dropdown is :" +drdClientId.get(1).getText() );
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from Client ID dropdown");
			  blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Lob id Value in 2nd drop down")
	public boolean selectLOBId() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(1))) {
				ClickWebObject(btnDropDowns.get(1));
				WaitForObjectVisibility(drdLOBId.get(2));
				//SelectDropDownListByValue(drdLOBId, LOBId);
				drdLOBId.get(2).sendKeys(Keys.TAB);
				OneframeLogger("Selected Value from the Dropdown is :" +drdLOBId.get(2).getText() );
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from LOB dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select State id Value in 3rd drop down")
	public boolean selectStateId() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(2))) {
				ClickWebObject(btnDropDowns.get(2));
				WaitForObjectVisibility(drdStateId.get(3));
				//SelectDropDownListByValue(drdStateId, StateId);
				drdStateId.get(3).sendKeys(Keys.TAB);
				OneframeLogger("Selected Value from the Dropdown is :" +drdStateId.get(3).getText() );
				blnRC = true;			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from State Id dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	@Step("Select State id Value in 4th drop down")
	public boolean selectDecisionType() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(3))) {
				ClickWebObject(btnDropDowns.get(3));
				WaitForObjectVisibility(drdDecisionType.get(0));
				//SelectDropDownListByValue(drdDecisionType, DType);
			
				OneframeLogger("Selected Value from the Dropdown is :" +drdDecisionType.get(0).getText() );
				blnRC = true;			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from Decision Type dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	@Step("Verify Start and End Date textbox is displayed")
	public boolean verifyStartandEndDatedisplay() throws InterruptedException {
		WaitForObjectVisibility(txtStartDate);
		return txtStartDate.isEnabled() && txtEndDate.isEnabled();
	}

	@Step("Verify Message textbox is displayed")
	public boolean verifyMessagedisplay() throws InterruptedException {
		WaitForObjectVisibility(txtEnterMessage);
		return txtEnterMessage.isEnabled();
	}

	@Step("Click on Edit Button")
	public void clickEditButton() throws InterruptedException {
		try {
			if (WaitForObjectVisibility(btnEdit)) {
				ClickWebObject(btnEdit);
				OneframeLogger("Edit Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Edit Button is not clicked");
		}
	}
	
	@Step("Get Random Alphabetical String")
	public String getRandomAlphabeticalString(int length) {
		String value = " ";
		String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		for (int i = 1; i < length; i++) {
			value += letters.charAt((int) Math.floor(Math.random() * letters.length()));
		}
		return "TEST" + value;
	}

	@Step("Update the RuleName")
	public void updateRuleName() {
		WaitForApplicationToLoadCompletely();
		if (ObjectExist(txtEnterName)) {
			ClickWebObject(txtEnterName);
			txtEnterName.sendKeys(Keys.CONTROL + "a");
			txtEnterName.sendKeys(Keys.DELETE);
			String randomString = getRandomAlphabeticalString(5);
			WaitForObjectVisibility(txtEnterName);
			txtEnterName.click();
			txtEnterName.sendKeys(randomString);
			OneframeLogger("Rule Name has been Entered");
		} else {
			OneframeLogger("Rule Name has not been Entered");
		}	
	}

	@Step("Click on Update Rule Button")
	public boolean clickUpdateRuleButton() {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(btnUpdateRule);
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnUpdateRule)) {
				ClickWebObject(btnUpdateRule);
				OneframeLogger("Update Rule Button is clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Update Rule Button is not clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Back Button")
	public void clickBackbutton() {
		try {
			ClickWebObject(txtRuleIDTitleOne);
			ClickWebObject(txtRuleIDTitleOne);
			ClickWebObject(txtRuleIDTitleOne);
			ClickWebObject(txtRuleIDTitleOne);
			
			if (ObjectExist(btnBack)) {
				ClickWebObject(btnBack);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Back Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Back button not clicked");
		}
	}

	@Step("Verify Back Button is displayed")
	public boolean verifyBackbuttondisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(btnBack);
		try {
			if (btnBack.isDisplayed()) {
				highlightElement(btnBack);
				OneframeLogger("Back Button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Back Button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Promote Button is displayed")
	public boolean verifyPromoteButtonDisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(btnPromote);
		try {
			if (btnPromote.isDisplayed()) {
				highlightElement(btnPromote);
				OneframeLogger("Promote Button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Promote Button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Promote Button")
	public void clickPromoteButton() {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(btnPromote)) {
				ClickWebObject(btnPromote);
				//ClickWebObject(btnPromote);
				OneframeLogger("Promote Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Promote button not clicked");

		}
	}
	@Step("Click LOB Text")
	public void clickLOBTxt() {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtLOB)) {
				ClickWebObject(txtLOB);

				OneframeLogger("Promote Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Promote button not clicked");

		}
	}
	@Step("Click on Impact Analysis button")
	public void clickImpactAnalysisbutton() {
		try {
			if (WaitForObjectVisibility(btnImpactAnalysis)) {
				ClickWebObject(btnImpactAnalysis);
				OneframeLogger("Impact Analysis Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Impact Analysis Button is not clicked");
		}
	}

	@Step("Verfiy Impact Analysis Message is Displayed")
	public boolean verifyImpactAnalysisMessage() {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(txtImpactProgress);
		OneframeLogger(txtImpactProgress.getText());
		try {
			if (txtImpactProgress.getText().equalsIgnoreCase("Impact analysis is in-progress...")) {
				highlightElement(txtImpactProgress);
				OneframeLogger("Impact Progress Message is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Impact Progress Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Benefits Statics are displayed")
	public boolean verifyBenefitsStaticsDisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(txtBenefitsgrid);
		try {
			if (txtBenefitsgrid.isDisplayed()) {
				highlightElement(txtBenefitsgrid);
				OneframeLogger("The Total No of Benefits are " + txtBenefitsgrid.getText());
				highlightElement(txtImpactgrid);
				OneframeLogger("The Total No of Impact Benefits are " + txtImpactgrid.getText());
				highlightElement(txtNoImpactgrid);
				OneframeLogger("The Total No of No-Impact Benefits are " + txtNoImpactgrid.getText());
				highlightElement(txtSkippedgird);
				OneframeLogger("The Total No of Skipped Benefits are " + txtSkippedgird.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Benefits Statics are not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Production Title is displayed")
	public boolean verifyProductionTitleDisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrProductionTitle);
		try {
			if (hdrProductionTitle.isDisplayed()) {
				highlightElement(hdrProductionTitle);
				OneframeLogger("Production Title is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Production Title is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("clicks download button for Impact Grid")
	public void clickDownloadImpactGrid() {
		if (CheckObjectExistence(btnDownloadRed) != null) {
			ClickWebObject(btnDownloadRed);
			OneframeLogger("Impact Grid Download option is clicked");
		} else {
			OneframeLogger("Impact Grid Download option is not clicked");
		}
	}

	@Step("clicks download button for No Impact Grid")
	public void clickDownloadNoImpactGrid() {
		if (CheckObjectExistence(btnDownloadGreen) != null) {
			ClickWebObject(btnDownloadGreen);
			OneframeLogger("No Impact Grid Download option is clicked");
		} else {
			OneframeLogger("No Impact Grid Download option is not clicked");
		}
	}

	@Step("Verify downloaded file")
	public boolean verifyDownloadedFile(String filetype) throws InterruptedException {
		Thread.sleep(30000);
		boolean blnRC = false;
		if (filetype.equalsIgnoreCase("csv")) {
			File directory = new File((System.getProperty("user.dir") + "\\src\\test\\resources\\RunTime"));
			File[] content = directory.listFiles();
			for (int i = 0; i < content.length; i++) {
				if ("No-ImpactedBenefits.csv".equals(content[i].getName())) {
					OneframeLogger("No Impact Benefits File downloaded in csv format");
					blnRC = true;
				}
			}
		} else {
			OneframeLogger("File not found in correct format: ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify All types of Benefit Count is equal to the Total Benefit Count")
	public boolean verifyBenefitCount() {
		boolean blnRC = false;
		WaitForObjectVisibility(txtBenefitsgrid);
		try {
			if (txtBenefitsgrid.isDisplayed()) {
				String benefitsgrid = txtBenefitsgrid.getText();
				//String[] totalBenefitsCount = benefitsgrid.split(" ");
				//int totalBenefits = Integer.parseInt(totalBenefitsCount[0].trim());
				int totalBenefits = Integer.parseInt(benefitsgrid);
				
				String impactgrid = txtImpactgrid.getText();
				//String[] impactCount = impactgrid.split(" ");
				int impact = Integer.parseInt(impactgrid);

				String noimpactgrid = txtNoImpactgrid.getText();
				//String[] noimpactCount = noimpactgrid.split(" ");
				int noimpact = Integer.parseInt(noimpactgrid);

				String skippedgrid = txtSkippedgird.getText();
				//String[] skippedCount = skippedgrid.split(" ");
				int skipped = Integer.parseInt(skippedgrid);

				int allBenefitsCount = impact + noimpact + skipped;

				if (totalBenefits == allBenefitsCount) {
					OneframeLogger("Total Benefits: " +totalBenefits);
					OneframeLogger("Impacted Benefits: " +impact);
					OneframeLogger("Non Impacted Benefits: " +noimpact);
					OneframeLogger("Skipped Benefits: " +skipped);
					
					OneframeLogger("All kinds of beneifts count equal to the Total Benefits Count");
					blnRC = true;
				} else {
					OneframeLogger("All kinds of beneifts count not equal to the Total Benefits Count");
					blnRC = false;
				}
			}
		} catch (NoSuchElementException toException) {
		}
		return blnRC;
	}

	@Step("Click on Edit Add Row Button")
	public boolean clickEditAddRowButton() throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnEditAddRow.get(0))) {
				ClickWebObject(btnEditAddRow.get(0));
				OneframeLogger("Edit Add Row Button is clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Edit Add Row  Button is not clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Edit Remove Row Button")
	public boolean clickEditRemoveRowButton() throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnEditRemoveRow.get(0))) {
				ClickWebObject(btnEditRemoveRow.get(0));
				OneframeLogger("Edit Remove Row  Button is clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Edit Remove Row Button is not clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Edit Cancel Button")
	public boolean clickEditCancelButton() throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnEditCancel)) {
				ClickWebObject(btnEditCancel);
				OneframeLogger("Cancel Button Button is clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cancel Button is not clicked");
			blnRC = false;
		}
		return blnRC;
	}


	@Step("Click on Back Button in Edit Functionality ")
	public void clickBackbuttoninEdit() {
		try {
			if (ObjectExist(btnEditBack)) {
				ClickWebObject(btnEditBack);
				OneframeLogger("Back Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Back button is not clicked");
		}
	}
}

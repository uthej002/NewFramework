package ibcweb.TestScripts;

import java.awt.AWTException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class SampleWebUITestScript extends OneframeContainer {


	@BeforeClass
	@Step("Initializing Test Script for validating Add New Address Default checkbox not selected on Addresses page")
	public void setUp() {
		InitializeLaunchPad("IRXW_10");



	}

	@DataProvider(name = "AddNewAddressTestData")
	public Object[][] getAddNewAddressTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "UserName", "Password", "AddressLine1", "AddressLine2", "ZIPCode", "City", "State"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Default checkbox not selected in Add New Address capability on IRx Web Portal", dataProvider = "AddNewAddressTestData")
	@Description("Validate Default checkbox not selected in Add New Address functionality of IngenioRx Web Portal")
	public void ValidateDefaultCheckboxNotSelectedCapability(String TestCaseID, String TestStatus, String UserName, String Password, String AddressLine1, String AddressLine2, String ZIPCode, String City, String State) throws AWTException, InterruptedException {
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (gTestIteration==1) {

			gTestResult = RESULT_PASS;
			OneframeLogger("Default checkbox not selected in Add New Address validation successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Default checkbox not selected in Add New Address validation unsuccessful");
		}
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}
}

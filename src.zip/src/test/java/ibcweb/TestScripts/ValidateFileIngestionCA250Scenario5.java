package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.FileIngestionDbValidations;
import ibcweb.PageObjects.IBPBenefitDetailsPage;
import ibcweb.PageObjects.IBPBenefitMandatePage;
import ibcweb.PageObjects.IBPBenefitNetworksPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateFileIngestionCA250Scenario5 extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitDetailsPage benefitDetailspage;
	IBPBenefitNetworksPage benefitNetworksPage;
	IBPBenefitMandatePage benefitMandatePage;
	FileIngestionDbValidations dbValidations;

	@BeforeClass
	@Step("Initializing Test Script for Validating File Ingestion CA250 scenario 5")
	public void setUp() {
		InitializeLaunchPad("IBPW_947");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		benefitDetailspage = new IBPBenefitDetailsPage();
		benefitNetworksPage = new IBPBenefitNetworksPage();
		benefitMandatePage = new IBPBenefitMandatePage();
		dbValidations = new FileIngestionDbValidations();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "xmlFile", "PlanProxyID" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate File Ingestion CA250 scenario 5", dataProvider = "TestData")
	@Description("Validate File Ingestion CA250 scenario 5")
	public void ValidateCA250Scenario1(String TestCaseID, String TestStatus, String xmlFile, String PlanProxyID)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		OneframeAssert ha = new OneframeAssert();

		SetTestRunVariables(TestCaseID);

		ha.assertTrue(dbValidations.validateFileStatus(xmlFile), "File Status is displayed as DONE");
		sa.assertTrue(dbValidations.validateBenefitVersion(null, PlanProxyID),
				"New Benefit Version is created in Benefit_Version table");
		String benefitID = dbValidations.getBenefitID(PlanProxyID);
		String benefitPlanID = dbValidations.getBenefitPlanID(benefitID);
		String curBenefitVersion = dbValidations.getBenefitVersion(PlanProxyID);

		dbValidations.closeDbConnection();

		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(benefitPlanID);

			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Benefit header is displayed");

			benefitMandatePage.clickMandatesTab();
			benefitMandatePage.clickStateTab();
			benefitMandatePage.verifyAndClickSubTabOption("California 250 Dollar Out of Network Copay Max Mandate ASO");
			benefitMandatePage.verifySubTabHeader("California 250 Dollar Out of Network Copay Max Mandate ASO (in)");
			benefitDetailspage.verifyFundingType("ASO");

			gTestResult = RESULT_PASS;
			OneframeLogger("Validated File Ingestion CA250 Scenario5 Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate File Ingestion CA250 Scenario5");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

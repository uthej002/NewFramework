// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

import anthem.irx.oneframe.core.OneframeContainer;

public class WebDriverFactory
{
    private DriverType currentDriver;
    
    public static WebDriverManager getDriverManager(final DriverType type) {
        final WebDriverFactory factory = new WebDriverFactory();
        factory.currentDriver = type;
        OneframeContainer.OneframeLogger("[ONEFRAME]" + type + " - Web Driver Manager Initiated");
        WebDriverManager driverManager = null;
        switch (type) {
            case CHROME: {
                driverManager = new ChromeWebDriverManager(DriverType.CHROME);
                break;
            }
            case CHROME_MOB_EMULATOR: {
                driverManager = new ChromeWebDriverManager(DriverType.CHROME_MOB_EMULATOR);
                break;
            }
            case CHROME_HEADLESS: {
                driverManager = new ChromeWebDriverManager(DriverType.CHROME_HEADLESS);
                break;
            }
            case IE: {
                driverManager = new IEWebDriverManager();
                break;
            }
            case FIREFOX: {
                driverManager = new FireFoxWebDriverManager();
                break;
            }
            case FIREFOX_HEADLESS: {
                driverManager = new FireFoxWebDriverManager();
                break;
            }
            case EDGE: {
                driverManager = new EdgeWebDriverManager();
                break;
            }
            default: {
                driverManager = new ChromeWebDriverManager(DriverType.CHROME);
                break;
            }
        }
        return driverManager;
    }
}

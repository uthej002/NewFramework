package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibrariesCreateCOBPackage extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;

	@BeforeClass
	@Step("Initializing Test Script for Validating Libraries Controls Create COB Package")
	public void setUp() {
		InitializeLaunchPad("IBPW_781");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"TerminationDate", "AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType",
				"MarketSegment", "ProductType", "Other", "COBlayer" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Libraries Controls Create COB Package", dataProvider = "TestData")
	@Description("Validate Libraries Controls Create COB Package")
	public void ValidateVersionEffectiveDate(String TestCaseID, String TestStatus, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String TerminationDate, String AutoApply,
			String BusinessEntity, String BusinessUnit, String CDHP, String Formulary, String FundingType,
			String MarketSegment, String ProductType, String Other, String COBlayer)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			controls.clickViewButtonofControls();
			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'controls' header");
			controls.clickCOBTab();
			sa.assertTrue(controls.verifyCOBRecords(), "Verified 'COB Details Records' header");
			controls.clickCreateCOBPackage();
			sa.assertTrue(controls.verifyCreateACOBPackageHeader(), "Verified 'Create a COB Package' button");
			sa.assertTrue(controls.verifyCreateCOBButtonIsDisabled(), "Verified 'Create COB' button is Disabled");
			String packageName = controls.enterPackageName();
			sa.assertTrue(controls.enterPackageDescription(), "Verified and Entered 'Package Description'");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			controls.EnterTerminationDate(TerminationDate);
			sa.assertTrue(controls.selectClientropdown(ClientId), "Verified and selected 'ClientID dropdown'");
			sa.assertTrue(controls.selectLobdropdown(LOBId), "Verified and selected 'LOB dropdown' ");
			sa.assertTrue(controls.selectStateDropdown(StateId),
					"Verified and Seleceted 'State dropdown'");
			controls.clickCOBPackageHeader();
			sa.assertTrue(controls.selectControlDefaultAutoApplyDropdown(AutoApply),
					"Verified and Selected 'Auto Apply' dropdown");
			sa.assertTrue(controls.selectBusinessEntityDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(controls.selectBusinessUnitDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' dropdown");
			sa.assertTrue(controls.selectCDHPTypeDropdown(CDHP), "Verified and Selected 'CDHP Type' dropdown");
			sa.assertTrue(controls.selectFormularyDropdown(Formulary), "Verified and Selected 'Formulary' dropdown");
			sa.assertTrue(controls.selectFundingTypeDropdown(FundingType),
					"Verified and Selected 'Funding Type' dropdown");
			sa.assertTrue(controls.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' dropdown");
			sa.assertTrue(controls.selectProductTypeDropdown(ProductType),
					"Verified and Selected 'Product Type' dropdown");
			sa.assertTrue(controls.selectOtherDropdown(Other), "Verified and Selected 'Others' dropdown");
			sa.assertTrue(controls.enterDetails(), "Verified and Entered 'Details'");
			sa.assertTrue(controls.selectCOBPaperElectronicLayerDropdown(COBlayer),
					"Verified and Selected 'COB Paper Electronic' dropdowns");
			sa.assertTrue(controls.verifyCreateCOBButtonIsEnabled(), "Verified 'Create COB button' is Enabled");
			controls.clickCreateCOBButton();
			sa.assertTrue(controls.verifyCOBPackageCreateSuccess(),
					"Verified the 'COB Package Created Successfully' is created");
			/* controls.clickControlsHeader();
			sa.assertTrue(controls.verifyPackageNameCreatedIsDisplayedInList(packageName),
					"Verified 'Created Package Name is present' in the list of COB Package Tab"); */

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Libraries Controls Create COB Package is created Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Libraries Controls Create COB Package");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

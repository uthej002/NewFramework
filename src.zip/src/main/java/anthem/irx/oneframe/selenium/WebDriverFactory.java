package anthem.irx.oneframe.selenium;

import anthem.irx.oneframe.core.OneframeContainer;

public class WebDriverFactory {
  private DriverType currentDriver;
  
  public static WebDriverManager getDriverManager(DriverType type) {
    WebDriverFactory factory = new WebDriverFactory();
    factory.currentDriver = type;
    OneframeContainer.OneframeLogger("[ONEFRAME]" + type + " - Web Driver Manager Initiated");
    WebDriverManager driverManager = null;
    switch (type) {
      case CHROME:
        driverManager = new ChromeWebDriverManager(DriverType.CHROME);
        return driverManager;
      case CHROME_MOB_EMULATOR:
        driverManager = new ChromeWebDriverManager(DriverType.CHROME_MOB_EMULATOR);
        return driverManager;
      case CHROME_HEADLESS:
        driverManager = new ChromeWebDriverManager(DriverType.CHROME_HEADLESS);
        return driverManager;
      case IE:
        driverManager = new IEWebDriverManager();
        return driverManager;
      case FIREFOX:
        driverManager = new FireFoxWebDriverManager();
        return driverManager;
      case FIREFOX_HEADLESS:
        driverManager = new FireFoxWebDriverManager();
        return driverManager;
      case EDGE:
        driverManager = new EdgeWebDriverManager();
        return driverManager;
    } 
    driverManager = new ChromeWebDriverManager(DriverType.CHROME);
    return driverManager;
  }
}

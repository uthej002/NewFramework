package ibcweb.TestScripts;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.CSVFile;
import anthem.irx.oneframe.utilities.ExcelFile;
import ibcweb.PageObjects.BulkProcessExcelValidation;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBulkUpdateBulkUpdatedPage;
import ibcweb.PageObjects.IBPBulkUpdatePage;
import ibcweb.PageObjects.IBPBulkUpdateReviewPage;
import ibcweb.PageObjects.IBPBulkUpdateWorkInProgressPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBulkUpdateUnlockedExcelValues extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitPage;
	IBPBulkUpdatePage bulkUpdatePage;
	IBPBulkUpdateWorkInProgressPage workInProgressPage;
	IBPBulkUpdateBulkUpdatedPage bulkUpdatedPage;
	IBPBulkUpdateReviewPage reviewPage;
	BulkProcessExcelValidation bulkUpdateExcel;
	// move to page object
	Robot robot;

	@BeforeClass
	@Step("Initializing Test Script for Validate Bulk Update General Default Submit Adjudication values")
	public void setUp() {
		InitializeLaunchPad("IBPW_1007");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitPage = new IBPBenefitPage();
		bulkUpdatePage = new IBPBulkUpdatePage();
		workInProgressPage = new IBPBulkUpdateWorkInProgressPage();
		reviewPage = new IBPBulkUpdateReviewPage();
		bulkUpdatedPage = new IBPBulkUpdateBulkUpdatedPage();
		bulkUpdateExcel = new BulkProcessExcelValidation();
	}

	@DataProvider(name = "LoginTestData")
	public Object[][] getLoginTestDataTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId", "Module", "Action",
				"EffectiveArea", "RetailInput", "HomeDeliveryInput", "DataSheetWithBenefits" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Bulk Update General Default Submit Adjudication values", dataProvider = "LoginTestData")
	@Description("Validate Bulk Update General Default Submit Adjudication values")
	public void ValidateBulkUpdateValues(String TestCaseID, String TestStatus, String ClientId, String LOBId,
			String StateId, String Module, String Action, String EffectiveArea, String RetailInput,
			String HomeDeliveryInput, String DataSheetWithBenefits)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();
		int numberOfRows = bulkUpdatePage.getRowCount(DataSheetWithBenefits);
		if (loginpage.MemberLogin()) {

			// Creating a New Project

			homepage.clickMenuButton();
			bulkUpdatePage.clickBulkProcess();
			bulkUpdatePage.clickBulkUpdate();

			bulkUpdatePage.clickOnCreateAProjectButton();
			sa.assertTrue(bulkUpdatePage.verifyCreateProjectHilightedInProgressBar(),
					"'Create Project' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatePage.verifyCreateAProjectHeader(), "'Create a Project' heading is displayed");
			sa.assertTrue(!bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is disabled");
			sa.assertTrue(bulkUpdatePage.verifyAndEnterProjectID("TestA"), "Verified and entered project id");
			sa.assertTrue(bulkUpdatePage.verifyAndEnterProjectDescription("Test Auto Project Desc"),
					"Verified and entered project description");
			sa.assertTrue(workInProgressPage.selectModuleDropdown(Module), "Selected Module as General Defaults");
			bulkUpdatePage.clickOnFileUploadButton();
			bulkUpdatePage.uploadFile(DataSheetWithBenefits);
			sa.assertTrue(bulkUpdatePage.verifySuccessfulUploadMessage(
					numberOfRows + " of " + numberOfRows + " benefits found"), "File upload");
			sa.assertTrue(bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is enabled");
			bulkUpdatePage.clickOnCreateProjectButton();
			bulkUpdatedPage.clickOnYesButton();
			sa.assertTrue(bulkUpdatePage.verifyProjectIsCreated(bulkUpdatePage.getProjectID()),
					"Project ID is found in the grid");
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "IN_PROGRESS"),
					"Project Status is In Progress");

			// Validations in Work in progress screen
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyWorkInProgressHilightedInProgressBar(),
					"'Work In Progress' is hilighted in Progress Bar");
			sa.assertTrue(workInProgressPage.verifyModuleHeader(), "Heading Module is displayed");
			sa.assertTrue(workInProgressPage.verifyActionHeader(), "Heading Action is displayed");

			sa.assertTrue(workInProgressPage.selectActionDropdown(Action), "Selected Action as Update");
			sa.assertTrue(workInProgressPage.verifyEffectiveAreaHeader(), "Heading Effective Area is displayed");
			sa.assertTrue(!workInProgressPage.verifyReviewProjectButtonEnabled(), "Review Project button is disabled");
			sa.assertTrue(workInProgressPage.selectEffectiveAreaDropdown(EffectiveArea),
					"Selected Effective Area as High Dollar");
			sa.assertTrue(workInProgressPage.verifyAndEnterRetailInput(RetailInput),
					"Retial input box is displayed and entered value is same as expected");

			sa.assertTrue(workInProgressPage.verifyAndEnterHomeDeliveryInput(HomeDeliveryInput),
					"Home Delivery input box is displayed and entered value is same as expected");

			sa.assertTrue(workInProgressPage.verifyReviewProjectButtonEnabled(), "Review Project button is enabled");
			workInProgressPage.clickProjectReviewButton();

			// Validations in Review screen
			sa.assertTrue(bulkUpdatePage.verifyReviewHilightedInProgressBar(), "'Review' is hilighted in Progress Bar");
			sa.assertTrue(reviewPage.verifyUpdateGeneralDefaultsHeading(),
					"UPDATE GENERAL DEFAULTS heading is displayed");
			sa.assertTrue(workInProgressPage.verifyHighDollarHeading(), "High Dollar heading is displayed");
			sa.assertTrue(reviewPage.verifyRetailValue(RetailInput), "Retail value is displayed");
			sa.assertTrue(reviewPage.verifyHomeDeliveryValue(HomeDeliveryInput), "Home Delivery value is displayed");
			reviewPage.clickBulkUpdateButton();

			reviewPage.verifyTextAreaSize();
			String notesText = benefitPage.getRandomString();
			reviewPage.enterNotes(notesText);
			reviewPage.verifyTextAreaSize();

			reviewPage.clickYesButton();
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "PROCESSING"),
					"Project Status is PROCESSING");

			// Validations in Processing screen
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyProcessingHilightedInProgressBar(),
					"'Processing' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatedPage.verifyBulkUpdatInProgressTextMessage(bulkUpdatePage.getProjectID()),
					"Benefit status is 'Bulk Update in Progress'");
			bulkUpdatedPage.clickOnBackButton();

			// Validations in Bulk Updated Screen
			bulkUpdatePage.verifybenefitStatus(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "BULKUPDATED"),
					"Project Status is BULK UPDATED");
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyBulkUpdatedHilightedInProgressBar(),
					"'Bulk Updated' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatedPage.verifyExportUpdatesLink(), "Export Updates link is displayed");
			sa.assertTrue(bulkUpdatedPage.verifyUnlockBenefitsButton(), "Unlock Benefits button is displayed");
			sa.assertTrue(bulkUpdatedPage.verifySubmitToAdjudication(), "Submit to Adjudication button is displayed");
			bulkUpdatedPage.clickUnlockBenefitsButton();
			bulkUpdatedPage.clickOnYesButton();
			sa.assertTrue(bulkUpdatedPage.verifyUnlockInProgressTextMessage(bulkUpdatePage.getProjectID()),
					"Unlock in Progress message is displayed");
			bulkUpdatedPage.clickOnBackButton();
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "COMPLETED"),
					"Project Status is COMPLETED");
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyCompleteHilightedInProgressBar(),
					"'Complete' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatedPage.verifyCompletedTextMessage(bulkUpdatePage.getProjectID()),
					"Benefit status is 'Completed' in Complete screen");

			bulkUpdatePage.clickExportLink();

			String strCell;
			ExcelFile xlFile4 = new ExcelFile("TestData", "BulkUpdateBenefitsDataSheet.xlsx");
			strCell = xlFile4.OpenWorkBook().OpenWorkSheet("Sheet1").ReadCell(1, 1);
			OneframeLogger("Read Cell by row and column reference - " + strCell);

			sa.assertTrue(bulkUpdateExcel.verifyDownloadedFile("csv"), "Verified FileName is same");
			String fileName = bulkUpdateExcel.getFileName();
			OneframeLogger(fileName);
			bulkUpdateExcel.switchTabs();

			String[] expectedColHeaders = new String[] { "Benefit Plan ID", "Client", "LOB", "State",
					"Version Before Update", "Version After Update", "High Dollar Retail Before Update",
					"High Dollar Retail After Update", "High Dollar Home Delivery Before Update",
					"High Dollar Home Delivery After Update" };

			CSVFile csvFile3 = new CSVFile("RunTime", fileName);
			csvFile3.OpenFile().validateColumnHeaders(expectedColHeaders);

			String version = csvFile3.OpenFile().ReadCell(2, 5);
			String version1 = csvFile3.OpenFile().ReadCell(2, 6);

			Float verFloat = Float.parseFloat(version);
			Float verFloat1 = Float.parseFloat(version1);
			Float versionRem = verFloat1 - verFloat;
			double versionVal = (verFloat + versionRem);
			double roundOff = Math.round(versionVal * 100.0) / 100.0;

			String versionUpdated = String.valueOf(roundOff);
			OneframeLogger("updated" + versionUpdated);

			csvFile3.validateColumn(2, "Benefit Plan ID", strCell);
			csvFile3.validateColumn(2, "Client", ClientId);
			csvFile3.validateColumn(2, "LOB", LOBId);
			csvFile3.validateColumn(2, "State", StateId);
			csvFile3.validateColumn(2, "Version After Update", versionUpdated);
			csvFile3.validateColumn(2, "High Dollar Retail After Update", RetailInput);
			csvFile3.validateColumn(2, "High Dollar Home Delivery After Update", HomeDeliveryInput);

			sa.assertAll();
			gTestResult = RESULT_PASS;

			OneframeLogger("Validated Bulk Update General Default Submit Adjudication values Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Bulk Update General Default Submit Adjudication values");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

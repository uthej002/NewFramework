// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import io.qameta.allure.model.TestResult;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.model.Status;
import io.qameta.allure.model.StepResult;
import io.qameta.allure.listener.TestLifecycleListener;
import io.qameta.allure.listener.StepLifecycleListener;

public class OneframeAllureListener implements StepLifecycleListener, TestLifecycleListener
{
    public static boolean TestStarted;
    
    public void afterStepStart(final StepResult result) {
        OneframeContainer.testLogsArr.clear();
    }
    
    public void afterStepStop(final StepResult result) {
        String base64Screenshot = "";
        try {
            OneframeContainer.OneframeLogger(result.getName() + " -> " + result.getStatus().toString());
            if (result.getStatus().equals((Object)Status.BROKEN) || result.getStatus().equals((Object)Status.FAILED)) {
                base64Screenshot = WebObjectHandler.takeScreenshotOnDemand();
            }
            OneframeContainer.ofReporter.CreateNode(result.getName(), result.getStatus().toString(), base64Screenshot);
        }
        catch (Exception e) {
            OneframeContainer.OneframeLogger("\t[ONEFRAME] Exception occured within allure listener ");
            e.printStackTrace();
        }
    }
    
    public void afterTestStart(final TestResult result) {
        OneframeAllureListener.TestStarted = true;
    }
    
    public void afterTestStop(final TestResult result) {
        try {
            OneframeAllureListener.TestStarted = false;
            if (result.getStatus().equals((Object)Status.PASSED)) {
                OneframeContainer.ofReporter.CompleteTest(com.aventstack.extentreports.Status.PASS, "Test Case - [" + result.getName() + "] Overall Test Status [" + result.getStatus().toString() + "]");
            }
            if (result.getStatus().equals((Object)Status.BROKEN) || result.getStatus().equals((Object)Status.FAILED)) {
                OneframeContainer.ofReporter.CompleteTest(com.aventstack.extentreports.Status.FAIL, "Test Case - [" + result.getName() + "] Overall Test Status [" + result.getStatus().toString() + "]");
            }
        }
        catch (Exception E) {
            OneframeContainer.OneframeLogger("\t[ONEFRAME] Exception occured within allure listener ");
            E.printStackTrace();
        }
    }
    
    static {
        OneframeAllureListener.TestStarted = false;
    }
}

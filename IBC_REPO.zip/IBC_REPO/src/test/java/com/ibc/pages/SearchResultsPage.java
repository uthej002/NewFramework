package com.ibc.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.ibc.base.PageBase;

public class SearchResultsPage extends PageBase {
    // Page Elements
	@FindBy(xpath = "//div[@class='search-results']")
	WebElement txtSearchResults;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()= ' Create a Benefit ']")
	WebElement btnCreateaBenefit;

	@FindBy(xpath = "//h3[text()='Benefit header']")
	WebElement hdrBenefitHeader;

    
    public SearchResultsPage(){
        super();
        PageFactory.initElements(driver, this);
    }

   public void clickCreateABenefitButton() {
	   waitForElementToBeClickable(btnCreateaBenefit);
	   clickElement(btnCreateaBenefit);
   }
   
   public String getResultsCount() {
	   waitForPageLoad();
	   waitForElementToBeVisible(txtSearchResults);
	   return txtSearchResults.getText().trim().toLowerCase().split(" ")[1];
   }
   
   public void verifySearchResultsCount(String expectedCount) {
	   Assert.assertEquals(getResultsCount(), expectedCount, "Expected & Actual are same");
   }
}


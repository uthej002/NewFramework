package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

public class IBPBenefitProgramsPage extends OneframeContainer {

	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//div[contains(text(),'Programs')]")
	WebElement tabPrograms;

	@FindBy(xpath = "//span[text()=' Add Program ']")
	WebElement lnkAddProgram;

	@FindBy(xpath = "//tbody[@role='rowgroup']//tr[@role='row']")
	List<WebElement> lstAddPrograms;

	@FindBy(xpath = "//mat-icon[@svgicon='add']")
	WebElement addProgram;

	@FindBy(xpath = "//div[@class='header__title']")
	WebElement txtAddaProgram;

	@FindBy(xpath = "//tbody[@role='rowgroup']//tr[@role='row']//td[contains(@class, 'mat-column-programName ')]")
	List<WebElement> lstProgramNames;

	@FindBy(xpath = "//span[text()=' Add to benefit ']")
	WebElement btnAddtoBenefit;

	@FindBy(xpath = "//div[text()='Therapeutic Strategies']")
	WebElement SubTabTherapeuticStrategies;

	@FindBy(xpath = "//div[text()='Cost of Care']")
	WebElement SubTabCostofCare;

	@FindBy(xpath = "//h3[text()=' AutoApplyNo ']")
	WebElement hdrAddedProgram;

	@FindBy(xpath = "//span[text()=' Specialty ']")
	WebElement SubTabSpeciality;

	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;

	@FindBy(xpath = "//*[@class='mat-paginator-icon']")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//mat-selection-list[@role='listbox']//mat-list-option[@role='option']/div")
	List<WebElement> lstBenefitPrograms;

	@FindBy(xpath = "//h3[text()='Programs Setup']")
	WebElement hdrProgramsSetup;

	@FindBy(xpath = "//h3[text()=' PENCD ']")
	WebElement btnPENCDProgram;

	@FindBy(xpath = "//mat-icon[@svgicon='x']")
	WebElement btnPENCDExit;

	@FindBy(xpath = "//*[@class='mat-selection-list mat-list-base']/mat-accordion/mat-list-option")
	List<WebElement> lstCostofCarePrograms;

	@FindBy(xpath = "//*[text()=' CATEGORY']")
	WebElement txtCategory;

	@FindBy(xpath = "//tbody['rowgroup']/tr/td[1]")
	List<WebElement> lstSpecialtyProgram;

	@FindBy(xpath = "//*[text()=' Add a Specialty ']")
	WebElement txtAddaSpecialty;

	@FindBy(xpath = "//div[@class='mat-title title' and text()='Programs']")
	WebElement hdrPrograms;

	@FindBy(xpath = "//*[text()='Specialty Details']")
	WebElement btnSpecialtyDetails;

	@FindBy(xpath = "//*[text()='Drug List']")
	WebElement txtDrugList;

	@FindBy(xpath = "//*[text() and normalize-space()=\"Drug List\"]//following::th")
	List<WebElement> txtDrugListValues;
	
	@FindBy(xpath = "//*[@svgicon='down-arrow']")
	WebElement btnDownArrow;

	// Initializing the Page Objects:
	public IBPBenefitProgramsPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on Program Tab")
	public void clickProgramTab() {
		try {
			if (WaitForObjectVisibility(tabPrograms)) {
				ClickWebObject(tabPrograms);
				OneframeLogger("Programs Tab in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Programs Tab in Benefit is not clicked");
		}
	}

	@Step("Click on Add Programs")
	public void clickAddProgramButton() {
		try {
			if (WaitForObjectVisibility(lnkAddProgram)) {
				ClickWebObject(lnkAddProgram);
				OneframeLogger("Add Program in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Program in Benefit is not clicked");
		}
	}

	@Step("Click on Cost of Care Sub Tab")
	public void clickCostofCareSubTab() {
		try {
			if (WaitForObjectVisibility(SubTabCostofCare)) {
				ClickWebObject(SubTabCostofCare);
				OneframeLogger("Cost of Care in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cost of Care in Benefit is not clicked");
		}
	}

	@Step("Click on Speciality Sub Tab")
	public void clickSpecialitySubTab() {
		try {
			if (WaitForObjectVisibility(SubTabSpeciality)) {
				ClickWebObject(SubTabSpeciality);
				OneframeLogger("Speciality in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Speciality in Benefit is not clicked");
		}
	}

	@Step("Click on Therapeutic Sub Tab")
	public void clickTherapeuticSubTab() {
		try {
			if (WaitForObjectVisibility(SubTabTherapeuticStrategies)) {
				ClickWebObject(SubTabTherapeuticStrategies);
				OneframeLogger("Therapeutic Strategies in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Therapeutic Strategies in Benefit is not clicked");
		}
	}

	@Step("Click on Add Program Text")
	public void clickAddaProgram() {
		ClickWebObject(txtAddaProgram);
		ClickWebObject(txtAddaProgram);
		ClickWebObject(txtAddaProgram);
	}

	@Step("Add Specfic Program into the benefit and verify whether it has been added or not")
	public boolean addSpecificProgram(String programName, String subTabName) throws Throwable {
		boolean blnRC = false;
		try {
			String xpath = "//tbody[@role='rowgroup']//tr[@role='row']//td[contains(@class, 'mat-column-programName ')][text()=' "
					+ programName + " ']";
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split(" ");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());

			// Dividing totalRecords by 5 because there are only 5 records per page
			int numberOfPages = Math.round(totalRecords / 5);

			if (numberOfPages != 0) {
				for (int i = 0; i < numberOfPages; i++) {
					try {
						clickAddaProgram();
						WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
						if (WaitForObjectVisibility(ele)) {
							ClickWebObject(ele);
							OneframeLogger("Program is Selected : " + ele.getText());
							break;
						}
					} catch (NoSuchElementException e) {
						ClickWebObject(lstPageTraverseChevronButton.get(1));
						ClickWebObject(txtPageNumber);
						ClickWebObject(txtPageNumber);
						WaitForApplicationToLoadCompletely();
					}

				}

			}
			WaitForApplicationToLoadCompletely();

			WaitForObjectVisibility(btnAddtoBenefit);
			// ClickWebObject(btnAddtoBenefit);
			if (btnAddtoBenefit.isEnabled()) {
				ClickWebObject(btnAddtoBenefit);
			}
			// ClickWebObject(btnAddtoBenefit);
			OneframeLogger("The Auto Apply program has been added to the benefit");

			String element = String.format("//div[normalize-space()='%s']", subTabName);

			WebElement tabName = oneframeDriver.findElement(By.xpath(element));
			WaitForObjectVisibility(tabName);
			ClickWebObject(tabName);
			OneframeLogger("Clicked on " + tabName.getText() + " in the benefit");
			WaitForObjectVisibility(lstBenefitPrograms.get(0));
			ScrollToBottomOfthePage();
			Thread.sleep(5000);
			for (WebElement ele : lstBenefitPrograms) {
				if (programName.equalsIgnoreCase(ele.getText())) {
					ClickWebObject(ele);
					OneframeLogger("The Program which has been added to the benefit :" + ele.getText());
					WebElement hdrAddedProgram = oneframeDriver.findElement(By.xpath("//div[@class='title']"));
					WaitForObjectVisibility(hdrAddedProgram);
					highlightElement(hdrAddedProgram);
					blnRC = true;
				}
			}
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Add any Program into the benefit and verify whether it has been added or not")
	public boolean addRandomProgram(String subTabName) throws Throwable {
		Thread.sleep(5000);
		ClickWebObject(txtAddaProgram);
		ClickWebObject(txtAddaProgram);
		boolean blnRC = false;
		try {
			WaitForObjectVisibility(lstProgramNames.get(0));
			ClickWebObject(lstProgramNames.get(0));
			String value = lstProgramNames.get(0).getText();
			OneframeLogger("Program is Selected : " + value);
			// WaitForObjectVisibility(btnAddtoBenefit);
			ClickWebObject(txtAddaProgram);
			ClickWebObject(txtAddaProgram);
			// ClickWebObject(btnAddtoBenefit);
			if (btnAddtoBenefit.isEnabled()) {
				ClickWebObject(btnAddtoBenefit);
			}
			OneframeLogger("The Auto Apply program has been added to the benefit");
			ClickWebObject(hdrProgramsSetup);
			ClickWebObject(hdrProgramsSetup);
			ClickWebObject(hdrProgramsSetup);

			String element = String.format("//div[normalize-space()='%s']", subTabName);

			WebElement tabName = oneframeDriver.findElement(By.xpath(element));
			WaitForObjectVisibility(tabName);
			ClickWebObject(tabName);
			OneframeLogger("Clicked on " + tabName.getText() + " in the benefit");
			Thread.sleep(3000);
			WaitForObjectVisibility(lstBenefitPrograms.get(0));
			for (WebElement ele : lstBenefitPrograms) {
				if (value.equalsIgnoreCase(ele.getText())) {
					ClickWebObject(ele);
					OneframeLogger("The Program which has been added to the benefit :" + ele.getText());
					WebElement hdrAddedProgram = oneframeDriver.findElement(By.xpath("//div[@class='title']"));
					WaitForObjectVisibility(hdrAddedProgram);
					highlightElement(hdrAddedProgram);
					blnRC = true;
				}
			}
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Add Specfic Cost of Care Program into the benefit and verify whether it has been added or not")
	public boolean addSpecificCostofCareProgram(String programName) throws Throwable {
		Thread.sleep(5000);
		boolean blnRC = false;
		try {
			ClickWebObject(txtAddaProgram);
			String element = String.format(
					"//tbody[@role='rowgroup']//tr[@role='row']//td[contains(@class, 'mat-column-programName ') and text()=' %s ']",
					programName);
			WebElement addprogram = oneframeDriver.findElement(By.xpath(element));
			if (WaitForObjectVisibility(addprogram)) {
				ClickWebObject(addprogram);
				Thread.sleep(5000);
				OneframeLogger("The Auto Apply as 'No' program has been selected for the benefit");
//			ClickWebObject(lstAddPrograms.get(0));
				WaitForObjectVisibility(btnAddtoBenefit);
				ClickWebObject(btnAddtoBenefit);
				OneframeLogger("The Auto Apply as 'No' program has been added to the benefit");
				clickCostofCareSubTab();
				OneframeLogger("Clicked on Cost of Care in the benefit");
				Thread.sleep(3000);
				blnRC = true;
//			String elementone = String.format(
//					"//mat-selection-list[@role='listbox']//mat-list-option[@role='option']//div[text()=' %s ']",
//					programName);
//			WebElement addedprogram = oneframeDriver.findElement(By.xpath(elementone));
//			WaitForObjectVisibility(addedprogram);
//			OneframeLogger("The Program which has been added to the benefit :"+addedprogram.getText());
//			ClickWebObject(addedprogram);		
//			String elementtwo = String.format("//h3[text()=' %s ']", programName);
//			WebElement hdrAddedProgram = oneframeDriver.findElement(By.xpath(elementtwo));
//			if (programName.equalsIgnoreCase(hdrAddedProgram.getText())) {
//				blnRC = true;
//			}
//			}
			}
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether Program is not displayed when Auto Apply as No while creating the benefit")
	public boolean verifyProgramNotDisplay() {
		boolean blnRC = false;
		try {
			if (FindObjectByLocatorNoWait(
					By.xpath("//div[@class='left-panel']//mat-selection-list[@role='listbox']")) != null) {
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify and Click on PENCD Program")
	public boolean clickonPENCDProgram() {
		boolean bln = false;
		if (ObjectExist(btnPENCDProgram)) {
			btnPENCDProgram.click();
			OneframeLogger("PENCD Program button is clicked");
			bln = true;
		}
		return bln;
	}

	@Step("Click on PENCD Program close button")
	public boolean clickonPENCDExitbtn() {
		boolean bln = false;
		if (ObjectExist(btnPENCDExit)) {
			btnPENCDExit.click();
			OneframeLogger("PENCD Program Close button is clicked");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Pencd Program under Cost of care Tab is present or not")
	public boolean verifyPencdProgramRemoved() {
		boolean bln = true;
		for (int i = 0; i < lstCostofCarePrograms.size(); i++) {
			if (lstCostofCarePrograms.get(i).getText().contains("PENCD")) {
				OneframeLogger("PENCD Program is present under Cost of care Tab ");
				bln = false;
				break;
			}

		}

		return bln;
	}

	public boolean verifyPriority(String programName, String expectedPriority) {
		boolean flg = false;

		String xpath = "//h3[contains(text(), '" + programName
				+ "')]/../following-sibling::form//input[@formcontrolname='priorityOrder']";
		WebElement actualPriority = oneframeDriver.findElement(By.xpath(xpath));

		if (WaitForObject(actualPriority)) {
			highlightElement(actualPriority);
			if (actualPriority.getAttribute("value").trim().equalsIgnoreCase(expectedPriority)) {
				flg = true;
			}

		} else {
			flg = false;
		}

		return flg;
	}

	public boolean verifyModifiedStrategyValue(String programName, String strategy, String value) {
		boolean flg = false;

		String xpath = "//h3[contains(text(), '" + programName + "')]//../..//small[contains(text(), '" + strategy
				+ "')]/following-sibling::strong";
		WebElement actualValue = oneframeDriver.findElement(By.xpath(xpath));
		//String expectedValue = (value.equalsIgnoreCase("false")) ? "no" : "yes";
		String actualVal = (actualValue.getText().trim().equalsIgnoreCase("No")) ? "false" : "true";

		if (WaitForObject(actualValue)) {
			highlightElement(actualValue);
			if (actualVal.equalsIgnoreCase(value)) {
				flg = true;
			}
		} else {
			flg = false;
		}

		return flg;
	}

	@Step("Validate and CLick on given Cost of care Program")
	public boolean validateAndClickCostOfCareProgram(String programName) {
		boolean flg = false;

		String xpath = "//div[text()=' " + programName + " ']";
		WebElement expectedHeader = oneframeDriver.findElement(By.xpath(xpath));

		if (WaitForObject(expectedHeader)) {
			highlightElement(expectedHeader);
			flg = true;
		} else {
			flg = false;
		}

		return flg;
	}

	@Step("Verify Compound Program is displayed from the Threapeutic Strategy")
	public boolean verifyCompoundCoverageOption(String value) {
		ClickWebObject(hdrProgramsSetup);
		ClickWebObject(hdrProgramsSetup);
		ClickWebObject(hdrProgramsSetup);
		boolean blnRC = false;
		try {
			String elementone = "//mat-selection-list[@role='listbox']//mat-list-option[@role='option']//div[text()=' Compounds ']";
			WebElement addedprogram = oneframeDriver.findElement(By.xpath(elementone));
			WaitForObjectVisibility(addedprogram);
			ClickWebObject(addedprogram);
			String elementtwo = "//h3[text()=' Compounds ']";
			WebElement header = oneframeDriver.findElement(By.xpath(elementtwo));
			WaitForObjectVisibility(header);
			highlightElement(header);
			String elementthree = String.format("//tbody[@role='rowgroup']/tr/td/following::td[text()=' %s ']", value);
			WebElement coverageOption = oneframeDriver.findElement(By.xpath(elementthree));
			WaitForObjectVisibility(coverageOption);
			highlightElement(coverageOption);
			if (coverageOption.getText().equalsIgnoreCase(value)) {
				blnRC = true;
			} else {
				blnRC = false;
			}

		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Required Compound Program is displayed from the Threapeutic Strategy")
	public boolean verifyCompoundProgramDisplay(String programName) {
		ClickWebObject(hdrProgramsSetup);
		ClickWebObject(hdrProgramsSetup);
		ClickWebObject(hdrProgramsSetup);
		boolean blnRC = false;
		try {
			String elementone = String.format(
					"//mat-selection-list[@role='listbox']//mat-list-option[@role='option']//div[text()=' %s ']",
					programName);
			WebElement addedprogram = oneframeDriver.findElement(By.xpath(elementone));
			WaitForObjectVisibility(addedprogram);
			if (addedprogram.getText().equalsIgnoreCase(programName)) {
				highlightElement(addedprogram);
				blnRC = true;
			} else {
				blnRC = false;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on first Specialty Program")
	public void clickonFirstSpecialtyProgram() throws InterruptedException {
		try {
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			Thread.sleep(3000);

			if (WaitForObject(lstSpecialtyProgram.get(0))) {
				ClickWebObject(lstSpecialtyProgram.get(0));
				OneframeLogger("Clicked on First Specialty Program");
			}
		} catch (TimeoutException e) {
			OneframeLogger("First Specialty Program is not Clicked");
		}
	}

	
	@Step("Click on existing Specialty Program")
	public void clickonExistingSpecialtyProgram() throws InterruptedException {
		try {
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			Thread.sleep(3000);

			if (WaitForObjectVisibility(lstSpecialtyProgram.get(1))) {
				ClickWebObject(lstSpecialtyProgram.get(1));
				OneframeLogger("Clicked on existing Specialty Program");
			}
		} catch (TimeoutException e) {
			OneframeLogger("existing Specialty Program is not Clicked");
		}
	}
	
	@Step("Verify {specialDetails} labels is displayed")
	public void verifySpecialDetailslabelsAreDisplayed(String specialDetails) {

		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()=\"%s\"]", specialDetails)));

		ScrollToElement(expectedHeader);

		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to validate Special Details labels");
		}
		sa.assertEquals(expectedHeader.getText(), specialDetails, "Validated Label is : " + specialDetails);
	}

	@Step("Verify {specialDetails} labels is displayed")
	public void verifySpecialtyDetailslabels(String specialDetails) {

		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()=\"%s\"]", specialDetails)));

		ScrollToElement(expectedHeader);

		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to validate Special Details labels");
		}
		sa.assertEquals(expectedHeader.getText(), specialDetails, "Validated Label is : " + specialDetails);
	}

	@Step("Verify {generalTab} labels is displayed")
	public void verifyGeneralTablabelsAreDisplayed(String generalTab) {
		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()=\"%s\"]", generalTab)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to validate Special Details labels");
		}
		sa.assertEquals(expectedHeader.getText(), generalTab, "Validated Label is : " + generalTab);
	}

	@Step("Click on Specialty Details")
	public void clickonSpecialtyDetails() throws InterruptedException {

		ClickWebObject(btnSpecialtyDetails);
		ClickWebObject(btnSpecialtyDetails);
		ClickWebObject(btnSpecialtyDetails);

		OneframeLogger("Specialty Details button is Clicked");
	}

	@Step("Click on Drug List Header")
	public void clickonDruglisthdr() throws InterruptedException {

		ClickWebObject(txtDrugList);
		ClickWebObject(txtDrugList);
		ClickWebObject(txtDrugList);

		OneframeLogger("Drug List Text is Clicked");
	}

	@Step("Verify Drug list Values on Specialty Details Tab")
	public void verifyDescriptionSpecialtyDetailsTab(String Desc) throws InterruptedException {

		if (WaitForObjectVisibility(txtDrugListValues.get(3))) {
			highlightElement(txtDrugListValues.get(3));
			sa.assertEquals(txtDrugListValues.get(3).getText(), Desc, "Validated Label is : " + Desc);
		}

	}
	
	@Step("Verify Drug list Values on Specialty Details Tab")
	public void verifyEffectiveDateSpecialtyDetailsTab(String effDt) throws InterruptedException {
		if (WaitForObjectVisibility(txtDrugListValues.get(6))) {
			highlightElement(txtDrugListValues.get(6));
			sa.assertEquals(txtDrugListValues.get(6).getText(), effDt, "Validated Label is : " + effDt);
		}
	}
	
	
	@Step("Verify Drug list Values on Specialty Details Tab")
	public void verifyTermDateSpecialtyDetailsTab(String termDt) throws InterruptedException {

		if (WaitForObjectVisibility(txtDrugListValues.get(7))) {
			highlightElement(txtDrugListValues.get(7));
			sa.assertEquals(txtDrugListValues.get(7).getText(), termDt, "Validated Label is : " + termDt);
		}

	}
	
	
	@Step("Click Down Arrow button of Specialty Program")
	public void clickDownArrowButton() {
		try {
			if (WaitForObject(btnDownArrow)) {
				ClickWebObject(btnDownArrow);

				OneframeLogger("Clicked on Down Arrow button of Specialty Program");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Down Arrow button of Specialty Program is not Clicked");
		}
	}
	
	@Step("Verify {networkTab} labels is displayed")
	public void verifyNetworkTablabelsAreDisplayed(String networkTab) {
		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()=\"%s\"]", networkTab)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to validate Network Tab labels");
		}
		sa.assertEquals(expectedHeader.getText(), networkTab, "Validated Label is : " + networkTab);
	}
	
	@Step("Verify {costSharesTab} labels is displayed")
	public void verifyCostShareslabelsAreDisplayed(String costSharesTab) {
		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()=\"%s\"]", costSharesTab)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to validate Cost Share Tab labels");
		}
		sa.assertEquals(expectedHeader.getText(), costSharesTab, "Validated Label is : " + costSharesTab);
	}

	@Step("Verify {accumTab} labels is displayed")
	public void verifyAccumTablabelsAreDisplayed(String accumTab) {
		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()=\"%s\"]", accumTab)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to validate Network Tab labels");
		}
		sa.assertEquals(expectedHeader.getText(), accumTab, "Validated Label is : " + accumTab);
	}
	
	@Step("Click on existing Cost of Care Program")
	public void clickonExistingCostofCareProgram() throws InterruptedException {
		try {
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			Thread.sleep(1500);

			if (WaitForObject(lstSpecialtyProgram.get(1))) {
				ClickWebObject(lstSpecialtyProgram.get(1));
				OneframeLogger("Clicked on existing Cost of care Program");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Existing Cost of care Program is not Clicked");
		}
	}
	
	
	@Step("Click on existing Therapeutic Program")
	public void clickonExistingTherapeuticProgram() throws InterruptedException {
		try {
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			ClickWebObject(hdrPrograms);
			Thread.sleep(1500);

			if (WaitForObject(lstSpecialtyProgram.get(4))) {
				ClickWebObject(lstSpecialtyProgram.get(4));
				OneframeLogger("Clicked on existing Therapeutic Program");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Existing Therapeutic Program is not Clicked");
		}
	}

}

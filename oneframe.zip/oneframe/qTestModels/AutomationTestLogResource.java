// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class AutomationTestLogResource
{
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("test_case_version_id")
    private Long testCaseVersionId;
    @JsonProperty("exe_start_date")
    private String exeStartDate;
    @JsonProperty("exe_end_date")
    private String exeEndDate;
    @JsonProperty("note")
    private String note;
    @JsonProperty("attachments")
    private List<AttachmentResource> attachments;
    @JsonProperty("name")
    private String name;
    @JsonProperty("planned_exe_time")
    private Long plannedExeTime;
    @JsonProperty("actual_exe_time")
    private Long actualExeTime;
    @JsonProperty("build_number")
    private String buildNumber;
    @JsonProperty("build_url")
    private String buildUrl;
    @JsonProperty("properties")
    private List<PropertyResource> properties;
    @JsonProperty("system_name")
    private String systemName;
    @JsonProperty("status")
    private String status;
    @JsonProperty("order")
    private Long order;
    @JsonProperty("test_step_logs")
    private List<AutomationTestStepLog> testStepLogs;
    @JsonProperty("module_names")
    private List<String> moduleNames;
    @JsonProperty("agent_ids")
    private List<Long> agentIds;
    @JsonProperty("automation_content")
    private String automationContent;
    @JsonProperty("tosca_guid")
    private String toscaGuid;
    @JsonProperty("tosca_node_path")
    private String toscaNodePath;
    
    public AutomationTestLogResource() {
        this.links = new ArrayList<Link>();
        this.id = null;
        this.testCaseVersionId = null;
        this.exeStartDate = null;
        this.exeEndDate = null;
        this.note = null;
        this.attachments = new ArrayList<AttachmentResource>();
        this.name = null;
        this.plannedExeTime = null;
        this.actualExeTime = null;
        this.buildNumber = null;
        this.buildUrl = null;
        this.properties = new ArrayList<PropertyResource>();
        this.systemName = null;
        this.status = null;
        this.order = null;
        this.testStepLogs = new ArrayList<AutomationTestStepLog>();
        this.moduleNames = new ArrayList<String>();
        this.agentIds = new ArrayList<Long>();
        this.automationContent = null;
        this.toscaGuid = null;
        this.toscaNodePath = null;
    }
    
    public AutomationTestLogResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public AutomationTestLogResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public AutomationTestLogResource id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public AutomationTestLogResource testCaseVersionId(final Long testCaseVersionId) {
        this.testCaseVersionId = testCaseVersionId;
        return this;
    }
    
    public Long getTestCaseVersionId() {
        return this.testCaseVersionId;
    }
    
    public void setTestCaseVersionId(final Long testCaseVersionId) {
        this.testCaseVersionId = testCaseVersionId;
    }
    
    public AutomationTestLogResource exeStartDate(final String exeStartDate) {
        this.exeStartDate = exeStartDate;
        return this;
    }
    
    public String getExeStartDate() {
        return this.exeStartDate;
    }
    
    public void setExeStartDate(final String exeStartDate) {
        this.exeStartDate = exeStartDate;
    }
    
    public AutomationTestLogResource exeEndDate(final String exeEndDate) {
        this.exeEndDate = exeEndDate;
        return this;
    }
    
    public String getExeEndDate() {
        return this.exeEndDate;
    }
    
    public void setExeEndDate(final String exeEndDate) {
        this.exeEndDate = exeEndDate;
    }
    
    public AutomationTestLogResource note(final String note) {
        this.note = note;
        return this;
    }
    
    public String getNote() {
        return this.note;
    }
    
    public void setNote(final String note) {
        this.note = note;
    }
    
    public AutomationTestLogResource attachments(final List<AttachmentResource> attachments) {
        this.attachments = attachments;
        return this;
    }
    
    public AutomationTestLogResource addAttachmentsItem(final AttachmentResource attachmentsItem) {
        this.attachments.add(attachmentsItem);
        return this;
    }
    
    public List<AttachmentResource> getAttachments() {
        return this.attachments;
    }
    
    public void setAttachments(final List<AttachmentResource> attachments) {
        this.attachments = attachments;
    }
    
    public AutomationTestLogResource name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public AutomationTestLogResource plannedExeTime(final Long plannedExeTime) {
        this.plannedExeTime = plannedExeTime;
        return this;
    }
    
    public Long getPlannedExeTime() {
        return this.plannedExeTime;
    }
    
    public void setPlannedExeTime(final Long plannedExeTime) {
        this.plannedExeTime = plannedExeTime;
    }
    
    public AutomationTestLogResource actualExeTime(final Long actualExeTime) {
        this.actualExeTime = actualExeTime;
        return this;
    }
    
    public Long getActualExeTime() {
        return this.actualExeTime;
    }
    
    public void setActualExeTime(final Long actualExeTime) {
        this.actualExeTime = actualExeTime;
    }
    
    public AutomationTestLogResource buildNumber(final String buildNumber) {
        this.buildNumber = buildNumber;
        return this;
    }
    
    public String getBuildNumber() {
        return this.buildNumber;
    }
    
    public void setBuildNumber(final String buildNumber) {
        this.buildNumber = buildNumber;
    }
    
    public AutomationTestLogResource buildUrl(final String buildUrl) {
        this.buildUrl = buildUrl;
        return this;
    }
    
    public String getBuildUrl() {
        return this.buildUrl;
    }
    
    public void setBuildUrl(final String buildUrl) {
        this.buildUrl = buildUrl;
    }
    
    public AutomationTestLogResource properties(final List<PropertyResource> properties) {
        this.properties = properties;
        return this;
    }
    
    public AutomationTestLogResource addPropertiesItem(final PropertyResource propertiesItem) {
        this.properties.add(propertiesItem);
        return this;
    }
    
    public List<PropertyResource> getProperties() {
        return this.properties;
    }
    
    public void setProperties(final List<PropertyResource> properties) {
        this.properties = properties;
    }
    
    public AutomationTestLogResource systemName(final String systemName) {
        this.systemName = systemName;
        return this;
    }
    
    public String getSystemName() {
        return this.systemName;
    }
    
    public void setSystemName(final String systemName) {
        this.systemName = systemName;
    }
    
    public AutomationTestLogResource status(final String status) {
        this.status = status;
        return this;
    }
    
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(final String status) {
        this.status = status;
    }
    
    public AutomationTestLogResource order(final Long order) {
        this.order = order;
        return this;
    }
    
    public Long getOrder() {
        return this.order;
    }
    
    public void setOrder(final Long order) {
        this.order = order;
    }
    
    public AutomationTestLogResource testStepLogs(final List<AutomationTestStepLog> testStepLogs) {
        this.testStepLogs = testStepLogs;
        return this;
    }
    
    public AutomationTestLogResource addTestStepLogsItem(final AutomationTestStepLog testStepLogsItem) {
        this.testStepLogs.add(testStepLogsItem);
        return this;
    }
    
    public List<AutomationTestStepLog> getTestStepLogs() {
        return this.testStepLogs;
    }
    
    public void setTestStepLogs(final List<AutomationTestStepLog> testStepLogs) {
        this.testStepLogs = testStepLogs;
    }
    
    public AutomationTestLogResource moduleNames(final List<String> moduleNames) {
        this.moduleNames = moduleNames;
        return this;
    }
    
    public AutomationTestLogResource addModuleNamesItem(final String moduleNamesItem) {
        this.moduleNames.add(moduleNamesItem);
        return this;
    }
    
    public List<String> getModuleNames() {
        return this.moduleNames;
    }
    
    public void setModuleNames(final List<String> moduleNames) {
        this.moduleNames = moduleNames;
    }
    
    public AutomationTestLogResource agentIds(final List<Long> agentIds) {
        this.agentIds = agentIds;
        return this;
    }
    
    public AutomationTestLogResource addAgentIdsItem(final Long agentIdsItem) {
        this.agentIds.add(agentIdsItem);
        return this;
    }
    
    public List<Long> getAgentIds() {
        return this.agentIds;
    }
    
    public void setAgentIds(final List<Long> agentIds) {
        this.agentIds = agentIds;
    }
    
    public AutomationTestLogResource automationContent(final String automationContent) {
        this.automationContent = automationContent;
        return this;
    }
    
    public String getAutomationContent() {
        return this.automationContent;
    }
    
    public void setAutomationContent(final String automationContent) {
        this.automationContent = automationContent;
    }
    
    public AutomationTestLogResource toscaGuid(final String toscaGuid) {
        this.toscaGuid = toscaGuid;
        return this;
    }
    
    public String getToscaGuid() {
        return this.toscaGuid;
    }
    
    public void setToscaGuid(final String toscaGuid) {
        this.toscaGuid = toscaGuid;
    }
    
    public AutomationTestLogResource toscaNodePath(final String toscaNodePath) {
        this.toscaNodePath = toscaNodePath;
        return this;
    }
    
    public String getToscaNodePath() {
        return this.toscaNodePath;
    }
    
    public void setToscaNodePath(final String toscaNodePath) {
        this.toscaNodePath = toscaNodePath;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final AutomationTestLogResource automationTestLogResource = (AutomationTestLogResource)o;
        return Objects.equals(this.links, automationTestLogResource.links) && Objects.equals(this.id, automationTestLogResource.id) && Objects.equals(this.testCaseVersionId, automationTestLogResource.testCaseVersionId) && Objects.equals(this.exeStartDate, automationTestLogResource.exeStartDate) && Objects.equals(this.exeEndDate, automationTestLogResource.exeEndDate) && Objects.equals(this.note, automationTestLogResource.note) && Objects.equals(this.attachments, automationTestLogResource.attachments) && Objects.equals(this.name, automationTestLogResource.name) && Objects.equals(this.plannedExeTime, automationTestLogResource.plannedExeTime) && Objects.equals(this.actualExeTime, automationTestLogResource.actualExeTime) && Objects.equals(this.buildNumber, automationTestLogResource.buildNumber) && Objects.equals(this.buildUrl, automationTestLogResource.buildUrl) && Objects.equals(this.properties, automationTestLogResource.properties) && Objects.equals(this.systemName, automationTestLogResource.systemName) && Objects.equals(this.status, automationTestLogResource.status) && Objects.equals(this.order, automationTestLogResource.order) && Objects.equals(this.testStepLogs, automationTestLogResource.testStepLogs) && Objects.equals(this.moduleNames, automationTestLogResource.moduleNames) && Objects.equals(this.agentIds, automationTestLogResource.agentIds) && Objects.equals(this.automationContent, automationTestLogResource.automationContent) && Objects.equals(this.toscaGuid, automationTestLogResource.toscaGuid) && Objects.equals(this.toscaNodePath, automationTestLogResource.toscaNodePath);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links, this.id, this.testCaseVersionId, this.exeStartDate, this.exeEndDate, this.note, this.attachments, this.name, this.plannedExeTime, this.actualExeTime, this.buildNumber, this.buildUrl, this.properties, this.systemName, this.status, this.order, this.testStepLogs, this.moduleNames, this.agentIds, this.automationContent, this.toscaGuid, this.toscaNodePath);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class AutomationTestLogResource {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    testCaseVersionId: ").append(this.toIndentedString(this.testCaseVersionId)).append("\n");
        sb.append("    exeStartDate: ").append(this.toIndentedString(this.exeStartDate)).append("\n");
        sb.append("    exeEndDate: ").append(this.toIndentedString(this.exeEndDate)).append("\n");
        sb.append("    note: ").append(this.toIndentedString(this.note)).append("\n");
        sb.append("    attachments: ").append(this.toIndentedString(this.attachments)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    plannedExeTime: ").append(this.toIndentedString(this.plannedExeTime)).append("\n");
        sb.append("    actualExeTime: ").append(this.toIndentedString(this.actualExeTime)).append("\n");
        sb.append("    buildNumber: ").append(this.toIndentedString(this.buildNumber)).append("\n");
        sb.append("    buildUrl: ").append(this.toIndentedString(this.buildUrl)).append("\n");
        sb.append("    properties: ").append(this.toIndentedString(this.properties)).append("\n");
        sb.append("    systemName: ").append(this.toIndentedString(this.systemName)).append("\n");
        sb.append("    status: ").append(this.toIndentedString(this.status)).append("\n");
        sb.append("    order: ").append(this.toIndentedString(this.order)).append("\n");
        sb.append("    testStepLogs: ").append(this.toIndentedString(this.testStepLogs)).append("\n");
        sb.append("    moduleNames: ").append(this.toIndentedString(this.moduleNames)).append("\n");
        sb.append("    agentIds: ").append(this.toIndentedString(this.agentIds)).append("\n");
        sb.append("    automationContent: ").append(this.toIndentedString(this.automationContent)).append("\n");
        sb.append("    toscaGuid: ").append(this.toIndentedString(this.toscaGuid)).append("\n");
        sb.append("    toscaNodePath: ").append(this.toIndentedString(this.toscaNodePath)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

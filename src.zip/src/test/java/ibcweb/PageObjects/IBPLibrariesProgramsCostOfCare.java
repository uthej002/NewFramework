package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPLibrariesProgramsCostOfCare extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(css = "div[aria-label=general]")
	WebElement generalTab;
	
	@FindBy(css = "div[aria-label=networks]")
	WebElement networkTab;
	
	@FindBy(css = "button.info__add-btn")
	WebElement addExceptionNetworksButton;
	
	@FindBy(xpath = "//div[@class='footer']//span[normalize-space()='Cancel']/..")
	WebElement cancelButton;
	
	@FindBy(xpath = "//div[@class='footer']//span[normalize-space()='Add Network']/..")
	WebElement addNetworkButton;
	
	@FindBy(css = "input[placeholder=Search]")
	WebElement searchBar;
	
	@FindBy(css = "mat-slide-toggle[data-automation-id='specificNetworksPrograms']")
	WebElement specificNetworksToggle;

	// Initializing the Page Objects:
	public IBPLibrariesProgramsCostOfCare() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on General Tab")
	public boolean clickGeneralTab() {
		try {
			if(WaitForObjectVisibility(generalTab)) {
				ClickWebObject(generalTab);
				OneframeLogger("Clicked on General Tab");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on general tab: " +e);
		}
		
		return false;
	}
	
	@Step("Click on Networks Tab")
	public boolean clickNetworksTab() {
		try {
			if(WaitForObjectVisibility(networkTab)) {
				ClickWebObject(networkTab);
				OneframeLogger("Clicked on Networks Tab");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Networks tab: " +e);
		}
		
		return false;
	}

	@Step("Validate text {string} is displayed")
	public boolean validateTextIsDisplayed(String string) {
		
		try {
			WaitForApplicationToLoadCompletely();
			String xpath = String.format("//*[text() and normalize-space()='%s']", string);
			WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
			
			if(ele.isDisplayed()) {
				highlightElement(ele);
				sa.assertEquals(ele.getText().trim(), string, "Validate Actual Text matches with Expected Text");
				return true;
			}
			
			
		} catch (Exception e) {
			OneframeLogger("Actual Text and Expected Text did not match");
		}
		return false;
	}
	
	@Step("Validate text {string} is displayed {timesDisplayed} times")
	public boolean validateTextIsDisplayed(String string, int timesDisplayed) {
		
		try {
			String xpath = String.format("//*[text() and normalize-space()='%s']", string);
			List<WebElement> headers = oneframeDriver.findElements(By.xpath(xpath));
			
			if(headers.size() == timesDisplayed) {
				for(WebElement ele: headers) {
					if(!ele.isDisplayed()) {
						return false;
					}
					else {
						highlightElement(ele);
						sa.assertEquals(ele.getText().trim(), string, "Validate Actual Text matches with Expected Text");
					}
				}	
				return true;
			}
						
		} catch (Exception e) {
			OneframeLogger("Actual Text and Expected Text did not match: " +e);
		}
		return false;
	}

	@Step("Click on Add Exception Networks")
	public boolean clickAddExceptionNetowrks() {
		try {
			if(WaitForObjectVisibility(addExceptionNetworksButton)) {
				highlightElement(addExceptionNetworksButton);
				ClickWebObject(addExceptionNetworksButton);
				OneframeLogger("Clicked on Add Exception Networks button");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Add Exception Networks button");
		}
		return false;
	}
	
	@Step("Select Network {network}")
	public boolean selectNetwork(String network) {
		
		try {
			String xpath = String.format("//tr/td[normalize-space()='%s']", network);
			ClickWebObject(searchBar);
			ClickWebObject(searchBar);
			ClickWebObject(searchBar);
			WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
			ClickWebObject(ele);
			OneframeLogger("Clicked on network " +network);
			if(addNetworkButton.isEnabled()) {
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on network " +network);
		}
		
		return false;
	}
	
	@Step("Click on Add Button")
	public boolean clickAddNetwork() {
		
		try {
			if(WaitForObjectVisibility(addNetworkButton)) {
				ClickWebObject(addNetworkButton);
				OneframeLogger("Clicked on Add Network Button");
				Thread.sleep(2000);
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Add Network Button");
		}
		
		return false;
	}
	
	@Step("Click Specific Networks Toggle")
	public boolean clickSpecificNetworksToggle() {
		
		try {
			if(WaitForObjectVisibility(specificNetworksToggle)) {
				ClickWebObject(specificNetworksToggle);
				OneframeLogger("Click on Specific Networks Toggle");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Specific Networks Toggle");
		}
		
		return false;
	}
}

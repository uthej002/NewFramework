package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateStartDateandEndDatewithInvalidData extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for Validating StartDate and End Date With Invalid Data")
	public void setUp() {
		InitializeLaunchPad("IBPW_15");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "RuleName", "Description", "Message", "StartDate",
				"EndDate","ClientId", "LOBId", "StateId", "DType" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate Start Date and End Date for Creating a rule", dataProvider = "TestData")
	@Description("validate Start Date and End Date for Creating a rule")
	public void ValidateDateValidations(String TestCaseID, String TestStatus, String RuleName, String Description,
			String Message, String StartDate, String EndDate, String ClientId, String LOBId, String StateId, String DType) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();
			addrulepage.verifyCreateaRuleHeader();
			OneframeLogger("Verifying whether the Add Rule button is disabled when Start Date or End Date is invalid");
			addrulepage.EnterRuleName(RuleName);
			addrulepage.EnterDescription(Description);
			addrulepage.EnterMessage(Message);
			addrulepage.EnterStartDate(StartDate);
			addrulepage.EnterEndDate(EndDate);
			addrulepage.selectClientIdDropdown(ClientId);
			addrulepage.selectLobIdDropdown(LOBId);
			addrulepage.selectStateIdDropdown(StateId);
			addrulepage.selectDecisionTypeDropdown(DType);
		
			sa.assertTrue(addrulepage.verifyAddRuleButtonisDisabled(), "Verified Add Rule Button is disabled");

			gTestResult = RESULT_PASS;
			
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger(" Start Date and End Date Validation for Creating a rule  is unsuccessful");
		}

		sa.assertAll();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

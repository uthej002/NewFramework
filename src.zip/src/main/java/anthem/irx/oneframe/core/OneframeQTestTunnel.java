package anthem.irx.oneframe.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class OneframeQTestTunnel {
  String ofRAresponseContent;
  
  public OneframeQTestTunnel(String qTestProject) {
    RestAssured.baseURI = "https://qtest.ingenio-rx.com:8443/";
    Header authHeader = new Header("Authorization", "bearer 3ae7b9d8-4d13-4d11-8680-bb01338d97ce");
    Header AcceptTypeHeader = new Header("Accept-Type", "application/json");
    Header ContentTypeHeader = new Header("Content-Type", "application/json");
    Headers qTestheaders = new Headers(new Header[] { authHeader, AcceptTypeHeader, ContentTypeHeader });
    RequestSpecification ofRArequest = RestAssured.given().relaxedHTTPSValidation();
    ofRArequest.headers(qTestheaders);
    Response ofRAresponse = (Response)ofRArequest.request(Method.GET, "/api/v3/projects", new Object[0]);
    System.out.println("Response Code : " + ofRAresponse.getStatusCode());
    ofRAresponse.prettyPeek();
    this.ofRAresponseContent = ofRAresponse.getBody().asString();
    ObjectMapper qtresMapper = new ObjectMapper();
  }
}

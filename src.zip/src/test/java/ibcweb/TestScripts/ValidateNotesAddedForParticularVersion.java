package ibcweb.TestScripts;

import static anthem.irx.oneframe.core.OneframeContainer.OneframeLogger;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.CSVFile;
import anthem.irx.oneframe.utilities.ExcelFile;
import ibcweb.PageObjects.IBPBenefitDetailsPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBulkUpdateBulkUpdatedPage;
import ibcweb.PageObjects.IBPBulkUpdatePage;
import ibcweb.PageObjects.IBPBulkUpdateReviewPage;
import ibcweb.PageObjects.IBPBulkUpdateWorkInProgressPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class ValidateNotesAddedForParticularVersion extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPBenefitDetailsPage details;

	@BeforeClass
	@Step("Initializing Test Script for validating Butterscotch App Login")
	public void setUp() {
		InitializeLaunchPad("IBPW_867");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		details = new IBPBenefitDetailsPage();
	}

	@DataProvider(name = "LoginTestData")
	public Object[][] getLoginTestDataTestData() {

		String[] fieldNames = {"TestCaseID", "TestStatus", "Benefit", "Status" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Notes added for previous version", dataProvider = "LoginTestData")
	@Description("Validate Notes added for previous version")
	public void ValidateNotesAddedInReviewScreen(String TestCaseID, String TestStatus, String Benefit, String Status) throws InterruptedException, IOException {
	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
		//	benefitpage.clickSearchResults();
		//	sa.assertTrue(details.verifyAndClickBenefitWithInProgressStatus(Status),
		//			"Verified and clicked Benefit status in In-Progress");
			String prevNotes = details.getNotes();
			benefitpage.clickEditButton();
			sa.assertTrue(createbenefitpage.CheckVerifyButtonisDisplayed(), "Verified the Verify Button is displayed");
			sa.assertTrue(details.verifyHistoryAndDocumentHeader(),
					"Verified History and documentation header is displayed");
			sa.assertTrue(details.verifyNotesHeader(), "Verified Notes header is displayed");
			String enteredNotes = details.verifyAndEnterNotes();
			benefitpage.clickCloseButton();
			benefitpage.clickSaveandExitButton();
			details.verifyNotesValue(enteredNotes);
			benefitpage.clickVersionDropDown();
			benefitpage.clickPreviousVersion();
			details.verifyNotesValue(prevNotes);
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			
			OneframeLogger("Validate Butterscotch App Login Succseefully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate Butterscotch App Login");
		}
		
		homepage.clickLogout();		
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}
	
	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

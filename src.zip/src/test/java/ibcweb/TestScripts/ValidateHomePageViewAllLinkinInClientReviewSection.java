package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class ValidateHomePageViewAllLinkinInClientReviewSection extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
    IBPHomePage homepage;
    IBPBenefitPage benefitpage;

	@BeforeClass
	@Step("Initializing Test Script for Validating View All Link in In Client Review Section ")
	public void setUp() {
		InitializeLaunchPad("IBPW_90");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID","TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate View All Link in In Client Review Section", dataProvider = "TestData")
	@Description("Validate View All Link in In Client Review Section")
	public void ValidateViewAllLinkinInClientReviewSection(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {
		
	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			sa.assertTrue(welcomePage.verifyMyTasksWidgetDisplay(), "Verified My Task Widget is displayed");
		    homepage.verifyMyTaskHeader();
		    homepage.verifyInClientReviewSectioninMyTask();
		    homepage.verifyViewAllLinkinInClientReviewSection();
		    homepage.ClickViewAllLinkinInClientReviewSection();
		    sa.assertTrue(homepage.verifyInClientReviewHeaderisDisplayed(), "Verified In Client Review Header is Displayed");
		    sa.assertTrue(homepage.verifyInClientReviewDataTable(), "Verified In Client Review Data Table is Displayed");

			gTestResult = RESULT_PASS;
			OneframeLogger("View All Link is  Verified in the In Cliect Review Section");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("View All Link is not Verified in the In Client Section");
		}
	
	
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

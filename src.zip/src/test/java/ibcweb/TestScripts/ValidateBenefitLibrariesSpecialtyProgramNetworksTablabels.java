package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBenefitProgramsPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesSpecialtyProgramNetworksTablabels extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;
	IBPLibrariesBaseFormularies baseFormulary;
	IBPBenefitProgramsPage benefitProgramsPage;

	@BeforeClass
	@Step("Initializing Test Script for Validate Specialty Program Network Tab Labels, toggles and Except section")
	public void setUp() {
		InitializeLaunchPad("IBPW_444");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();
		baseFormulary = new IBPLibrariesBaseFormularies();
		benefitProgramsPage = new IBPBenefitProgramsPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Specialty Program Network Tab Labels, toggles and Except section", dataProvider = "TestData")
	@Description("Validate Specialty Program Network Tab Labels, toggles and Except section")
	public void ValidateSpecialtyNetworkTabLabels(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickOnSpeciality();
			benefitProgramsPage.clickonExistingSpecialtyProgram();
			librariesprogramspage.verifyNetworkTabIsEnabledAndClicked();
			librariesprogramspage.verifyAndClickEditButton();
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("All Networks");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("Specific Networks");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("Retail");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("INCLUDE");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("MAX DAY SUPPLY");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("REFILL TOO SOON");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("NUMBER OF GRACE FILLS");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("What happens after number of fills");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("Except");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("NETWORK NAME");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("NETWORK CODE");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("ADJUDICATION CODE");
			benefitProgramsPage.verifyNetworkTablabelsAreDisplayed("NETWORK TYPE");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("CLIENT");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("LOB");
			benefitProgramsPage.verifySpecialDetailslabelsAreDisplayed("STATE");
			librariesprogramspage.verifyAllNetworksTogggleDisplayed();
			librariesprogramspage.verifySpecificNetworksTogggleDisplayed();
			benefitpage.clickCancelButtoninClientFeedback();
			librariesprogramspage.clickLeaveButton();
			benefitProgramsPage.clickDownArrowButton();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Specialty Program details, General labels and field Details Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Specialty Program details, General labels and field Details");
		}

		homepage.clickLogout();
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

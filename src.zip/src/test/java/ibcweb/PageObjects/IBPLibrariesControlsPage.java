package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import java.util.Date;
import static anthem.irx.oneframe.selenium.WebObjectHandler.EnterText;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ScrollToElement;
import static anthem.irx.oneframe.selenium.WebObjectHandler.SelectDropDownListByValue;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForApplicationToLoadCompletely;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPLibrariesControlsPage extends OneframeContainer {
	OneframeSoftAssert sa = new OneframeSoftAssert();
	OneframeAssert ha = new OneframeAssert();

	@FindBy(xpath = "//a[@routerlink=\"/admin/library/controls\"]")
	WebElement btnViewControls;

	@FindBy(xpath = "//div[text()=\"Controls\"]")
	WebElement hdrControls;

	@FindBy(xpath = "//*[contains(text(),\" Coordination of Benefits (COB) \")]")
	WebElement btnCOBTab;

	@FindBy(xpath = "//table[@class=\"mat-table cdk-table mat-sort irx-listings ng-star-inserted\"]//tbody//tr[1]")
	WebElement lstCOBPackageRecords;

	@FindBy(xpath = "//*[contains(text(),' COB Defaults ')]")
	WebElement btnCOBDefaultTab;

	@FindBy(xpath = "//*[contains(text(),' Coordination of Benefits (COB) ')]")
	WebElement btnCOBPackageTab;

	@FindBy(xpath = "//*[contains(text(),\" Create a COB Package \")]")
	WebElement createCOBPackageButton;

	@FindBy(xpath = "//*[contains(text(),' Create a COB Default ')]")
	WebElement createCOBDefaultButton;

	@FindBy(xpath = "//*[contains(text(),\"Create a COB Package\")]")
	WebElement hdrCreateCOBPackage;

	@FindBy(xpath = "//*[contains(text(),'Create a Coordination of Benefit Default')]")
	WebElement hdrCreateCOBDefault;

	@FindBy(xpath = "//h3[contains(text(),'Dynamic Layer')]")
	WebElement hdrDynamicLayer;

	@FindBy(xpath = "//mat-select[@id='mat-select-48']/div/div[2]")
	WebElement drdAutoApply;

	@FindBy(xpath = "//*[@placeholder=\"Select\"]")
	List<WebElement> dynamicLayer;

	@FindBy(xpath = "//*[@data-automation-id=\"Paper\"]//div//div//div")
	List<WebElement> lstCOBPaperElectronicLayer;

	@FindBy(xpath = "//span[contains(text(),\"Create COB\")]")
	WebElement btnCreateCOB;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> firstDropdownOption;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	WebElement dropdownOption;

	@FindBy(xpath = "//mat-option[@role='option']/span")
	List<WebElement> dropdowns;

	@FindBy(xpath = "//button[@class=\"mat-focus-indicator mat-flat-button mat-button-base mat-primary\"]")
	WebElement btnCreateCOBPackage;

	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;

	@FindBy(xpath = "//*[@class=\"mat-paginator-icon\"]")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//mat-select[@formcontrolname='clients']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdClient;

	@FindBy(xpath = "//mat-select[@formcontrolname='lobs']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdLob;

	@FindBy(xpath = "//mat-select[@formcontrolname='states']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdState;

	@FindBy(xpath = "//*[@formcontrolname=\"terminationDate\"]")
	WebElement txtTermDate;

//	@FindBy(xpath = "//*[@placeholder=\"COB Processing Method\"]")
//	WebElement cobProcessingMethod;

	@FindBy(xpath = "//mat-select[@formcontrolname='cobProcessingMethod']")
	WebElement cobProcessingMethod;

//	@FindBy(xpath = "//*[@placeholder=\"COB Package\"]")
//	WebElement cobPackageField;

	@FindBy(xpath = "//mat-select[@formcontrolname='cobPackageId']")
	WebElement cobPackageField;

	@FindBy(xpath = "//span[contains(text(),\"COB Package\")]")
	WebElement drdCOBPackage;

	@FindBy(xpath = "//span[contains(text(),\" ADD COB Defaults \")]")
	WebElement btnAddCOBDefault;

	@FindBy(xpath = "//div[contains(text(),\"COB Default succesfully configured.\")]")
	WebElement txtCOBDefaultSuccess;

	@FindBy(xpath = "//div[contains(text(),\"COB Package successfully configured.\")]")
	WebElement txtCOBPackageSuccess;

	@FindBy(xpath = "//button[@class=\"mat-focus-indicator filter mat-icon-button mat-button-base\"]")
	WebElement btnFilter;

	@FindBy(xpath = "//mat-select[@formcontrolname='client']")
	WebElement drdClientFilter;

	@FindBy(xpath = "//mat-select[@formcontrolname='lob']")
	WebElement drdLobFilter;

	@FindBy(xpath = "//mat-select[@formcontrolname='state']")
	WebElement drdStateFilter;

	@FindBy(xpath = "//*[text()='Auto Apply']/../../preceding-sibling::mat-select")
	WebElement drdAutoApplyFilter;

	@FindBy(xpath = "//*[text()='Business Entity']/../../preceding-sibling::mat-select")
	WebElement drdBusinessEntityFilter;

	@FindBy(xpath = "//*[text()='Business Unit']/../../preceding-sibling::mat-select")
	WebElement drdBusinessUnitFilter;

	@FindBy(xpath = "//*[text()='CDHP Type']/../../preceding-sibling::mat-select")
	WebElement drdCDHPTypeFilter;

	@FindBy(xpath = "//*[text()='Formulary']/../../preceding-sibling::mat-select")
	WebElement drdFormularyFilter;

	@FindBy(xpath = "//*[text()='Funding Type']/../../preceding-sibling::mat-select")
	WebElement drdFundingTypeFilter;

	@FindBy(xpath = "//*[text()='Market Segment']/../../preceding-sibling::mat-select")
	WebElement drdMarketSegmentFilter;

	@FindBy(xpath = "//*[text()='Product Type']/../../preceding-sibling::mat-select")
	WebElement drdProductTypeFilter;

	@FindBy(xpath = "//*[text()='Other']/../../preceding-sibling::mat-select")
	WebElement drdOtherFilter;

	@FindBy(xpath = "//*[@aria-label=\"COB Package Name\"]")
	WebElement drdCOBPackageNameFilter;

	@FindBy(xpath = "//*[@placeholder=\"Package Name\"]")
	WebElement txtPackageName;

	@FindBy(xpath = "//*[@placeholder=\"Description\"]")
	WebElement txtPackageDescription;

	@FindBy(xpath = "//*[@placeholder=\"COB Details\"]")
	WebElement txtDetails;

	@FindBy(xpath = "//*[@aria-label=\"COB Processing Method\"]")
	WebElement drdCOBProcessingMethodFilter;

	@FindBy(xpath = "//input[@aria-haspopup='dialog']")
	WebElement txtEffectiveDate;

	@FindBy(xpath = "//*[@formcontrolname='stopSaleDate']")
	WebElement txtStopSaleDateField;

	@FindBy(xpath = "//*[@formcontrolname=\"terminationDate\"]")
	WebElement txtTerminationDate;

	@FindBy(xpath = "//*[contains(text(),\"Apply filter\")]/..")
	WebElement btnApplyFilter;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-clients mat-column-clients ng-star-inserted\"]")
	List<WebElement> lstClient;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-client mat-column-client ng-star-inserted\"]")
	List<WebElement> lstClientCOBPackage;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-lobs mat-column-lobs ng-star-inserted\"]")
	List<WebElement> lstLOB;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-lob mat-column-lob ng-star-inserted\"]")
	List<WebElement> lstLOBCOBPackage;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-states mat-column-states ng-star-inserted\"]")
	List<WebElement> lstState;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-state mat-column-state ng-star-inserted\"]")
	List<WebElement> lstStateCOBPackage;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-cobPackageId mat-column-cobPackageId ng-star-inserted\"]")
	List<WebElement> lstCOBPackage;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-cobProcessingMethod mat-column-cobProcessingMethod ng-star-inserted\"]")
	List<WebElement> lstCOBProcessingMethod;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-effectiveDate mat-column-effectiveDate ng-star-inserted\"]")
	List<WebElement> lstEffectiveDate;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-terminationDate mat-column-terminationDate ng-star-inserted\"]")
	List<WebElement> lstTerminationDate;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted\"]")
	List<WebElement> lstPackageNameRecords;

	@FindBy(xpath = "//tr[@class=\"mat-row cdk-row ng-star-inserted\"]")
	List<WebElement> lstCOBPackageRecordsRow;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-clients mat-column-clients ng-star-inserted\"]")
	List<WebElement> lstClientRecords;

	@FindBy(xpath = "//div[@class=\"mat-drawer-inner-container ng-tns-c179-17\"]")
	WebElement flyingPage;

	@FindBy(xpath = "//h3[contains(text(),\" COB Package details \")]")
	WebElement hdrCOBPackageDetails;

	@FindBy(xpath = "//h3[contains(text(),\" COB Default details \")]")
	WebElement hdrCOBDefaultDetails;

	@FindBy(xpath = "//*[@svgicon=\"edit\"]")
	WebElement btnEdit;

	@FindBy(xpath = "//*[@placeholder=\"Select\"]/div")
	List<WebElement> lstBOBAndDynamicLayerFields;

	@FindBy(xpath = "//input[@formcontrolname=\"name\"]")
	WebElement packageNameField;

	@FindBy(xpath = "//span[contains(text(),\"Cancel\")]")
	WebElement btnCancel;

	@FindBy(xpath = "//span[contains(text(),\"Save changes\")]")
	WebElement btnSaveChanges;
	
	@FindBy(xpath = "//span[contains(text(),\"Save changes\")]")
	WebElement btnSaveChange;

	@FindBy(xpath = "//h3[@class=\"mat-dialog-title\"]")
	WebElement hdrLeaveWithOutSaving;

	@FindBy(xpath = "//div[@class=\"mat-dialog-content\"]")
	WebElement txtYouHaveMadeChanges;

	@FindBy(xpath = "//h3[@class=\"mat-dialog-title\"]//following::div[2]/button")
	List<WebElement> btnCancelAndLeave;

	@FindBy(xpath = "//span[contains(text(),\"Changes Saved\")]")
	WebElement txtChangesSaved;

	@FindBy(xpath = "//mat-select[@formcontrolname='drug']")
	WebElement drdDrugList;

	@FindBy(xpath = "//mat-select[@formcontrolname='generalOverrides']")
	WebElement drdGeneralOverrides;

	@FindBy(xpath = "//mat-select[@formcontrolname='networkOverrides']")
	WebElement drdNetworkOverrides;

	@FindBy(xpath = "//mat-select[@formcontrolname='costSharesOverrides']")
	WebElement drdCostShareOverrides;

	@FindBy(xpath = "//mat-select[@formcontrolname='accumOverrides']")
	WebElement drdAccumOverrides;

	@FindBy(xpath = "//mat-option/span[normalize-space()='Yes']")
	WebElement drdValueYes;

	@FindBy(xpath = "//input[@formcontrolname='timelyFiling']")
	WebElement txtTimeFilingFilter;

	@FindBy(xpath = "//input[@formcontrolname='retailHighDollar']")
	WebElement txtHighLimitRetailFilter;

	@FindBy(xpath = "//input[@formcontrolname='homeDeliveryHighDollar']")
	WebElement txtHighLimitDeliveryFilter;

	@FindBy(xpath = "//*[@formcontrolname='paperClaimsInnList']")
	WebElement drdPaperClaimInNetworkFilter;

	@FindBy(xpath = "//*[@formcontrolname='paperClaimsOonList']")
	WebElement drdPaperClaimOutOfNetworkFilter;

	@FindBy(xpath = "//*[@formcontrolname='followMeLogicList']")
	WebElement drdFollowMeLogicAppliesFilter;

	@FindBy(xpath = "//*[@formcontrolname='clientIds']")
	WebElement drdClientFilters;

	@FindBy(xpath = "//*[@formcontrolname='lobIds']")
	WebElement drdLOBFilters;

	@FindBy(xpath = "//*[@formcontrolname='stateIds']")
	WebElement drdStateFilters;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-timeFilling mat-column-timeFilling ng-star-inserted']")
	List<WebElement> lstTimeFiling;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-retailHighDollar mat-column-retailHighDollar ng-star-inserted']")
	List<WebElement> lstHighLimitRetail;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-homeDeliveryHighDollar mat-column-homeDeliveryHighDollar ng-star-inserted']")
	List<WebElement> lstHighLimitDelivery;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-paperClaimsInn mat-column-paperClaimsInn ng-star-inserted']")
	List<WebElement> lstPaperClaimsInNetwork;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-paperClaimsOon mat-column-paperClaimsOon ng-star-inserted']")
	List<WebElement> lstPaperClaimsOutOfNetwork;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-followMeLogic mat-column-followMeLogic ng-star-inserted']")
	List<WebElement> lstFollowMeLogicApplies;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-clientDto mat-column-clientDto ng-star-inserted']")
	List<WebElement> lstClientValue;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-lobDto mat-column-lobDto ng-star-inserted']")
	List<WebElement> lstLOBValue;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-stateDto mat-column-stateDto ng-star-inserted']")
	List<WebElement> lstStateValue;

	@FindBy(xpath = "//span[text()=' General Defaults ']")
	WebElement txtGeneralDefaulttab;

	@FindBy(xpath = "//*[text()=' Create General Default ']")
	WebElement btnCreateGeneralDefault;

	@FindBy(xpath = "//*[text()='Create a General Defaults Structure']")
	WebElement hdrCreateAGeneralDefaultStructure;

	@FindBy(xpath = "//*[@class=\"mat-icon notranslate left-arrow mat-icon-no-color\"]")
	WebElement btnBack;

	@FindBy(xpath = "//*[@formcontrolname=\"foreignClaim\"]")
	WebElement txtForeignClaimsField;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> dropdownValues;

	@FindBy(xpath = "//*[text() and normalize-space()=\"General Default Structure Details\"]")
	WebElement hdrGeneralDefaultStructureDetails;

	// Initializing the@Step("Click View button of Mandates")
	public IBPLibrariesControlsPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click view button of controls")
	public boolean clickViewButtonofControls() {
		try {
			if (WaitForObject(btnViewControls)) {
				ClickWebObject(btnViewControls);
				OneframeLogger("Clicked on View button of Controls");
				return true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("View button of Controls is not Clicked");
		}
		return false;
	}

	@Step("Verify Control header is displayed")
	public boolean verifyControlsHeader() {
		boolean flag = false;
		if (WaitForObjectVisibility(hdrControls)) {
			if (hdrControls.getText().equalsIgnoreCase("Controls")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("click Controls header")
	public void clickControlsHeader() throws InterruptedException {
		WaitForObjectVisibility(hdrControls);
		ClickWebObject(hdrControls);
		ClickWebObject(hdrControls);
		ClickWebObject(hdrControls);
		ClickWebObject(hdrControls);
		Thread.sleep(5000);
	}

	@Step("Click COB Tab")
	public void clickCOBTab() {
		try {
			if (WaitForObject(btnCOBTab)) {
				ClickWebObject(btnCOBTab);
				OneframeLogger("Clicked COB tab");
			}
		} catch (TimeoutException e) {
			OneframeLogger("COB tab is not Clicked");
		}
	}

	@Step("Verify list of COB Records is displayed")
	public boolean verifyCOBRecords() {
		boolean bln = false;
		if (WaitForObject(lstCOBPackageRecords)) {
			// highlightElement(lstCOBPackageRecords);
			bln = true;
		}
		return bln;
	}

	@Step("Click COB Default Tab")
	public void clickCOBDefaultTab() {
		try {
			if (WaitForObject(btnCOBDefaultTab)) {
				ClickWebObject(btnCOBDefaultTab);
				OneframeLogger("Clicked COB Default tab");
			}
		} catch (TimeoutException e) {
			OneframeLogger("COB Default tab is not Clicked");
		}
	}

	@Step("Click COB Package Tab")
	public void clickCOBPackageTab() {
		try {
			if (WaitForObject(btnCOBPackageTab)) {
				ClickWebObject(btnCOBPackageTab);
				OneframeLogger("Clicked COB Package tab");
			}
		} catch (TimeoutException e) {
			OneframeLogger("COB Package tab is not Clicked");
		}
	}

	@Step("Click the first record of COB Package")
	public void clickFirstRecordCOBPackage() {
		lstPackageNameRecords.get(0).click();
		OneframeLogger("COB Package first record is Clicked");
	}

	@Step("Click any record of COB Default")
	public void clickFirstRecordCOBDefault() throws InterruptedException {
		ObjectExist(lstClientRecords.get(3));
		lstClientRecords.get(3).click();
		OneframeLogger("COB Default first record is Clicked");
	}

	@Step("Verify Create a COB Package Details header is displayed")
	public boolean verifyCOBPackageDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCOBPackageDetails)) {
			if (hdrCOBPackageDetails.getText().equalsIgnoreCase("COB Package details")) {
				highlightElement(hdrCOBPackageDetails);
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Create a COB Default Details header is displayed")
	public boolean verifyCOBDefaultDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCOBDefaultDetails)) {
			if (hdrCOBDefaultDetails.getText().equalsIgnoreCase("COB Default details")) {
				highlightElement(hdrCOBDefaultDetails);
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click COB package Details header")
	public void clickCOBPackageDetailsHeader() {
		hdrCOBPackageDetails.click();
		hdrCOBPackageDetails.click();
		hdrCOBPackageDetails.click();
		OneframeLogger("Clicked on COB Package Details header");
	}

	@Step("Click COB Default Details header")
	public void clickCOBDefaultDetailsHeader() {
		hdrCOBDefaultDetails.click();
		hdrCOBDefaultDetails.click();
		// hdrCOBDefaultDetails.click();
		OneframeLogger("Clicked on COB Default Details header");
	}

	@Step("Verify and Click on Edit button")
	public boolean verifyAndClickEditButton() {
		boolean bln = false;
		if (ObjectExist(btnEdit)) {
			btnEdit.click();
			bln = true;
		}
		return bln;
	}

	@Step("Verify Edit button")
	public void verifyEditButton() {
		WaitForApplicationToLoadCompletely();
		if (WaitForObjectVisibility(btnEdit)) {
			sa.assertTrue(true, "Verified Edit button");
		}
	}

	@Step("Edit and Get Text Package Name field in COB Package Details")
	public String editAndGetPackageName() {
		ObjectExist(packageNameField);
		ClickWebObject(packageNameField);
		while (!packageNameField.getAttribute("value").equalsIgnoreCase("")) {
			packageNameField.sendKeys(Keys.BACK_SPACE);
		}
		String type = "TestAuto";
		int randomNumber = getRandomNumber();
		String name = type + randomNumber;
		packageNameField.sendKeys(name);

		OneframeLogger("Entered Package Name field value is : " + packageNameField.getAttribute("value"));
		return packageNameField.getAttribute("value");
	}

	@Step("Verify the edited Package")
	public boolean verifyEditedPackageName(String packageName) {
		boolean bln = false;
		hdrCOBPackageDetails.click();
		ObjectExist(packageNameField);
		highlightElement(packageNameField);
		String actualData = packageNameField.getAttribute("value");
		String actualData2 = packageNameField.getText();
		if (actualData.equalsIgnoreCase(packageName)) {
			OneframeLogger("The Edited package Name is same as expected : " + packageNameField.getAttribute("value"));
			bln = true;
		} else {
			OneframeLogger("The Edited package Name is not same : " + packageNameField.getAttribute("value"));
		}
		return bln;
	}

	@Step("Verify Package Name Field is Enabled")
	public boolean verifyPackageNameFieldIsEnabled() {
		boolean bln = false;
		if (ObjectExist(packageNameField)) {
			packageNameField.isEnabled();
			highlightElement(packageNameField);
			bln = true;
		}
		return bln;
	}

	@Step("Click Create a COB Package")
	public void clickCreateCOBPackage() {
		try {
			if (WaitForObject(createCOBPackageButton)) {
				ClickWebObject(createCOBPackageButton);
				OneframeLogger("Clicked on Create COB Package button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Create COB Package button is not Clicked");
		}
	}

	@Step("Click Create a COB Default")
	public void clickCreateCOBDefault() {
		try {
			if (WaitForObject(createCOBDefaultButton)) {
				ClickWebObject(createCOBDefaultButton);
				OneframeLogger("Clicked on Create COB Default button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Create COB Default button is not Clicked");
		}
	}

	@Step("Verify Create a COB Package header is displayed")
	public boolean verifyCreateACOBPackageHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCreateCOBPackage)) {
			if (hdrCreateCOBPackage.getText().equalsIgnoreCase("Create a COB Package")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Create a COB Default header is displayed")
	public boolean verifyCreateACOBDefaultHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCreateCOBDefault)) {
			if (hdrCreateCOBDefault.getText().equalsIgnoreCase("Create a Coordination of Benefit Default")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click COB Default header")
	public void clickCOBDefaultHeader() {
		hdrCreateCOBDefault.click();
		hdrCreateCOBDefault.click();
		OneframeLogger("COB Default header clicked");
	}

	@Step("Click COB Package header")
	public void clickCOBPackageHeader() {
		hdrCreateCOBPackage.click();
		hdrCreateCOBPackage.click();
		hdrCreateCOBPackage.click();
		OneframeLogger("COB Package header clicked");
	}

	@Step("Click Dynamic Layer header")
	public void clickDynamicLayerHeader() {
		hdrDynamicLayer.click();
		hdrDynamicLayer.click();
		OneframeLogger("Dynamic layer header clicked");
	}

	@Step("Verify Auto Apply Dropdown")
	public boolean verifyAutoApplyDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply)) {
				highlightElement(drdAutoApply);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Auto Apply COB Default Dropdown")
	public boolean selectAutoApplyCOBDefaultDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(0))) {
				highlightElement(dynamicLayer.get(0));
				blnRC = true;
			}
		} catch (TimeoutException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Control Auto Apply Dropdown")
	public boolean selectControlDefaultAutoApplyDropdown(String autoApply) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(0))) {
				ClickWebObject(dynamicLayer.get(0));
				String autoApplyVal = selectDropdownValue(autoApply);
				OneframeLogger("The Selected Auto Apply Dropdown value is : " + autoApplyVal);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Control Autoapply dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Business Entity Dropdown")
	public boolean selectBusinessEntityDropdown(String BusinessEntity) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(1))) {
				ClickWebObject(dynamicLayer.get(1));
				String businessEntityVal = selectDropdownValue(BusinessEntity);
				OneframeLogger("The Selected Business Entity Dropdown value is : " + businessEntityVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Entity dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-container\"]"));
		ClickWebObject(overlayElement);
	}

	@Step("Select Business Unit Dropdown")
	public boolean selectBusinessUnitDropdown(String BusinessUnit) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(2))) {
				ClickWebObject(dynamicLayer.get(2));
				String businessUnitVal = selectDropdownValue(BusinessUnit);
				OneframeLogger("The Selected Business Unit Dropdown value is : " + businessUnitVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Unit dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select CDHP Type Dropdown")
	public boolean selectCDHPTypeDropdown(String CDHP) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(3))) {
				ClickWebObject(dynamicLayer.get(3));
				String CDHPVal = selectDropdownValue(CDHP);
				OneframeLogger("The Selected CDHP Dropdown value is : " + CDHPVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select CDHP type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Formulary Dropdown")
	public boolean selectFormularyDropdown(String formulary) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(4))) {
				ClickWebObject(dynamicLayer.get(4));
				String formularyVal = selectDropdownValue(formulary);
				OneframeLogger("The Selected Formulary Dropdown value is : " + formularyVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Formulary dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Funding Type Dropdown")
	public boolean selectFundingTypeDropdown(String FundingType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(5))) {
				ClickWebObject(dynamicLayer.get(5));
				String fundingTypeVal = selectDropdownValue(FundingType);
				OneframeLogger("The Selected Funding Type Dropdown value is : " + fundingTypeVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Funding Type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Market Segment Dropdown")
	public boolean selectMarketSegmentDropdown(String MarketSegment) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(6))) {
				ClickWebObject(dynamicLayer.get(6));
				String marketSegmentVal = selectDropdownValue(MarketSegment);
				OneframeLogger("The Selected Market Segment Dropdown value is : " + marketSegmentVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Market Segment dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Product Type Dropdown")
	public boolean selectProductTypeDropdown(String ProductType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(7))) {
				ClickWebObject(dynamicLayer.get(7));
				String productTypeVal = selectDropdownValue(ProductType);
				OneframeLogger("The Selected Product Type Dropdown value is : " + productTypeVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Product type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Other Dropdown")
	public boolean selectOtherDropdown(String Other) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayer.get(8))) {
				ClickWebObject(dynamicLayer.get(8));
				String otherVal = selectDropdownValue(Other);
				OneframeLogger("The Selected Other Dropdown value is : " + otherVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Others dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Value Client from dropdown")
	public boolean selectClientropdown(String client) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdClient)) {
				ClickWebObject(drdClient);
				String clientVal = selectDropdownValues(client);
				OneframeLogger("The Selected client Dropdown value is : " + clientVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from client dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[normalize-space()='%s']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		return dropdownvalue.getText();
	}

	@Step("Select Value LOB from dropdown")
	public boolean selectLobdropdown(String lob) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdLob)) {
				ClickWebObject(drdLob);
				String lobVal = selectDropdownValues(lob);
				OneframeLogger("The Selected lob Dropdown value is : " + lobVal);
				Robot rt = new Robot();
				rt.keyPress(KeyEvent.VK_TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from lob dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Value State from dropdown")
	public boolean selectStatedropdown(String state) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdState)) {
				ClickWebObject(drdState);
				selectDropdownValues(state);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from state dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Value State from dropdown")
	public boolean selectStateDropdown(String state) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdState)) {
				ClickWebObject(drdState);
				String stateValue = selectDropdownValue(state);
				OneframeLogger("The Selected lob Dropdown value is : " + stateValue);
				Robot rt = new Robot();
				rt.keyPress(KeyEvent.VK_TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from state dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Enter Term date")
	public void EnterTermDate(String TermDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtTermDate)) {
				ClickWebObject(txtTermDate);
				EnterText(txtTermDate, TermDate);
				OneframeLogger("Term Date has been Entered : " + txtTermDate.getAttribute("value"));
				txtTermDate.sendKeys(Keys.TAB);
			}
		} catch (TimeoutException e) {
			OneframeLogger("Term Date has been Entered");
		}
	}

	@Step("Select COB Processing Method Dropdown")
	public boolean selectCOBProcessingMethodDropdown(String COBProcessingMethod) throws Throwable {
		Thread.sleep(5000);
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(cobProcessingMethod)) {
				ClickWebObject(cobProcessingMethod);
//				SelectDropDownListByValue(dropdownOption, COBProcessingMethod);
				String element = String.format("//mat-option[@role='option']/span[text()=' %s']", COBProcessingMethod);
				WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
				WaitForObjectVisibility(dropdownvalue);
				String value = dropdownvalue.getText();
				ClickWebObject(dropdownvalue);
				OneframeLogger("COB Processing Method dropdown selected:" + value);
			}
			blnRC = true;
		} catch (NoSuchElementException toException) {
			OneframeLogger("Unable to select COB Processing Method Dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select COB Package Dropdown")
	public boolean selectCOBPackageDropdown(String COBPackage) throws Throwable {
		Thread.sleep(4000);
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(cobPackageField)) {
				ClickWebObject(cobPackageField);
//				SelectDropDownListByValue(dropdownOption, COBProcessingMethod);
				String element = String.format("//mat-option[@role='option']/span[text()=' %s']", COBPackage);
				WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
				WaitForObjectVisibility(dropdownvalue);
				String value = dropdownvalue.getText();
				ClickWebObject(dropdownvalue);
				OneframeLogger("COB Package dropdown selected:" + value);
			}
			blnRC = true;
		} catch (NoSuchElementException toException) {
			OneframeLogger("Unable to select COB Processing Method Dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Edit and Select COB Package Dropdown")
	public String editAndSelectCOBPackageDropdown(String COBPackage) throws InterruptedException {
		for (int i = 0; i < 3; i++) {
			try {
				if (WaitForObjectVisibility(cobPackageField)) {
					Thread.sleep(500);
					ClickWebObject(cobPackageField);
					Thread.sleep(500);
					for (int j = 0; j < firstDropdownOption.size(); j++) {
						if (firstDropdownOption.get(j).getText().equalsIgnoreCase("Standard 3")) {
							SelectDropDownListByValue(firstDropdownOption.get(j), COBPackage);
							OneframeLogger("COB Package dropdown selected:" + cobPackageField.getText());
							break;
						}
					}
				}
			} catch (StaleElementReferenceException e) {
				OneframeLogger("Unable to select COB Package Dropdown");

			}
		}
		return cobPackageField.getText();
	}

//	@Step("Select COB Package Dropdown")
//	public boolean selectCOBPackageDropdown(String COBPackage) throws InterruptedException {
//		boolean blnRC = false;
//		for (int i = 0; i < 2; i++) {
//			try {
//				if (WaitForObject(cobPackageField)) {
//					ClickWebObject(cobPackageField);
//					Thread.sleep(2000);
////					SelectDropDownListByValue(dropdownOption, COBPackage);	
//					String element = String.format(
//							"//mat-option[@role='option']/span[text()='%s']",
//							COBPackage);
//					WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
//					WaitForObjectVisibility(dropdownvalue);
//					ClickWebObject(dropdownvalue);
//					OneframeLogger("COB Package Method dropdown selected:" + dropdownvalue.getText());
//					blnRC = true;
//					break;
//				}
//			} catch (StaleElementReferenceException e) {
//				OneframeLogger("Unable to select COB Package Dropdown");
//				blnRC = false;
//			}
//		}
//		return blnRC;
//	}

	@Step("Verify COB Package Dropdown values is same as per BOB combination from COB Package")
	public boolean verifyCOBPackageDropdownValue(List<String> COBPackage) throws InterruptedException {
		boolean blnRC = false;
		ArrayList<String> listOne = new ArrayList<>(Arrays.asList());
		try {
			if (WaitForObject(cobPackageField)) {
				cobPackageField.sendKeys(Keys.ENTER);
				for (int i = 0; i < firstDropdownOption.size(); i++) {
					listOne.add(firstDropdownOption.get(i).getText());
				}
				if (listOne.size() > 0)
					blnRC = true;
				for (String pName : COBPackage) {
					if (listOne.contains(pName)) {
						blnRC = blnRC & true;
					}
				}
				OneframeLogger("COB Package dropdown values : " + listOne);
				OneframeLogger("COB Package values from COB package list : " + COBPackage);
				clickOverlayElement();
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select COB Package Dropdown");
		}
		return blnRC;
	}

	@Step("Click Add COB Default button")
	public void clickAddCOBDefaultButton() {
		WaitForObject(btnAddCOBDefault);
		btnAddCOBDefault.click();
		OneframeLogger("Clicked on Add COB Default button");
	}

	@Step("Verify COB Default Created Successfully ")
	public boolean verifyCOBDefaultCreateSuccess() {
		boolean bln = false;
		if (WaitForObjectVisibility(txtCOBDefaultSuccess)) {
			highlightElement(txtCOBDefaultSuccess);
			txtCOBDefaultSuccess.isDisplayed();
			bln = true;
		}
		return bln;
	}

	@Step("Verify COB Created Successfully ")
	public boolean verifyCOBPackageCreateSuccess() {
		boolean bln = false;
		if (WaitForObject(txtCOBPackageSuccess)) {
			highlightElement(txtCOBPackageSuccess);
			txtCOBPackageSuccess.isDisplayed();
			bln = true;
		}
		return bln;
	}

	@Step("Click on Filter button")
	public void clickFilterButton() {
		WaitForObjectVisibility(btnFilter);
		btnFilter.click();
		OneframeLogger("Clicked on Filter button");
	}

	@Step("Select and Get client value from COB Default Filter")
	public String selectAndGetClientValue(String client) {
		try {
			if (WaitForObject(drdClientFilter)) {
				drdClientFilter.click();
				String clientVal = selectDropdownValues(client);
				OneframeLogger("The Selected client Dropdown value is : " + clientVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Client dropdown ");

		}
		return drdClientFilter.getText();
	}

	@Step("Select and Get Lob value from COB Default Filter")
	public String selectAndGetLobValue(String lob) {
		try {
			if (WaitForObject(drdLobFilter)) {
				drdLobFilter.click();
				String lobVal = selectDropdownValues(lob);
				OneframeLogger("The Selected lob Dropdown value is : " + lobVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Lob dropdown ");

		}
		return drdLobFilter.getText();
	}

	@Step("Select and Get State value from COB Default Filter")
	public String selectAndGetStateValue(String State) {
		try {
			if (WaitForObject(drdStateFilter)) {
				drdStateFilter.click();
				String stateVal = selectDropdownValues(State);
				OneframeLogger("The Selected State Dropdown value is : " + stateVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select State dropdown ");
		}
		return drdStateFilter.getText();
	}

	@Step("Select Control Default Auto Apply Filter Dropdown")
	public boolean selectAutoApplyFilterDropdown(String autoApply) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApplyFilter)) {
				ClickWebObject(drdAutoApplyFilter);
				String autoApplyVal = selectDropdownValue(autoApply);
				OneframeLogger("The Selected Auto Apply Dropdown value is : " + autoApplyVal);
				// clickOverlayElement();
				drdAutoApplyFilter.sendKeys(Keys.ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Control Default Autoapply Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Business Entity Filter Dropdown")
	public boolean selectBusinessEntityFilterDropdown(String BusinessEntity) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdBusinessEntityFilter)) {
				ClickWebObject(drdBusinessEntityFilter);
				String businessEntityVal = selectDropdownValue(BusinessEntity);
				OneframeLogger("The Selected Business Entity Dropdown value is : " + businessEntityVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Entity Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Business Unit Filter Dropdown")
	public boolean selectBusinessUnitFilterDropdown(String BusinessUnit) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdBusinessUnitFilter)) {
				ClickWebObject(drdBusinessUnitFilter);
				String businessUnitVal = selectDropdownValue(BusinessUnit);
				OneframeLogger("The Selected Business Unit Dropdown value is : " + businessUnitVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Unit Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select CDHP Type Filter Dropdown")
	public boolean selectCDHPTypeFilterDropdown(String CDHP) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdCDHPTypeFilter)) {
				ClickWebObject(drdCDHPTypeFilter);
				String CDHPVal = selectDropdownValue(CDHP);
				OneframeLogger("The Selected CDHP Dropdown value is : " + CDHPVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select CDHP type Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Formulary Filter Dropdown")
	public boolean selectFormularyFilterDropdown(String formulary) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdFormularyFilter)) {
				ClickWebObject(drdFormularyFilter);
				String formularyVal = selectDropdownValue(formulary);
				OneframeLogger("The Selected Formulary Dropdown value is : " + formularyVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Formulary Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Funding Type Filter Dropdown")
	public boolean selectFundingTypeFilterDropdown(String FundingType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdFundingTypeFilter)) {
				ClickWebObject(drdFundingTypeFilter);
				String fundingTypeVal = selectDropdownValue(FundingType);
				OneframeLogger("The Selected Funding Type Dropdown value is : " + fundingTypeVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Funding Type Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Market Segment Filter Dropdown")
	public boolean selectMarketSegmentFilterDropdown(String MarketSegment) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdMarketSegmentFilter)) {
				ClickWebObject(drdMarketSegmentFilter);
				String marketSegmentVal = selectDropdownValue(MarketSegment);
				OneframeLogger("The Selected Market Segment Dropdown value is : " + marketSegmentVal);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Market Segment Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Product Type Filter Dropdown")
	public boolean selectProductTypeFilterDropdown(String ProductType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdProductTypeFilter)) {
				ClickWebObject(drdProductTypeFilter);
				String productTypeVal = selectDropdownValue(ProductType);
				OneframeLogger("The Selected Product Type Dropdown value is : " + productTypeVal);
				clickOverlayElement();
				drdProductTypeFilter.sendKeys(Keys.ESCAPE);
				
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Product type Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Other Filter Dropdown")
	public boolean selectOtherFilterDropdown(String Other) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdOtherFilter)) {
				ClickWebObject(drdOtherFilter);
				String otherVal = selectDropdownValue(Other);
				OneframeLogger("The Selected Other Dropdown value is : " + otherVal);
				drdOtherFilter.sendKeys(Keys.ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Others Filter dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select and Get COB Package Filter Dropdown")
	public String selectAndGetCOBPackageFilterDropdown(String COBPackage) {
		try {
			if (WaitForObject(drdCOBPackageNameFilter)) {
				ClickWebObject(drdCOBPackageNameFilter);
				selectDropdownValues(COBPackage);
				clickOverlayElement();
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select COB Package Filter Dropdown");
		}
		return drdCOBPackageNameFilter.getText();
	}

	@Step("Select and Get COB Processing Method Filter Dropdown")
	public String selectAndGetCOBProcessingMethodFilterDropdown(String COBProcessingMethod) throws AWTException {
		try {
			if (WaitForObjectVisibility(drdCOBProcessingMethodFilter)) {
				ClickWebObject(drdCOBProcessingMethodFilter);
				selectDropdownValues(COBProcessingMethod);
				Robot rt = new Robot();
				rt.keyPress(KeyEvent.VK_TAB);
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Unable to select COB Processing Method Dropdown");
		}
		return drdCOBProcessingMethodFilter.getText();
	}

	@Step("Enter Effective date")
	public String EnterCBEffectiveDate(String EffectiveDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtEffectiveDate)) {
				ClickWebObject(txtEffectiveDate);
				EnterText(txtEffectiveDate, EffectiveDate);
				OneframeLogger("Effective Date has been Entered : " + txtEffectiveDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Effective Date has been Entered");
		}
		return txtEffectiveDate.getAttribute("value");
	}

	@Step("Verify Effective date field is Enabled")
	public boolean verifyEffectiveDateFieldIsEnabled() {
		boolean bln = false;
		if (ObjectExist(txtEffectiveDate)) {
			txtEffectiveDate.isEnabled();
			bln = true;
		}
		return bln;
	}

	@Step("Enter Termination date")
	public String EnterTerminationDate(String EffectiveDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtTerminationDate)) {
				ClickWebObject(txtTerminationDate);
				EnterText(txtTerminationDate, EffectiveDate);
				OneframeLogger("Termination Date has been Entered : " + txtTerminationDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Termination Date has been Entered");
		}
		return txtTerminationDate.getAttribute("value");
	}

	@Step("Verify Termination date field is Enabled")
	public boolean verifyTerminationDateFieldIsEnabled() {
		boolean bln = false;
		if (ObjectExist(txtTerminationDate)) {
			txtTerminationDate.isEnabled();
			bln = true;
		}
		return bln;
	}

	@Step("Verify COB Processing Method field is Enabled")
	public boolean verifyCOBProcessingMethodFieldIsEnabled() {
		boolean bln = false;
		if (ObjectExist(cobProcessingMethod)) {
			cobProcessingMethod.isEnabled();
			bln = true;
		}
		return bln;
	}

	@Step("Verify COB Package field is Enabled")
	public boolean verifyCOBPackageFieldIsEnabled() {
		boolean bln = false;
		if (ObjectExist(cobPackageField)) {
			cobPackageField.isEnabled();
			bln = true;
		}
		return bln;
	}

	@Step("Verify COB Details field is Enabled")
	public boolean verifyCOBDetailsFieldIsEnabled() {
		boolean bln = false;
		if (ObjectExist(txtDetails)) {
			txtDetails.isEnabled();
			bln = true;
		}
		return bln;
	}

	@Step("Click on Apply filter button")
	public void clickApplyFilterButton() throws InterruptedException {
		WaitForObjectVisibility(btnApplyFilter);
		btnApplyFilter.click();
		OneframeLogger("Clicked on Apply filter button");
		Thread.sleep(5000);
	}

	@Step("Verify the Client filter list is Same as Expected")
	public Boolean verifyCOBDefaultClientFilterList(String Client) {
		boolean bln = false;
		WaitForObject(lstClient.get(0));
		highlightElement(lstClient.get(0));
		if (lstClient.get(0).getText().contains(Client)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the Client filter list is Same as Expected")
	public Boolean verifyCOBPackageClientFilterList(String Client) {
		boolean bln = false;
		WaitForObject(lstClientCOBPackage.get(0));
		highlightElement(lstClientCOBPackage.get(0));
		if (lstClientCOBPackage.get(0).getText().equalsIgnoreCase(Client)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the LOB filter list is Same as Expected")
	public Boolean verifyCOBDefaultLOBFilterList(String LOB) throws InterruptedException {
		boolean bln = false;
		WaitForObject(lstLOB.get(0));
		highlightElement(lstLOB.get(0));
		clickControlsHeader();
		if (lstLOB.get(0).getText().contains(LOB)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the LOB filter list is Same as Expected")
	public Boolean verifyCOBPackageLOBFilterList(String LOB) throws InterruptedException {
		boolean bln = false;
		WaitForObject(lstLOBCOBPackage.get(0));
		highlightElement(lstLOBCOBPackage.get(0));
		clickControlsHeader();
		if (lstLOBCOBPackage.get(0).getText().equalsIgnoreCase(LOB)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the State filter list is Same as Expected")
	public Boolean verifyCOBDefaultStateFilterList(String State) {
		boolean bln = false;
		WaitForObject(lstState.get(0));
		highlightElement(lstState.get(0));
		if (lstState.get(0).getText().contains(State)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the State filter list is Same as Expected")
	public Boolean verifyCOBPackageStateFilterList(String State) {
		boolean bln = false;
		WaitForObject(lstStateCOBPackage.get(0));
		highlightElement(lstStateCOBPackage.get(0));
		if (lstStateCOBPackage.get(0).getText().equalsIgnoreCase(State)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the COB Package Name filter list is Same as Expected")
	public Boolean verifyCOBPackageNameFilterList(String COBPackageName) {
		boolean bln = false;
		WaitForObject(lstCOBPackage.get(0));
		highlightElement(lstCOBPackage.get(0));
		if (lstCOBPackage.get(0).getText().equalsIgnoreCase(COBPackageName)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the COB Processing Method filter list is Same as Expected")
	public Boolean verifyCOBProcessingMethodFilterList(String COBProcessingMethod) {
		boolean bln = false;
		WaitForObject(lstCOBProcessingMethod.get(0));
		highlightElement(lstCOBProcessingMethod.get(0));
		if (lstCOBProcessingMethod.get(0).getText().equalsIgnoreCase(COBProcessingMethod)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the Effective Date filter list is Same as Expected")
	public Boolean verifyEffectiveDateFilterList(String EffectiveDate) {
		boolean bln = false;
		WaitForObject(lstEffectiveDate.get(0));
		String dateValue = convertDateFormat(EffectiveDate);
		highlightElement(lstEffectiveDate.get(0));
		if (lstEffectiveDate.get(0).getText().equalsIgnoreCase(dateValue)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the Effective Date filter list is Same as Expected")
	public Boolean verifyEffectiveDateFilter(String EffectiveDate) throws InterruptedException {
		boolean bln = false;
		Thread.sleep(1500);
		WaitForObject(lstEffectiveDate.get(0));
		highlightElement(lstEffectiveDate.get(0));
		if (lstEffectiveDate.get(0).getText().equalsIgnoreCase(EffectiveDate)) {
			bln = true;
		}
		return bln;
	}

	@Step("Convert date Format")
	public String convertDateFormat(String date) {
		String newDate = null;
		Date dateValue = new Date(date);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		newDate = sdf.format(dateValue);
		return newDate;
	}

	@Step("Verify the Termination Date filter list is Same as Expected")
	public Boolean verifyTerminationDateFilterList(String TerminationDate) {
		boolean bln = false;
		WaitForObject(lstTerminationDate.get(0));
		String dateValue = convertDateFormat(TerminationDate);
		highlightElement(lstTerminationDate.get(0));
		if (lstTerminationDate.get(0).getText().equalsIgnoreCase(dateValue)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the Termination Date filter list is Same as Expected")
	public Boolean verifyTerminationDateFilter(String TerminationDate) {
		boolean bln = false;
		WaitForObject(lstTerminationDate.get(0));
		highlightElement(lstTerminationDate.get(0));
		if (lstTerminationDate.get(0).getText().equalsIgnoreCase(TerminationDate)) {
			bln = true;
		}
		return bln;
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		return value;
	}

	@Step("Select COB Paper Electronic Layer Dropdown")
	public boolean selectCOBPaperElectronicLayerDropdown(String COBlayer) {
		boolean blnRC = false;
		for (int i = 0; i < lstCOBPaperElectronicLayer.size(); i++) {
			if (WaitForObject(lstCOBPaperElectronicLayer.get(i))) {
				ClickWebObject(lstCOBPaperElectronicLayer.get(i));
				String element = String.format(
						"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()='%s']",
						COBlayer);
				WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
				String value = dropdownvalue.getText();
				ClickWebObject(dropdownvalue);
				OneframeLogger("COB dropdown selected: " + value);
				blnRC = true;
			}
		}
		return blnRC;
	}

	@Step("Enter Package Name in COB Package page")
	public String enterPackageName() {
		if (ObjectExist(txtPackageName)) {
			ClickWebObject(txtPackageName);
			String packageNm = "TESTAUTOPackage";
			int randomNumber = getRandomNumber();
			String packageName = packageNm + randomNumber;
			txtPackageName.sendKeys(packageName);
			OneframeLogger("The Package Name is : " + txtPackageName.getAttribute("value"));
		}
		return txtPackageName.getAttribute("value");
	}

	@Step("Enter Package Description in COB Package page")
	public Boolean enterPackageDescription() {
		boolean bln = false;
		if (ObjectExist(txtPackageDescription)) {
			ClickWebObject(txtPackageDescription);
			String packageDesc = "TestAutomationPackageDesc";
			int randomNumber = getRandomNumber();
			String packageDescription = packageDesc + randomNumber;
			txtPackageDescription.sendKeys(packageDescription);
			OneframeLogger("The Package Name is : " + txtPackageDescription.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Enter Details in COB Package page")
	public Boolean enterDetails() {
		boolean bln = false;
		if (ObjectExist(txtDetails)) {
			ClickWebObject(txtDetails);
			String details = "Details";
			int randomNumber = getRandomNumber();
			String DetailsValue = details + randomNumber;
			txtDetails.sendKeys(DetailsValue);
			OneframeLogger("The Package Name is : " + txtDetails.getText());
			bln = true;
		}
		return bln;
	}

	@Step("Edit and Enter Details")
	public String editAndEnterDetails() {
		if (ObjectExist(txtDetails)) {
			ClickWebObject(txtDetails);
			while (!txtDetails.getAttribute("value").equalsIgnoreCase("")) {
				txtDetails.sendKeys(Keys.BACK_SPACE);
			}
			String details = "Details";
			int randomNumber = getRandomNumber();
			String DetailsValue = details + randomNumber;
			txtDetails.sendKeys(DetailsValue);
			OneframeLogger("The Details is : " + txtDetails.getAttribute("value"));
		}
		return txtDetails.getAttribute("value");
	}

	@Step("Verify the edited Details is same")
	public boolean verifyEditedDetailsIsSame(String details) {
		boolean bln = false;
		ObjectExist(txtDetails);
		highlightElement(txtDetails);
		if (txtDetails.getAttribute("value").equalsIgnoreCase(details)) {
			OneframeLogger("Details value after edit : " + txtDetails.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Verify the edited COB Package is same")
	public boolean verifyEditedCOBPackageIsSame(String COBPackage) {
		boolean bln = false;
		ObjectExist(cobPackageField);
		highlightElement(cobPackageField);
		if (cobPackageField.getText().equalsIgnoreCase(COBPackage)) {
			OneframeLogger("COB Package value after edit : " + cobPackageField.getText());
			bln = true;
		}
		return bln;
	}

	@Step("Verify the edited Effective date is same")
	public boolean verifyEditedEffectiveDateIsSame(String effectiveDate) {
		boolean bln = false;
		ObjectExist(txtEffectiveDate);
		highlightElement(txtEffectiveDate);
		if (txtEffectiveDate.getAttribute("value").equalsIgnoreCase(effectiveDate)) {
			OneframeLogger("Effective date value after edit : " + txtEffectiveDate.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Enter current date in Effective Date field")
	public String editEffectiveDate() {
		ObjectExist(txtDetails);
		while (!txtEffectiveDate.getAttribute("value").equalsIgnoreCase("")) {
			txtEffectiveDate.sendKeys(Keys.BACK_SPACE);
		}
		String currentStrDate = convertDateFormat();
		txtEffectiveDate.sendKeys(currentStrDate);
		OneframeLogger("The Effective Date field is : " + txtEffectiveDate.getAttribute("value"));
		return txtEffectiveDate.getAttribute("value");
	}

	@Step("Convert current date format to MM/DD/YYYY")
	public String convertDateFormat() {
		Date currentDate = new Date();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		String currentStrDate = dateFormat.format(currentDate);
		return currentStrDate;
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Click Create COB button")
	public void clickCreateCOBButton() {
		btnCreateCOB.click();
		OneframeLogger("Clicked on Create COB button");
	}

	@Step("Verify Create COB button is Enabled")
	public boolean verifyCreateCOBButtonIsEnabled() {
		boolean bln = false;
		if (ObjectExist(btnCreateCOB)) {
			btnCreateCOB.isEnabled();
			highlightElement(btnCreateCOB);
			OneframeLogger("Create COB button is enabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Create COB button is Disabled")
	public boolean verifyCreateCOBButtonIsDisabled() {
		boolean bln = false;
		if (btnCreateCOBPackage.getAttribute("disabled").equalsIgnoreCase("true")) {
			highlightElement(btnCreateCOBPackage);
			OneframeLogger("Create COB button is disabled");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Cancel button is displayed")
	public boolean verifyCancelButton() {
		boolean bln = false;
		if (ObjectExist(btnCancel)) {
			btnCancel.isDisplayed();
			highlightElement(btnCancel);
			bln = true;
		}
		return bln;
	}

	@Step("Click Cancel button")
	public void clickCancelButton() {
		btnCancel.click();
		OneframeLogger("Clicked on Cancel button");
	}

	@Step("Click Save Changes button button")
	public void clickSaveChangesButton() {
		btnSaveChanges.click();
		OneframeLogger("Clicked on Save changes button");
	}

	@Step("Verify Leave Without Saving header is displayed")
	public boolean verifyLeaveWithOutSavingHeader() {
		boolean bln = false;
		if (hdrLeaveWithOutSaving.getText().equalsIgnoreCase("Leave without Saving?")) {
			highlightElement(hdrLeaveWithOutSaving);
			bln = true;
		}
		return bln;
	}

	@Step("Verify text You have made changes is displayed")
	public boolean verifyTextYouhaveMadeChanges() {
		boolean bln = false;
		if (txtYouHaveMadeChanges.getText().contains("You've made changes to ")) {
			highlightElement(txtYouHaveMadeChanges);
			bln = true;
		}
		return bln;
	}

	@Step("Verify Save Changes button is displayed")
	public boolean verifySaveChangesButton() {
		boolean bln = false;
		if (ObjectExist(btnSaveChange)) {
			btnSaveChange.isDisplayed();
			highlightElement(btnSaveChange);
			bln = true;
		}
		return bln;
	}

	@Step("Verify Text Save Changes is displayed")
	public boolean verifyChangesSavedText() {
		boolean bln = false;
		if (WaitForObjectVisibility(txtChangesSaved)) {
			txtChangesSaved.isDisplayed();
			highlightElement(txtChangesSaved);
			OneframeLogger("Changes saved text is displayed");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Cancel button in Leave Without Saving popup")
	public boolean verifyCancelButtonInLeavePage() {
		boolean bln = false;
		if (ObjectExist(btnCancelAndLeave.get(0))) {
			btnCancelAndLeave.get(0).isDisplayed();
			highlightElement(btnCancelAndLeave.get(0));
			bln = true;
		}
		return bln;
	}

	@Step("Click Cancel button in Leave Without Saving popup")
	public void clickCancelButtonInLeavePage() {
		btnCancelAndLeave.get(0).click();
		OneframeLogger("Clicked on Cancel button in Leave Without Saving popup");
	}

	@Step("Click Leave button in Leave Without Saving popup")
	public void clickLeaveButtonInLeavePage() {
		btnCancelAndLeave.get(1).click();
		OneframeLogger("Clicked on Leave button in Leave Without Saving popup");
	}

	@Step("Verify Leave button in Leave Without Saving popup")
	public boolean verifyLeaveButtonInLeavePage() {
		boolean bln = false;
		if (ObjectExist(btnCancelAndLeave.get(1))) {
			btnCancelAndLeave.get(1).isDisplayed();
			highlightElement(btnCancelAndLeave.get(1));
			bln = true;
		}
		return bln;
	}

	@Step("Verify Package Name created is Displayed in list")
	public boolean verifyPackageNameCreatedIsDisplayedInList(String packageName) {
		boolean bln = false;
		try {
			hdrControls.click();
			hdrControls.click();
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstPackageNameRecords.size(); i++) {
					if (lstPackageNameRecords.get(i).getText().equalsIgnoreCase(packageName)) {
						highlightElement(lstPackageNameRecords.get(i));
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to get Package Name");
			bln = false;
		}
		return bln;
	}

	@Step("Verify and Click Package Name")
	public boolean verifyAndClickPackageName(String packageName) {
		boolean bln = false;
		try {
			String xpath = "//tr/td[1][contains(text(), '"+packageName+"')]";
			Thread.sleep(3000);
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split(" ");
			//String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());
			
			int numberOfPages = Math.round(totalRecords/10) + 1;
			
			if(numberOfPages != 0) {
				for(int i=0; i<numberOfPages; i++) {
					try {
						WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
						if(WaitForObjectVisibility(ele)) {
							ClickWebObject(ele);
							OneframeLogger("Cliked Package : " +ele.getText());
							return true;
						}
					}
					catch (NoSuchElementException e) {
						 ClickWebObject(lstPageTraverseChevronButton.get(1));
						 ClickWebObject(txtPageNumber); 
						 ClickWebObject(txtPageNumber);
						 WaitForApplicationToLoadCompletely();
					}
					
				}
			}
		} catch (StaleElementReferenceException | InterruptedException e) {
			OneframeLogger("Unable to get Package Name");
			bln = false;
		}
		return bln;
	}

	@Step("Verify the BOB and Dynamic Layer fields are in Disabled mode in COB Default Details page")
	public boolean verifyBOBAndDynamicFieldsAreDisabled() {
		ObjectExist(lstBOBAndDynamicLayerFields.get(0));
		boolean bln = false;
		for (int i = 0; i < lstBOBAndDynamicLayerFields.size(); i++) {
			if (lstBOBAndDynamicLayerFields.get(i).getAttribute("aria-hidden").equalsIgnoreCase("true")) {
				highlightElement(lstBOBAndDynamicLayerFields.get(i));
				bln = true;
			}
		}
		return bln;
	}

	@Step("Get Package Name which contains the BOB combination of COB Default in COB package list")
	public List<String> getPackageNameOfBOBCombinationOfCOBDefault(String client, String lob, String state,
			String effDate, String termDate) throws ParseException {
		List<String> ls = new ArrayList<>(Arrays.asList());
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstClientCOBPackage.size(); i++) {
					if (lstClientCOBPackage.get(i).getText().contains(client)
							&& lstLOBCOBPackage.get(i).getText().contains(lob)
							&& lstStateCOBPackage.get(i).getText().contains(state)) {

						DateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
						Date effecDatelst = (Date) parser.parse(lstEffectiveDate.get(i).getText());
						Date termDatelst = (Date) parser.parse(lstTerminationDate.get(i).getText());

						String effDateStr = convertDateFormat(effDate);
						String termDateStr = convertDateFormat(termDate);
						Date effectiveDate = (Date) parser.parse(effDateStr);
						Date TerminationDate = (Date) parser.parse(termDateStr);

						if (effectiveDate.after(effecDatelst) && effectiveDate.before(termDatelst)
								&& TerminationDate.after(effecDatelst) && TerminationDate.before(termDatelst)
								&& effectiveDate.before(TerminationDate)) {
							ls.add(lstPackageNameRecords.get(i).getText());
							highlightElement(lstPackageNameRecords.get(i));
						}
					}
					if (recordsPresentPerPage == totalRecords) {
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
					clickControlsHeader();
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException | InterruptedException e) {
			OneframeLogger("Unable to get Package Name");
		}
		OneframeLogger("Package name : " + ls);
		return ls;
	}

	@Step("Select Drug List Dropdown")
	public boolean selectDrugList(String DrugList) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdDrugList)) {
				ClickWebObject(drdDrugList);
				selectDropdownValue(DrugList);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select DrugList dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select General Overrides Dropdown")
	public boolean selectGeneralOverrides(String generalOverrides) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdGeneralOverrides)) {
				ClickWebObject(drdGeneralOverrides);
				if (generalOverrides.equalsIgnoreCase("yes")) {
					ClickWebObject(drdValueYes);
				}
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select General Overrides dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Network Overrides Dropdown")
	public boolean selectNetworkOverrides(String networkOverrides) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdNetworkOverrides)) {
				ClickWebObject(drdNetworkOverrides);
				if (networkOverrides.equalsIgnoreCase("yes")) {
					ClickWebObject(drdValueYes);
				}
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Network Overrides dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Cost Share Overrides Dropdown")
	public boolean selectCostShareOverrides(String costShareOverrides) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdCostShareOverrides)) {
				ClickWebObject(drdCostShareOverrides);
				if (costShareOverrides.equalsIgnoreCase("yes")) {
					ClickWebObject(drdValueYes);
				}
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Network Overrides dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Accum Overrides Dropdown")
	public boolean selectAccumOverrides(String accumOverrides) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAccumOverrides)) {
				ClickWebObject(drdAccumOverrides);
				if (accumOverrides.equalsIgnoreCase("yes")) {
					ClickWebObject(drdValueYes);
				}
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Network Overrides dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	public boolean verifyFiltersAreCleared() {

		boolean flg = true;
		ArrayList<String> filters = new ArrayList<String>();

		filters.add(txtEffectiveDate.getAttribute("value"));
		filters.add(txtTerminationDate.getAttribute("value"));
		filters.add(drdClientFilter.getAttribute("value"));
		filters.add(drdLobFilter.getAttribute("value"));
		filters.add(drdStateFilter.getAttribute("value"));
		filters.add(drdDrugList.getAttribute("value"));
		filters.add(drdGeneralOverrides.getAttribute("value"));
		filters.add(drdNetworkOverrides.getAttribute("value"));
		filters.add(drdCostShareOverrides.getAttribute("value"));
		filters.add(drdAccumOverrides.getAttribute("value"));
		filters.add(drdAutoApplyFilter.getAttribute("value"));
		filters.add(drdBusinessEntityFilter.getAttribute("value"));
		filters.add(drdBusinessUnitFilter.getAttribute("value"));
		filters.add(drdCDHPTypeFilter.getAttribute("value"));
		filters.add(drdFormularyFilter.getAttribute("value"));
		filters.add(drdFundingTypeFilter.getAttribute("value"));
		filters.add(drdMarketSegmentFilter.getAttribute("value"));
		filters.add(drdProductTypeFilter.getAttribute("value"));
		filters.add(drdOtherFilter.getAttribute("value"));

		filters.removeAll(Collections.singleton(null));

		for (String x : filters) {
			if (x != "") {
				flg = false;
				break;
			}
		}

		return flg;
	}

	@Step("Check Visibility of Apply filter button")
	public boolean verifyVisibilityOfApplyFilterButton() {
		WaitForObject(btnApplyFilter);
		IBPBulkUpdatePage bulkUpdate = new IBPBulkUpdatePage();
		bulkUpdate.hdrbenefitBulkUpdate.click();
		bulkUpdate.hdrbenefitBulkUpdate.click();
		highlightElement(btnApplyFilter);
		if (btnApplyFilter.getAttribute("disabled").equalsIgnoreCase("false")) {
			OneframeLogger("Apply filter button is Enabled");
			return true;
		} else {
			OneframeLogger("Apply filter button is Disabled");
			return false;
		}

	}

	@Step("Enter and get Time Filing value")
	public String enterAndGetTimeFilingFilter(String timeFiling) {
		if (WaitForObjectVisibility(txtTimeFilingFilter)) {
			ClickWebObject(txtTimeFilingFilter);
			EnterText(txtTimeFilingFilter, timeFiling);
		}
		return txtTimeFilingFilter.getAttribute("value");
	}

	@Step("Enter and Get High Limit Retail value")
	public String enterAndGetHighLimitRetailFilter(String highLimitRetail) {
		if (WaitForObjectVisibility(txtHighLimitRetailFilter)) {
			ClickWebObject(txtHighLimitRetailFilter);
			EnterText(txtHighLimitRetailFilter, highLimitRetail);
		}
		return txtHighLimitRetailFilter.getAttribute("value");
	}

	@Step("Enter and Get High Limit Delivery value")
	public String enterAndGetHighLimitDeliveryFilter(String highLimitDelivery) {
		if (WaitForObjectVisibility(txtHighLimitDeliveryFilter)) {
			ClickWebObject(txtHighLimitDeliveryFilter);
			EnterText(txtHighLimitDeliveryFilter, highLimitDelivery);
		}
		return txtHighLimitDeliveryFilter.getAttribute("value");
	}

	@Step("Select and Get Paper Claim In network dropdown value in filter")
	public String selectAndGetPaperClaimInNetworkFilterDropdown(String paperClaimInNetwork) {
		try {
			if (WaitForObjectVisibility(drdPaperClaimInNetworkFilter)) {
				ClickWebObject(drdPaperClaimInNetworkFilter);
				String paperClaimInNetworkVal = selectDropdownValues(paperClaimInNetwork);
				OneframeLogger("The Selected Paper Claim In Network Dropdown value is : " + paperClaimInNetworkVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Paper Claim In Network dropdown ");

		}
		OneframeLogger(drdPaperClaimInNetworkFilter.getText());
		return drdPaperClaimInNetworkFilter.getText();
	}

	@Step("Select and Get Paper Claim Out of network dropdown value in filter")
	public String selectAndGetPaperClaimOutOfNetworkFilterDropdown(String paperClaimOutofNetwork) {
		try {
			if (WaitForObjectVisibility(drdPaperClaimOutOfNetworkFilter)) {
				ClickWebObject(drdPaperClaimOutOfNetworkFilter);
				String paperClaimOutOfNetworkVal = selectDropdownValues(paperClaimOutofNetwork);
				OneframeLogger(
						"The Selected Paper Claim Out of Network Dropdown value is : " + paperClaimOutOfNetworkVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Paper Claim Out of Network dropdown ");

		}
		return drdPaperClaimOutOfNetworkFilter.getText();
	}

	@Step("Select and Get Follow Me Logic Applies dropdown value in filter")
	public String SelectAndGetFollowMeLogicAppliesFilterDropdown(String followMeLogicApplies) {
		try {
			if (WaitForObjectVisibility(drdFollowMeLogicAppliesFilter)) {
				ClickWebObject(drdFollowMeLogicAppliesFilter);
				String followMeLogicAppliesVal = selectDropdownValues(followMeLogicApplies);
				OneframeLogger("The SelectedFollow Me Logic Applies Dropdown value is : " + followMeLogicAppliesVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Follow Me Logic Applies dropdown ");
		}
		return drdFollowMeLogicAppliesFilter.getText();
	}

	@Step("Select and Get client Filter dropdownvalue ")
	public String selectAndGetClientDropdownValue(String client) {
		try {
			if (WaitForObject(drdClientFilters)) {
				drdClientFilters.click();
				String clientVal = selectDropdownValues(client);
				OneframeLogger("The Selected client Dropdown value is : " + clientVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Client dropdown ");

		}
		return drdClientFilters.getText();
	}

	@Step("Select and Get Lob Filter dropdown value")
	public String selectAndGetLobFilterDropdownValue(String lob) {
		try {
			if (WaitForObject(drdLOBFilters)) {
				drdLOBFilters.click();
				String lobVal = selectDropdownValues(lob);
				OneframeLogger("The Selected lob Dropdown value is : " + lobVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Lob dropdown ");

		}
		return drdLOBFilters.getText();
	}

	@Step("Select and Get State Filter dropdown value")
	public String selectAndGetStateFilterDropdownValue(String State) {
		try {
			if (WaitForObject(drdStateFilters)) {
				drdStateFilters.click();
				String stateVal = selectDropdownValues(State);
				OneframeLogger("The Selected State Dropdown value is : " + stateVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select State dropdown ");
		}
		return drdStateFilters.getText();
	}

	@Step("Verify the Time Filing filtered value is Same as Expected")
	public void verifyTimeFilingFilteredList(String timeFiling) {
		WaitForObjectVisibility(lstTimeFiling.get(0));
		if (lstTimeFiling.get(0).getText().contains(timeFiling)) {
			highlightElement(lstTimeFiling.get(0));
		}
		sa.assertEquals(lstTimeFiling.get(0).getText(), timeFiling, "Verified Time Filing value is same as expected");
	}

	@Step("Verify the High Limit Retail filtered value is Same as Expected")
	public void verifyHighLimitRetailFilteredList(String highLimitRetail) {
		WaitForObjectVisibility(lstHighLimitRetail.get(0));

		if (lstHighLimitRetail.get(0).getText().equalsIgnoreCase(highLimitRetail)) {
			highlightElement(lstHighLimitRetail.get(0));
		}
		sa.assertEquals(lstHighLimitRetail.get(0).getText(), highLimitRetail,
				"Verified High Limit Retail value is same as expected");
	}

	@Step("Verify the High Limit Delivery filtered value is Same as Expected")
	public void verifyHighLimitDeliveryFilteredList(String highLimitDelivery) {
		WaitForObject(lstHighLimitDelivery.get(0));

		if (lstHighLimitDelivery.get(0).getText().equalsIgnoreCase(highLimitDelivery)) {
			highlightElement(lstHighLimitDelivery.get(0));
		}
		sa.assertEquals(lstHighLimitDelivery.get(0).getText(), highLimitDelivery,
				"Verified High Limit Delivery value is same as expected");
	}

	@Step("Verify the Paper Claims In Network filtered value is Same as Expected")
	public void verifyPaperClaimsInNetworkFilteredList(String paperClaimsInNetwork) {
		WaitForObject(lstPaperClaimsInNetwork.get(0));
		highlightElement(lstPaperClaimsInNetwork.get(0));
		sa.assertEquals(lstPaperClaimsInNetwork.get(0).getText(), paperClaimsInNetwork,
				"Verified Paper Claims In Network value is same as expected");
	}

	@Step("Verify the Paper Claims Out of Network filtered Value is Same as Expected")
	public void verifyPaperClaimsOutOfNetworkFilteredList(String paperClaimsOutOfNetwork) {
		WaitForObject(lstPaperClaimsOutOfNetwork.get(0));
		highlightElement(lstPaperClaimsOutOfNetwork.get(0));
		sa.assertEquals(lstPaperClaimsOutOfNetwork.get(0).getText(), paperClaimsOutOfNetwork,
				"Verified Paper Claims Out of Network value is same as expected");
	}

	@Step("Verify the Follow Me Logic Applies filtered value is Same as Expected")
	public void verifyFollowMeLogicAppliesFilteredList(String followMeLogicApplies) {
		WaitForObject(lstFollowMeLogicApplies.get(0));
		highlightElement(lstFollowMeLogicApplies.get(0));
		sa.assertEquals(lstFollowMeLogicApplies.get(0).getText(), followMeLogicApplies,
				"Verified Follow Me Logic Applies value is same as expected");
	}

	@Step("Verify the Client filtered value is Same as Expected")
	public void verifyClientFilteredList(String client) {
		WaitForObject(lstClientValue.get(0));
		highlightElement(lstClientValue.get(0));
		sa.assertEquals(lstClientValue.get(0).getText(), client, "Verified Client value is same as expected");
	}

	@Step("Verify the lob filtered value is Same as Expected")
	public void verifyLobFilteredList(String lob) {
		WaitForObject(lstLOBValue.get(0));
		highlightElement(lstLOBValue.get(0));
		sa.assertEquals(lstLOBValue.get(0).getText(), lob, "Verified lob value is same as expected");
	}

	@Step("Verify the State filtered value is Same as Expected")
	public void verifyStateFilteredList(String State) {
		WaitForObject(lstStateValue.get(0));
		highlightElement(lstStateValue.get(0));
		sa.assertEquals(lstStateValue.get(0).getText(), State, "Verified Client value is same as expected");
	}

	@Step("Verify text General Default tab")
	public void verifyTextGeneralTab() {
		if (WaitForObjectVisibility(txtGeneralDefaulttab)) {
			sa.assertEquals(txtGeneralDefaulttab.getText(), "General Defaults", "Verified text General Default tab");
		}
	}

	@Step("Verify General Default url")
	public void verifyGeneralDefaultUrl() {
		WaitForObjectVisibility(btnCreateGeneralDefault);
		btnCreateGeneralDefault.click();
		sa.assertEquals(hdrCreateAGeneralDefaultStructure.getText(), "Create a General Defaults Structure",
				"Validated header is same as expected");
		String currentUrl = oneframeDriver.getCurrentUrl();
		ha.assertTrue(currentUrl.contains("admin/library/controls/general-defaults/new"),
				"Validated New general Default url is as expected");
		btnBack.click();
		String currentURl = oneframeDriver.getCurrentUrl();
		ha.assertTrue(currentURl.contains("admin/library/controls/general-defaults"),
				"Validated general Default url is as expected");

	}

	@Step("Enter Current Date as Stop Sale date")
	public String EnterCurrentStopSaleDate() throws ParseException {
		WaitForApplicationToLoadCompletely();
		while (!txtStopSaleDateField.getAttribute("value").equalsIgnoreCase("")) {
			txtStopSaleDateField.sendKeys(Keys.BACK_SPACE);
		}
		if (WaitForObjectVisibility(txtStopSaleDateField)) {
			ClickWebObject(txtStopSaleDateField);
			String StopSaleDate = verifyStopSaleDate();
			DateFormat userDateFormat = new SimpleDateFormat("yyyy-mm-dd");
			DateFormat dateFormatNeeded = new SimpleDateFormat("mm/dd/yyyy");
			Date date = userDateFormat.parse(StopSaleDate);
			String convertedDate = dateFormatNeeded.format(date);

			EnterText(txtStopSaleDateField, convertedDate);
			OneframeLogger(
					"Current Date as Stop sale Date has been Entered : " + txtStopSaleDateField.getAttribute("value"));
		}
		return txtStopSaleDateField.getAttribute("value");
	}

	public String verifyStopSaleDate() {
		LocalDate stopSaleDate = LocalDate.now();
		String StopSaleDate = stopSaleDate.toString();
		return StopSaleDate;
	}

	@Step("Verify Foreign Claims Dropdown values")
	public void verifyForeignClaimsDropdownValue(String dropdownValue) throws InterruptedException {
		// boolean blnRC = false;
		ArrayList<String> drdValue = new ArrayList<>(Arrays.asList());
		ArrayList<String> listOne = new ArrayList<>(Arrays.asList());
		drdValue.add(dropdownValue);
		if (WaitForObjectVisibility(txtForeignClaimsField)) {
			txtForeignClaimsField.click();
			for (int i = 0; i < dropdownValues.size(); i++) {
				listOne.add(dropdownValues.get(i).getText());
			}
			// if (listOne.size() > 0)
			// blnRC = true;
			for (String drdVal : drdValue) {
				if (listOne.contains(drdVal)) {
					sa.assertEquals(listOne, drdVal, "Verified Dropdown values is same as expected");
					// blnRC = blnRC & true;
				}
			}
			OneframeLogger("dropdown values provided from TDS: " + drdValue);
			OneframeLogger("dropdown values is same as expected: " + listOne);
			clickOverlayElement();
		}

	}

	@Step("Verify Stop Sale Date")
	public void verifyStopSaleDt(String stopsaleDate) {
		WaitForObjectVisibility(txtStopSaleDateField);
		sa.assertEquals(txtStopSaleDateField.getAttribute("value"), stopsaleDate,
				"Verified Stop Sale date value is same as expected");
		sa.assertAll();

	}

	@Step("Verify Name created is Displayed in list")
	public boolean verifyNameCreatedIsDisplayedInList(String packageName) {
		boolean bln = false;
		WaitForApplicationToLoadCompletely();
		try {
			hdrControls.click();
			hdrControls.click();
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstPackageNameRecords.size(); i++) {
					if (lstPackageNameRecords.get(i).getText().equalsIgnoreCase(packageName)) {
						highlightElement(lstPackageNameRecords.get(i));
						ClickWebObject(lstPackageNameRecords.get(i));
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to get Package Name");
			bln = false;
		}
		return bln;
	}

	@Step("Verify {generalDefault} labels is displayed")
	public void verifyLabelsAreDisplayed(String generalDefault) {
		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()='%s']", generalDefault)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to see labels");
		}
		sa.assertEquals(expectedHeader.getText(), generalDefault, "Validated Label is : " + generalDefault);
	}

	@Step("Verify {generalDefault} labels is displayed")
	public void verifyIDLabelsAreDisplayed(String generalDefault) {
		WebElement expectedHeader = oneframeDriver.findElement(
				By.xpath(String.format("//mat-label[text() and normalize-space()=\"%s\"]", generalDefault)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to see labels");
		}
		sa.assertEquals(expectedHeader.getText(), generalDefault, "Validated Label is : " + generalDefault);
	}

	@Step("Verify General default Structure Details header is displayed")
	public boolean verifyGeneralDefaultStructureDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrGeneralDefaultStructureDetails)) {
			if (hdrGeneralDefaultStructureDetails.getText().equalsIgnoreCase("General Default Structure Details")) {
				highlightElement(hdrGeneralDefaultStructureDetails);
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify LOB General Default Dropdown values")
	public void verifyLOBGeneralDefaultDropdownValue(String dropdownValue) throws InterruptedException {
		ArrayList<String> drdValue = new ArrayList<>(Arrays.asList());
		ArrayList<String> listOne = new ArrayList<>(Arrays.asList());
		drdValue.add(dropdownValue);
		if (WaitForObjectVisibility(drdLOBFilters)) {
			drdLOBFilters.click();
			for (int i = 0; i < dropdownValues.size(); i++) {
				listOne.add(dropdownValues.get(i).getText());
			}

			for (String drdVal : drdValue) {
				if (listOne.contains(drdVal)) {
					sa.assertEquals(listOne, drdVal, "Verified Dropdown values is same as expected");
				}
			}
			OneframeLogger("dropdown values provided from TDS: " + drdValue);
			OneframeLogger("dropdown values is same as expected: " + listOne);
			clickOverlayElement();
		}

	}

}

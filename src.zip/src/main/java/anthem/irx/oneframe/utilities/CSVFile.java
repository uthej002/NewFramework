package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeConstants;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeLogger;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class CSVFile {
  private File CSVFile;
  
  private CSVParser OfcsvParser;
  
  private List<CSVRecord> ofCSVRecords;
  
  private BufferedReader reader;
  
  private String currCSVFileName;
  
  private int totRowCount;
  
  private static OneframeSoftAssert ofSA;
  
  public CSVFile(String CSVResourceFolderPath, String CSVFileName) {
    this.currCSVFileName = OneframeConstants.RESOURCES_FOLDER + CSVResourceFolderPath + "/" + CSVFileName;
    ofSA = new OneframeSoftAssert();
    try {
      this.reader = Files.newBufferedReader(Paths.get(this.currCSVFileName, new String[0]), StandardCharsets.ISO_8859_1);
      this.OfcsvParser = new CSVParser(this.reader, CSVFormat.EXCEL);
      this.ofCSVRecords = this.OfcsvParser.getRecords();
      OneframeContainer.OneframeLogger("Opened CSV file - " + this.currCSVFileName);
    } catch (IOException e) {
      OneframeContainer.OneframeErrorLogger(e.getMessage());
    } 
  }
  
  public CSVFile OpenFile() {
    if (this.OfcsvParser == null) {
      OneframeLogger.ErrorLog("CSV file is not initialized");
      System.exit(0);
    } 
    return this;
  }
  
  public void CloseFile() {
    this.OfcsvParser = null;
  }
  
  public int getTotalRowCount() {
    int rowCounter = 0;
    if (this.ofCSVRecords.isEmpty()) {
      OneframeContainer.OneframeErrorLogger("No records found");
      return 0;
    } 
    rowCounter = this.ofCSVRecords.size();
    return rowCounter;
  }
  
  public int getTotalColumnCount() {
    int colCount = 0;
    colCount = ((CSVRecord)this.ofCSVRecords.get(0)).size();
    return colCount;
  }
  
  public String[] getRowContentByKeyValue(String KeyColumn, String KeyValue) {
    return getRowContentByRowNumber(getRowIdentifier(KeyColumn, KeyValue));
  }
  
  public String[][] getRowsContentByKeyValue(String KeyColumn, String KeyValue) {
    int RowIdentifier = 0;
    int cols = getTotalColumnCount();
    int rows = getRowsCountByKeyValue(KeyColumn, KeyValue);
    int TotalRows = getTotalRowCount();
    int keyColid = getColIndexByName(KeyColumn);
    int rowCounter = 0;
    String[][] RowsContent = new String[rows][cols];
    for (int i = 0; i < TotalRows; i++) {
      String colValue = ReadCellActRef(i, keyColid);
      if (colValue.contentEquals(KeyValue)) {
        RowIdentifier = i + 1;
        RowsContent[rowCounter] = getRowContentByRowNumber(RowIdentifier);
        rowCounter++;
      } 
    } 
    return RowsContent;
  }
  
  public int getRowsCountByKeyValue(String KeyColumn, String KeyValue) {
    int rowCounter = 0;
    int TotalRows = getTotalRowCount();
    int keyColid = getColIndexByName(KeyColumn);
    for (int i = 0; i < TotalRows; i++) {
      String colValue = ReadCellActRef(i, keyColid);
      if (colValue.contentEquals(KeyValue))
        rowCounter++; 
    } 
    return rowCounter;
  }
  
  public String[] getRowContentByRowNumber(int RowNumber) {
    if (RowNumber < 0) {
      OneframeContainer.OneframeLogger("Invalid Row or no matching row found for the key value");
      return null;
    } 
    String[] RowContent = new String[getTotalColumnCount()];
    int acRowRef = getCellRef(RowNumber);
    for (int i = 0; i < getTotalColumnCount(); i++)
      RowContent[i] = ReadCellActRef(acRowRef, i); 
    return RowContent;
  }
  
  private String ReadCellActRef(int RowNbr, int ColNbr) {
    String cellValue = null;
    cellValue = ((CSVRecord)this.ofCSVRecords.get(RowNbr)).get(ColNbr);
    return cellValue;
  }
  
  public String ReadCell(int RowNbr, int ColNbr) {
    return ReadCellActRef(getCellRef(RowNbr), getCellRef(ColNbr));
  }
  
  public String ReadCell(int RowNbr, String ColumnName) {
    return ReadCell(RowNbr, getColIndexByName(ColumnName) + 1);
  }
  
  public String ReadCell(String KeyColumn, String KeyValue, String ColumnName) {
    return ReadCell(getRowIdentifier(KeyColumn, KeyValue) + 1, ColumnName);
  }
  
  public String[] getColumnHeaders() {
    int headerRow = 0, i = 0;
    int totColumns = getTotalColumnCount();
    OneframeContainer.OneframeLogger("Total number of columns : " + totColumns);
    for (String colname : this.ofCSVRecords.get(headerRow)) {
      OneframeContainer.OneframeLogger("[ONEFRAME]CSV File => Row, Column (" + headerRow + "," + i + ") : " + colname);
      i++;
    } 
    return (String[])((CSVRecord)this.ofCSVRecords.get(0)).toList().toArray((Object[])new String[0]);
  }
  
  public CSVFile PrintColumnHeaders() {
    int headerRow = 0, i = 0;
    int totColumns = getTotalColumnCount();
    OneframeContainer.OneframeLogger("Total number of columns : " + totColumns);
    for (String colname : this.ofCSVRecords.get(headerRow)) {
      OneframeContainer.OneframeLogger("[ONEFRAME]CSV File => Row, Column (" + headerRow + "," + i + ") : " + colname);
      i++;
    } 
    return this;
  }
  
  private int getCellRef(int cellRef) {
    return cellRef - 1;
  }
  
  private int getRowIdentifier(String KeyColumn, String KeyValue) {
    int rowIdentifier = -1;
    int TotalRows = getTotalRowCount();
    int keyColid = getColIndexByName(KeyColumn);
    for (int i = 0; i < TotalRows; i++) {
      String colValue = ReadCellActRef(i, keyColid);
      if (colValue.contentEquals(KeyValue)) {
        rowIdentifier = i;
        break;
      } 
    } 
    return rowIdentifier;
  }
  
  private int getColIndexByName(String ColName) {
    for (int i = 0; i < ((CSVRecord)this.ofCSVRecords.get(0)).size(); i++) {
      if (ColName.contentEquals(((CSVRecord)this.ofCSVRecords.get(0)).get(i)))
        return i; 
    } 
    OneframeContainer.OneframeLogger("Column [" + ColName + "] not found in the Excel Sheet");
    return -1;
  }
  
  public void WriteToCell(int row, int col, String CellValue) {
    OneframeContainer.OneframeErrorLogger("This function is yet to be implemented");
  }
  
  public CSVFile WriteToCell(String KeyColumn, String KeyValue, String ColumnName, String CellValue) {
    OneframeContainer.OneframeErrorLogger("This function is yet to be implemented");
    return this;
  }
  
  public CSVFile WriteToCell(int RowNbr, String ColumnName, String CellValue) throws IOException {
    OneframeContainer.OneframeErrorLogger("This function is yet to be implemented");
    int colNum = getColIndexByName(ColumnName);
    FileInputStream inputStream = new FileInputStream(this.currCSVFileName);
    inputStream.close();
    FileOutputStream outputStream = null;
    outputStream = new FileOutputStream(this.currCSVFileName);
    outputStream.close();
    return this;
  }
  
  public CSVFile validateColumnHeaders(String[] ExpectedColumns) {
    String[] actualColumns = getColumnHeaders();
    for (int i = 0; i < ExpectedColumns.length; i++)
      ofSA.assertEquals(actualColumns[i], ExpectedColumns[i], "Validate column header name for column(" + (i + 1) + ")"); 
    return this;
  }
  
  public CSVFile validateColumn(int RowIdentifier, String ColumnName, String ExpectedValue) {
    String xlCellValue = ReadCell(RowIdentifier, ColumnName);
    ofSA.assertEquals(xlCellValue, ExpectedValue, "Validate column [" + ColumnName + "]");
    return this;
  }
  
  public CSVFile validateColumn(String KeyColumn, String KeyValue, String ColumnName, String ExpectedValue) {
    String xlCellValue = ReadCell(KeyColumn, KeyValue, ColumnName);
    ofSA.assertEquals(xlCellValue, ExpectedValue, "Validate column [" + ColumnName + "]");
    return this;
  }
  
  public CSVFile validateColumns(int RowIdentifier, String[] ColumnNames, String[] ExpectedValues) {
    return this;
  }
  
  public CSVFile validateColumns(String KeyColumn, String KeyValue, String[] ColumnNames, String[] ExpectedValues) {
    return this;
  }
  
  protected void finalize() {
    CloseFile();
  }
}
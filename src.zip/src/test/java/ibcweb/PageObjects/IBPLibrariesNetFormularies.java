package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

public class IBPLibrariesNetFormularies extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//a[contains(@href, '/admin/library/formularies/base-formularies')]")
	WebElement lnkViewFormulary;

	@FindBy(xpath = "//div[text()=\"Formularies\"]")
	WebElement hdrFormularies;

	@FindBy(xpath = "//*[text()=\" Net Formularies \"]")
	WebElement tabNetFormulary;

	@FindBy(xpath = "//*[text()=\" Create a Net Formulary \"]")
	WebElement btnCreateNetFormulary;

	@FindBy(xpath = "//h3[text()=\"Create a Net Formulary\"]")
	WebElement hdrCreateANetFormulary;

	@FindBy(xpath = "//input[@placeholder='Enter Formulary']")
	WebElement newNetFormularyFormularyIdDropdown;

	@FindBy(xpath = "//*[text()=\" CA Select \"]")
	WebElement newNetFormularyIdDropdown;

	@FindBy(xpath = "//input[@formcontrolname='formularyIdentifier']")
	WebElement newNetFormularyNetFormularyIdTextField;

	@FindBy(xpath = "//input[@formcontrolname='adjudicationFormularyId']")
	WebElement newNetFormularyAdjudicationFormularyIdTextField;

	@FindBy(xpath = "//*[@data-automation-id='newNetFormularyTiers']")
	WebElement newNetFormularyNumberTiersDropdown;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> newNetFormularyTiersDropdown;
	
	@FindBy(xpath="//h3[text()='Formulary Data']")
	WebElement hdrFormularyData;

	@FindBy(xpath = "//*[@formcontrolname='costShareTierStructureId']")
	WebElement newNetFormularyCostShareTierStructureDropdown;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> netFormularyCostShareDropdown;

	@FindBy(xpath = "//*[@formcontrolname='formularyName']")
	WebElement newNetFormularyNetFormularyNameTextField;

	@FindBy(xpath = "//*[@formcontrolname='effectiveDate']")
	WebElement effectiveDate;

	@FindBy(xpath = "//*[@formcontrolname='clients']/..")
	WebElement newNetFormularyClientDropdown;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> clientDropdown;

	@FindBy(xpath = "//*[@formcontrolname='lobs']")
	WebElement newNetFormularyLOBDropdown;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> LOBDropdown;

	@FindBy(xpath = "//*[@formcontrolname='states']")
	WebElement newNetFormularyStateDropdown;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> StateDropdown;

	@FindBy(xpath = "//*[@formcontrolname='employerGroup']")
	WebElement newNetFormularyEmployerGroupDropdown;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> EmployerGroupDropdown;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyManagedBy\"]")
	WebElement newNetFormularyManagedBy;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> ManagedByDropdown;

	@FindBy(xpath = "//*[@formcontrolname='formularyUrl']")
	WebElement newNetFormularyFormularyLinkTextField;

	@FindBy(xpath = "//*[@placeholder=\"Enter Formulary Tag\"]")
	WebElement formularyTags;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> formularyTagsDropdown;

	@FindBy(xpath = "//*[@class=\"mat-chip mat-focus-indicator mat-primary mat-standard-chip mat-chip-with-trailing-icon ng-star-inserted\"]")
	WebElement formularyTagAdded;

	@FindBy(xpath = "//*[text()=\" Add Formulary \"]")
	WebElement btnAddFormulary;

	@FindBy(xpath = "//*[@formcontrolname='stopSaleDate']")
	WebElement txtStopSaleDate;

	@FindBy(xpath = "//*[@formcontrolname='termDate']")
	WebElement txtTermDate;

	@FindBy(xpath = "//*[@formcontrolname='implementationDate']")
	WebElement txtImpDate;

	@FindBy(xpath = "//div[@class='cdk-overlay-backdrop cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing']")
	WebElement cdkOverlay;

	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;

	@FindBy(xpath = "//*[@class=\"mat-paginator-icon\"]")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-netFormularyName mat-column-netFormularyName ng-star-inserted\"]")
	List<WebElement> lstNetFormularyName;

	@FindBy(xpath = "//*[text()=' Save changes ']")
	WebElement btnSaveChanges;

	@FindBy(xpath = "//span[text()='Formulary tier number 4 does not match with existing tier number 2']")
	WebElement txtTierNoMatchMessage;

	@FindBy(xpath = "//span[text()='Error saving create a new net formulary. Check console for error']")
	WebElement txtErrorSavingMessage;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> lstdrpDownManagedBy;

	@FindBy(xpath = "//*[@formcontrolname='clientValue']")
	WebElement drdClientFilters;

	@FindBy(xpath = "//*[@formcontrolname='lobValue']")
	WebElement drdLOBFilters;

	@FindBy(xpath = "//*[@formcontrolname='stateValue']")
	WebElement drdStateFilters;

	@FindBy(xpath = "//*[@formcontrolname='tiersValue']")
	WebElement drdTiersFilters;

	@FindBy(xpath = "//*[@formcontrolname='tierStructureValue']")
	WebElement drdTierStructureFilters;

	@FindBy(xpath = "//*[@formcontrolname='tagsValue']")
	WebElement drdTagsFilter;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-tiers mat-column-tiers ng-star-inserted\"]")
	List<WebElement> lstTiers;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-costShareTierStructure mat-column-costShareTierStructure ng-star-inserted\"]")
	List<WebElement> lstTierStructure;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-tags mat-column-tags ng-star-inserted\"]")
	List<WebElement> lstTagsFilter;

	@FindBy(xpath = "//*[@type=\"text\"]")
	WebElement txtFormularyField;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-formularyId mat-column-formularyId ng-star-inserted\"]")
	List<WebElement> lstFormularyId;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyIdentifier\"]")
	WebElement txtNetFormularyIdField;

	@FindBy(xpath = "//*[@formcontrolname=\"adjudicationFormularyId\"]")
	WebElement txtNetAdjudicationFormularyIdField;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyTiers\"]")
	WebElement txtNetFormularyTiersField;

	@FindBy(xpath = "//*[@formcontrolname=\"costShareTierStructureId\"]")
	WebElement txtNetCostShareTierStructureIdField;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyName\"]")
	WebElement txtNetFormularyField;

	@FindBy(xpath = "//*[@formcontrolname=\"effectiveDate\"]")
	WebElement txtEffectiveField;

	@FindBy(xpath = "//*[@formcontrolname=\"stopSaleDate\"]")
	WebElement txtStopSaleDateField;

	@FindBy(xpath = "//*[@formcontrolname=\"termDate\"]")
	WebElement txtTermDateField;

	@FindBy(xpath = "//*[@formcontrolname=\"clients\"]")
	WebElement txtClientField;

	@FindBy(xpath = "//*[@formcontrolname=\"lobs\"]")
	WebElement txtLOBField;

	@FindBy(xpath = "//*[@formcontrolname=\"states\"]")
	WebElement txtStateField;

	@FindBy(xpath = "//*[@formcontrolname=\"employerGroup\"]")
	WebElement txtNetEmployedGroupField;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyManagedBy\"]")
	WebElement txtManagedByField;

	@FindBy(xpath = "//*[@formcontrolname=\"implementationDate\"]")
	WebElement txtImplementationDateField;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyUrl\"]")
	WebElement txtFormularyLinkField;

	@FindBy(xpath = "//*[@formcontrolname=\"tags\"]")
	WebElement txtNetTagsField;

	@FindBy(xpath = "//h3[text()='Create a Drug Exception List']")
	WebElement hdrCreateADrugException;

	@FindBy(xpath = "//*[text()=' Add Drug Exception List ']")
	WebElement btnAddDrugExceptionList;

	@FindBy(xpath = "//*[contains(text(),'was added')]")
	WebElement txtAddedDrugException;
	
	@FindBy(xpath = "//*[contains(text(),'was succesfully created')]")
	WebElement txtNetFormularyCreated;
	
	@FindBy(xpath = "//*[@formcontrolname='terminationDate']")
	WebElement txtTerminationDate;

	public IBPLibrariesNetFormularies() {
		// Initializing the Page Objects
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click Formulary View button")
	public void clickFormularyViewButton() {
		if (ObjectExist(lnkViewFormulary)) {
			lnkViewFormulary.click();
			OneframeLogger("Clicked Formulary View button");
		}
	}

	@Step("Verify Formulary header is displayed")
	public boolean verifyFormularyHeader() {
		boolean flag = false;
		if (ObjectExist(hdrFormularies)) {
			if (hdrFormularies.getText().equalsIgnoreCase("Formularies")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click on Formularies header")
	public void clickFormulariesHeader() {
		hdrFormularies.click();
		hdrFormularies.click();
		hdrFormularies.click();
	}

	@Step("Click Net Formulary tab")
	public void clickNetFormularyTab() {
		tabNetFormulary.click();
		OneframeLogger("Clicked Net formulary tab");
	}

	@Step("Click on Create a Net Formulary button")
	public void clickCreateNetFormularyButton() {
		btnCreateNetFormulary.click();
		OneframeLogger("Clicked on Create Net Formulary button");
	}

	@Step("Verify Create A Net Formulary header is displayed")
	public boolean verifyCreateANetFormularyHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCreateANetFormulary)) {
			if (hdrCreateANetFormulary.getText().equalsIgnoreCase("Create a Net Formulary")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Select value from FormularyID dropdown")
	public boolean selectValueFromFormularyIDDropdown(String itemName) throws InterruptedException {
		boolean flag = false;
		if (WaitForObjectVisibility(newNetFormularyFormularyIdDropdown));
		newNetFormularyFormularyIdDropdown.click();
		newNetFormularyFormularyIdDropdown.sendKeys(itemName);
		Thread.sleep(3000);
		lstdrpDownManagedBy.get(0).click();
		OneframeLogger("Selected formulary Id:" + newNetFormularyFormularyIdDropdown.getAttribute("value"));
		flag = true;

		return flag;
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Get Random Numeric value")
	public String getRandomNumericValue(int length) {
		String value = "";
		String letters = "123456789";
		for (int i = 0; i < length; i++) {
			value += letters.charAt((int) Math.floor(Math.random() * letters.length()));
		}
		return value;
	}

	@Step("Enter Random value to Net formuary ID")
	public boolean inputRandomNumericValueInNetFormularyID() {
		boolean bln = false;
		if (ObjectExist(newNetFormularyNetFormularyIdTextField)) {
			String randomNumericValue = getRandomNumericValue(4);
			// newNetFormularyNetFormularyIdTextField.clear();
			newNetFormularyNetFormularyIdTextField.sendKeys(randomNumericValue);
			OneframeLogger("Entered Random value in Net formulary field is : " + randomNumericValue);
			bln = true;
		}
		return bln;
	}

	@Step("Enter Random value to Adjudication Formulary ID")
	public boolean inputRandomNumericValueInAdjudicationFormularyID() {
		boolean bln = false;
		if (ObjectExist(newNetFormularyAdjudicationFormularyIdTextField)) {
			String randomNumericValueAdjudicationID = getRandomNumericValue(5);
			// newNetFormularyAdjudicationFormularyIdTextField.clear();
			newNetFormularyAdjudicationFormularyIdTextField.sendKeys(randomNumericValueAdjudicationID);
			OneframeLogger("Enter Random value in Adjudication Formulary ID field:" + randomNumericValueAdjudicationID);
			bln = true;
		}
		return bln;
	}

	@Step("Select Tiers value")
	public boolean selectTiersValue() {
		boolean bln = false;
		if (ObjectExist(newNetFormularyNumberTiersDropdown)) {
			newNetFormularyNumberTiersDropdown.click();
			newNetFormularyTiersDropdown.get(0).click();
			OneframeLogger(
					"Selected first value from tier dropdown : " + newNetFormularyNumberTiersDropdown.getText());
			bln = true;
		}
		return bln;
	}

	@Step("Select Cost share tier structure")
	public boolean selectCostShareTierStructure(String costshare) {
		boolean bln = false;
		hdrFormularyData.click();
		hdrFormularyData.click();
		if (WaitForObjectVisibility(newNetFormularyCostShareTierStructureDropdown)) {
			newNetFormularyCostShareTierStructureDropdown.click();
			selectDropdownValue(costshare);
			OneframeLogger("Selected first value from cost share tier structure dropdown : "
					+ newNetFormularyCostShareTierStructureDropdown.getText());
			bln = true;
		}
		return bln;
	}

	@Step("Select Cost share tier structure dropdown values")
	public void verifyAndSelectCostShareTierStructureDropdownValue(String costShareTierStructure) {
		boolean blnRC = false;
		try {
			if (ObjectExist(newNetFormularyNumberTiersDropdown)) {
				newNetFormularyCostShareTierStructureDropdown.click();
				selectDropdownValue(costShareTierStructure);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Tier dropdown");
			blnRC = false;
		}
		sa.assertTrue(blnRC, "Validated and selected Tier dropdown");

	}

	@Step("Get Random Alphabetical String")
	public String getRandomAlphabeticalString(int length) {
		String value = " ";
		String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		for (int i = 1; i < length; i++) {
			value += letters.charAt((int) Math.floor(Math.random() * letters.length()));
		}
		return "AUTO" + value;
	}

	@Step("Enter Random Alphabet for Net Formulary Name field")
	public String inputRandomAlphaNumericValueInNetFormularyNameField() {
		String randomString = getRandomAlphabeticalString(5);
		// newNetFormularyNetFormularyNameTextField.clear();
		newNetFormularyNetFormularyNameTextField.sendKeys(randomString);
		OneframeLogger("Enter Random value In Net Formulary Name Field : " + randomString);
		return randomString;
	}

	/*
	 * public void getAndInputCurrentDate () { Date today = new Date(); int dd =
	 * today.getDate(); int mm = today.getMonth() + 1; int yyyy = today.getYear();
	 * 
	 * if (dd < 10) { dd = '0' + dd; }
	 * 
	 * if (mm < 10) { mm = '0' + mm; }
	 * 
	 * int today1 = mm + '/' + dd + '/' + yyyy; effectiveDate.sendKeys(today1); } }
	 * 
	 * public void getcurrentDate() { LocalDate endDt = LocalDate.now();
	 * effectiveDate.sendKeys(endDt); }
	 */

	@Step("Select Client Dropdown")
	public void selectClientDropdown(String Client) {
		newNetFormularyClientDropdown.click();
		selectDropdownValues(Client);
		// cdkOverlay.sendKeys(Keys.ESCAPE);
		hdrCreateANetFormulary.click();
		OneframeLogger("Selected first client dropdown ");
	}

	@Step("Select LOB Dropdown")
	public void selectLOBDropdown(String LOB) {
		newNetFormularyLOBDropdown.click();
		selectDropdownValues(LOB);
		hdrCreateANetFormulary.click();
		OneframeLogger("Selected first client dropdown ");
	}

	@Step("Select State Dropdown")
	public boolean selectStateDropdown(String State) throws AWTException {
		boolean bln = false;
		if (WaitForObjectVisibility(newNetFormularyStateDropdown)) {
			//newNetFormularyStateDropdown.click();
			ClickWebObject(newNetFormularyStateDropdown);
			selectDropdownValue(State);
			//hdrCreateANetFormulary.click();
			Robot rt = new Robot();
			rt.keyPress(KeyEvent.VK_TAB);
			OneframeLogger("Selected first client dropdown ");
			bln = true;
		}
		return bln;
	}

	@Step("Select Employer Group Dropdown")
	public boolean selectEmployerGroupDropdown() {
		boolean bln = false;
		if (ObjectExist(newNetFormularyEmployerGroupDropdown)) {
			newNetFormularyEmployerGroupDropdown.click();
			EmployerGroupDropdown.get(0).click();
			OneframeLogger("Selected first Employer Group dropdown : " + EmployerGroupDropdown.get(0).getText());
			bln = true;
		}
		return bln;
	}

	@Step("Select ManagedBy Dropdown")
	public boolean selectManagedByDropdown() {
		boolean bln = false;
		if (ObjectExist(newNetFormularyManagedBy)) {
			newNetFormularyManagedBy.click();
			ManagedByDropdown.get(0).click();
			OneframeLogger("Selected first ManagedBy dropdown : " + ManagedByDropdown.get(0).getText());
			bln = true;
		}
		return bln;
	}

	@Step("Enter Formulary link")
	public boolean inputValueInFormularyLinkField(String text) {
		boolean bln = false;
		if (ObjectExist(newNetFormularyFormularyLinkTextField)) {
			// newNetFormularyFormularyLinkTextField.clear();
			newNetFormularyFormularyLinkTextField.sendKeys(text);
			OneframeLogger("Entered Formulary link : " + text);
			bln = true;
		}
		return bln;
	}

	@Step("Select Formulary tag")
	public boolean selectFormularyTagsDropdown() {
		boolean bln = false;
		if (ObjectExist(formularyTags)) {
			formularyTags.click();
			formularyTagsDropdown.get(0).click();
			OneframeLogger("Selected first Formulary tags : " + formularyTagAdded.getText());
			bln = true;
		}
		return bln;
	}

	@Step("Click Add Formulary button")
	public void clickAddFormularyButton() {
		btnAddFormulary.click();
		OneframeLogger("Clicked Add Formulary button");
	}

	@Step("Enter Effective date")
	public void EnterEffectiveDate(String EffectiveDate) throws AWTException {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(effectiveDate)) {
				ClickWebObject(effectiveDate);
				EnterText(effectiveDate, EffectiveDate);
				OneframeLogger("EffectiveDate Date has been Entered: " + effectiveDate.getAttribute("value"));

			}
		} catch (TimeoutException e) {
			OneframeLogger("EffectiveDate Date has been Entered");
		}
	}

	@Step("Enter StopSale date")
	public void EnterStopSaleDate(String StopSaleDate) throws AWTException {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtStopSaleDate)) {
				ClickWebObject(txtStopSaleDate);
				EnterText(txtStopSaleDate, StopSaleDate);
				OneframeLogger("StopSale Date has been Entered: " + txtStopSaleDate.getAttribute("value"));
				
			}
		} catch (TimeoutException e) {
			OneframeLogger("StopSale Date has been Entered");
		}
	}

	@Step("Enter Term date")
	public void EnterTermDate(String TermDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtTerminationDate)) {
				ClickWebObject(txtTerminationDate);
				EnterText(txtTerminationDate, TermDate);
				OneframeLogger("Term Date has been Entered : " + txtTerminationDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Term Date has been Entered");
		}
	}

	@Step("Verify Net Formulary is created")
	public boolean VerifyNetFormularyIsCreated(String netFormularyName) throws InterruptedException {
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstNetFormularyName.size(); i++) {
					if (lstNetFormularyName.get(i).getText().equalsIgnoreCase(netFormularyName)) {
						highlightElement(lstNetFormularyName.get(i));
						OneframeLogger("Mandate is created : " + lstNetFormularyName.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
					// clickMandatesHeader();
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException exc) {

		}
		return bln;
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
		return dropdownvalue.getText();
	}

	@Step("Click Save Changes button")
	public void clickSaveChangesButton() {
		ObjectExist(btnSaveChanges);
		ClickWebObject(btnSaveChanges);
		OneframeLogger("Save Changes button clicked");
	}

	@Step("Verify Tier Does not match message is displayed ")
	public void verifyTierDoesNotMatchMessage() {
		ObjectExist(txtTierNoMatchMessage);
		if (txtTierNoMatchMessage.isDisplayed()) {
			highlightElement(txtTierNoMatchMessage);
		} else {
			OneframeLogger("Message is not displayed");
		}
		sa.assertEquals(txtTierNoMatchMessage.getText(),
				"Formulary tier number 4 does not match with existing tier number 2",
				"Validated Tier Does Not Match Message is displayed");
	}

	@Step("Verify Error Saving message is displayed ")
	public void verifyErrorSavingMessage() {
		ObjectExist(txtErrorSavingMessage);
		if (txtErrorSavingMessage.isDisplayed()) {
			highlightElement(txtErrorSavingMessage);
		} else {
			OneframeLogger("Error Saving Message is not displayed");
		}
		sa.assertEquals(txtErrorSavingMessage.getText(),
				"Error saving create a new net formulary. Check console for error",
				"Validated Error Saving Message is displayed");
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
		WebElement secondElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(secondElement);
		return dropdownvalue.getText();

	}

	@Step("Select the values from dropdowns")
	public String selDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[text()='%s']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
		WebElement secondElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(secondElement);
		return dropdownvalue.getText();

	}

	@Step("Enter Implementation date")
	public void EnterImplementationDate(String txtImplDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtImpDate)) {
				ClickWebObject(txtImpDate);
				EnterText(txtImpDate, txtImplDate);
				OneframeLogger("Implementaton Date has been Entered : " + txtImpDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Implementaton Date has been Entered");
		}
	}

	@Step("Select and Get client Filter dropdownvalue ")
	public String selectAndGetClientDropdownValue(String client) {
		try {
			if (WaitForObject(drdClientFilters)) {
				drdClientFilters.click();
				String clientVal = selectDropdownValues(client);
				OneframeLogger("The Selected client Dropdown value is : " + clientVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Client dropdown ");

		}
		return drdClientFilters.getText();
	}

	@Step("Select and Get Lob Filter dropdown value")
	public String selectAndGetLobFilterDropdownValue(String lob) {
		try {
			if (WaitForObject(drdLOBFilters)) {
				drdLOBFilters.click();
				String lobVal = selectDropdownValues(lob);
				OneframeLogger("The Selected lob Dropdown value is : " + lobVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Lob dropdown ");

		}
		return drdLOBFilters.getText();
	}

	@Step("Select and Get State Filter dropdown value")
	public String selectAndGetStateFilterDropdownValue(String State) {
		try {
			if (WaitForObject(drdStateFilters)) {
				drdStateFilters.click();
				String stateVal = selectDropdownValues(State);
				OneframeLogger("The Selected State Dropdown value is : " + stateVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select State dropdown ");
		}
		return drdStateFilters.getText();
	}

	@Step("Select and Get State Filter dropdown value")
	public String selectAndGetStateFilterDropdownVal(String State) {
		try {
			if (WaitForObject(drdStateFilters)) {
				drdStateFilters.click();
				String stateVal = selectDropdownValue(State);
				OneframeLogger("The Selected State Dropdown value is : " + stateVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select State dropdown ");
		}
		return drdStateFilters.getText();
	}

	@Step("Select and Get tags Filter dropdown value")
	public String selectAndGetTagsFilterDropdownValue(String tags) {
		try {
			if (WaitForObject(drdTagsFilter)) {
				drdTagsFilter.click();
				String tagsVal = selDropdownValues(tags);
				OneframeLogger("The Selected Tags Dropdown value is : " + tagsVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Tags dropdown ");
		}
		return drdTagsFilter.getText();
	}

	@Step("Select and Get tiers Filter dropdown value")
	public String selectAndGetTiersFilterDropdownValue(String tiers) {
		try {
			if (WaitForObject(drdTiersFilters)) {
				drdTiersFilters.click();
				String tiersVal = selectDropdownValue(tiers);
				OneframeLogger("The Selected Tiers Dropdown value is : " + tiersVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Tiers dropdown ");
		}
		return drdTiersFilters.getText();
	}

	@Step("Select and Get tiers Structure Filter dropdown value")
	public String selectAndGetTiersStructureFilterDropdownValue(String tiers) {
		try {
			if (WaitForObject(drdTierStructureFilters)) {
				drdTierStructureFilters.click();
				String tiersVal = selectDropdownValue(tiers);
				OneframeLogger("The Selected Tiers Structure Dropdown value is : " + tiersVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Tiers Structure dropdown ");
		}
		return drdTierStructureFilters.getText();
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-container\"]"));
		ClickWebObject(overlayElement);
	}

	@Step("Verify the Tiers filtered value is Same as Expected")
	public void verifyTiersFilteredList(String tiers) {
		WaitForObjectVisibility(lstTiers.get(0));
		highlightElement(lstTiers.get(0));
		sa.assertEquals(lstTiers.get(0).getText(), tiers, "Verified Tiers value is same as expected");
	}

	@Step("Verify the Tiers Structure filtered value is Same as Expected")
	public void verifyTierStructureFilteredList(String tierStructure) {
		WaitForObjectVisibility(lstTierStructure.get(0));
		highlightElement(lstTierStructure.get(0));
		sa.assertEquals(lstTierStructure.get(0).getText(), tierStructure,
				"Verified Tiers Structure value is same as expected");
	}

	@Step("Verify the tags Structure filtered value is Same as Expected")
	public void verifyTagsFilteredList(String tags) {
		WaitForObjectVisibility(lstTagsFilter.get(0));
		highlightElement(lstTagsFilter.get(0));
		sa.assertEquals(lstTagsFilter.get(0).getText(), tags, "Verified tags value is same as expected");
	}

	@Step("Click on first record of Net Formulary")
	public void clickFirstRecordOfNetFormulary() {
		WaitForObjectVisibility(lstFormularyId.get(0));
		lstFormularyId.get(0).click();
		OneframeLogger("Clicked on first record of Net Formulary");
	}

	@Step("Verify {netFormulary} field are displayed")
	public void verifyNetFormularyFieldsIsDisplayed(String netFormulary) {
		switch (netFormulary) {
		case "Formulary":
			if (txtFormularyField.isDisplayed()) {
				highlightElement(txtFormularyField);
				sa.assertTrue(true, "Verified Formulary Field is displayed");
			}
			break;
		case "Net Formulary ID":
			if (txtNetFormularyIdField.isDisplayed()) {
				highlightElement(txtNetFormularyIdField);
				sa.assertTrue(true, "Verified Net Formulary Id Field is displayed");
			}
			break;
		case "Adjudication Formulary ID":
			if (txtNetAdjudicationFormularyIdField.isDisplayed()) {
				highlightElement(txtNetAdjudicationFormularyIdField);
				sa.assertTrue(true, "Verified Adjudication Formulary ID Field is displayed");
			}
			break;
		case "Tiers":
			if (txtNetFormularyTiersField.isDisplayed()) {
				highlightElement(txtNetFormularyTiersField);
				sa.assertTrue(true, "Verified Tiers Field is displayed");
			}
			break;
		case "Cost Share Tier Structure":
			if (txtNetCostShareTierStructureIdField.isDisplayed()) {
				highlightElement(txtNetCostShareTierStructureIdField);
				sa.assertTrue(true, "Verified Cost Share Tier Structure Field is displayed");
			}
			break;
		case "Net Formulary Name":
			if (txtNetFormularyField.isDisplayed()) {
				highlightElement(txtNetFormularyField);
				sa.assertTrue(true, "Verified Net Formulary Name Field is displayed");
			}
			break;
		case "Client":
			if (txtClientField.isDisplayed()) {
				highlightElement(txtClientField);
				sa.assertTrue(true, "Verified Client Field is displayed");
			}
			break;
		case "LOB":
			if (txtLOBField.isDisplayed()) {
				highlightElement(txtLOBField);
				sa.assertTrue(true, "Verified LOB Field is displayed");
			}
			break;
		case "State":
			if (txtStateField.isDisplayed()) {
				highlightElement(txtStateField);
				sa.assertTrue(true, "Verified State Field is displayed");
			}
			break;
		case "Effective Date":
			if (txtEffectiveField.isDisplayed()) {
				highlightElement(txtEffectiveField);
				sa.assertTrue(true, "Verified Effective Date Field is displayed");
			}
			break;
		case "Stop Sale Date":
			if (txtStopSaleDateField.isDisplayed()) {
				highlightElement(txtStopSaleDateField);
				sa.assertTrue(true, "Verified Stop Sale Date Field is displayed");
			}
			break;
		case "Term Date":
			if (txtTermDateField.isDisplayed()) {
				highlightElement(txtTermDateField);
				sa.assertTrue(true, "Verified Term Date Field is displayed");
			}
			break;
		case "Managed By":
			if (txtManagedByField.isDisplayed()) {
				highlightElement(txtManagedByField);
				sa.assertTrue(true, "Verified Managed By Field is displayed");
			}
			break;
		case "Formulary Link":
			if (txtFormularyLinkField.isDisplayed()) {
				ScrollToElement(txtFormularyLinkField);
				highlightElement(txtFormularyLinkField);
				sa.assertTrue(true, "Verified Formulary Link Field is displayed");
			}
			break;
		case "Implementation Date":
			if (txtImplementationDateField.isDisplayed()) {
				highlightElement(txtImplementationDateField);
				sa.assertTrue(true, "Verified Implementation Date Field is displayed");
			}
			break;
		case "Employee Group":
			if (txtNetEmployedGroupField.isDisplayed()) {
				highlightElement(txtNetEmployedGroupField);
				sa.assertTrue(true, "Verified Employee Group Field is displayed");
			}
			break;
		case "Formulary Tags":
			if (txtNetTagsField.isDisplayed()) {
				highlightElement(txtNetTagsField);
				sa.assertTrue(true, "Verified Formulary Tags Field is displayed");
			}
			break;
		default:
			OneframeLogger(netFormulary + " Net formularies field is not displayed");

		}
	}

	@Step("Select Client Dropdown")
	public void DrugExceptionclientDropdown(String Client) {
		newNetFormularyClientDropdown.click();
		selectDropdownValues(Client);
		// cdkOverlay.sendKeys(Keys.ESCAPE);
		hdrCreateADrugException.click();
		OneframeLogger("Selected first client dropdown ");
	}

	@Step("Select LOB Dropdown")
	public void DrugExceptionLOBDropdown(String LOB) {
		newNetFormularyLOBDropdown.click();
		selectDropdownValues(LOB);
		hdrCreateADrugException.click();
		OneframeLogger("Selected first LOB dropdown ");
	}

	@Step("Select State Dropdown")
	public void DrugExceptionStateDropdown(String State) throws AWTException {
		newNetFormularyStateDropdown.click();
		selectStateDropdownValue(State);
		Robot rt = new Robot();
		rt.keyPress(KeyEvent.VK_TAB);
		// hdrCreateADrugException.click();
		OneframeLogger("Selected first State dropdown ");
	}

	@Step("Select the values from dropdowns")
	public void selectStateDropdownValue(String values) throws AWTException {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());

	}

	@Step("Click Add Drug Exception List button")
	public void clickAddDrugExceptionListButton() {
		ObjectExist(btnAddDrugExceptionList);
		ClickWebObject(btnAddDrugExceptionList);
		OneframeLogger("Add Drug Exception List button clicked");
	}

	@Step("Verify Added message when Drug Exception is created")
	public boolean verifyDrugExceptionAddedMessage() {
		boolean bln = false;
		if (ObjectExist(txtAddedDrugException)) {
			highlightElement(txtAddedDrugException);
			txtAddedDrugException.isDisplayed();
			OneframeLogger(" Added Message is " + txtAddedDrugException.getText());
			bln = true;
		}
		return bln;
	}
	
	@Step("Verify message when Net Formulary is created")
	public boolean verifyNetFormularyCreateddMessage() {
		boolean bln = false;
		if (WaitForObjectVisibility(txtNetFormularyCreated)) {
			highlightElement(txtNetFormularyCreated);
			txtNetFormularyCreated.isDisplayed();
			OneframeLogger(" Added Message is " + txtNetFormularyCreated.getText());
			bln = true;
		}
		
		return bln;
	}

}

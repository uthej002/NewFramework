// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeAssertion;
import java.util.ArrayList;
import org.apache.commons.csv.CSVPrinter;
import java.io.FileWriter;
import java.util.Iterator;
import anthem.irx.oneframe.core.OneframeLogger;
import java.io.IOException;
import anthem.irx.oneframe.core.OneframeContainer;
import java.io.Reader;
import org.apache.commons.csv.CSVFormat;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import anthem.irx.oneframe.core.OneframeConstants;
import java.io.BufferedReader;
import org.apache.commons.csv.CSVRecord;
import java.util.List;
import org.apache.commons.csv.CSVParser;
import java.io.File;

public class CSVFile
{
    private File CSVFile;
    private CSVParser OfcsvParser;
    private List<CSVRecord> ofCSVRecords;
    private String[][] UpdCSVRecords;
    private BufferedReader reader;
    private String currCSVFileName;
    private String currCSVFolder;
    private String currCSVFile;
    private int totRowCount;
    private int totColCount;
    private static final String COMMA = ",";
    private static final String DEFAULT_SEPARATOR = ",";
    private static final String DOUBLE_QUOTES = "\"";
    private static final String EMBEDDED_DOUBLE_QUOTES = "\"\"";
    private static final String NEW_LINE_UNIX = "\n";
    private static final String NEW_LINE_WINDOWS = "\r\n";
    
    public CSVFile(final String CSVResourceFolderPath, final String CSVFileName) {
        this.currCSVFileName = CSVFileName;
        this.currCSVFolder = OneframeConstants.RESOURCES_FOLDER + CSVResourceFolderPath + "/";
        this.currCSVFile = this.currCSVFolder + CSVFileName;
        this.totRowCount = 0;
        try {
            this.reader = Files.newBufferedReader(Paths.get(this.currCSVFile, new String[0]), StandardCharsets.ISO_8859_1);
            this.OfcsvParser = new CSVParser((Reader)this.reader, CSVFormat.EXCEL);
            this.ofCSVRecords = (List<CSVRecord>)this.OfcsvParser.getRecords();
            OneframeContainer.OneframeLogger("Opened CSV file - " + this.currCSVFile);
        }
        catch (IOException e) {
            OneframeContainer.OneframeErrorLogger(e.getMessage());
        }
    }
    
    public CSVFile OpenFile() {
        if (this.OfcsvParser == null) {
            OneframeLogger.ErrorLog("CSV file is not initialized");
            System.exit(0);
        }
        else {
            this.totRowCount = this.getTotalRowCount();
            this.totColCount = this.getTotalColumnCount();
            if (this.totRowCount > 0 && this.totColCount > 0) {
                this.UpdCSVRecords = new String[this.totRowCount][this.totColCount];
                for (int i = 0; i < this.totRowCount; ++i) {
                    for (int j = 0; j < this.totColCount; ++j) {
                        try {
                            this.UpdCSVRecords[i][j] = this.ofCSVRecords.get(i).get(j);
                        }
                        catch (ArrayIndexOutOfBoundsException aioobExcep) {
                            this.UpdCSVRecords[i][j] = null;
                        }
                    }
                }
            }
            OneframeContainer.OneframeLogger("[" + this.ofCSVRecords.size() + "] records read from CSV file");
        }
        return this;
    }
    
    public void CloseFile() {
        this.OfcsvParser = null;
    }
    
    public int getTotalRowCount() {
        int rowCounter = 0;
        if (this.ofCSVRecords.isEmpty()) {
            OneframeContainer.OneframeErrorLogger("No records found");
            return 0;
        }
        rowCounter = this.ofCSVRecords.size();
        return rowCounter;
    }
    
    public int getTotalColumnCount() {
        int colCount = 0;
        colCount = this.ofCSVRecords.get(0).size();
        return colCount;
    }
    
    public String[] getRowContentByKeyValue(final String KeyColumn, final String KeyValue) {
        return this.getRowContentByRowNumber(this.getRowIdentifier(KeyColumn, KeyValue));
    }
    
    public String[][] getRowsContentByKeyValue(final String KeyColumn, final String KeyValue) {
        int RowIdentifier = 0;
        final int cols = this.getTotalColumnCount();
        final int rows = this.getRowsCountByKeyValue(KeyColumn, KeyValue);
        final int TotalRows = this.getTotalRowCount();
        final int keyColid = this.getColIndexByName(KeyColumn);
        int rowCounter = 0;
        final String[][] RowsContent = new String[rows][cols];
        for (int i = 0; i < TotalRows; ++i) {
            final String colValue = this.ReadCellActRef(i, keyColid);
            if (colValue.contentEquals(KeyValue)) {
                RowIdentifier = i + 1;
                RowsContent[rowCounter] = this.getRowContentByRowNumber(RowIdentifier);
                ++rowCounter;
            }
        }
        return RowsContent;
    }
    
    public int getRowsCountByKeyValue(final String KeyColumn, final String KeyValue) {
        int rowCounter = 0;
        final int TotalRows = this.getTotalRowCount();
        final int keyColid = this.getColIndexByName(KeyColumn);
        for (int i = 0; i < TotalRows; ++i) {
            final String colValue = this.ReadCellActRef(i, keyColid);
            if (colValue.contentEquals(KeyValue)) {
                ++rowCounter;
            }
        }
        return rowCounter;
    }
    
    public String[] getRowContentByRowNumber(final int RowNumber) {
        if (RowNumber < 0) {
            OneframeContainer.OneframeLogger("Invalid Row or no matching row found for the key value");
            return null;
        }
        final String[] RowContent = new String[this.getTotalColumnCount()];
        final int acRowRef = this.getCellRef(RowNumber);
        for (int i = 0; i < this.getTotalColumnCount(); ++i) {
            RowContent[i] = this.ReadCellActRef(acRowRef, i);
        }
        return RowContent;
    }
    
    private String ReadCellActRef(final int RowNbr, final int ColNbr) {
        String cellValue = null;
        try {
            cellValue = this.ofCSVRecords.get(RowNbr).get(ColNbr);
        }
        catch (ArrayIndexOutOfBoundsException aioobExcep) {
            OneframeContainer.OneframeLogger("[ONEFRAME]" + aioobExcep.getMessage());
        }
        return cellValue;
    }
    
    public String ReadCell(final int RowNbr, final int ColNbr) {
        return this.ReadCellActRef(this.getCellRef(RowNbr), this.getCellRef(ColNbr));
    }
    
    public String ReadCell(final int RowNbr, final String ColumnName) {
        return this.ReadCell(RowNbr, this.getColIndexByName(ColumnName) + 1);
    }
    
    public String ReadCell(final String KeyColumn, final String KeyValue, final String ColumnName) {
        return this.ReadCell(this.getRowIdentifier(KeyColumn, KeyValue) + 1, ColumnName);
    }
    
    public String[] getColumnHeaders() {
        final int headerRow = 0;
        int i = 0;
        final int totColumns = this.getTotalColumnCount();
        OneframeContainer.OneframeLogger("Total number of columns : " + totColumns);
        for (final String colname : this.ofCSVRecords.get(headerRow)) {
            OneframeContainer.OneframeLogger("[ONEFRAME]CSV File => Row, Column (" + headerRow + "," + i + ") : " + colname);
            ++i;
        }
        return this.ofCSVRecords.get(0).toList().toArray(new String[0]);
    }
    
    public CSVFile PrintColumnHeaders() {
        final int headerRow = 0;
        int i = 0;
        final int totColumns = this.getTotalColumnCount();
        OneframeContainer.OneframeLogger("Total number of columns : " + totColumns);
        for (final String colname : this.ofCSVRecords.get(headerRow)) {
            OneframeContainer.OneframeLogger("[ONEFRAME]CSV File => Row, Column (" + headerRow + "," + i + ") : " + colname);
            ++i;
        }
        return this;
    }
    
    private int getCellRef(final int cellRef) {
        return cellRef - 1;
    }
    
    private int getRowIdentifier(final String KeyColumn, final String KeyValue) {
        int rowIdentifier = -1;
        final int TotalRows = this.getTotalRowCount();
        final int keyColid = this.getColIndexByName(KeyColumn);
        for (int i = 0; i < TotalRows; ++i) {
            final String colValue = this.ReadCellActRef(i, keyColid);
            if (colValue.contentEquals(KeyValue)) {
                rowIdentifier = i;
                break;
            }
        }
        return rowIdentifier;
    }
    
    private int getColIndexByName(final String ColName) {
        for (int i = 0; i < this.ofCSVRecords.get(0).size(); ++i) {
            if (ColName.contentEquals(this.ofCSVRecords.get(0).get(i))) {
                return i;
            }
        }
        OneframeContainer.OneframeLogger("Column [" + ColName + "] not found in the Excel Sheet");
        return -1;
    }
    
    public CSVFile SaveCSVFile() throws IOException {
        final String editedFile = this.currCSVFileName;
        FileOpsHelper.deleteFile(this.currCSVFile);
        final CSVPrinter csvFilePrinter = new CSVPrinter((Appendable)new FileWriter(this.currCSVFolder + editedFile), CSVFormat.EXCEL);
        for (int i = 0; i < this.totRowCount; ++i) {
            final ArrayList<String> rowContent = new ArrayList<String>();
            for (int j = 0; j < this.totColCount; ++j) {
                rowContent.add(this.UpdCSVRecords[i][j]);
            }
            csvFilePrinter.printRecord(rowContent.toArray());
        }
        csvFilePrinter.flush();
        csvFilePrinter.close();
        OneframeContainer.OneframeLogger("CSV file was updated successfully !!!");
        return this;
    }
    
    private static String[] toArray(final CSVRecord rec) {
        final String[] arr = new String[rec.size()];
        int i = 0;
        for (final String str : rec) {
            arr[i++] = str;
        }
        return arr;
    }
    
    private static void print(final CSVPrinter printer, final String[] s) throws Exception {
        for (final String val : s) {
            printer.print((Object)((val != null) ? String.valueOf(val) : ""));
        }
        printer.println();
    }
    
    public CSVFile WriteToCell(final String KeyColumn, final String KeyValue, final String ColumnName, final String CellValue) {
        this.WriteToCell(this.getRowIdentifier(KeyColumn, KeyValue) + 1, this.getColIndexByName(ColumnName) + 1, CellValue);
        return this;
    }
    
    public CSVFile WriteToCell(final int RowNbr, final String ColumnName, final String CellValue) throws IOException {
        this.WriteToCell(RowNbr, this.getColIndexByName(ColumnName) + 1, CellValue);
        return this;
    }
    
    public CSVFile WriteToCell(final int row, final int col, final String CellValue) {
        final int actRow = row - 1;
        final int actCol = col - 1;
        this.UpdCSVRecords[actRow][actCol] = CellValue;
        OneframeContainer.OneframeLogger("Updated Row [" + (actRow + 1) + "], Column [" + (actCol + 1) + "] = [" + CellValue + "]");
        return this;
    }
    
    public CSVFile validateColumnHeaders(final String[] ExpectedColumns) {
        final String[] actualColumns = this.getColumnHeaders();
        for (int i = 0; i < ExpectedColumns.length; ++i) {
            OneframeAssertion.AssertResult("Validate column header name for column(" + (i + 1) + ")", actualColumns[i], ExpectedColumns[i]);
        }
        return this;
    }
    
    public CSVFile validateColumnHeaders(final String[] ExpectedColumns, final boolean IgnoreCaseSensitivity, final boolean IgnoreSpace) {
        final String[] actualColumns = this.getColumnHeaders();
        for (int i = 0; i < ExpectedColumns.length; ++i) {
            OneframeAssertion.AssertResult("Validate column header name for column(" + (i + 1) + ")", actualColumns[i], ExpectedColumns[i], IgnoreCaseSensitivity, IgnoreSpace);
        }
        return this;
    }
    
    public CSVFile validateColumn(final int RowIdentifier, final String ColumnName, final String ExpectedValue) {
        final String xlCellValue = this.ReadCell(RowIdentifier, ColumnName);
        OneframeAssertion.AssertResult("Validate column [" + ColumnName + "]", xlCellValue, ExpectedValue);
        return this;
    }
    
    public CSVFile validateColumn(final int RowIdentifier, final String ColumnName, final String ExpectedValue, final boolean IgnoreCaseSensitivity, final boolean IgnoreSpace) {
        final String xlCellValue = this.ReadCell(RowIdentifier, ColumnName);
        OneframeAssertion.AssertResult("Validate column [" + ColumnName + "]", xlCellValue, ExpectedValue, IgnoreCaseSensitivity, IgnoreSpace);
        return this;
    }
    
    public CSVFile validateColumn(final String KeyColumn, final String KeyValue, final String ColumnName, final String ExpectedValue) {
        final String xlCellValue = this.ReadCell(KeyColumn, KeyValue, ColumnName);
        OneframeAssertion.AssertResult("Validate column [" + ColumnName + "]", xlCellValue, ExpectedValue);
        return this;
    }
    
    public CSVFile validateColumn(final String KeyColumn, final String KeyValue, final String ColumnName, final String ExpectedValue, final boolean IgnoreCaseSensitivity, final boolean IgnoreSpace) {
        final String xlCellValue = this.ReadCell(KeyColumn, KeyValue, ColumnName);
        OneframeAssertion.AssertResult("Validate column [" + ColumnName + "]", xlCellValue, ExpectedValue, IgnoreCaseSensitivity, IgnoreSpace);
        return this;
    }
    
    public CSVFile validateColumns(final int RowIdentifier, final String[] ColumnNames, final String[] ExpectedValues) {
        return this;
    }
    
    public CSVFile validateColumns(final String KeyColumn, final String KeyValue, final String[] ColumnNames, final String[] ExpectedValues) {
        return this;
    }
    
    @Override
    protected void finalize() {
        this.CloseFile();
    }
}

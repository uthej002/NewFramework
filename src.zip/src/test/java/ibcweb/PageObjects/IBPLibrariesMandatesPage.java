package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.EnterText;
import static anthem.irx.oneframe.selenium.WebObjectHandler.FindObjectByLocatorNoWait;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;
import static anthem.irx.oneframe.selenium.WebObjectHandler.SelectDropDownListByValue;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForApplicationToLoadCompletely;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPLibrariesMandatesPage extends OneframeContainer {
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//a[@routerlink=\"/admin/library/mandates\"]")
	WebElement btnViewMandates;

	@FindBy(xpath = "//div[@class='mat-title title' and text()='Mandates']")
	WebElement hdrMandates;

	@FindBy(xpath = "//span[contains(text(),\"State\")]")
	WebElement btnStateMandateTab;

	@FindBy(xpath = "//span[contains(text(),\" Add a Federal Mandate \")]")
	WebElement AddFederalMandateButton;

	@FindBy(xpath = "//span[contains(text(),\" Add a State Mandate \")]")
	WebElement AddStateMandateButton;

	@FindBy(xpath = "//div[@class='content__heading' and text()='Add New Mandate']")
	WebElement hdrAddNewMandate;

	@FindBy(xpath = "//mat-select[@id='mat-select-15']/div/div[2]")
	WebElement drdAutoApply;

	@FindBy(xpath = "//mat-label[text()='Auto Apply']/../../preceding-sibling::mat-select/div/div[2]")
	WebElement federalAutoApply;

	@FindBy(xpath = "//*[@formcontrolname='name']")
	WebElement mandateNameField;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	WebElement dropdownOption;

	@FindBy(xpath = "//*[@formcontrolname='terminationDate']")
	WebElement terminationDate;

	@FindBy(xpath = "//*[@formcontrolname='nonSellableDate']")
	WebElement nonSellableDate;

	@FindBy(xpath = "//*[@data-automation-id='generalOverrides']")
	WebElement generalOverRideField;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> firstDropdownOption;

	@FindBy(xpath = "//*[@data-automation-id='networkOverrides']")
	WebElement networkOverRideField;

	@FindBy(xpath = "//*[@data-automation-id='costShareOverrides']")
	WebElement costShareOverrideField;

	@FindBy(xpath = "//*[@data-automation-id='accumsOverrides']")
	WebElement accumsOverrideField;

	@FindBy(xpath = "//*[@formcontrolname='priority']")
	WebElement priorityField;

	@FindBy(xpath = "//*[@formcontrolname='description']")
	WebElement descriptionField;

	@FindBy(xpath = "//*[@formcontrolname='details']")
	WebElement detailsField;

	@FindBy(xpath = "//*[@data-automation-id=\"autoOptInApplicability\"]")
	WebElement autoOPtApplicabiltyField;

	@FindBy(xpath = "//*[@data-automation-id='createMandates']")
	List<WebElement> dynamicLayerFields;

	@FindBy(xpath = "//input[@data-automation-id='implementationDate']")
	WebElement implementationDate;

	@FindBy(xpath = "//*[@data-automation-id=\"programCreateAddBtn\"]")
	WebElement addMandate;

	@FindBy(xpath = "//*[@class=\"mat-cell cdk-cell left left--w-15 cdk-column-programName mat-column-programName ng-star-inserted\"]")
	List<WebElement> mandateNameList;

	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell left left--w-15 cdk-column-programName mat-column-programName ng-star-inserted\"]")
	List<WebElement> lstProgramNameRecords;

	@FindBy(xpath = "//*[@class=\"mat-paginator-icon\"]")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//*[contains(text(),\"was successfully created.\")]")
	WebElement txtMandateCreated;

	@FindBy(xpath = "//div[@class=\"table\"]//table//thead")
	List<WebElement> hdrTable;

	@FindBy(xpath = "//input[@formcontrolname='variationOf']")
	WebElement inputVariationOf;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']//mat-option/span")
	List<WebElement> selectInputVariationOf;

	@FindBy(xpath = "//input[@formcontrolname='bill']")
	WebElement billField;

	@FindBy(xpath = "//mat-select[@formcontrolname='generalOverrides']")
	WebElement drdGeneralOverrides;

	@FindBy(xpath = "//mat-select[@formcontrolname='networkOverrides']")
	WebElement drdNetworkOverrides;

	@FindBy(xpath = "//mat-select[@formcontrolname='costSharesOverrides']")
	WebElement drdCostShareOverrides;

	@FindBy(xpath = "//mat-select[@formcontrolname='accumOverrides']")
	WebElement drdAccumOverrides;

	@FindBy(xpath = "//mat-select[@formcontrolname='drug']")
	WebElement drdDrugList;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center center--short cdk-column-effectiveDate mat-column-effectiveDate ng-star-inserted\"]")
	List<WebElement> lstEffectiveDate;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center center--short cdk-column-terminationDate mat-column-terminationDate ng-star-inserted\"]")
	List<WebElement> lstTerminationDate;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center cdk-column-client mat-column-client ng-star-inserted\"]")
	List<WebElement> lstClient;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center cdk-column-lob mat-column-lob ng-star-inserted\"]")
	List<WebElement> lstLOB;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center cdk-column-state mat-column-state ng-star-inserted\"]")
	List<WebElement> lstState;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center center--short cdk-column-generalOverrides mat-column-generalOverrides ng-star-inserted\"]")
	List<WebElement> lstGeneralOverride;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center center--short cdk-column-networkOverrides mat-column-networkOverrides ng-star-inserted\"]")
	List<WebElement> lstNetworkOverride;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center center--short cdk-column-costShareOverrides mat-column-costShareOverrides ng-star-inserted\"]")
	List<WebElement> lstCostShareOverride;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center center--short cdk-column-accumsOverrides mat-column-accumsOverrides ng-star-inserted\"]")
	List<WebElement> lstAccumsOverride;

	@FindBy(xpath = "//span[@class=\"cell__group__label\"]")
	List<WebElement> lstZeroCostShareDropdownValues;

	@FindBy(xpath = "//input[@formcontrolname=\"copay\"]")
	WebElement txtCopayField;

	@FindBy(xpath = "//input[@formcontrolname=\"coInsurance\"]")
	WebElement txtCoInsuranceField;

	@FindBy(xpath = "//input[@formcontrolname=\"min\"]")
	WebElement txtMinField;

	@FindBy(xpath = "//input[@formcontrolname=\"max\"]")
	WebElement txtMaxField;

	@FindBy(xpath = "//*[@formcontrolname=\"tier\"]")
	WebElement drdTier;

	@FindBy(xpath = "//span[text()='Cancel']")
	WebElement btnCancel;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()='Leave']")
	WebElement btnLeave;

	@FindBy(xpath = "//*[@data-automation-id=\"INN RetailField\"]")
	WebElement drdInnRetail;

	@FindBy(xpath = "//*[@data-automation-id=\"INN Home DeliveryField\"]")
	WebElement drdInnHomeDelivery;

	@FindBy(xpath = "//*[@data-automation-id=\"OON RetailField\"]")
	WebElement drdONNRetail;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> dropdownValues;

	// Initializing the Page Objects:
	public IBPLibrariesMandatesPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click View button of Mandates")
	public void clickViewButtonofMandates() {
		try {
			if (WaitForObject(btnViewMandates)) {
				ClickWebObject(btnViewMandates);
				OneframeLogger("Clicked on View button of Mandates");
			}
		} catch (TimeoutException e) {
			OneframeLogger("View button of Mandates is not Clicked");
		}
	}

	@Step("Verify Mandate header is displayed")
	public boolean verifyMandatesHeader() {
		boolean flag = false;
		if (ObjectExist(hdrMandates)) {
			if (hdrMandates.getText().equalsIgnoreCase("Mandates")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("click on Mandate header")
	public void clickMandatesHeader() throws InterruptedException {
		if (WaitForObject(hdrMandates)) {
			// Thread.sleep(2000);
			ClickWebObject(hdrMandates);
			ClickWebObject(hdrMandates);
			ClickWebObject(hdrMandates);
			OneframeLogger("Clicked on Mandate header");
		}
	}

	@Step("Click State Mandate Tab")
	public void clickStateMandateTab() {
		try {
			if (WaitForObject(btnStateMandateTab)) {
				ClickWebObject(btnStateMandateTab);
				OneframeLogger("Clicked State mandate tab");
			}
		} catch (TimeoutException e) {
			OneframeLogger("State mandate tab is not Clicked");
		}
	}

	@Step("Click Add State Mandate")
	public void clickAddStateMandate() {
		try {
			if (WaitForObject(AddStateMandateButton)) {
				ClickWebObject(AddStateMandateButton);
				OneframeLogger("Clicked on Clicked Add State Mandate button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add State Mandate button is not Clicked");
		}
	}

	@Step("Click Add Federal Mandate")
	public void clickAddFederalMandate() {
		try {
			if (WaitForObject(AddFederalMandateButton)) {
				ClickWebObject(AddFederalMandateButton);
				OneframeLogger("Clicked on Clicked Add Federal Mandate button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Federal Mandate button is not Clicked");
		}
	}

	@Step("Verify Add New Program header is displayed")
	public boolean verifyAddNewMandateHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAddNewMandate)) {
			if (hdrAddNewMandate.getText().equalsIgnoreCase("Add New Mandate")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Auto Apply Dropdown")
	public boolean verifyAutoApplyDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply)) {
				highlightElement(drdAutoApply);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Federal Auto Apply Dropdown")
	public boolean verifyFederalAutoApplyDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObject(federalAutoApply)) {
				highlightElement(federalAutoApply);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Federal Auto Apply Dropdown")
	public boolean selectFederalAutoApplyDropdown(String autoApply) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(dynamicLayerFields.get(0))) {
				ClickWebObject(dynamicLayerFields.get(0));
				selectDropdownValue(autoApply);
				// clickOverlayElement();
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select Federal Autoapply dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());

	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);

	}

	@Step("Select the values from dropdowns")
	public void selectDropdownVal(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()='%s']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);

	}

	@Step("Enter and Get Mandate Name")
	public String enterAndGetMandateName(String mandateNm) {
		if (WaitForObject(mandateNameField)) {
			ClickWebObject(mandateNameField);
			String mandate = mandateNm + " Mandate";
			int randomNumber = getRandomNumber();
			String mandateName = mandate + randomNumber;
			mandateNameField.sendKeys(mandateName);
			OneframeLogger("The Mandate Name is : " + mandateNameField.getAttribute("value"));
		}
		return mandateNameField.getAttribute("value");
	}

	@Step("Enter Variation Of")
	public String enterVariationOf(String variationOf) {
		if (WaitForObject(inputVariationOf)) {
			ClickWebObject(inputVariationOf);
			inputVariationOf.sendKeys(variationOf);
			hdrAddNewMandate.click();
			hdrAddNewMandate.click();
			hdrAddNewMandate.click();
			OneframeLogger("Entered VariationOf is : " + inputVariationOf.getAttribute("value"));
		}
		return inputVariationOf.getAttribute("value");
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Select General Override Dropdown")
	public boolean selectGeneralOverrideDropdownYes(String generalOverride) {
		boolean blnRC = false;
		try {
			if (WaitForObject(generalOverRideField)) {
				ClickWebObject(generalOverRideField);
				selectDropdownValue(generalOverride);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select General Override dropdown ");

			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Input Variation Dropdown")
	public boolean selectVariationOfDropdown(String variationOf) {
		boolean blnRC = false;

		try {
			if (WaitForObject(inputVariationOf)) {
				ClickWebObject(inputVariationOf);
				for (int i = 0; i < selectInputVariationOf.size(); i++) {
					String dropdownValue = selectInputVariationOf.get(i).getText().trim();
					if (dropdownValue.equalsIgnoreCase(variationOf)) {
						selectInputVariationOf.get(i).click();
					}
				}

				// clickOverlayElement();
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select General Override dropdown ");

			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select General Override Dropdown")
	public boolean selectGeneralOverrideDropdown(String generalOverride) {
		boolean blnRC = false;
		try {
			if (WaitForObject(generalOverRideField)) {
				ClickWebObject(generalOverRideField);
				selectDropdownValue(generalOverride);
				// clickOverlayElement();
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select General Override dropdown ");

			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Network Override Dropdown")
	public boolean selectNetworkOverrideDropdown(String networkOverride) throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObject(networkOverRideField)) {
				ClickWebObject(networkOverRideField);
				selectDropdownValue(networkOverride);
//				clickOverlayElement();
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select Network Override dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select CostShare Override Dropdown")
	public boolean selectCostShareOverrideDropdown(String costShareOverride) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(costShareOverrideField)) {
				ClickWebObject(costShareOverrideField);
				selectDropdownValue(costShareOverride);
				// clickOverlayElement();
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select CostShare Override dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Accums Override Dropdown")
	public boolean selectAccumsOverrideDropdown(String AccumOverride) {
		boolean blnRC = false;
		try {
			if (WaitForObject(accumsOverrideField)) {
				ClickWebObject(accumsOverrideField);
				selectDropdownValue(AccumOverride);
				// clickOverlayElement();
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select Accums Override dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Automatic Opt Dropdown")
	public boolean selectAutomaticOptDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObject(autoOPtApplicabiltyField)) {
				ClickWebObject(autoOPtApplicabiltyField);
				ClickWebObject(firstDropdownOption.get(0));
				OneframeLogger("Automatic Opt dropdown selected:" + firstDropdownOption.get(0).getText());
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Automatic Opt dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Business Entity Dropdown")
	public boolean selectBusinessEntityDropdown(String BusinessEntity) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(1))) {
				ClickWebObject(dynamicLayerFields.get(1));
				selectDropdownValues(BusinessEntity);
				Actions action = new Actions(oneframeDriver);
				action.sendKeys(Keys.ESCAPE).build().perform();

				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Entity dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(overlayElement);
	}

	@Step("Select Business Unit Dropdown")
	public boolean selectBusinessUnitDropdown(String BusinessUnit) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(2))) {
				ClickWebObject(dynamicLayerFields.get(2));
				selectDropdownValues(BusinessUnit);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Unit dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select CDHP Type Dropdown")
	public boolean selectCDHPTypeDropdown(String CDHP) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(3))) {
				ClickWebObject(dynamicLayerFields.get(3));
				selectDropdownValues(CDHP);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select CDHP type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Formulary Dropdown")
	public boolean selectFormularyDropdown(String formulary) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(4))) {
				ClickWebObject(dynamicLayerFields.get(4));
				selectDropdownValues(formulary);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Formulary dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Funding Type Dropdown")
	public boolean selectFundingTypeDropdown(String FundingType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(5))) {
				ClickWebObject(dynamicLayerFields.get(5));
				selectDropdownValues(FundingType);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Funding Type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Market Segment Dropdown")
	public boolean selectMarketSegmentDropdown(String MarketSegment) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(6))) {
				ClickWebObject(dynamicLayerFields.get(6));
				selectDropdownValues(MarketSegment);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Market Segment dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Product Type Dropdown")
	public boolean selectProductTypeDropdown(String ProductType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(7))) {
				ClickWebObject(dynamicLayerFields.get(7));
				selectDropdownValues(ProductType);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Product type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Other Dropdown")
	public boolean selectOtherDropdown(String Other) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(8))) {
				ClickWebObject(dynamicLayerFields.get(8));
				selectDropdownValues(Other);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Others dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Enter Mandate Description")
	public boolean enterMandateDescription(String mandateDesc) {
		boolean bln = false;
		if (WaitForObject(descriptionField)) {
			ClickWebObject(descriptionField);
			String mandateDescription = mandateDesc + " Mandate Description";
			int randomNumber = getRandomNumber();
			String mandateName = mandateDescription + randomNumber;
			descriptionField.sendKeys(mandateName);
			OneframeLogger("The Mandate Name is : " + descriptionField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Enter Priority")
	public boolean enterPriority(String value) {
		boolean bln = false;
		if (WaitForObject(priorityField)) {
			ClickWebObject(priorityField);
			EnterText(priorityField, value);
			OneframeLogger("The Priority Value is : " + priorityField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Enter Bill")
	public boolean enterBill(String value) {
		boolean bln = false;
		if (WaitForObject(billField)) {
			ClickWebObject(billField);
			billField.sendKeys(value);
			OneframeLogger("The Bill Value is : " + billField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Click on Add Mandate Button")
	public void clickAddMandate() {

		try {
			if (WaitForObject(addMandate)) {
				ClickWebObject(addMandate);
				OneframeLogger("Clicked on Add Mandate Button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Mandate button is not Clicked");
		}
	}

	@Step("Verify Mandate is created")
	public boolean VerifyMandateNameIsCreated(String mandateName) throws InterruptedException {
		boolean bln = false;
		try {
			clickMandatesHeader();
			clickMandatesHeader();
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split(" ");
			// String[] totalRecordCnt = recordCnt[4].split("of");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());
			int recordsPresentPerPage = Integer.parseInt(recordCnt[2].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < mandateNameList.size(); i++) {
					if (mandateNameList.get(i).getText().equalsIgnoreCase(mandateName)) {
						highlightElement(mandateNameList.get(i));
						OneframeLogger("Mandate is created : " + mandateNameList.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
//					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
					// clickMandatesHeader();
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split(" ");
				// totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(recordCnt[4].trim());
				recordsPresentPerPage = Integer.parseInt(recordCnt[2].trim());
			}
		} catch (StaleElementReferenceException exc) {

		}
		return bln;
	}

	@Step("Verify Mandate Successfully Created Text Is Displayed")
	public boolean verifyTextMandateSuccessfullyCreated(String mandate) {
		boolean flag = false;
		if (ObjectExist(txtMandateCreated)) {
//			String stateMandate=txtMandateCreated.getText();
//			String state=mandate+" "+stateMandate;
			if (txtMandateCreated.getText().contains(mandate)) {
				// txtMandateCreated.isDisplayed();
				OneframeLogger("State Mandate is created");
			}
			flag = true;
		}
		return flag;
	}

	@Step("Click on Mandate DropDown")
	public void clickMandateDropDown(String variationOf) {
		String xpath = "//td[contains(text(), '​​" + variationOf + "')]/following-sibling::td[11]/button";
		WaitForApplicationToLoadCompletely();
		try {
			OneframeLogger(xpath);
			WebElement drdMandate = oneframeDriver.findElement(By.xpath(xpath));
			if (WaitForObject(drdMandate)) {
				ClickWebObject(drdMandate);
			}

		} catch (NoSuchElementException e) {
			OneframeLogger("Webelement not found: " + xpath);
		}

	}

	@Step("Select General Overrides Dropdown")
	public String selectGeneralOverrides(String generalOverrides) {
		try {
			if (WaitForObjectVisibility(drdGeneralOverrides)) {
				ClickWebObject(drdGeneralOverrides);
				selectDropdownValue(generalOverrides);
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select General Overrides dropdown ");
		}
		return drdGeneralOverrides.getText();
	}

	@Step("Select Network Overrides Dropdown")
	public String selectNetworkOverrides(String networkOverrides) {
		try {
			if (WaitForObjectVisibility(drdNetworkOverrides)) {
				ClickWebObject(drdNetworkOverrides);
				selectDropdownVal(networkOverrides);
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Network Overrides dropdown ");
		}
		return drdNetworkOverrides.getText();
	}

	@Step("Select Cost Share Overrides Dropdown")
	public String selectCostShareOverrides(String costShareOverrides) {
		try {
			if (WaitForObjectVisibility(drdCostShareOverrides)) {
				ClickWebObject(drdCostShareOverrides);
				selectDropdownVal(costShareOverrides);
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select CostShare Overrides dropdown ");
		}
		return drdCostShareOverrides.getText();
	}

	@Step("Select Accum Overrides Dropdown")
	public String selectAccumOverrides(String accumOverrides) {
		try {
			if (WaitForObjectVisibility(drdAccumOverrides)) {
				ClickWebObject(drdAccumOverrides);
				selectDropdownVal(accumOverrides);
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Network Overrides dropdown ");
		}
		return drdAccumOverrides.getText();
	}

	@Step("Select and Get drugList value")
	public String selectAndGetDrugListValue(String drugList) {
		try {
			if (WaitForObject(drdDrugList)) {
				drdDrugList.click();
				SelectDropDownListByValue(drdDrugList, drugList);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select State dropdown ");
		}
		return drdDrugList.getText();
	}

	@Step("Verify Effective Date filter list is Same as Expected")
	public void verifyEffectiveDateFilterList(String effectiveDate) {
		WaitForObjectVisibility(lstEffectiveDate.get(0));
		if (lstEffectiveDate.get(0).getText().equalsIgnoreCase(effectiveDate)) {
			highlightElement(lstEffectiveDate.get(0));
		}
		sa.assertEquals(lstEffectiveDate.get(0).getText(), effectiveDate,
				"Verified effective date value is same as expecteds");
	}

	@Step("Verify Termination Date filter list is Same as Expected")
	public void verifyTerminationDateFilterList(String terminationDate) {
		WaitForObjectVisibility(lstTerminationDate.get(0));
		if (lstTerminationDate.get(0).getText().equalsIgnoreCase(terminationDate)) {
			highlightElement(lstTerminationDate.get(0));
		}
		sa.assertEquals(lstTerminationDate.get(0).getText(), terminationDate,
				"Verified Termination date value is same as expecteds");
	}

	@Step("Verify Client filter list is Same as Expected")
	public void verifyClientFilterList(String client) {
		WaitForObjectVisibility(lstClient.get(0));
		if (lstClient.get(0).getText().equalsIgnoreCase(client)) {
			highlightElement(lstClient.get(0));
		}
		sa.assertEquals(lstClient.get(0).getText(), client, "Verified Client value is same as expecteds");
	}

	@Step("Verify LOB filter list is Same as Expected")
	public void verifyLOBFilterList(String LOB) {
		WaitForObjectVisibility(lstLOB.get(0));
		if (lstLOB.get(0).getText().equalsIgnoreCase(LOB)) {
			highlightElement(lstLOB.get(0));
		}
		sa.assertEquals(lstLOB.get(0).getText(), LOB, "Verified LOB value is same as expecteds");
	}

	@Step("Verify State filter list is Same as Expected")
	public void verifyStateFilterList(String State) {
		WaitForObjectVisibility(lstState.get(0));
		if (lstState.get(0).getText().equalsIgnoreCase(State)) {
			highlightElement(lstState.get(0));
		}
		sa.assertEquals(lstState.get(0).getText(), State, "Verified State value is same as expecteds");
	}

	@Step("Verify General Override filter list is Same as Expected")
	public void verifyGeneralOverrideFilterList(String generalOverride) {
		WaitForObjectVisibility(lstGeneralOverride.get(0));
		if (lstGeneralOverride.get(0).getText().equalsIgnoreCase(generalOverride)) {
			highlightElement(lstGeneralOverride.get(0));
		}
		sa.assertEquals(lstGeneralOverride.get(0).getText(), generalOverride,
				"Verified General Override value is same as expecteds");
	}

	@Step("Verify Network Override filter list is Same as Expected")
	public void verifyNetworkOverrideFilterList(String networkOverride) {
		WaitForObjectVisibility(lstNetworkOverride.get(0));
		if (lstNetworkOverride.get(0).getText().equalsIgnoreCase(networkOverride)) {
			highlightElement(lstNetworkOverride.get(0));
			sa.assertEquals(lstNetworkOverride.get(0).getText(), networkOverride,
					"Verified Network Override value is same as expecteds");
		}
	}

	@Step("Verify CostShare Override filter list is Same as Expected")
	public void verifyCostShareOverrideFilterList(String costShareOverride) {
		WaitForObjectVisibility(lstCostShareOverride.get(0));
		if (lstCostShareOverride.get(0).getText().equalsIgnoreCase(costShareOverride)) {
			highlightElement(lstCostShareOverride.get(0));
			sa.assertEquals(lstCostShareOverride.get(0).getText(), costShareOverride,
					"Verified costShare Override value is same as expected");
		}
	}

	@Step("Verify Accums Override filter list is Same as Expected")
	public void verifyAccumsOverrideFilterList(String accumsOverride) {
		WaitForObjectVisibility(lstAccumsOverride.get(0));
		if (lstAccumsOverride.get(0).getText().equalsIgnoreCase(accumsOverride)) {
			highlightElement(lstAccumsOverride.get(0));

			sa.assertEquals(lstAccumsOverride.get(0).getText(), accumsOverride,
					"Verified Accums Override value is same as expecteds");
		}
	}

	@Step("Verify Zero Cost Share Values Details header")
	public void verifyZeroCostShareDetailsHeaderValues() {
		WaitForObjectVisibility(lstZeroCostShareDropdownValues.get(0));
		for (int i = 0; i < lstZeroCostShareDropdownValues.size(); i++) {
			if (lstZeroCostShareDropdownValues.get(i).getText().equalsIgnoreCase("COPAY")) {
				highlightElement(lstZeroCostShareDropdownValues.get(i));
				sa.assertEquals(lstZeroCostShareDropdownValues.get(i).getText(), "COPAY",
						"Validated the 'COPAY' header");
			} else if (lstZeroCostShareDropdownValues.get(i).getText().equalsIgnoreCase("CO-INSURANCE")) {
				highlightElement(lstZeroCostShareDropdownValues.get(i));
				sa.assertEquals(lstZeroCostShareDropdownValues.get(i).getText(), "CO-INSURANCE",
						"Validated the 'CO-INSURANCE' header");
			} else if (lstZeroCostShareDropdownValues.get(i).getText().equalsIgnoreCase("MIN")) {
				highlightElement(lstZeroCostShareDropdownValues.get(i));
				sa.assertEquals(lstZeroCostShareDropdownValues.get(i).getText(), "MIN", "Validated the 'MIN' header");
			} else if (lstZeroCostShareDropdownValues.get(i).getText().equalsIgnoreCase("MAX")) {
				highlightElement(lstZeroCostShareDropdownValues.get(i));
				sa.assertEquals(lstZeroCostShareDropdownValues.get(i).getText(), "MAX", "Validated the 'MAX' header");
			} else {
				sa.assertTrue(false, "Unable to validate header");
			}
		}
	}

	@Step("Verify INN Retail Copay Value as Zero")
	public void verifyINNRetailCopayValueAsZero() {
		WaitForObjectVisibility(txtCopayField);
		if (txtCopayField.getAttribute("value").contains("0")) {
			highlightElement(txtCopayField);
			sa.assertEquals(txtCopayField.getAttribute("value"), "0", "Validated the Copay value as '0'");
		} else {
			sa.assertTrue(false, "Unable to validate copay value");
		}
	}

	@Step("Verify INN Retail Coinsurance Value as Zero")
	public void verifyINNRetailCoInsuranceValueAsZero() {
		WaitForObjectVisibility(txtCoInsuranceField);
		if (txtCoInsuranceField.getAttribute("value").contains("0")) {
			highlightElement(txtCoInsuranceField);
			sa.assertEquals(txtCoInsuranceField.getAttribute("value"), "0", "Validated the Coinsurance value as '0'");
		} else {
			sa.assertTrue(false, "Unable to validate Coinsurance value");
		}
	}

	@Step("Verify INN Retail MIN Value as Zero")
	public void verifyINNRetailMINValueAsZero() {
		WaitForObjectVisibility(txtMinField);
		if (txtMinField.getAttribute("value").contains("0")) {
			highlightElement(txtMinField);
			sa.assertEquals(txtMinField.getAttribute("value"), "0", "Validated the MIN value as '0'");
		} else {
			sa.assertTrue(false, "Unable to validate MIN value");
		}
	}

	@Step("Verify INN Retail MAX Value as Zero")
	public void verifyINNRetailMAXValueAsZero() {
		WaitForObjectVisibility(txtMaxField);
		if (txtMaxField.getAttribute("value").contains("0")) {
			highlightElement(txtMaxField);
			sa.assertEquals(txtMaxField.getAttribute("value"), "0", "Validated the MAX value as '0'");
		} else {
			sa.assertTrue(false, "Unable to validate MAX value");
		}
	}

	@Step("verify Copay Coinsurance Min Max label is not displayed")
	public void verifyCopayCoinsuranceMinMaxLabelsIsNotPresent() {
		boolean bln = false;
		if (FindObjectByLocatorNoWait(By.xpath("//span[@class='cell__group__label']")) != null) {
			bln = false;
		} else {
			bln = true;
		}
		sa.assertTrue(bln, "Validated Copay, Conisurance, Min and Max labels is not displayed in State Mandate");
	}

	@Step("Verify and select Tier dropdown")
	public void verifyAndSelecttierDropdown(String tier) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdTier)) {
				ClickWebObject(drdTier);
				selectDropdownValue(tier);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Tier dropdown");
			blnRC = false;
		}
		sa.assertTrue(blnRC, "Validated and selected Tier dropdown");
	}

	@Step("Click on Cancel button")
	public void clickCancelButton() {
		btnCancel.click();
		OneframeLogger("Clicked on Cancel button");
	}

	@Step("Click on Leave button")
	public void clickLeaveButton() {
		btnLeave.click();
		OneframeLogger("Clicked on Leave button");
	}

	@Step("Verify Cost Share Tab INN Retail Dropdown values")
	public void verifyCostShareTabINNRetailDropdownValue(String dropdownValue) throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdInnRetail)) {
				ClickWebObject(drdInnRetail);
				selectDropdownValue(dropdownValue);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Tier dropdown");
			blnRC = false;
		}
		sa.assertTrue(blnRC, "Validated INN Retail Dropdown values is same as expected");
	}

	@Step("Verify Cost Share Tab INN Home Delivery Dropdown values")
	public void verifyCostShareTabINNHomeDeliveryDropdownValue(String dropdownValue) throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdInnHomeDelivery)) {
				ClickWebObject(drdInnHomeDelivery);
				selectDropdownValue(dropdownValue);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Tier dropdown");
			blnRC = false;
		}
		sa.assertTrue(blnRC, "Validated INN Home Delivery Dropdown values is same as expected");
	}

	@Step("Verify Cost Share Tab ONN retail Dropdown values")
	public void verifyCostShareTabONNRetailDropdownValue(String dropdownValue) throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdONNRetail)) {
				ClickWebObject(drdONNRetail);
				selectDropdownValue(dropdownValue);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Tier dropdown");
			blnRC = false;
		}
		sa.assertTrue(blnRC, "Validated ONN Retail Dropdown values is same as expected");
	}

	@Step("Verify and Click Program Name")
	public boolean verifyAndClickProgramName(String programName) {
		boolean bln = false;
		WaitForApplicationToLoadCompletely();
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstProgramNameRecords.size(); i++) {
					WaitForObjectVisibility(lstProgramNameRecords.get(i));
					if (lstProgramNameRecords.get(i).getText().contains(programName)) {
						highlightElement(lstProgramNameRecords.get(i));
						ClickWebObject(lstProgramNameRecords.get(i));
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to get Program Name");
			bln = false;
		}
		return bln;
	}
}

package com.ibc.util;

import org.apache.log4j.Logger;
import org.testng.Reporter;

public class LoggerUtil {
	private static Logger logger = Logger.getLogger(LoggerUtil.class);
	
	public static void log(String logtext) {
		logger.info(logtext);
		Reporter.log(logtext);
	}
}

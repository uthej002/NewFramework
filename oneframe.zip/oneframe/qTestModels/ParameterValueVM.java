// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ParameterValueVM
{
    @JsonProperty("id")
    private String id;
    @JsonProperty("value")
    private String value;
    
    public ParameterValueVM() {
        this.id = null;
        this.value = null;
    }
    
    public ParameterValueVM id(final String id) {
        this.id = id;
        return this;
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public ParameterValueVM value(final String value) {
        this.value = value;
        return this;
    }
    
    public String getValue() {
        return this.value;
    }
    
    public void setValue(final String value) {
        this.value = value;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ParameterValueVM parameterValueVM = (ParameterValueVM)o;
        return Objects.equals(this.id, parameterValueVM.id) && Objects.equals(this.value, parameterValueVM.value);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.value);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class ParameterValueVM {\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    value: ").append(this.toIndentedString(this.value)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

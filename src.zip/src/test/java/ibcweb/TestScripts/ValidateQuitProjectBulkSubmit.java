package ibcweb.TestScripts;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.geom.GeneralPath;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.CSVFile;
import anthem.irx.oneframe.utilities.ExcelFile;
import ibcweb.PageObjects.IBPBulkSubmitPage;
import ibcweb.PageObjects.IBPBulkUpdateBulkUpdatedPage;
import ibcweb.PageObjects.IBPBulkUpdatePage;
import ibcweb.PageObjects.IBPBulkUpdateReviewPage;
import ibcweb.PageObjects.IBPBulkUpdateWorkInProgressPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class ValidateQuitProjectBulkSubmit extends OneframeContainer {
	
		IBPWelcomePage welcomePage;
		IBPLoginPage   loginpage;
		IBPHomePage homepage;
		IBPBulkUpdatePage bulkUpdatePage;
		IBPBulkUpdateWorkInProgressPage workInProgressPage;
		IBPBulkUpdateBulkUpdatedPage bulkUpdatedPage;
		IBPBulkUpdateReviewPage reviewPage;
		IBPBulkSubmitPage bulkSubmitPage;
		
		// move to page object
		Robot robot;
		String highDollarRetialBeforeUpdate;
		String highDollarHomeDeliveryBeforeUpdate;

	@BeforeClass
	@Step("Initializing Test Script for validating Butterscotch App Login")
	public void setUp() {
		InitializeLaunchPad("IBPW_917");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		bulkUpdatePage = new IBPBulkUpdatePage();
		workInProgressPage = new IBPBulkUpdateWorkInProgressPage();
		reviewPage = new IBPBulkUpdateReviewPage();
		bulkUpdatedPage = new IBPBulkUpdateBulkUpdatedPage();
		bulkSubmitPage = new IBPBulkSubmitPage();
	}

	@DataProvider(name = "LoginTestData")
	public Object[][] getLoginTestDataTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "DataSheetWithBenefits"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Quit project flow in bulk submit", dataProvider = "LoginTestData")
	@Description("Validate quit project flow in bulk submit")
	public void quitProjectFlow(String TestCaseID, String TestStatus, String DataSheet) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			int numberOfRows = bulkUpdatePage.getRowCount(DataSheet);
			
			homepage.clickMenuButton();
			bulkUpdatePage.clickBulkProcess();
			bulkUpdatePage.clickBulkSubmit();
			
			//Creating a New Project
			bulkUpdatePage.clickOnCreateAProjectButton();
			sa.assertTrue(bulkUpdatePage.verifyCreateAProjectHeader(), "'Create a Project' heading is displayed");
			sa.assertTrue(!bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is disabled");
			sa.assertTrue(bulkUpdatePage.verifyProjectDataHeading(), "'Project Data' heading is displayed");	
			sa.assertTrue(bulkUpdatePage.verifyProjectIDHeading(), "'Project ID' heading is displayed");
			sa.assertTrue(bulkUpdatePage.verifyProjectDescriptionHeading(), "'Description' heading is displayed");
			sa.assertTrue(bulkUpdatePage.verifyAndEnterProjectID("TestAu"), "Verified and entered project id");
			sa.assertTrue(bulkUpdatePage.verifyAndEnterProjectDescription("Test Auto Project Desc"), "Verified and entered project description");
			bulkUpdatePage.clickOnFileUploadButton();
			bulkUpdatePage.uploadFile(DataSheet);
			sa.assertTrue(bulkSubmitPage.verifySuccessfulUploadMessage("1 of 2 benefits found"), "File upload");
			sa.assertTrue(bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is enabled");
			bulkUpdatePage.clickOnCreateProjectButton();
			bulkUpdatedPage.clickOnYesButton();			
			sa.assertTrue(bulkUpdatePage.verifyProjectIsCreated(bulkUpdatePage.getProjectID()), "Project ID is found in the grid");
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "PROJECT_CREATED"), "Project Status is PROJECT_CREATED");
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());			
			sa.assertTrue(bulkSubmitPage.verifyProjectCreatedIsActive(), "PROJECT CREATED is active in stepper menu");
			sa.assertTrue(bulkSubmitPage.verifyProjectCreatedHeading(bulkUpdatePage.getProjectID()), "'" +bulkUpdatePage.getProjectID()+" Project Created' message is displayed.");		
			bulkSubmitPage.clickQuitProcess();
			bulkUpdatedPage.clickOnYesButton();	
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "QUITTED"), "Project Status is QUITTED");
			homepage.clickMenuButton();
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			
			OneframeLogger("Validate Butterscotch App Login Succseefully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate Butterscotch App Login");
		}
		
		homepage.clickLogout();
		
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}
	
	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

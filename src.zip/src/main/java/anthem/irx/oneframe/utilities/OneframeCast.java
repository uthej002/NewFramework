package anthem.irx.oneframe.utilities;

public class OneframeCast {}

package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsCostOfCare;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateUIElementsProgramsCostOfCareGeneralTab extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPLibrariesProgramsCostOfCare generalTab;

	@BeforeClass
	@Step("Initializing Test Script for Validating UI elements in programs -> cost of care -> general tab")
	public void setUp() {
		InitializeLaunchPad("IBPW_453");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		generalTab =  new IBPLibrariesProgramsCostOfCare();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ProgramName" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate the UI elements in programs -> cost of care -> general tab", dataProvider = "TestData")
	@Description("Validate the UI elements in programs -> cost of care -> general tab")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus, String ProgramName)throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickCostofCareofPrograms();
			//sa.assertTrue(librariesprogramspage.verifyAndClickProgramName("TESTAUTO"), "Click on Cost of Care program");
			librariesprogramspage.clickProgramsHeader();
			sa.assertTrue(librariesprogramspage.verifyAndClickProgramName("TESTAUTO"),
					"Verified and clicked Program name");
			sa.assertTrue(generalTab.clickGeneralTab(), "Clicked on General Tab");
			sa.assertTrue(generalTab.validateTextIsDisplayed("High Dollar Amounts"), "Validate text High Dollar Amounts is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Retail High Dollar Amount"), "Validate text Retail High Dollar Amount is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Mail High Dollar Amount"), "Validate text Mail High Dollar Amount is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("UM"), "Validate text UM is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Channel Name"), "Validate text Channel Name is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Quantity Limit"), "Validate text Quantity Limit is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Quantity Limitation Time Period"), "Validate text Quantity Limitation Time Period is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Days Supply"), "Validate text Days Supply is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Initial Fill Days Supply"), "Validate text Initial Fill Days Supply is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Lookback Days"), "Validate text Lookback Days is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Max Fill Days Supply"), "Validate text Max Fill Days Supply is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Lower Age Limit Restriction"), "Validate text Lower Age Limit Restriction is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Upper Age Limit Restriction"), "Validate text Upper Age Limit Restriction is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("What Happens Under Age Restriction"), "Validate text What Happens Under Age Restriction is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("What Happens Over Age Restriction"), "Validate text What Happens Over Age Restriction is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("What Happens Between Age Restriction"), "Validate text What Happens Between Age Restriction is displayed");
			
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if the General/Network/CostShares/Accum tabs are enabled after selecting General/Network/CostShares/Accum overrides as Yes in the form while creating a Cost of Care Program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to create a Cost of Care Program");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateEditFederalMandateCostShareDetail extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validate Edit Federal Mandate Cost Share tab details")
	public void setUp() {
		InitializeLaunchPad("IBPW_324");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ProgramName", "CostShareOverride", "costShareStructure",
				"costShareTierStructure", "customCostShare", "customSteppingCostShare", "costShareTierStruc" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit Federal Mandate Cost Share tab details", dataProvider = "TestData")
	@Description("Validate Edit Federal Mandate Cost Share tab details")
	public void ValidateCostOfCareEditAndCancelFunctionality(String TestCaseID, String TestStatus, String ProgramName,
			String CostShareOverride, String costShareStructure, String costShareTierStructure, String customCostShare,
			String customSteppingCostShare, String costShareTierStruc) throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			mandate.clickViewButtonofMandates();
			sa.assertTrue(mandate.verifyMandatesHeader(), "Verified 'Mandates header' is displayed");
			mandate.clickMandatesHeader();
			sa.assertTrue(mandate.verifyAndClickProgramName(ProgramName),
					"Verified and clicked Program name");

			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			sa.assertTrue(librariesprogramspage.verifyCostShareTabIsEnabledAndClicked(CostShareOverride),
					"Verified Cost Share tab is Enabled and clicked");
			librariesprogramspage.selectCostShareStructureDropdown(costShareStructure);

			librariesprogramspage.selectCostShareTierStructureDropdown(costShareTierStructure);
			librariesprogramspage.clickCustomSteppingToggle();
			librariesprogramspage.selectCustomCostShareDropdown(customCostShare, customSteppingCostShare);

			librariesprogramspage.clickSaveChangesButton();
			librariesprogramspage.verifyChangesSavedText();
			librariesprogramspage.clickCostShareTierStructureHeader();
			librariesprogramspage.clickCostShareTierStructureHeader();
			librariesprogramspage.clickCostShareTierStructureHeader();
			librariesprogramspage.clickCostShareTierStructureHeader();
			librariesprogramspage.verifyCustomCostShareDropdown(customCostShare, customSteppingCostShare);

			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			librariesprogramspage.selectCostShareTierStructureDropdown(costShareTierStruc);
			librariesprogramspage.clickCustomSteppingToggle();
			librariesprogramspage.clickSaveChangesButton();
			librariesprogramspage.verifyChangesSavedText();

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit Federal Mandate Cost Share tab details is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Edit Federal Mandate Cost Share tab details");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class TestStepResource
{
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("description")
    private String description;
    @JsonProperty("expected")
    private String expected;
    @JsonProperty("order")
    private Integer order;
    @JsonProperty("group")
    private Integer group;
    @JsonProperty("called_test_case_name")
    private String calledTestCaseName;
    @JsonProperty("root_called_test_case_id")
    private Long rootCalledTestCaseId;
    @JsonProperty("called_test_case")
    private TestCaseWithCustomFieldResource calledTestCase;
    @JsonProperty("parent_test_step_id")
    private Long parentTestStepId;
    @JsonProperty("information")
    private TestStepInformationVM information;
    @JsonProperty("plain_value_text")
    private String plainValueText;
    @JsonProperty("parameter_values")
    private List<String> parameterValues;
    @JsonProperty("called_test_case_id")
    private Long calledTestCaseId;
    
    public TestStepResource() {
        this.links = new ArrayList<Link>();
        this.id = null;
        this.description = null;
        this.expected = null;
        this.order = null;
        this.group = null;
        this.calledTestCaseName = null;
        this.rootCalledTestCaseId = null;
        this.calledTestCase = null;
        this.parentTestStepId = null;
        this.information = null;
        this.plainValueText = null;
        this.parameterValues = new ArrayList<String>();
        this.calledTestCaseId = null;
    }
    
    public TestStepResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public TestStepResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public TestStepResource id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public TestStepResource description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public TestStepResource expected(final String expected) {
        this.expected = expected;
        return this;
    }
    
    public String getExpected() {
        return this.expected;
    }
    
    public void setExpected(final String expected) {
        this.expected = expected;
    }
    
    public TestStepResource order(final Integer order) {
        this.order = order;
        return this;
    }
    
    public Integer getOrder() {
        return this.order;
    }
    
    public void setOrder(final Integer order) {
        this.order = order;
    }
    
    public TestStepResource group(final Integer group) {
        this.group = group;
        return this;
    }
    
    public Integer getGroup() {
        return this.group;
    }
    
    public void setGroup(final Integer group) {
        this.group = group;
    }
    
    public TestStepResource calledTestCaseName(final String calledTestCaseName) {
        this.calledTestCaseName = calledTestCaseName;
        return this;
    }
    
    public String getCalledTestCaseName() {
        return this.calledTestCaseName;
    }
    
    public void setCalledTestCaseName(final String calledTestCaseName) {
        this.calledTestCaseName = calledTestCaseName;
    }
    
    public TestStepResource rootCalledTestCaseId(final Long rootCalledTestCaseId) {
        this.rootCalledTestCaseId = rootCalledTestCaseId;
        return this;
    }
    
    public Long getRootCalledTestCaseId() {
        return this.rootCalledTestCaseId;
    }
    
    public void setRootCalledTestCaseId(final Long rootCalledTestCaseId) {
        this.rootCalledTestCaseId = rootCalledTestCaseId;
    }
    
    public TestStepResource calledTestCase(final TestCaseWithCustomFieldResource calledTestCase) {
        this.calledTestCase = calledTestCase;
        return this;
    }
    
    public TestCaseWithCustomFieldResource getCalledTestCase() {
        return this.calledTestCase;
    }
    
    public void setCalledTestCase(final TestCaseWithCustomFieldResource calledTestCase) {
        this.calledTestCase = calledTestCase;
    }
    
    public TestStepResource parentTestStepId(final Long parentTestStepId) {
        this.parentTestStepId = parentTestStepId;
        return this;
    }
    
    public Long getParentTestStepId() {
        return this.parentTestStepId;
    }
    
    public void setParentTestStepId(final Long parentTestStepId) {
        this.parentTestStepId = parentTestStepId;
    }
    
    public TestStepResource information(final TestStepInformationVM information) {
        this.information = information;
        return this;
    }
    
    public TestStepInformationVM getInformation() {
        return this.information;
    }
    
    public void setInformation(final TestStepInformationVM information) {
        this.information = information;
    }
    
    public TestStepResource plainValueText(final String plainValueText) {
        this.plainValueText = plainValueText;
        return this;
    }
    
    public String getPlainValueText() {
        return this.plainValueText;
    }
    
    public void setPlainValueText(final String plainValueText) {
        this.plainValueText = plainValueText;
    }
    
    public TestStepResource parameterValues(final List<String> parameterValues) {
        this.parameterValues = parameterValues;
        return this;
    }
    
    public TestStepResource addParameterValuesItem(final String parameterValuesItem) {
        this.parameterValues.add(parameterValuesItem);
        return this;
    }
    
    public List<String> getParameterValues() {
        return this.parameterValues;
    }
    
    public void setParameterValues(final List<String> parameterValues) {
        this.parameterValues = parameterValues;
    }
    
    public TestStepResource calledTestCaseId(final Long calledTestCaseId) {
        this.calledTestCaseId = calledTestCaseId;
        return this;
    }
    
    public Long getCalledTestCaseId() {
        return this.calledTestCaseId;
    }
    
    public void setCalledTestCaseId(final Long calledTestCaseId) {
        this.calledTestCaseId = calledTestCaseId;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final TestStepResource testStepResource = (TestStepResource)o;
        return Objects.equals(this.links, testStepResource.links) && Objects.equals(this.id, testStepResource.id) && Objects.equals(this.description, testStepResource.description) && Objects.equals(this.expected, testStepResource.expected) && Objects.equals(this.order, testStepResource.order) && Objects.equals(this.group, testStepResource.group) && Objects.equals(this.calledTestCaseName, testStepResource.calledTestCaseName) && Objects.equals(this.rootCalledTestCaseId, testStepResource.rootCalledTestCaseId) && Objects.equals(this.calledTestCase, testStepResource.calledTestCase) && Objects.equals(this.parentTestStepId, testStepResource.parentTestStepId) && Objects.equals(this.information, testStepResource.information) && Objects.equals(this.plainValueText, testStepResource.plainValueText) && Objects.equals(this.parameterValues, testStepResource.parameterValues) && Objects.equals(this.calledTestCaseId, testStepResource.calledTestCaseId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links, this.id, this.description, this.expected, this.order, this.group, this.calledTestCaseName, this.rootCalledTestCaseId, this.calledTestCase, this.parentTestStepId, this.information, this.plainValueText, this.parameterValues, this.calledTestCaseId);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class TestStepResource {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("    expected: ").append(this.toIndentedString(this.expected)).append("\n");
        sb.append("    order: ").append(this.toIndentedString(this.order)).append("\n");
        sb.append("    group: ").append(this.toIndentedString(this.group)).append("\n");
        sb.append("    calledTestCaseName: ").append(this.toIndentedString(this.calledTestCaseName)).append("\n");
        sb.append("    rootCalledTestCaseId: ").append(this.toIndentedString(this.rootCalledTestCaseId)).append("\n");
        sb.append("    calledTestCase: ").append(this.toIndentedString(this.calledTestCase)).append("\n");
        sb.append("    parentTestStepId: ").append(this.toIndentedString(this.parentTestStepId)).append("\n");
        sb.append("    information: ").append(this.toIndentedString(this.information)).append("\n");
        sb.append("    plainValueText: ").append(this.toIndentedString(this.plainValueText)).append("\n");
        sb.append("    parameterValues: ").append(this.toIndentedString(this.parameterValues)).append("\n");
        sb.append("    calledTestCaseId: ").append(this.toIndentedString(this.calledTestCaseId)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

package anthem.irx.oneframe.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class MSTeamMessageCard {
  @JsonProperty("@type")
  public String type;
  
  @JsonProperty("@context")
  public String context;
  
  public String themeColor;
  
  public String summary;
  
  public ArrayList<MessageSection> sections;
}

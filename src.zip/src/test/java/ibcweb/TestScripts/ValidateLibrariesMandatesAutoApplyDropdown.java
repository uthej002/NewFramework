package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibrariesMandatesAutoApplyDropdown extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesMandatesPage librariesmandatespage;
	IBPLibrariesProgramsPage librariesprogramspage;

	@BeforeClass
	@Step("Initializing Test Script for validating Benefit Libraries Federal Mandate Add Mandate Auto Apply Dropdown")
	public void setUp() {
		InitializeLaunchPad("IBPW_X8");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesmandatespage = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "EffectiveDate","ClientId","LOBId", "StateId"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefit Libraries Federal Mandate Add Mandate Auto Apply Dropdown", dataProvider = "TestData")
	@Description("Validate Benefit Libraries Federal Mandate Add Mandate Auto Apply Dropdown")
	public void ValidateLibrariesAddFederalMandateAutoApply(String TestCaseID, String TestStatus, String EffectiveDate,String ClientId,
			String LOBId, String StateId)throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesmandatespage.clickViewButtonofMandates();
			sa.assertTrue(librariesmandatespage.verifyMandatesHeader(), "Verified Mandates header");
			librariesmandatespage.clickAddFederalMandate();
			sa.assertTrue(librariesmandatespage.verifyAddNewMandateHeader(), "Verified Add New Mandate button");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId), "The ClientID dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectLobdropdown(LOBId), "The LOB dropdown has been selected");
			sa.assertTrue(librariesprogramspage.verifyAutoApplyDropdown(), "The Auto Apply dropdown is displayed");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate whether Auto Apply Dropdown has populated Successfully when BOB values are given while Adding Federal Mandate");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Auto Apply Dropdown when BOB values are given while Adding Federal Mandate");
		}

//		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}



}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateFilterFunctionalityOfCOBPackage extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validating Filter Functionality of COB Package")
	public void setUp() {
		InitializeLaunchPad("IBPW_782");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType", "MarketSegment",
				"ProductType", "Other", "TerminationDate" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Filter Functionality of COB Package", dataProvider = "TestData")
	@Description("Validate Filter Functionality of COB Package")
	public void ValidateCOBDefaultDynamicLayer(String TestCaseID, String TestStatus, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String AutoApply, String BusinessEntity,
			String BusinessUnit, String CDHP, String Formulary, String FundingType, String MarketSegment,
			String ProductType, String Other, String TerminationDate)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			controls.clickViewButtonofControls();
			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'Controls' header is displayed");
			controls.clickCOBPackageTab();
			controls.clickFilterButton();
			String clientValue = controls.selectAndGetClientValue(ClientId);
			String lobValue = controls.selectAndGetLobValue(LOBId);
			String stateValue = controls.selectAndGetStateValue(StateId);
			sa.assertTrue(controls.selectAutoApplyFilterDropdown(AutoApply),
					"Verified and Selected 'Auto Apply' Filter dropdown");
			sa.assertTrue(controls.selectBusinessEntityFilterDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' Filter dropdown");
			sa.assertTrue(controls.selectBusinessUnitFilterDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' Filter dropdown");
			sa.assertTrue(controls.selectCDHPTypeFilterDropdown(CDHP),
					"Verified and Selected 'CDHP Type' Filter dropdown");
			sa.assertTrue(controls.selectFormularyFilterDropdown(Formulary),
					"Verified and Selected 'Formulary' Filter dropdown");
			sa.assertTrue(controls.selectFundingTypeFilterDropdown(FundingType),
					"Verified and Selected 'Funding Type' Filter dropdown");
			sa.assertTrue(controls.selectMarketSegmentFilterDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' Filter dropdown");
			sa.assertTrue(controls.selectProductTypeFilterDropdown(ProductType),
					"Verified and Selected 'Product Type' Filter dropdown");
			sa.assertTrue(controls.selectOtherFilterDropdown(Other), "Verified and Selected 'Others' Filter dropdown");
			String effectiveDate = controls.EnterCBEffectiveDate(EffectiveDate);
			String terminationDate = controls.EnterTerminationDate(TerminationDate);
			controls.clickApplyFilterButton();
			controls.clickControlsHeader();
			sa.assertTrue(controls.verifyCOBPackageClientFilterList(clientValue),
					"Verified the search results 'Client Value' is same as expected");
			sa.assertTrue(controls.verifyCOBPackageLOBFilterList(lobValue),
					"Verified the search results 'Lob Value' is same as expected");
			sa.assertTrue(controls.verifyCOBPackageStateFilterList(stateValue),
					"Verified the search results 'State Value' is same as expected");
			/* sa.assertTrue(controls.verifyEffectiveDateFilterList(effectiveDate),
					"Verified the search results 'Effective Date Value' is same as expected");
			sa.assertTrue(controls.verifyTerminationDateFilterList(terminationDate),
					"Verified the search results 'Termination Date Value' is same as expected"); */

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Filter Functionality of COB Package is  Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Filter Functionality of COB Package");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}


package ibcweb.PageObjects;

import java.lang.*;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import APIUtilities.OracleDBConnection;
import anthem.irx.oneframe.core.OneframeContainer;
import io.qameta.allure.Step;
import anthem.irx.oneframe.database.OneframeDatabaseDriver;

public class UserRolesDB extends OneframeContainer {
	
	OracleDBConnection db = new OracleDBConnection();

	OneframeDatabaseDriver newdb = new OneframeDatabaseDriver();
	
	
	@Step("Get previous benefit version if there are any")
	public String getBenefitVersion(String proxyPlanID) {
		try {
			List<HashMap<String, String>> benefitVersion = db.
					getResultSet("select * from BENEFIT_VERSION where legacy_benefit_plan_id='"+ proxyPlanID +"' order by minor_version desc FETCH NEXT 1 row only");
			
			if(benefitVersion.size() != 0) {
				OneframeLogger("Benefit Version is: " +benefitVersion.get(0).get("MINOR_VERSION"));
				return benefitVersion.get(0).get("MINOR_VERSION");
			}
			else {
				return null;
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Step("Verify File Status is 'DONE'")
	public boolean validateFileStatus(String fileName) {
		try {
			List<HashMap<String, String>> fileStatus = db.getResultSet("select * from FILE_STATUS where file_name like '"+ fileName +"' order by date_received desc Fetch next 1 row only");
			
			String status = fileStatus.get(0).get("STATUS");
			
			if(status.equalsIgnoreCase("DONE")) {
				OneframeLogger("File Status is displayed as: " +status);
				return true;
			}
			else {
				OneframeLogger("File Status is displayed as: " +status);
				return false;
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;		
	}

	
	@Step("Verify Benefit Version is created in Benefit_Version table")
	public boolean validateBenefitVersion(String prevBenVersion, String proxyPlanID) {
		boolean flg = false;
		try {
			List<HashMap<String, String>> benefitVersion = db.
					getResultSet("select * from BENEFIT_VERSION where legacy_benefit_plan_id='"+ proxyPlanID +"' order by minor_version desc FETCH NEXT 1 row only");
			
			int currentBenefitVersion = Integer.parseInt(benefitVersion.get(0).get("MINOR_VERSION"));
			int prevBenefitVersion = 0;
			
			OneframeLogger("Current Benefit Version is: " +currentBenefitVersion);
			
			if(prevBenVersion != null) {
				prevBenefitVersion = Integer.parseInt(prevBenVersion);
				if(currentBenefitVersion == prevBenefitVersion+1) {
					OneframeLogger("New Benefit version is created. Current Version: " +currentBenefitVersion+ ", Previous Version: " +prevBenefitVersion);
					flg = true;
				}
				else {
					OneframeLogger("New Benefit version is not created");
					flg = false;
				}
			}	
			else {
				OneframeLogger("Previous Benefit Versions are not available. Created a New Benefit Version. Current Version: " +currentBenefitVersion);
				flg = true;
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flg;
	}

	@Step("Get Benefit ID from Benefit_version table")
	public String getBenefitID(String proxyPlanID) {
		try {
			List<HashMap<String, String>> benefitID = db.
					getResultSet("select * from BENEFIT_VERSION where legacy_benefit_plan_id='"+ proxyPlanID +"' order by minor_version desc FETCH NEXT 1 row only");
			OneframeLogger("Benefit ID is: " +benefitID.get(0).get("BENEFIT_ID"));
			
			return benefitID.get(0).get("BENEFIT_ID");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Step("Get Benefit Plan ID from Benefit table")
	public String getBenefitPlanID(String planID) {
		try {
			List<HashMap<String, String>> benefitID = db.
					getResultSet("select * from BENEFIT WHERE ID = "+planID);
			OneframeLogger("Benefit Plan ID is: " +benefitID.get(0).get("BENEFIT_PLAN_ID"));
			
			return benefitID.get(0).get("BENEFIT_PLAN_ID");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public void closeDbConnection() {
		db.closeDataBaseConnection();
	}

	public String getNewPlanProxyID() {
		try {
			List<HashMap<String, String>> legacyBenefitPlanId = db.getResultSet("select  UNIQUE legacy_benefit_plan_id from BENEFIT_VERSION \n"
					+ "        where regexp_like( legacy_benefit_plan_id, '^[[:digit:]]*$') \n"
					+ "        order by legacy_benefit_plan_id desc\n"
					+ "        FETCH NEXT 1 row only");
			
			String planProxyID = legacyBenefitPlanId.get(0).get("LEGACY_BENEFIT_PLAN_ID");
			System.out.println(planProxyID);
			
			long newPlanProxyID = Long.parseLong(planProxyID) + 1;
			
			List<HashMap<String, String>> checkLegacyBenefitPlanId = db.getResultSet("select legacy_benefit_plan_id from BENEFIT_VERSION WHERE legacy_benefit_plan_id = '"+newPlanProxyID+"'");
			
			if(checkLegacyBenefitPlanId.size() == 0) {
				OneframeLogger("New Plan Proxy ID is: " +newPlanProxyID);
				return newPlanProxyID + "";
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	
	public List<String> getColumnAsList(String tableName, String columnName, String condition, String sortOrder){
		List<String> programs = new ArrayList();
		List<HashMap<String, String>> listCostOfCare = null;
		try {
			String query = String.format("select %s from %s %s order by %s %s", columnName, tableName, condition, columnName, sortOrder);
			listCostOfCare = db.getResultSet(query);
			for(HashMap<String, String> h: listCostOfCare) {
				
				if(columnName.equalsIgnoreCase("TERMINATION_DATE") || columnName.equalsIgnoreCase("EFFECTIVE_DATE")) {
					if(h.get(columnName.toUpperCase()) != null) {
						LocalDateTime datetime = LocalDateTime.parse(h.get(columnName.toUpperCase()), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S"));
						String finalDate = datetime.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
						programs.add(finalDate.replace("-", "/"));
					}
					else {
						programs.add("");
					}
				}
				else {
					programs.add(h.get(columnName.toUpperCase()));
				}
								
			}
		}
		catch (Exception e) {
			OneframeLogger(e.toString());
		}
		
		return programs;
	}

	public void removeUserRoles(String string, List rolesToRemove) {
		String deleteQuery = "DELETE FROM user_account_user_role WHERE user_account_id='1300' and user_role_id in ";
		String INcondition = "(";
		
		for(int i = 0; i < rolesToRemove.size(); i++) {
			if(i > 0 && i < rolesToRemove.size() + 1) {
				INcondition = INcondition + "," + rolesToRemove.get(i);
			}
			else {
				INcondition = INcondition + rolesToRemove.get(i);
			}
			
			if(i == rolesToRemove.size() - 1) {
				INcondition = INcondition + ")";
			}
		}
		
		deleteQuery = deleteQuery + INcondition;
		
		try {
			newdb.OpenDBConnection("db1");
			newdb.executeSQLQuery(deleteQuery);
			
			db.getResultSet("commit");
			
		} catch (Exception e) {
			OneframeLogger(e.toString());
		}
		
		
		System.out.println("break");
		
	}
	
}

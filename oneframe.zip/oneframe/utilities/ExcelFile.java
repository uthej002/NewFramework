// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import java.io.FileNotFoundException;
import org.apache.poi.ss.usermodel.CellType;
import java.util.Iterator;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVFormat;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import anthem.irx.oneframe.core.OneframeLogger;
import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.EncryptedDocumentException;
import anthem.irx.oneframe.core.OneframeContainer;
import java.io.InputStream;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import anthem.irx.oneframe.core.OneframeConstants;
import java.io.FileInputStream;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import java.io.File;

public class ExcelFile
{
    private File xlFile;
    private Workbook xlWorkBook;
    private Sheet xlSheet;
    private String xlCurrSheetName;
    private String xlCurrWorkBookName;
    private int totRowCount;
    private static OneframeSoftAssert ofSA;
    private FileInputStream inputStream;
    private static int interimTotalCol;
    private static int interimTotalrow;
    
    public ExcelFile(final String xlResourceFolderPath, final String xlFileName) {
        this.xlCurrWorkBookName = xlFileName;
        this.xlFile = new File(OneframeConstants.RESOURCES_FOLDER + "/" + xlResourceFolderPath + "/" + xlFileName);
        ExcelFile.ofSA = new OneframeSoftAssert();
        ExcelFile.interimTotalCol = 0;
        ExcelFile.interimTotalrow = 0;
        try {
            this.inputStream = new FileInputStream(this.xlFile);
            this.xlWorkBook = WorkbookFactory.create((InputStream)this.inputStream);
            OneframeContainer.OneframeLogger("Opened Excel workboox - " + xlFileName);
        }
        catch (EncryptedDocumentException | InvalidFormatException | IOException ex2) {
            final Exception ex;
            final Exception e = ex;
            OneframeContainer.OneframeErrorLogger(e.getMessage());
        }
    }
    
    public ExcelFile(final String xlFilePathAndName) {
        this.xlCurrWorkBookName = xlFilePathAndName;
        this.xlFile = new File(xlFilePathAndName);
        ExcelFile.ofSA = new OneframeSoftAssert();
        try {
            this.inputStream = new FileInputStream(this.xlFile);
            this.xlWorkBook = WorkbookFactory.create((InputStream)this.inputStream);
            OneframeContainer.OneframeLogger("Opened Excel workboox - " + xlFilePathAndName);
        }
        catch (EncryptedDocumentException | InvalidFormatException | IOException ex2) {
            final Exception ex;
            final Exception e = ex;
            OneframeContainer.OneframeErrorLogger(e.getMessage());
        }
    }
    
    public ExcelFile OpenWorkBook() {
        if (this.xlWorkBook == null) {
            OneframeLogger.ErrorLog("Excel workbook is not initialized");
            System.exit(0);
        }
        return this;
    }
    
    public ExcelFile OpenLargeWorkBook() {
        return this;
    }
    
    public ExcelFile OpenWorkSheet(final String xlSheetName) {
        this.xlCurrSheetName = xlSheetName;
        this.xlSheet = this.xlWorkBook.getSheet(xlSheetName);
        if (this.xlSheet.getProtect()) {
            OneframeContainer.OneframeLogger("Excel worksheet [" + xlSheetName + "] is password protected");
            this.xlSheet.protectSheet((String)null);
            OneframeContainer.OneframeLogger("Password protection removed");
        }
        OneframeContainer.OneframeLogger("Opened Excel worksheet - " + xlSheetName);
        return this;
    }
    
    private void OpenWorkSheet() {
        this.OpenWorkSheet(this.xlCurrSheetName);
    }
    
    private void CloseWorkSheet() {
        this.xlSheet = null;
        OneframeContainer.OneframeLogger("Closed Excel worksheet '" + this.xlCurrSheetName + "'");
    }
    
    private void CloseInputStream() {
        try {
            this.inputStream.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void CloseWorkBook() {
        try {
            this.xlWorkBook.close();
            this.xlWorkBook = null;
            OneframeContainer.OneframeLogger("Closed Excel workbook '" + this.xlCurrWorkBookName + "'");
        }
        catch (IOException e) {
            OneframeLogger.ErrorLog(e.getMessage());
        }
    }
    
    public void CloseExcelFile() {
        this.CloseWorkSheet();
        this.CloseWorkBook();
    }
    
    public int getTotalRowCount() {
        return this.xlSheet.getPhysicalNumberOfRows();
    }
    
    public int getTotalColumnCount() {
        final Row headerRow = this.xlSheet.getRow(0);
        return headerRow.getPhysicalNumberOfCells();
    }
    
    public String[] getRowContentByKeyValue(final String KeyColumn, final String KeyValue) {
        return this.getRowContentByRowNumber(this.getRowIdentifier(KeyColumn, KeyValue));
    }
    
    public String[][] getRowsContentByKeyValue(final String KeyColumn, final String KeyValue) {
        int RowIdentifier = 0;
        final int cols = this.getTotalColumnCount();
        final int rows = this.getRowsCountByKeyValue(KeyColumn, KeyValue);
        final int TotalRows = this.getTotalRowCount();
        final int keyColid = this.getColIndexByName(KeyColumn);
        int rowCounter = 0;
        final String[][] RowsContent = new String[rows][cols];
        for (int i = 0; i < TotalRows; ++i) {
            final String colValue = this.ReadCellActRef(i, keyColid);
            if (colValue.contentEquals(KeyValue)) {
                RowIdentifier = i + 1;
                RowsContent[rowCounter] = this.getRowContentByRowNumber(RowIdentifier);
                ++rowCounter;
            }
        }
        return RowsContent;
    }
    
    public int getRowsCountByKeyValue(final String KeyColumn, final String KeyValue) {
        int rowCounter = 0;
        final int TotalRows = this.getTotalRowCount();
        final int keyColid = this.getColIndexByName(KeyColumn);
        for (int i = 0; i < TotalRows; ++i) {
            final String colValue = this.ReadCellActRef(i, keyColid);
            if (colValue.contentEquals(KeyValue)) {
                ++rowCounter;
            }
        }
        return rowCounter;
    }
    
    public String[] getRowContentByRowNumber(final int RowNumber) {
        if (RowNumber < 0) {
            OneframeContainer.OneframeLogger("Invalid Row or no matching row found for the key value");
            return null;
        }
        final String[] RowContent = new String[this.getTotalColumnCount()];
        final int acRowRef = this.getCellRef(RowNumber);
        for (int i = 0; i < this.getTotalColumnCount(); ++i) {
            RowContent[i] = this.ReadCellActRef(acRowRef, i);
        }
        return RowContent;
    }
    
    private String ReadCellActRef(final int RowNbr, final int ColNbr) {
        final DataFormatter formatter = new DataFormatter();
        final Cell cell = this.xlSheet.getRow(RowNbr).getCell(ColNbr);
        return formatter.formatCellValue(cell);
    }
    
    public String ReadCell(final int RowNbr, final int ColNbr) {
        return this.ReadCellActRef(this.getCellRef(RowNbr), this.getCellRef(ColNbr));
    }
    
    public String ReadCell(final int RowNbr, final String ColumnName) {
        final int ColNbr = this.getColIndexByName(ColumnName) + 1;
        return this.ReadCell(RowNbr, ColNbr);
    }
    
    public String ReadCell(final String KeyColumn, final String KeyValue, final String ColumnName) {
        return this.ReadCell(this.getRowIdentifier(KeyColumn, KeyValue), ColumnName);
    }
    
    public String[] getColumnHeaders() {
        final int headerRow = 0;
        final int totColumns = this.getTotalColumnCount();
        final String[] ColHeaders = new String[totColumns];
        OneframeContainer.OneframeLogger("Total number of columns : " + totColumns);
        for (int i = 0; i < totColumns; ++i) {
            final String cellValue = this.ReadCellActRef(0, i);
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Row, Column (" + headerRow + "," + i + ") : " + cellValue);
            if (cellValue != "" || cellValue != null) {
                ColHeaders[i] = cellValue;
            }
        }
        return ColHeaders;
    }
    
    public ExcelFile PrintColumnHeaders() {
        final int headerRow = 0;
        final int totColumns = this.getTotalColumnCount();
        OneframeContainer.OneframeLogger("Total number of columns : " + totColumns);
        for (int i = 0; i < totColumns; ++i) {
            final String cellValue = this.ReadCellActRef(0, i);
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Row, Column (" + headerRow + "," + i + ") : " + cellValue);
            if (cellValue != "" || cellValue != null) {
                OneframeContainer.OneframeLogger(cellValue);
            }
        }
        return this;
    }
    
    private int getCellRef(final int cellRef) {
        return cellRef - 1;
    }
    
    private int getRowIdentifier(final String KeyColumn, final String KeyValue) {
        int rowIdentifier = -1;
        final int TotalRows = this.getTotalRowCount();
        final int keyColid = this.getColIndexByName(KeyColumn);
        for (int i = 0; i < TotalRows; ++i) {
            final String colValue = this.ReadCellActRef(i, keyColid);
            if (colValue.contentEquals(KeyValue)) {
                rowIdentifier = i;
                break;
            }
        }
        return rowIdentifier;
    }
    
    private int getColIndexByName(final String ColName) {
        final int rowCount = this.xlSheet.getLastRowNum() - this.xlSheet.getFirstRowNum();
        final Row xlHeaderRow = this.xlSheet.getRow(0);
        for (int j = 0; j < xlHeaderRow.getLastCellNum(); ++j) {
            final String actColName = this.ReadCellActRef(0, j);
            if (actColName.equalsIgnoreCase(ColName)) {
                return j;
            }
        }
        OneframeLogger.Log("Column [" + ColName + "] not found in the Excel Sheet");
        return -1;
    }
    
    public ExcelFile WriteToCell(final int row, final int col, final String CellValue) {
        final Row xlDataRow = this.xlSheet.getRow(row);
        final Cell cell = xlDataRow.getCell(col);
        cell.setCellValue(CellValue);
        return this;
    }
    
    public ExcelFile WriteToCell(final String KeyColumn, final String KeyValue, final String ColumnName, final String CellValue) throws IOException {
        return this.WriteToCell(this.getRowIdentifier(KeyColumn, KeyValue), ColumnName, CellValue);
    }
    
    public ExcelFile WriteToCell(final int RowNbr, final String ColumnName, final String CellValue) throws IOException {
        return this.WriteToCell(RowNbr, this.getColIndexByName(ColumnName), CellValue);
    }
    
    public ExcelFile SaveChangesToExcelFile() {
        try {
            this.CloseInputStream();
            final FileOutputStream outputStream = new FileOutputStream(this.xlFile);
            this.xlWorkBook.write((OutputStream)outputStream);
            outputStream.close();
            OneframeLogger.Log("Chanages are saved to the excel file");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return this;
    }
    
    public ExcelFile SaveExcelAsCSVfile() {
        String OutputFile = OneframeConstants.RUNTIME_FOLDER;
        OutputFile = OutputFile.concat("/").concat(this.xlCurrWorkBookName.substring(0, this.xlCurrWorkBookName.indexOf(".xlsx"))).concat(".csv");
        return this.SaveExcelAsCSVfile(OutputFile);
    }
    
    public ExcelFile SaveExcelAsCSVfile(final String OutputFileName) {
        CSVPrinter csvPrinter = null;
        try {
            final FileWriter csvFileWriter = new FileWriter(OutputFileName);
            csvPrinter = new CSVPrinter((Appendable)csvFileWriter, CSVFormat.DEFAULT);
            if (this.xlWorkBook != null) {
                final Iterator<Row> rowIterator = (Iterator<Row>)this.xlSheet.rowIterator();
                while (rowIterator.hasNext()) {
                    final Row row = rowIterator.next();
                    final Iterator<Cell> cellIterator = (Iterator<Cell>)row.cellIterator();
                    while (cellIterator.hasNext()) {
                        final Cell cell = cellIterator.next();
                        switch (cell.getCellTypeEnum()) {
                            case BOOLEAN: {
                                csvPrinter.print((Object)cell.getBooleanCellValue());
                                continue;
                            }
                            case NUMERIC: {
                                csvPrinter.print((Object)cell.getNumericCellValue());
                                continue;
                            }
                            case STRING: {
                                csvPrinter.print((Object)cell.getStringCellValue());
                                continue;
                            }
                            case BLANK: {
                                csvPrinter.print((Object)"");
                                continue;
                            }
                            case FORMULA:
                            case _NONE:
                            case ERROR: {
                                continue;
                            }
                            default: {
                                csvPrinter.print((Object)"");
                                continue;
                            }
                        }
                    }
                    csvPrinter.println();
                }
            }
        }
        catch (Exception e) {
            OneframeContainer.OneframeErrorLogger("Error occurred while converting Excel to CSV - [" + e.getLocalizedMessage() + "]");
            try {
                if (csvPrinter != null) {
                    csvPrinter.flush();
                    csvPrinter.close();
                }
            }
            catch (IOException ioe) {
                OneframeContainer.OneframeErrorLogger("Error occurred while closing the CSV Printer - [" + ioe.getLocalizedMessage() + "]");
            }
        }
        finally {
            try {
                if (csvPrinter != null) {
                    csvPrinter.flush();
                    csvPrinter.close();
                }
            }
            catch (IOException ioe2) {
                OneframeContainer.OneframeErrorLogger("Error occurred while closing the CSV Printer - [" + ioe2.getLocalizedMessage() + "]");
            }
        }
        return this;
    }
    
    public ExcelFile addColumnToSheet(final String ColumnHeader) {
        Cell prevCell = null;
        for (final Row currentRow : this.xlSheet) {
            if (currentRow.getLastCellNum() != 0) {
                prevCell = currentRow.getCell(currentRow.getLastCellNum() - 1);
            }
            final Cell currCell = currentRow.createCell((int)currentRow.getLastCellNum(), CellType.STRING);
            if (prevCell != null) {
                currCell.setCellStyle(prevCell.getCellStyle());
            }
            if (currentRow.getRowNum() == 0) {
                currCell.setCellValue(ColumnHeader);
            }
        }
        return this;
    }
    
    public ExcelFile addRowToSheet() {
        Cell prevCell = null;
        for (final Row currentRow : this.xlSheet) {
            if (currentRow.getLastCellNum() != 0) {
                prevCell = currentRow.getCell(currentRow.getLastCellNum() - 1);
            }
            final Cell currCell = currentRow.createCell((int)currentRow.getLastCellNum(), CellType.STRING);
            if (prevCell != null) {
                currCell.setCellStyle(prevCell.getCellStyle());
            }
        }
        return this;
    }
    
    private FileInputStream OpenXlFileAsInputStream() {
        try {
            this.inputStream = new FileInputStream(this.xlFile);
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return this.inputStream;
    }
    
    public ExcelFile validateColumnHeaders(final String[] ExpectedColumns) {
        final String[] actualColumns = this.getColumnHeaders();
        for (int i = 0; i < ExpectedColumns.length; ++i) {
            ExcelFile.ofSA.assertEquals(actualColumns[i], ExpectedColumns[i], "Validate column header name for column(" + (i + 1) + ")");
        }
        return this;
    }
    
    public ExcelFile validateColumn(final int RowIdentifier, final String ColumnName, final String ExpectedValue) {
        final String xlCellValue = this.ReadCell(RowIdentifier, ColumnName);
        ExcelFile.ofSA.assertEquals(xlCellValue, ExpectedValue, "Validate column [" + ColumnName + "]");
        return this;
    }
    
    public ExcelFile validateColumn(final String KeyColumn, final String KeyValue, final String ColumnName, final String ExpectedValue) {
        final String xlCellValue = this.ReadCell(KeyColumn, KeyValue, ColumnName);
        ExcelFile.ofSA.assertEquals(xlCellValue, ExpectedValue, "Validate column [" + ColumnName + "]");
        return this;
    }
    
    public ExcelFile validateColumns(final int RowIdentifier, final String[] ColumnNames, final String[] ExpectedValues) {
        return this;
    }
    
    public ExcelFile validateColumns(final String KeyColumn, final String KeyValue, final String[] ColumnNames, final String[] ExpectedValues) {
        return this;
    }
    
    @Override
    protected void finalize() {
        this.CloseExcelFile();
        this.CloseInputStream();
    }
    
    static {
        ExcelFile.interimTotalCol = -1;
        ExcelFile.interimTotalrow = -1;
    }
}

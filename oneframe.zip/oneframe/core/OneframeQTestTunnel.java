// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import io.restassured.specification.RequestSpecification;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.http.Headers;
import io.restassured.http.Header;
import io.restassured.RestAssured;

public class OneframeQTestTunnel
{
    String ofRAresponseContent;
    
    public OneframeQTestTunnel(final String qTestProject) {
        RestAssured.baseURI = "https://qtest.ingenio-rx.com:8443/";
        final Header authHeader = new Header("Authorization", "bearer 3ae7b9d8-4d13-4d11-8680-bb01338d97ce");
        final Header AcceptTypeHeader = new Header("Accept-Type", "application/json");
        final Header ContentTypeHeader = new Header("Content-Type", "application/json");
        final Headers qTestheaders = new Headers(new Header[] { authHeader, AcceptTypeHeader, ContentTypeHeader });
        final RequestSpecification ofRArequest = RestAssured.given().relaxedHTTPSValidation();
        ofRArequest.headers(qTestheaders);
        final Response ofRAresponse = (Response)ofRArequest.request(Method.GET, "/api/v3/projects", new Object[0]);
        System.out.println("Response Code : " + ofRAresponse.getStatusCode());
        ofRAresponse.prettyPeek();
        this.ofRAresponseContent = ofRAresponse.getBody().asString();
        final ObjectMapper qtresMapper = new ObjectMapper();
    }
}

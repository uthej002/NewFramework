package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateHomePagePaginationImplementedClientReviewPendingWidget extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
    IBPHomePage homepage;
    
    @BeforeClass
	@Step("Initializing Test Script for validate Pagination is implemented in Client Review Pending Queue")
	public void setUp() {
		InitializeLaunchPad("IBPW_98");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Pagination is implemented in Client Review Pending Queue", dataProvider = "TestData")
	@Description("Validate Pagination is implemented in Client Review Pending Queue")
	public void verifyPaginationIsImplementedInProgressQueue(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			sa.assertTrue(welcomePage.verifyMyTasksWidgetDisplay(), "Verified My Task Widget is displayed");
			sa.assertTrue(welcomePage.verifyRemediationRequiredWidgetDisplay(), "Verified Remediation Required Widget is displayed");
			sa.assertTrue(welcomePage.verifyUsersWidgetDisplay(), "Verified User Widget is Displayed" );
			homepage.verifySearchButton();
			homepage.verifyMenuButton();
			sa.assertTrue(welcomePage.verifyClientReviewPendingWidgetDisplay(), "Verified Client Review Pending Header is displayed");
			sa.assertTrue(welcomePage.verifyViewAllButtonClientReviewPendingDisplay(), "Verified View All Button in Client Review Pending Secion is displayed");
			welcomePage.clickViewAllButtonClientReviewPending();
			sa.assertTrue(welcomePage.verifyPageTraversing("Client Review Pending"),"Verified Pagination is Implemneted in Client Review Pending Widget");	
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Pagination is implemented in Client Review Pending Queue Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Pagination is implemented in Client Review Pending Queue");
		}
		sa.assertAll();
		homepage.clickLogout();
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

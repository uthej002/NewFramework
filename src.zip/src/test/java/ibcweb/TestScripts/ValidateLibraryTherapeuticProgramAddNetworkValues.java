package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibraryTherapeuticProgramAddNetworkValues extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPLibrariesMandatesPage mandate;

	@BeforeClass
	@Step("Initializing Test Script for Validate if user is able to enter the values in networks tab after selecting the include option while creating a Therapeutic Program")
	public void setUp() {
		InitializeLaunchPad("IBPW_720");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		mandate =  new IBPLibrariesMandatesPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "NetworkOverride"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate if user is able to enter the values in networks tab after selecting the include option while creating a Therapeutic Program", dataProvider = "TestData")
	@Description("Validate if user is able to enter the values in networks tab after selecting the include option while creating a Therapeutic Program")
	public void ValidateLibrariesAddProgramNetworkValues(String TestCaseID, String TestStatus, String NetworkOverride)throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickAddProgramofPrograms();
			sa.assertTrue(librariesprogramspage.verifyAddNewProgramHeader(), "The Add New Program Section Page is displayed");			
			sa.assertTrue(mandate.selectNetworkOverrideDropdown(NetworkOverride),
					"Verified and Selected 'Network OverRide' dropdown");
			librariesprogramspage.clickNetworkTab();
			sa.assertTrue(librariesprogramspage.verifyAllNetworksHeader(), "The All Networks Section Page is displayed");
			librariesprogramspage.clickAllNetworksCheckbox();
			sa.assertTrue(librariesprogramspage.verifyandEnterRetailValues(), "Verified user is able to enter the values in networks tab after selecting the include option");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if user is able to enter the values in networks tab after selecting the include option while creating a Therapeutic Program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("User is unable to enter the values in networks tab after selecting the include option while creating a Therapeutic Program");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}



}

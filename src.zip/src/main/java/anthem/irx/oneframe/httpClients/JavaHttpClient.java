package anthem.irx.oneframe.httpClients;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;

public class JavaHttpClient {
  HttpURLConnection connection;
  
  URL url;
  
  public JavaHttpClient OpenConnection(String HttpURL) {
    try {
      this.url = new URL(HttpURL.trim());
      this.connection = (HttpURLConnection)this.url.openConnection();
    } catch (IOException e) {
      e.printStackTrace();
    } 
    return this;
  }
  
  public void Post(String joPayLoad) {
    String ContentLength = String.valueOf(joPayLoad.length());
    try {
      this.connection.setRequestMethod("POST");
      this.connection.setRequestProperty("Accept", "application/json");
      this.connection.setRequestProperty("Content-Type", "application/json");
      this.connection.setRequestProperty("Accept-Charset", "UTF-8");
      this.connection.setReadTimeout(15000);
      this.connection.setConnectTimeout(15000);
      this.connection.setDoOutput(true);
      this.connection.setRequestProperty("Content-Length", ContentLength);
    } catch (ProtocolException e1) {
      e1.printStackTrace();
    } 
    try {
      OutputStream outStream = this.connection.getOutputStream();
      outStream.write(joPayLoad.getBytes());
    } catch (IOException e) {
      e.printStackTrace();
    } 
    try {
      InputStream inputStream = this.connection.getInputStream();
      BufferedReader br1 = new BufferedReader(new InputStreamReader(inputStream));
      System.out.println("Connection Status - " + this.connection.getResponseCode());
      System.out.println("Server Error - " + this.connection.getErrorStream().toString());
      StringBuilder response = new StringBuilder();
      String responseSingle = null;
      while ((responseSingle = br1.readLine()) != null)
        response.append(responseSingle); 
      String xx = response.toString();
      System.out.println(xx);
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public String Get() {
    InputStream responseStream = null;
    try {
      responseStream = this.connection.getInputStream();
    } catch (IOException e) {
      e.printStackTrace();
    } 
    return responseStream.toString();
  }
}

package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesAccumulatorStructures;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumulatorLibraryCreateNewAccumApplyDeductibleEnable extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesAccumulatorStructures librariesaccumulatorpage;
	IBPAccumsBenefitPage accumsPage;

	@BeforeClass
	@Step("Initializing Test Script for Verify whether Accum Structure and apply deductable are in enable mode after clicking the create button")
	public void setUp() {
		InitializeLaunchPad("IBPW_707");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesaccumulatorpage = new IBPLibrariesAccumulatorStructures();
		accumsPage = new IBPAccumsBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","EffectiveDate","TermDate"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Verify whether Accum Structure and apply deductable are in enable  mode after clicking  the create button", dataProvider = "TestData")
	@Description("Verify whether Accum Structure and apply deductable are in enable  mode after clicking  the create button")
	public void ValidateAccumlatorStructreDeductibleLibrary(String TestCaseID, String TestStatus,String EffectiveDate,String TermDate)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesaccumulatorpage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			librariesaccumulatorpage.clickViewButtonOfAccumulatorStructures();
			sa.assertTrue(librariesaccumulatorpage.verifyAccumulatorStructuresHeader(),
					"Verified 'Accumulator Structures header' is displayed");
			librariesaccumulatorpage.clickAccumulatorStructuresTab();
			librariesaccumulatorpage.clickAccumulatorStructuresButton();
			sa.assertTrue(librariesaccumulatorpage.verifyAddAccumulatorStructureHeader(),
					"Verified 'Add New Accum Structure' header is Displayed");
	        String accumName = librariesaccumulatorpage.EnterAccumStructureName();		
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			librariesaccumulatorpage.EnterTermDate(TermDate);
			librariesaccumulatorpage.selectClientDropdown();
			librariesaccumulatorpage.selectLOBDropdown();
			librariesaccumulatorpage.selectStateDropdown();
			sa.assertTrue(librariesaccumulatorpage.verifyApplyDefaultsHeader(),
					"Verified 'Apply Defaults' header is Displayed");
			sa.assertTrue(librariesaccumulatorpage.clickDeductibleToggle(),
					"Verified and clicked on Apply Deductible Toggle");
			librariesaccumulatorpage.clickDeductibleTab();
			sa.assertTrue(accumsPage.EnterDeductibleValues(),
					"Verified and Entered All Deductible Values");
			librariesaccumulatorpage.clickAddAccumButton();
			sa.assertTrue(librariesaccumulatorpage.VerifyAccumIsCreated(accumName),
					"Verified the 'New Accum' is created and present in the Accum List");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Accum Structure and apply deductable are in enable mode after clicking the create button Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Create Accum Structure and apply deductable are in enable mode");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

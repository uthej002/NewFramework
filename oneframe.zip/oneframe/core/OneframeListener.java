// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import java.util.Iterator;
import java.util.Collection;
import org.testng.IInvokedMethod;
import anthem.irx.oneframe.utilities.DateTimeProcessor;
import org.testng.ISuite;
import org.testng.ITestContext;
import com.aventstack.extentreports.Status;
import org.testng.ITestResult;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import org.testng.IExecutionListener;
import org.testng.IInvokedMethodListener;
import org.testng.ISuiteListener;
import org.testng.ITestListener;

public class OneframeListener implements ITestListener, ISuiteListener, IInvokedMethodListener, IExecutionListener
{
    private static OneframeLogger oflogger;
    
    public void onExecutionStart() {
        WebObjectHandler.readOneframeConfiguration();
        OneframeContainer.OneframeLogger("[ONEFRAME][Oneframe Listener] Test Execution start - TestNG Runner");
    }
    
    public void onExecutionFinish() {
        OneframeContainer.OneframeLogger("[ONEFRAME][OL] Test Execution complete - TestNG Runner");
    }
    
    public void onTestStart(final ITestResult result) {
        final String className = result.getTestClass().getName();
        OneframeContainer.OneframeLogger("[ONEFRAME][OL][OnTS] Starting Test @ " + className);
        OneframeContainer.OneframeLogger("[ONEFRAME][OL][OnTS] Start Time :" + result.getTestContext().getStartDate().toString());
    }
    
    public void onTestSuccess(final ITestResult result) {
        OneframeContainer.OneframeLogger("[ONEFRAME][OL][OnTSu] Executed Test : " + result.getMethod().getMethodName() + " : Test Result -> PASSED");
        WebObjectHandler.gTestResult = "PASS";
        WebObjectHandler.ofReporter.CompleteTest(Status.PASS, result.getMethod().getDescription());
    }
    
    public void onTestFailure(final ITestResult result) {
        final String testName = result.getMethod().getMethodName();
        String base64Screenshot = "";
        String logMessage1 = "UNABLE TO GET FAILURE REASON OR ERRORS";
        WebObjectHandler.gTestResult = "FAIL";
        try {
            base64Screenshot = WebObjectHandler.takeScreenshotOnDemand();
            OneframeContainer.OneframeLogger("[ONEFRAME][OL][OnTestFailure][Failed @ Method Name] -> [" + result.getMethod().getMethodName() + "]");
            if (result.getThrowable() != null) {
                logMessage1 = "Method [".concat(testName).concat("] failed with error [").concat(this.getFailureReason(result));
                OneframeContainer.OneframeLogger("[ONEFRAME][OL][OnTestFailure][ERROR] -> " + this.getFailureReason(result));
            }
            if (base64Screenshot.equalsIgnoreCase(WebObjectHandler.glblScreenshotString)) {
                OneframeContainer.OneframeLogger("Test Method [" + testName + "] Failed \n [TEST_STEP_EXCEPTION] : " + logMessage1);
            }
            else {
                WebObjectHandler.glblScreenshotString = base64Screenshot;
                if (WebObjectHandler.glblScreenshotString != "") {
                    OneframeContainer.OneframeLogger("Test method [" + testName + "] Failed");
                }
                else {
                    OneframeContainer.OneframeLogger("Test  method [" + testName + "] Failed");
                }
            }
        }
        catch (Exception ex) {
            OneframeContainer.OneframeLogger(ex.getLocalizedMessage());
            OneframeContainer.OneframeLogger(result.getThrowable().getLocalizedMessage());
        }
    }
    
    public void onTestSkipped(final ITestResult result) {
        WebObjectHandler.gTestResult = "TEST SKIPPED";
        WebObjectHandler.ofReporter.CompleteTest(Status.SKIP, result.getTestClass().getTestName());
        OneframeContainer.OneframeLogger("[ONEFRAME][OF-LSTNR] Test Skipped : " + result.getTestName() + " : " + result.getTestClass());
    }
    
    public void onTestFailedButWithinSuccessPercentage(final ITestResult result) {
    }
    
    public void onStart(final ITestContext context) {
        final String className = context.getCurrentXmlTest().getClass().getCanonicalName();
        final String testScriptName = context.getCurrentXmlTest().getName();
        OneframeContainer.OneframeLogger("[ONEFRAME][OL][OnStart] Begin test execution of tests in class [" + className + "]");
        WebObjectHandler.ofReporter.CreateTest(testScriptName, testScriptName);
    }
    
    public void onFinish(final ITestContext context) {
        final String className = context.getName();
        OneframeContainer.OneframeLogger("[ONEFRAME][Oneframe Listener] Executed all tests in class " + className);
    }
    
    public void onStart(final ISuite suite) {
        OneframeContainer.OneframeLogger("[ONEFRAME][OL][onSS] Executing test suite [" + suite.getName() + "] on the 'Oneframe' automation framework");
        OneframeListener.oflogger = new OneframeLogger();
        (WebObjectHandler.ofReporter = new OneframeReporter()).createExtentReport(suite.getName() + "_" + DateTimeProcessor.getCurrentDateTime());
        OneframeContainer.OneframeLogger("[ONEFRAME][OL][onSS] oneframelogger and onframereporter initialized");
    }
    
    public void onFinish(final ISuite suite) {
        OneframeContainer.OneframeLogger("[ONEFRAME][Oneframe Listener][SoS] Completed executing test suite [" + suite.getName() + "] on the 'Oneframe' automation framework");
        WebObjectHandler.ofReporter.FinishExtentReport();
        OneframeListener.oflogger.cleanUp();
    }
    
    public void beforeInvocation(final IInvokedMethod method, final ITestResult testResult) {
        final String MethodName = method.getTestMethod().getMethodName();
        if (method.isTestMethod()) {
            OneframeContainer.OneframeLogger("[ONEFRAME][OL][BoM] Test Name - " + MethodName);
            OneframeContainer.OneframeLogger("[ONEFRAME][OL][BoM] Test Description - " + testResult.getMethod().getDescription());
            OneframeListener.oflogger.startVideoRecording(MethodName);
        }
        else {
            OneframeContainer.OneframeLogger("[ONEFRAME][OL][BoM] Execute Method => [" + testResult.getInstanceName() + "].[" + MethodName + "]");
        }
    }
    
    public void afterInvocation(final IInvokedMethod method, final ITestResult testResult) {
        final String MethodName = method.getTestMethod().getMethodName();
        String ErrorMessage = "";
        if (testResult.getStatus() != 1) {
            ErrorMessage = this.getFailureReason(testResult);
            OneframeContainer.OneframeLogger("[ONEFRAME][OL][EoM] Method [" + MethodName + "] failed due to " + ErrorMessage);
        }
        if (method.isTestMethod()) {
            OneframeContainer.OneframeLogger("[ONEFRAME][Oneframe Listener][EoM] Test Method Name - " + MethodName + "()");
            OneframeContainer.OneframeLogger("[ONEFRAME][Oneframe Listener][EoM] Test Description - " + testResult.getMethod().getDescription());
            OneframeListener.oflogger.stopVideoRecording();
        }
        else {
            OneframeContainer.OneframeLogger("[ONEFRAME][OL][EoM] End of Method - [" + testResult.getInstanceName() + "].[" + MethodName + "()]");
        }
    }
    
    protected String getFailureReason(final ITestResult result) {
        String errorMessage = "";
        String message = "";
        if (result.getThrowable() != null) {
            final Throwable thr = result.getThrowable();
            errorMessage = this.getFullStackTrace(thr);
            message = thr.getMessage();
            result.getTestContext().setAttribute("TestFailureMessage", (Object)message);
        }
        if (errorMessage.isEmpty()) {
            final Collection<ITestResult> results = (Collection<ITestResult>)result.getTestContext().getSkippedConfigurations().getAllResults();
            for (final ITestResult resultItem : results) {
                final String methodName = resultItem.getMethod().getMethodName();
                if (methodName.equals("executeBeforeTestMethod")) {
                    errorMessage = this.getFullStackTrace(resultItem.getThrowable());
                }
            }
        }
        if (errorMessage.length() == 0) {
            errorMessage = "UNABLE TO GET THE ERROR MESSAGE - REVIEW THE STACK TRACE";
        }
        return errorMessage;
    }
    
    private String getFullStackTrace(final Throwable thr) {
        String stackTrace = "";
        if (thr != null) {
            stackTrace = thr.getMessage() + "\n";
            final StackTraceElement[] stackTrace2;
            final StackTraceElement[] elems = stackTrace2 = thr.getStackTrace();
            for (final StackTraceElement elem : stackTrace2) {
                stackTrace = stackTrace + "\n" + elem.toString();
            }
        }
        return stackTrace;
    }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitNetworksPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitNetworksTabValues extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPBenefitNetworksPage networksPage;

	@BeforeClass
	@Step("Initializing Test Script for validating R90, Standard and Out Of Network values under Network Tab in Benefit Screen")
	public void setUp() {
		InitializeLaunchPad("IBPW_616");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		networksPage = new IBPBenefitNetworksPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefit Libraries Block of Business page Navigation", dataProvider = "TestData")
	@Description("Validate Benefit Libraries Block of Business page Navigation")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus, String Benefit)throws AWTException, InterruptedException, IOException {
		
		Map<String, String> backup = new HashedMap<String, String>();
		Map<String, String> newValues = new HashedMap<String, String>();
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Benefit header is displayed");
			
			sa.assertTrue(networksPage.clickNetworksTab(), "Click on Networks Tab");
			
			//take backup of existing values
			backup.put("StandardRetailMaxDaySupply", networksPage.getValue("Standard", "Retail", "maxDaySupply"));
			backup.put("StandardRetailRefillToSoon", networksPage.getValue("Standard", "Retail", "refillTooSoon"));
			backup.put("StandardHomeDeliveryMaxDaySupply", networksPage.getValue("Standard", "Home Delivery", "maxDaySupply"));
			backup.put("StandardHomeDeliveryRefillToSoon", networksPage.getValue("Standard", "Home Delivery", "refillTooSoon"));
			backup.put("R90RetailMaxDaySupply", networksPage.getValue("R90", "Retail", "maxDaySupply"));
			backup.put("R90RetailRefillToSoon", networksPage.getValue("R90", "Retail", "refillTooSoon"));
			backup.put("R90HomeDeliveryMaxDaySupply", networksPage.getValue("R90", "Home Delivery", "maxDaySupply"));
			backup.put("R90HomeDeliveryRefillToSoon", networksPage.getValue("R90", "Home Delivery", "refillTooSoon"));
			backup.put("OutOfNetworkRetailMaxDaySupply", networksPage.getValue("Out of Network", "Retail", "maxDaySupply"));
			backup.put("OutOfNetworkRetailRefillToSoon", networksPage.getValue("Out of Network", "Retail", "refillTooSoon"));
			
			//enter new values and save the benefit
			sa.assertTrue(createbenefitpage.ClickEditButtoninWFE(), "Clicked on Edit Button");
			sa.assertTrue(networksPage.clearAndEnterValue("Standard", "Retail", "maxDaySupply", "100"), "Enter Standard Retail Max Day Supply as 100");
			sa.assertTrue(networksPage.clearAndEnterValue("Standard", "Retail", "refillTooSoon", "100"), "Enter Standard Retail Refill Too Soon as 100");
			sa.assertTrue(networksPage.clearAndEnterValue("Standard", "Home Delivery", "maxDaySupply", "100"), "Enter Standard Home Delivery Max Day Supply as 100");
			sa.assertTrue(networksPage.clearAndEnterValue("Standard", "Home Delivery", "refillTooSoon", "100"), "Enter Standard Home Delivery Refill Too Soon as 100");			
			sa.assertTrue(networksPage.clearAndEnterValue("R90", "Retail", "maxDaySupply", "100"), "Enter R90 Retail Max Day Supply as 100");
			sa.assertTrue(networksPage.clearAndEnterValue("R90", "Retail", "refillTooSoon", "100"), "Enter R90 Retail Refill Too Soon as 100");
			sa.assertTrue(networksPage.clearAndEnterValue("R90", "Home Delivery", "maxDaySupply", "100"), "Enter R90 Home Delivery Max Day Supply as 100");
			sa.assertTrue(networksPage.clearAndEnterValue("R90", "Home Delivery", "refillTooSoon", "100"), "Enter R90 Home Delivery Refill Too Soon as 100");
			sa.assertTrue(networksPage.clearAndEnterValue("Out of Network", "Retail", "maxDaySupply", "100"), "Enter Out of Network Retail Max Day Supply as 100");
			sa.assertTrue(networksPage.clearAndEnterValue("Out of Network", "Retail", "refillTooSoon", "100"), "Enter Out of Network Retail Refill Too Soon as 100");
			
			sa.assertTrue(createbenefitpage.ClickWFECloseButton(), "Clicked on Close button");
			sa.assertTrue(createbenefitpage.ClickWFEExitAndSaveButton(), "Clicked on Exit & Save Button");
			
			//get the new values after saving benefit
			newValues.put("StandardRetailMaxDaySupply", networksPage.getValue("Standard", "Retail", "maxDaySupply"));
			newValues.put("StandardRetailRefillToSoon", networksPage.getValue("Standard", "Retail", "refillTooSoon"));
			newValues.put("StandardHomeDeliveryMaxDaySupply", networksPage.getValue("Standard", "Home Delivery", "maxDaySupply"));
			newValues.put("StandardHomeDeliveryRefillToSoon", networksPage.getValue("Standard", "Home Delivery", "refillTooSoon"));
			newValues.put("R90RetailMaxDaySupply", networksPage.getValue("R90", "Retail", "maxDaySupply"));
			newValues.put("R90RetailRefillToSoon", networksPage.getValue("R90", "Retail", "refillTooSoon"));
			newValues.put("R90HomeDeliveryMaxDaySupply", networksPage.getValue("R90", "Home Delivery", "maxDaySupply"));
			newValues.put("R90HomeDeliveryRefillToSoon", networksPage.getValue("R90", "Home Delivery", "refillTooSoon"));
			newValues.put("OutOfNetworkRetailMaxDaySupply", networksPage.getValue("Out of Network", "Retail", "maxDaySupply"));
			newValues.put("OutOfNetworkRetailRefillToSoon", networksPage.getValue("Out of Network", "Retail", "refillTooSoon"));
			
			//verify that the new values are same as we entered
			sa.assertTrue(networksPage.verifyNetworkValues(newValues, "100"), "Actual & Expected Values should be same after update");
					
			//update the benefit with the backup values
			sa.assertTrue(createbenefitpage.verifySavedMessage(), "Verify Benefit Saved Successfully Message");
			benefitpage.clickDetailsTab();
			sa.assertTrue(networksPage.clickNetworksTab(), "Click on Networks Tab");
			sa.assertTrue(networksPage.clickNetworksTab(), "Click on Networks Tab");
			sa.assertTrue(createbenefitpage.ClickEditButtoninWFE(), "Clicked on Edit Button");
			sa.assertTrue(networksPage.clearAndEnterValue("Standard", "Retail", "maxDaySupply", backup.get("StandardRetailMaxDaySupply")));
			sa.assertTrue(networksPage.clearAndEnterValue("Standard", "Retail", "refillTooSoon", backup.get("StandardRetailRefillToSoon")));
			sa.assertTrue(networksPage.clearAndEnterValue("Standard", "Home Delivery", "maxDaySupply", backup.get("StandardHomeDeliveryMaxDaySupply")));
			sa.assertTrue(networksPage.clearAndEnterValue("Standard", "Home Delivery", "refillTooSoon", backup.get("StandardHomeDeliveryRefillToSoon")));
			sa.assertTrue(networksPage.clearAndEnterValue("R90", "Retail", "maxDaySupply", backup.get("R90RetailMaxDaySupply")));
			sa.assertTrue(networksPage.clearAndEnterValue("R90", "Retail", "refillTooSoon", backup.get("R90RetailRefillToSoon")));
			sa.assertTrue(networksPage.clearAndEnterValue("R90", "Home Delivery", "maxDaySupply", backup.get("R90HomeDeliveryMaxDaySupply")));
			sa.assertTrue(networksPage.clearAndEnterValue("R90", "Home Delivery", "refillTooSoon", backup.get("R90HomeDeliveryRefillToSoon")));
			sa.assertTrue(networksPage.clearAndEnterValue("Out of Network", "Retail", "maxDaySupply", backup.get("OutOfNetworkRetailMaxDaySupply")));
			sa.assertTrue(networksPage.clearAndEnterValue("Out of Network", "Retail", "refillTooSoon", backup.get("OutOfNetworkRetailRefillToSoon")));
			
			
			newValues.put("StandardRetailMaxDaySupply", networksPage.getValue("Standard", "Retail", "maxDaySupply"));
			newValues.put("StandardRetailRefillToSoon", networksPage.getValue("Standard", "Retail", "refillTooSoon"));
			newValues.put("StandardHomeDeliveryMaxDaySupply", networksPage.getValue("Standard", "Home Delivery", "maxDaySupply"));
			newValues.put("StandardHomeDeliveryRefillToSoon", networksPage.getValue("Standard", "Home Delivery", "refillTooSoon"));
			newValues.put("R90RetailMaxDaySupply", networksPage.getValue("R90", "Retail", "maxDaySupply"));
			newValues.put("R90RetailRefillToSoon", networksPage.getValue("R90", "Retail", "refillTooSoon"));
			newValues.put("R90HomeDeliveryMaxDaySupply", networksPage.getValue("R90", "Home Delivery", "maxDaySupply"));
			newValues.put("R90HomeDeliveryRefillToSoon", networksPage.getValue("R90", "Home Delivery", "refillTooSoon"));
			newValues.put("OutOfNetworkRetailMaxDaySupply", networksPage.getValue("Out of Network", "Retail", "maxDaySupply"));
			newValues.put("OutOfNetworkRetailRefillToSoon", networksPage.getValue("Out of Network", "Retail", "refillTooSoon"));
			
			//verify that benefit is updated with backup values
			sa.assertTrue(networksPage.verifyNetworkValues(newValues, backup), "Actual & Expected Values should be same after update");
			
			sa.assertTrue(createbenefitpage.ClickWFECloseButton(), "Clicked on Close button");
			sa.assertTrue(createbenefitpage.ClickWFEExitAndSaveButton(), "Clicked on Exit & Save Button");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Benefit Libraries Block of Business page Navigation Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Benefit Libraries Block of Business page Navigation");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

package com.ibc.base;

public class UtilityBase {

}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateUIElementsInAccumsVendorPage extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating UI elements in Accums Tab -> Vendor subtab on the Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_353");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "NewBenefitID"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate  Edit the Deductible Tab values in Accums Tab on the Benefit", dataProvider = "TestData")
	@Description("Validate Edit the Deductible Tab values in Accums Tab on the Benefit")
	public void ValidateCDHPFieldValuesinAccumsTab(String TestCaseID, String TestStatus, String NewBenefitID)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitID);
			createbenefitpage.verifyFilterByTxt();
			createbenefitpage.clickExistBenefit();
			accumsbenefitpage.clickOnAccumsTab();
			
			sa.assertTrue(accumsbenefitpage.clickVendorTab(), "Clicked on Vendor Tab");
			sa.assertTrue(accumsbenefitpage.verifyVendorTabHeaderAndValuesAreDisplayed() , "Verified Vendor tab elements are displayed");
			
			createbenefitpage.ClickEditButtoninWFE();		
			
			sa.assertTrue(accumsbenefitpage.verifyVendorTabHeaderAndValuesAreDisplayed() , "Verified Vendor tab elements are displayed");
			
			createbenefitpage.ClickWFECloseButton(); 
			createbenefitpage.ClickWFEExitAndSaveButton(); 
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit the Deductible Tab values in Accums Tab on the Benefit Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Edit the Deductible Tab values in Accums Tab on the Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

	
	

}

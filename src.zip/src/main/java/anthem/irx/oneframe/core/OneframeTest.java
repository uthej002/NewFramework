package anthem.irx.oneframe.core;

public class OneframeTest {}

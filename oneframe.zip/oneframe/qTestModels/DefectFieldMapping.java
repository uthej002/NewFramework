// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DefectFieldMapping
{
    @JsonProperty("field")
    private String field;
    @JsonProperty("qtest_fields")
    private List<String> qtestFields;
    
    public DefectFieldMapping() {
        this.field = null;
        this.qtestFields = new ArrayList<String>();
    }
    
    public DefectFieldMapping field(final String field) {
        this.field = field;
        return this;
    }
    
    public String getField() {
        return this.field;
    }
    
    public void setField(final String field) {
        this.field = field;
    }
    
    public DefectFieldMapping qtestFields(final List<String> qtestFields) {
        this.qtestFields = qtestFields;
        return this;
    }
    
    public DefectFieldMapping addQtestFieldsItem(final String qtestFieldsItem) {
        this.qtestFields.add(qtestFieldsItem);
        return this;
    }
    
    public List<String> getQtestFields() {
        return this.qtestFields;
    }
    
    public void setQtestFields(final List<String> qtestFields) {
        this.qtestFields = qtestFields;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final DefectFieldMapping defectFieldMapping = (DefectFieldMapping)o;
        return Objects.equals(this.field, defectFieldMapping.field) && Objects.equals(this.qtestFields, defectFieldMapping.qtestFields);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.field, this.qtestFields);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class DefectFieldMapping {\n");
        sb.append("    field: ").append(this.toIndentedString(this.field)).append("\n");
        sb.append("    qtestFields: ").append(this.toIndentedString(this.qtestFields)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

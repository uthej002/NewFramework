// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

public class EdgeWebDriverManager extends WebDriverManager
{
    @Override
    protected void createWebDriver() {
    }
}

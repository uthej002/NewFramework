package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumsCostSharesApplyOtherContents extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating headers and toggles in Cost Shares Apply tab under Accums Tab on Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_131");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "Benefit" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate headers and toggles in Cost Shares Apply tab under Accums Tab on Benefit", dataProvider = "TestData")
	@Description("Validate headers and toggles in Cost Shares Apply tab under Accums Tab on Benefit")
	public void ValidateEnableDisableTogglesandTabsinAccumsTab(String TestCaseID, String TestStatus, String Benefit)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {	
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");
			accumsbenefitpage.clickOnAccumsTab();
			accumsbenefitpage.clickCostSharesApply();
			sa.assertTrue(accumsbenefitpage.validteOthersLabelIsDisplayed(), "'Others' label is displayed");
			sa.assertTrue(accumsbenefitpage.validteGenericDrugsLabelIsDisplayed(), "Generic Drugs header is displayed");
			sa.assertTrue(accumsbenefitpage.validteDawPenaltyLabelIsDisplayed(), "DAW Penalty header is displayed");
			sa.assertTrue(accumsbenefitpage.validteInNetworkLabelIsDisplayed(), "IN NETWORK header is displayed");
			sa.assertTrue(accumsbenefitpage.validteOutOfNetworkLabelIsDisplayed(), "OUT OF NETWORK header is displayed");
			sa.assertTrue(accumsbenefitpage.validteGenericDrugsTogglesAreNotInteractable(), "Generic Drugs Toggles are Not Interactable in view mode");
			sa.assertTrue(accumsbenefitpage.validteDawPenaltyTogglesAreNotInteractable(), "DAW Penalty Toggles are Not Interactable in view mode");
			sa.assertTrue(createbenefitpage.ClickEditButtoninWFE(), "CLicked on edit button");			
			createbenefitpage.clickMandatesTab();
			createbenefitpage.clickStateTab();
			accumsbenefitpage.clickOnAccumsTab();
			accumsbenefitpage.clickCostSharesApply();
			sa.assertTrue(accumsbenefitpage.enableGenericDrugsToggles(), "Enabled all Generic Drugs toggles");
			sa.assertTrue(accumsbenefitpage.enableDawPenaltyToggles(), "Enabled all Daw Penalty toggles");
			sa.assertTrue(createbenefitpage.ClickCloseButton(), "Clicked on CLose Button");
			sa.assertTrue(createbenefitpage.ClickWFEExitAndSaveButton(), "Clicked on Exit and Save Button");
			sa.assertTrue(accumsbenefitpage.validteGenericDrugsTogglesAreOn(), "Verified Generic Drugs Toggles are ON");
			sa.assertTrue(accumsbenefitpage.validteDawPenaltyTogglesAreOn(), "Verified DAW Penalty Toggles are ON");
			accumsbenefitpage.clickOnAccumsTab();
			sa.assertTrue(createbenefitpage.ClickEditButtoninWFE(), "Clicked on Edit Button");
			createbenefitpage.clickMandatesTab();
			createbenefitpage.clickStateTab();
			accumsbenefitpage.clickOnAccumsTab();
			accumsbenefitpage.clickCostSharesApply();
			sa.assertTrue(accumsbenefitpage.validteGenericDrugsTogglesAreOn(), "Generic Drugs Toggles are ON");
			sa.assertTrue(accumsbenefitpage.validteDawPenaltyTogglesAreOn(), "DAW Penalty Toggles are ON");
			sa.assertTrue(accumsbenefitpage.disableGenericDrugsToggles(), "Disabled all Generic Drugs toggles");
			sa.assertTrue(accumsbenefitpage.disableDawPenaltyToggles(), "Disabled all Daw Penalty toggles");
			sa.assertTrue(createbenefitpage.ClickCloseButton(), "Clicked on CLose Button");
			sa.assertTrue(createbenefitpage.ClickWFEExitAndSaveButton(), "Clicked on Exit and Save Button");
			
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated enable and disable toggles and respective tabs display in Accums Tab on Benefit successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate enable and disable toggles and respective tabs display in Accums Tab on Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

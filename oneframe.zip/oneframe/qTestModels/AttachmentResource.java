// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import org.joda.time.DateTime;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class AttachmentResource
{
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("name")
    private String name;
    @JsonProperty("content_type")
    private String contentType;
    @JsonProperty("data")
    private String data;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("web_url")
    private String webUrl;
    @JsonProperty("created_date")
    private DateTime createdDate;
    @JsonProperty("author")
    private AttachmentAuthor author;
    @JsonProperty("artifact_id")
    private Long artifactId;
    
    public AttachmentResource() {
        this.links = new ArrayList<Link>();
        this.name = null;
        this.contentType = null;
        this.data = null;
        this.id = null;
        this.webUrl = null;
        this.createdDate = null;
        this.author = null;
        this.artifactId = null;
    }
    
    public AttachmentResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public AttachmentResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public AttachmentResource name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public AttachmentResource contentType(final String contentType) {
        this.contentType = contentType;
        return this;
    }
    
    public String getContentType() {
        return this.contentType;
    }
    
    public void setContentType(final String contentType) {
        this.contentType = contentType;
    }
    
    public AttachmentResource data(final String data) {
        this.data = data;
        return this;
    }
    
    public String getData() {
        return this.data;
    }
    
    public void setData(final String data) {
        this.data = data;
    }
    
    public AttachmentResource id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public String getWebUrl() {
        return this.webUrl;
    }
    
    public AttachmentResource createdDate(final DateTime createdDate) {
        this.createdDate = createdDate;
        return this;
    }
    
    public DateTime getCreatedDate() {
        return this.createdDate;
    }
    
    public void setCreatedDate(final DateTime createdDate) {
        this.createdDate = createdDate;
    }
    
    public AttachmentResource author(final AttachmentAuthor author) {
        this.author = author;
        return this;
    }
    
    public AttachmentAuthor getAuthor() {
        return this.author;
    }
    
    public void setAuthor(final AttachmentAuthor author) {
        this.author = author;
    }
    
    public Long getArtifactId() {
        return this.artifactId;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final AttachmentResource attachmentResource = (AttachmentResource)o;
        return Objects.equals(this.links, attachmentResource.links) && Objects.equals(this.name, attachmentResource.name) && Objects.equals(this.contentType, attachmentResource.contentType) && Objects.equals(this.data, attachmentResource.data) && Objects.equals(this.id, attachmentResource.id) && Objects.equals(this.webUrl, attachmentResource.webUrl) && Objects.equals(this.createdDate, attachmentResource.createdDate) && Objects.equals(this.author, attachmentResource.author) && Objects.equals(this.artifactId, attachmentResource.artifactId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links, this.name, this.contentType, this.data, this.id, this.webUrl, this.createdDate, this.author, this.artifactId);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class AttachmentResource {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    contentType: ").append(this.toIndentedString(this.contentType)).append("\n");
        sb.append("    data: ").append(this.toIndentedString(this.data)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    webUrl: ").append(this.toIndentedString(this.webUrl)).append("\n");
        sb.append("    createdDate: ").append(this.toIndentedString(this.createdDate)).append("\n");
        sb.append("    author: ").append(this.toIndentedString(this.author)).append("\n");
        sb.append("    artifactId: ").append(this.toIndentedString(this.artifactId)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

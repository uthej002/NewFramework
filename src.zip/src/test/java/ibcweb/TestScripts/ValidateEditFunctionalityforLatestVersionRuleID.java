package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateEditFunctionalityforLatestVersionRuleID extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;

	@BeforeClass
	@Step("Initializing Test Script for validating Edit Functinality for Latest Version RuleID")
	public void setUp() {
		InitializeLaunchPad("IBPW_20");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","LibraryName","RuleName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit Functinality for Latest Version RuleID", dataProvider = "TestData")
	@Description("Validate Edit Functinality for Latest Version RuleID")
	public void ValidateEditFunctionofVersions(String TestCaseID, String TestStatus,String LibraryName,String RuleName) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickStagingLink(); 
            rulebuilderstaging.clickLibrary(LibraryName);
            //ruleid.getLatestVersionID(LibraryName, RuleName);
            String versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
           // rulebuilderstaging.clickRuleName(LibraryName, RuleName);
			ruleid.clickLatestVersionofRuleID(versionId);
			sa.assertTrue(!ruleid.verifyRuleNamedisplay(), "Verified Rule Name field is disabled");
			sa.assertTrue(!ruleid.verifyDescriptiondisplay(), "Verified Description field is disabled");
			sa.assertTrue(!ruleid.verifyStartandEndDatedisplay(), "Verified Start and End Date field is disabled");
			sa.assertTrue(!ruleid.verifyMessagedisplay(), "Verified Message field is disabled");
			sa.assertTrue(ruleid.verifyImpactAnalysisbuttondisplay(), "Verified Impact Analysis button is displayed");
			sa.assertTrue(ruleid.verifyEditbuttondisplay(), "Verified Edit button is displayed");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Edit Functionality for Latest Version RuleID successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Edit Functionality for Latest Version RuleID unsuccessful");
		}
		
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}


}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBREEditRulePage extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;
	IBPRuleIDPage ruleidpage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Edit Rule Page")
	public void setUp() {
		InitializeLaunchPad("IBPW_18");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();
		ruleidpage = new IBPRuleIDPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {
		String[] fieldNames = { "TestCaseID", "TestStatus", "RuleName", "Description", "Message", "StartDate",
				"EndDate", "ClientId", "LOBId", "StateId", "DType" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit Rule Page", dataProvider = "TestData")
	@Description("Validate Edit Rule Page")
	public void ValidateEditRulePage(String TestCaseID, String TestStatus, String RuleName, String Description,
			String Message, String StartDate, String EndDate,  String ClientId, String LOBId, String StateId, String DType) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();
			sa.assertTrue(addrulepage.verifyCreateaRuleHeader(), "Create a Rule Header is displayed");
			addrulepage.EnterRuleName(RuleName);
			addrulepage.EnterDescription(Description);
			addrulepage.EnterMessage(Message);
			addrulepage.EnterStartDate(StartDate);
			addrulepage.EnterEndDate(EndDate);			
			sa.assertTrue(addrulepage.selectClientIdDropdown(ClientId), "Client Dropdown has been selected");
			sa.assertTrue(addrulepage.selectLobIdDropdown(LOBId), "Lob Dropdown has been selected");
			sa.assertTrue(addrulepage.selectStateIdDropdown(StateId), "State Dropdown has been selected");
			addrulepage.clickAddButton();
			sa.assertTrue(addrulepage.selectLibraryDropdown(), "Library Dropdown has been selected");
			sa.assertTrue(addrulepage.selectPropertyDropdown(), "Property Dropdown has been selected");
			sa.assertTrue(addrulepage.selectOperatorDropdown(), "Operator Dropdown has been selected");
			sa.assertTrue(addrulepage.selectRHSDropdown(), "RHS Dropdown has been selected");		
			sa.assertTrue(addrulepage.selectDecisionTypeDropdown(DType), "Decision Type Dropdown has been selected");
			addrulepage.ClickAddRuleButton();
			sa.assertTrue(rulebuilderstaging.verifyRuleIDTitleDisplay(), "Rule ID Title is displayed");
			//ruleidpage.clickLatestVersionofRuleID();
			//rulebuilderstaging.clickLibrary(LibraryName);
           // String versionId = ruleidpage.getLatestVersionID("Base Formulary", RuleName);
            //rulebuilderstaging.clickRule(LibraryName, RuleName);
            ruleidpage.clickLatestVersionofRuleID("0.1");
			sa.assertTrue(ruleidpage.verifyEditbuttondisplay(), "Edit Button is displayed");
			sa.assertTrue(ruleidpage.verifyImpactAnalysisbuttondisplay(), "Impact Analysis is button displayed");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Edit Rule Page successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Edit Rule Page");
		}	
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}


}

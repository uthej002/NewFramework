// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeContainer;
import java.net.UnknownHostException;
import java.net.InetAddress;

public class SystemInformation
{
    public static String SystemName;
    public static String CanonicalSystemName;
    public static String HostAddress;
    public static String username;
    public static String OSName;
    public static String OSArchicture;
    public static String OSVersion;
    public static String JavaVersion;
    
    public SystemInformation() {
        try {
            SystemInformation.username = System.getProperty("user.name");
            SystemInformation.OSName = System.getProperty("os.name");
            SystemInformation.OSArchicture = System.getProperty("os.arch");
            SystemInformation.OSVersion = System.getProperty("os.version");
            SystemInformation.SystemName = InetAddress.getLocalHost().getHostName();
            SystemInformation.CanonicalSystemName = InetAddress.getLocalHost().getCanonicalHostName();
            SystemInformation.HostAddress = InetAddress.getLocalHost().getHostAddress();
            SystemInformation.JavaVersion = System.getProperty("java.version");
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
    
    public void printSystemInformation() {
        OneframeContainer.OneframeLogger("OS Name - " + SystemInformation.OSName);
        OneframeContainer.OneframeLogger("OS Architecture - " + SystemInformation.OSArchicture);
        OneframeContainer.OneframeLogger("OS Version - " + SystemInformation.OSVersion);
        OneframeContainer.OneframeLogger("User Name - " + SystemInformation.username);
        OneframeContainer.OneframeLogger("System Name - " + SystemInformation.SystemName);
        OneframeContainer.OneframeLogger("IP Address - " + SystemInformation.HostAddress);
        OneframeContainer.OneframeLogger("Java Version - " + SystemInformation.JavaVersion);
    }
    
    static {
        SystemInformation.SystemName = null;
        SystemInformation.CanonicalSystemName = null;
        SystemInformation.HostAddress = null;
        SystemInformation.username = null;
        SystemInformation.OSName = null;
        SystemInformation.OSArchicture = null;
        SystemInformation.OSVersion = null;
        SystemInformation.JavaVersion = null;
    }
}

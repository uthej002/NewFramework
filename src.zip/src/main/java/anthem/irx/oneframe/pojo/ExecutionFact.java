package anthem.irx.oneframe.pojo;

public class ExecutionFact {
  public String name;
  
  public String value;
  
  public void setName(String name) {
    this.name = name;
  }
  
  public void setValue(String value) {
    this.value = value;
  }
  
  public boolean equals(Object o) {
    if (o == this)
      return true; 
    if (!(o instanceof ExecutionFact))
      return false; 
    ExecutionFact other = (ExecutionFact)o;
    if (!other.canEqual(this))
      return false; 
    Object this$name = getName(), other$name = other.getName();
    if ((this$name == null) ? (other$name != null) : !this$name.equals(other$name))
      return false; 
    Object this$value = getValue(), other$value = other.getValue();
    return !((this$value == null) ? (other$value != null) : !this$value.equals(other$value));
  }
  
  protected boolean canEqual(Object other) {
    return other instanceof ExecutionFact;
  }
  
  public int hashCode() {
    int PRIME = 59;
    int result = 1;
    Object $name = getName();
    result = result * 59 + (($name == null) ? 43 : $name.hashCode());
    Object $value = getValue();
    return result * 59 + (($value == null) ? 43 : $value.hashCode());
  }
  
  public String toString() {
    return "ExecutionFact(name=" + getName() + ", value=" + getValue() + ")";
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getValue() {
    return this.value;
  }
}

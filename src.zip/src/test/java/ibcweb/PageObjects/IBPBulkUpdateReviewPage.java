
package ibcweb.PageObjects;

import java.lang.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.CSVFile;
import io.qameta.allure.Step;

public class IBPBulkUpdateReviewPage extends OneframeContainer {
	
	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();
	
	//PageObjects
	
	@FindBy(xpath="//div[@class='tabs-container']/h3")
	WebElement hdrUpdateGeneralDefaults;
	
	@FindBy(xpath="//h3[text()='High Dollar']")
	WebElement hdrHighDollar;
	
	@FindBy(xpath="//h3[text()='High Dollar']/following-sibling::div/p/span[1]")
	WebElement txtRetailValue;
	
	@FindBy(xpath="//h3[text()='High Dollar']/following-sibling::div/p/span/span")
	WebElement txtHomeDeliveryValue;
	
	@FindBy(xpath="//div[@class='tabs-container']/div/a")
	WebElement lnkExportPreview;
	
	@FindBy(xpath="//button[@type='button']")
	WebElement btnBack;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement btnBulkUpdate;
	
	@FindBy(xpath="//form/h3")
	WebElement hdrBulkUpdate;

	@FindBy(xpath="//form/textarea")
	WebElement textAreaNotes;
	
	@FindBy(xpath="//form/div/strong")
	WebElement confirmMessage;
	
	@FindBy(xpath="//form//button/span[text()='No']")
	WebElement btnNo;
	
	@FindBy(xpath="//form//button/span[text()='Yes']")
	WebElement btnYes;
	
	@FindBy(xpath="//form/mat-error")
	WebElement inputBoxSize;
	
	
	
// Initializing the Page Objects:
	public IBPBulkUpdateReviewPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions
	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}
	
	@Step("Verify UPDATE GENERAL DEFAULTS Header is displayed")
	public boolean verifyUpdateGeneralDefaultsHeading() {
		boolean flag = false;
		if (ObjectExist(hdrUpdateGeneralDefaults)) {
			if (hdrUpdateGeneralDefaults.getText().trim().equalsIgnoreCase("UPDATE GENERAL DEFAULTS")) {
				flag = true;
				highlightElement(hdrUpdateGeneralDefaults);
				OneframeLogger("UPDATE GENERAL DEFAULTS header is displayed");
			}
		}
		else {
			OneframeLogger("UPDATE GENERAL DEFAULTS header is not displayed");
		}
		return flag;
	}
	
	@Step("Verify Retial value")
	public boolean verifyRetailValue(String retailVal) {
		boolean flag = false;
		String expectedRetialValue = "$"+retailVal;
		if (ObjectExist(txtRetailValue)) {
			String actualValue = txtRetailValue.getText().trim();
			if (actualValue.trim().equalsIgnoreCase(expectedRetialValue)) {
				flag = true;
				highlightElement(txtRetailValue);
				OneframeLogger("Retial value is displayed");
			}
		}
		else {
			OneframeLogger("Retial value is not displayed");
		}
		return flag;
	}
	
	@Step("Verify Home Delivery value")
	public boolean verifyHomeDeliveryValue(String homeDeliveryVal) {
		boolean flag = false;
		String expectedHomeDeliveryValue = "$"+homeDeliveryVal;
		if (ObjectExist(txtHomeDeliveryValue)) {
			String actualValue = txtHomeDeliveryValue.getText().trim();
			if (actualValue.trim().equalsIgnoreCase(expectedHomeDeliveryValue)) {
				flag = true;
				highlightElement(txtHomeDeliveryValue);
				OneframeLogger("Home Delivery value is displayed");
			}
		}
		else {
			OneframeLogger("Home Delivery value is not displayed");
		}
		return flag;
	}
	
	@Step("Click on Back Button")
	public void clickBackButton() {
		if (btnBack.isEnabled()) {
			highlightElement(btnBack);
			ClickWebObject(btnBack);
		}
	}
	
	@Step("Click on Bulk Update Button")
	public void clickBulkUpdateButton() {
		if (btnBulkUpdate.isEnabled()) {
			highlightElement(btnBulkUpdate);
			
			ClickWebObject(btnBulkUpdate);
		}
	}
	
	@Step("Click on Yes Button")
	public void clickYesButton() {
		if (btnYes.isEnabled()) {
			highlightElement(btnYes);
			ClickWebObject(btnYes);
		}
	}
	
	@Step("Click on Export Preview link")
	public void clickExportPreviewLink() {
		if (lnkExportPreview.isEnabled()) {
			highlightElement(lnkExportPreview);
			ClickWebObject(lnkExportPreview);
			OneframeLogger("Clicked on Export Preview Link");
		}
	}
	

	@Step("Validate data in excel against data in the UI")
	public boolean excelValidations(ArrayList<ArrayList> expectedContent, String projectID) throws InterruptedException {
		boolean flg = false;
		CSVFile csvFile1;
		String fileName = null;
		Thread.sleep(5000);
		Path dir = Paths.get("C:\\Users\\ah91660\\git\\ibc\\src\\test\\resources\\RunTime");
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*.csv"))
        {
           
            for(Path p: stream)
            {  
                System.out.println(p.getFileName());
                fileName = p.getFileName().toString();
            }
        }
        catch(Exception e)
        {
            System.out.println("problems locating directory");
        }
		
		//String fileName = "BulkUpdate__General_" + projectID + "_" +java.time.LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS).toString().replace(":", "_");
		System.out.println(fileName);
		
		
		//swapping the values to match the order in excel sheet
		for(ArrayList list: expectedContent) {
			Object tmp = list.get(6);
			list.remove(6);
			list.add(7, tmp);	
		}
		
		String[] expectedColHeaders = new String[]{
				"Benefit Plan ID", 
				"Client", 
				"LOB", 
				"State", 
				"Version Before Update", 
				"High Dollar Retail Before Update", 
				"High Dollar Retail To Be Updated With",
				"High Dollar Home Delivery Before Update",
				"High Dollar Home Delivery To Be Updated With"};
		
		//using old csv file which was manually copied to testdata folder	
		try {
			csvFile1 = new CSVFile("RunTime", fileName);
			csvFile1.OpenFile().validateColumnHeaders(expectedColHeaders);
		}
		catch(Exception e) {
			csvFile1 = new CSVFile("RunTime", fileName);
			csvFile1.OpenFile().validateColumnHeaders(expectedColHeaders);
		}
		
		for(int j=0; j<expectedContent.size(); j++) {			
			String[] actualRowContent = csvFile1.getRowContentByRowNumber(j+2);			
			
			for(int i=0; i<expectedColHeaders.length; i++) {
				//boolean flag = expectedContent.contains(actualRowContent[i]);
				
				  if(actualRowContent[i].equalsIgnoreCase((String)expectedContent.get(j).get(i))) { 
					  OneframeLogger("Actual Value: " +actualRowContent[i]+ " | Expected Value: " +expectedContent.get(j).get(i));
					  flg = true; 
				  } 
				  else { 
					  OneframeLogger("Actual Value: " +actualRowContent[i]+ " | Expected Value: " +expectedContent.get(j).get(i));
					  flg = false; 
					  return flg; 
				  }
				 
			}

		}
		csvFile1.CloseFile();
		
	return flg;
	}
	
	
	@Step("Verify the size of Text Area")
	public void verifyTextAreaSize() {
		String expectedText = "0/256";
		if(WaitForObject(inputBoxSize)) {
			int lengthOfDataInTextArea = textAreaNotes.getAttribute("value").length();
			String actualLimit = inputBoxSize.getText().trim();
			String toBeRemoved = actualLimit.substring(actualLimit.indexOf("/"));
			int dataSize = Integer.parseInt(actualLimit.replace(toBeRemoved, ""));
			
			if(lengthOfDataInTextArea == 0) {
				if(inputBoxSize.getText().trim().equalsIgnoreCase(expectedText)) {
					OneframeLogger("Text Area capacity is displayed as: " +expectedText);
				}
				else {
					OneframeLogger("Text Area capacity is not displayed as: " +expectedText);
				}	
			}
			else {
				if(lengthOfDataInTextArea == dataSize) {
					OneframeLogger("Text Area capacity is displayed as: " +expectedText);
				}
				else {
					OneframeLogger("Text Area capacity is not displayed as: " +expectedText);
				}
			}
		}
	}
	
	
	@Step("Enter data into the notes field")
	public void enterNotes(String data) {
		if(WaitForObject(textAreaNotes)) {
			EnterText(textAreaNotes, data);
		}
	}
	
}

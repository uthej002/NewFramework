
package ibcweb.PageObjects;

import static anthem.irx.oneframe.core.OneframeContainer.OneframeLogger;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.stream.IntStream;
import java.lang.*;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.ExcelFile;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class IBPBulkUpdatePage extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();
	Robot robot;
	String projectID = "";

	// PageObjects

	@FindBy(xpath = "//div[@class='header']/h2")
	WebElement hdrBenefitBulkSubmit;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Bulk Process ']")
	WebElement btnBulkProcess;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Bulk Update ']")
	WebElement btnBulkUpdate;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Bulk Submit ']")
	WebElement btnBulkSubmit;

	@FindBy(xpath = "//div[@class='header']/h2")
	WebElement hdrbenefitBulkUpdate;

	@FindBy(xpath = "//button/span[text()=' Create a Project ']")
	WebElement btnCreateAProject;

	@FindBy(xpath = "//button[@data-automation-id='createCancel']")
	WebElement btnCancel;

	@FindBy(xpath = "//span[text()=' Create Project ']/..")
	WebElement btnCreateProject;

	@FindBy(xpath = "//h3[text()='Create a Project']")
	WebElement hdrCreateProject;

	@FindBy(xpath = "//span[text()='CREATE PROJECT']")
	WebElement progressBarCreateProject;

	@FindBy(xpath = "//span[text()='WORK IN PROGRESS']")
	WebElement progressBarWorkInProgress;

	@FindBy(xpath = "//span[text()='REVIEW']")
	WebElement progressBarReview;

	@FindBy(xpath = "//span[text()='PROCESSING']")
	WebElement progressBarProcessing;

	@FindBy(xpath = "//span[text()='BULK UPDATED']")
	WebElement progressBarBulkUpdated;

	@FindBy(xpath = "//span[text()='UNLOCK BENEFITS']")
	WebElement progressBarUnlockBenefits;

	@FindBy(xpath = "//span[text()='COMPLETE']")
	WebElement progressBarComplete;

	@FindBy(xpath = "//h3[text()='Project Data']")
	WebElement hdrProjectData;

	@FindBy(xpath = "//input[@formcontrolname='projectId']")
	WebElement inputProjectID;

	@FindBy(xpath = "//textarea[@formcontrolname='description']/following-sibling::span//mat-label")
	WebElement hdrDescription;

	@FindBy(xpath = "//textarea[@formcontrolname='description']")
	WebElement inputDescription;

	@FindBy(xpath = "//input[@formcontrolname='projectId']/following-sibling::span//mat-label")
	WebElement hdrProjectID;

	@FindBy(xpath = "//label[text()='File Upload']")
	WebElement lnkFileUpload;

	@FindBy(xpath = "//h4[text()=' Upload Benefits ']")
	WebElement hdrUploadBenefits;

	@FindBy(xpath = "//div[@class='file-upload']")
	WebElement uploadedFileName;

	@FindBy(css = "div.upload-result-success p b")
	WebElement uploadSuccessMessage;

	@FindBy(xpath = "//table/tbody/tr[1]")
	WebElement projectIDListItem1;

	@FindBy(xpath = "//mat-paginator/div/div/div/div")
	WebElement txtPageNumber;

	@FindBy(xpath = "//button[@aria-label='Next page']")
	WebElement nextButton;

	@FindBy(xpath = "//*[@class=\"mat-paginator-icon\"]")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//table/thead/tr/th")
	List<WebElement> hdrLandingPage;

	@FindBy(xpath = "//mat-select[@formcontrolname='assignee']")
	WebElement drdAsignee;

	@FindBy(xpath = "//mat-select[@formcontrolname='status']")
	WebElement drdStatus;

	@FindBy(xpath = "//table/tbody/tr/td[4]")
	List<WebElement> tableColumnStatus;

	@FindBy(xpath = "//table/tbody/tr/td[3]")
	List<WebElement> tableColumnAsignee;

	@FindBy(xpath = "//span[text()='Clear filter']/..")
	WebElement btnClearFilter;

	@FindBy(xpath = "//*[@class=\"export-link link-text\"]")
	WebElement lnkExport;

	@FindBy(xpath = "//span[text()='Completed']")
	WebElement txtCompletedPage;

	@FindBy(xpath = "//*[text()='Benefit Bulk Update']")
	WebElement hdrBenefitBulkUpdate;

	// Initializing the Page Objects:
	public IBPBulkUpdatePage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on Bulk Process")
	public void clickBulkProcess() {
		// WaitForApplicationToLoadCompletely();

		try {
			if (ObjectExist(btnBulkProcess)) {
				highlightElement(btnBulkProcess);
				OneframeLogger("Bulk Process Button is displayed");
				ClickWebObject(btnBulkProcess);
				OneframeLogger("Bulk Process Button is clicked");
			} else {
				OneframeLogger("Unable to click on Bulk Process Button");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Verify Project ID header in Landing Page")
	public boolean verifyProjectIDHeaderInLandingPage() {
		WaitForObjectVisibility(hdrLandingPage.get(0));
		if (hdrLandingPage.get(0).getText().equalsIgnoreCase("project id")) {
			highlightElement(hdrLandingPage.get(0));
			OneframeLogger("Project ID Header is displayed in Landing Page");
			return true;
		}
		return false;
	}

	@Step("Verify Description header in Landing Page")
	public boolean verifyDescriptionHeaderInLandingPage() {
		WaitForObjectVisibility(hdrLandingPage.get(1));
		if (hdrLandingPage.get(1).getText().equalsIgnoreCase("description")) {
			highlightElement(hdrLandingPage.get(1));
			OneframeLogger("Description Header is displayed in Landing Page");
			return true;
		}
		return false;
	}

	@Step("Verify Benefit Bulk Submit header in Landing Page")
	public boolean verifyBulkSubmitHeaderInLandingPage() {
		WaitForObjectVisibility(hdrBenefitBulkSubmit);
		if (hdrBenefitBulkSubmit.getText().equalsIgnoreCase("Benefit Bulk Submit")) {
			highlightElement(hdrBenefitBulkSubmit);
			OneframeLogger("Benefit Bulk Submit Header is displayed in Landing Page");
			return true;
		}
		return false;
	}

	@Step("Verify Asignee header in Landing Page")
	public boolean verifyAsigneeHeaderInLandingPage() {
		WaitForObjectVisibility(hdrLandingPage.get(2));

		if (hdrLandingPage.get(2).getText().equalsIgnoreCase("Assignee")) {
			highlightElement(hdrLandingPage.get(2));
			OneframeLogger("Asignee Header is displayed in Landing Page");
			return true;
		}
		return false;
	}

	@Step("Verify Status header in Landing Page")
	public boolean verifyStatusHeaderInLandingPage() {
		WaitForObjectVisibility(hdrLandingPage.get(3));
		if (hdrLandingPage.get(3).getText().equalsIgnoreCase("Status")) {
			highlightElement(hdrLandingPage.get(3));
			OneframeLogger("Status Header is displayed in Landing Page");
			return true;
		}
		return false;
	}

	@Step("Click on Bulk Update")
	public void clickBulkUpdate() {
		// WaitForApplicationToLoadCompletely();

		try {
			if (ObjectExist(btnBulkUpdate)) {
				OneframeLogger("Bulk Update Button is displayed");
				ClickWebObject(btnBulkUpdate);
				OneframeLogger("Bulk Update Button is clicked");
			} else {
				OneframeLogger("Unable to click on Bulk Update option");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Click on Bulk Update")
	public void clickBulkSubmit() {
		// WaitForApplicationToLoadCompletely();

		try {
			if (ObjectExist(btnBulkSubmit)) {
				highlightElement(btnBulkSubmit);
				OneframeLogger("Bulk Submit Button is displayed");
				ClickWebObject(btnBulkSubmit);
				OneframeLogger("Bulk Submit Button is clicked");
			} else {
				OneframeLogger("Unable to click on Bulk Submit option");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Click on Create Project")
	public void clickOnCreateAProjectButton() {
		// WaitForApplicationToLoadCompletely();

		try {
			if (ObjectExist(btnCreateAProject)) {
				highlightElement(btnCreateAProject);
				OneframeLogger("Create A Project Button is displayed");
				ClickWebObject(btnCreateAProject);
				OneframeLogger("Create A Project Button is clicked");
			} else {
				OneframeLogger("Unable to click on Create Project Button");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Click on File Upload")
	public void clickOnFileUploadButton() {
		// WaitForApplicationToLoadCompletely();

		try {
			if (ObjectExist(lnkFileUpload)) {
				ClickWebObject(lnkFileUpload);
				OneframeLogger("Clicked on File Upload link");
			} else {
				OneframeLogger("Unable to click on File Upload link");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Verify file name after uploading the file")
	public boolean verifyFileName(String string) {
		WaitForObjectVisibility(uploadedFileName);
		if (uploadedFileName.getText().trim().equalsIgnoreCase(string)) {
			OneframeLogger("Uploaded file name is displayed");
			return true;
		}
		return false;
	}

	@Step("Verify success message after uploading the file")
	public boolean verifySuccessfulUploadMessage(String string) {
		WaitForObjectVisibility(uploadSuccessMessage);
		if (uploadSuccessMessage.getText().equalsIgnoreCase(string)) {
			highlightElement(uploadSuccessMessage);
			OneframeLogger("File uploaded successfully");
			return true;
		}
		return false;
	}

	@Step("Verify 'Create Project' text is hilighted in proress bar")
	public boolean verifyCreateProjectHilightedInProgressBar() {
		return verifyCreateProjectInProgressBar(progressBarCreateProject);
	}

	@Step("Verify 'Work In Progress' text is hilighted in proress bar")
	public boolean verifyWorkInProgressHilightedInProgressBar() {
		return verifyCreateProjectInProgressBar(progressBarWorkInProgress);
	}

	@Step("Verify 'Review' text is hilighted in proress bar")
	public boolean verifyReviewHilightedInProgressBar() {
		return verifyCreateProjectInProgressBar(progressBarReview);
	}

	@Step("Verify 'Processing' text is hilighted in proress bar")
	public boolean verifyProcessingHilightedInProgressBar() {
		return verifyCreateProjectInProgressBar(progressBarProcessing);
	}

	@Step("Verify 'Bulk Updated' text is hilighted in proress bar")
	public boolean verifyBulkUpdatedHilightedInProgressBar() {
		return verifyCreateProjectInProgressBar(progressBarBulkUpdated);
	}

	@Step("Verify 'Complete' text is hilighted in proress bar")
	public boolean verifyCompleteHilightedInProgressBar() {
		return verifyCreateProjectInProgressBar(progressBarComplete);
	}

	public boolean verifyCreateProjectInProgressBar(WebElement element) {
		if (ObjectExist(element)) {
			String actualColor = element.getCssValue("color");
			highlightElement(element);
			if (actualColor.contains("rgba(0, 83, 184, 1)")) {
				OneframeLogger(element.getText() + " heading is hilighted in blue color in progress bar: "
						+ element.getCssValue("color"));
				return true;
			}
		} else {
			OneframeLogger(element.getText() + " heading is not hilighted in blue color in progress bar");
			return false;
		}
		return false;
	}

	@Step("Verify Create A Project header")
	public boolean verifyCreateAProjectHeader() {
		if (WaitForObject(hdrCreateProject)) {
			if (hdrCreateProject.getText().equalsIgnoreCase("Create a Project")) {
				highlightElement(hdrCreateProject);
				OneframeLogger("'Create a Project' heading is displayed");
				return true;
			}
		} else {
			OneframeLogger("'Create a Project' heading is not displayed");
			return false;
		}
		return false;
	}

	@Step("Verify Project Data Header")
	public boolean verifyProjectDataHeading() {
		if (WaitForObject(hdrProjectData)) {
			if (hdrProjectData.getText().equalsIgnoreCase("Project Data")) {
				highlightElement(hdrProjectData);
				OneframeLogger("'Project Data' heading is displayed");
				return true;
			}
		} else {
			OneframeLogger("'Project Data' heading is not displayed");
			return false;
		}
		return false;
	}

	@Step("Verify visibility of Project ID input box and enter Project ID into it")
	public boolean verifyAndEnterProjectID(String string) {
		int randomNumber = getRandomNumber();
		projectID = string + randomNumber;

		if (ObjectExist(inputProjectID)) {
			// EnterText(inputProjectID, projectID);
			inputProjectID.sendKeys(projectID);
			OneframeLogger("Project ID entered as : " + inputProjectID.getAttribute("value"));
			return true;
		} else {
			OneframeLogger("'Project ID' input box is not displayed");
			return false;
		}
	}

	public String getProjectID() {
		return projectID.toUpperCase();
	}

	@Step("Verify visibility of Description input box and enter text into it")
	public boolean verifyAndEnterProjectDescription(String string) {

		if (ObjectExist(inputDescription)) {
			EnterText(inputDescription, string);
			// inputDescription.sendKeys(string);
			OneframeLogger("Project Description entered as : " + inputDescription.getAttribute("value"));
			return true;
		} else {
			OneframeLogger("'Project Description' input box is not displayed");
			return false;
		}
	}

	public int getRandomNumber() {
		int min = 100;
		int max = 10000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Verify Project ID header")
	public boolean verifyProjectIDHeading() {
		if (ObjectExist(hdrProjectID)) {
			if (hdrProjectID.getText().equalsIgnoreCase("Project ID")) {
				highlightElement(hdrProjectID);
				OneframeLogger("'Project ID' heading is displayed");
				return true;
			}
		} else {
			OneframeLogger("'Project ID' heading is not displayed");
			return false;
		}
		return false;
	}

	@Step("Verify Project Description Header")
	public boolean verifyProjectDescriptionHeading() {
		if (ObjectExist(hdrDescription)) {
			if (hdrDescription.getText().equalsIgnoreCase("Description")) {
				highlightElement(hdrDescription);
				OneframeLogger("'Description' heading is displayed");
				return true;
			}
		} else {
			OneframeLogger("'Description' heading is not displayed");
			return false;
		}
		return false;
	}

	@Step("Click on Cancel button")
	public void clickCancelButton() {
		// WaitForApplicationToLoadCompletely();

		try {
			if (ObjectExist(btnCancel)) {
				OneframeLogger("Cancel button is displayed");
				ClickWebObject(btnCancel);
				OneframeLogger("Cancel button is clicked");
			} else {
				OneframeLogger("Unable to click on Cancel button");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Verify Project is created")
	public boolean verifyProjectIsCreated(String projectID) throws InterruptedException {
		try {
			WaitForApplicationToLoadCompletely();
			WaitForObjectVisibility(txtPageNumber);
			hdrbenefitBulkUpdate.click();
			hdrbenefitBulkUpdate.click();
			hdrbenefitBulkUpdate.click();
			if (ObjectExist(txtPageNumber)) {
				String[] pageNum = txtPageNumber.getText().trim().split(" ");
				int numOfPages = (int) Math.ceil(Double.parseDouble(pageNum[4]) / 10);

				String xpath = "//table/tbody/tr/td[1][text()=' " + projectID.toUpperCase() + " ']/../td";
				List<WebElement> projectInGrid = oneframeDriver.findElements(By.xpath(xpath));

				for (int i = 1; i < numOfPages; i++) {
					if (ObjectExist(projectInGrid.get(0))) {
						highlightElement(projectInGrid.get(0));
						OneframeLogger("Project is created : " + projectInGrid.get(0).getText());
						return true;
					} else {
						ClickWebObject(nextButton);
					}
				}
				return false;

			} else {
				OneframeLogger("Unable to get page number");
				return false;
			}
		} catch (StaleElementReferenceException SEP) {
		}
		return false;
	}

	@Step("Click on the newly created project")
	public void clickOnProject(String projectID) {
		WaitForObjectVisibility(projectIDListItem1);
		String xpath = "//table/tbody/tr/td[1][text()=' " + projectID + " ']/../td";
		List<WebElement> projectInGrid = oneframeDriver.findElements(By.xpath(xpath));
		ClickWebObject(projectInGrid.get(0));

	}

	@Step("Verify Create Project Button")
	public boolean verifyCreateProjectButton() {
		if (btnCreateProject.isEnabled()) {
			highlightElement(btnCreateProject);
			OneframeLogger("Create Project button is enabled: " + btnCreateProject.isEnabled());
			return true;
		}
		return false;
	}

	@Step("Click on Create Project Button")
	public void clickOnCreateProjectButton() {
		try {
			if (ObjectExist(btnCreateProject)) {
				ClickWebObject(btnCreateProject);
				OneframeLogger("Clicked on Create Project Button");
			} else {
				OneframeLogger("Unable to click on Create Project Button");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Verify the status of a project")
	public boolean verifyStatus(String projectID, String status) throws InterruptedException {

		WaitForObjectVisibility(projectIDListItem1);
		String xpath = "//table/tbody/tr/td[1][text()=' " + projectID.toUpperCase() + " ']/../td";
		List<WebElement> projectInGrid = oneframeDriver.findElements(By.xpath(xpath));
		if (projectInGrid.get(3).getText().trim().equalsIgnoreCase(status)) {
			highlightElement(projectInGrid.get(3));
			// OneframeLogger("Project status is displayed as " +status);
			oneframeDriver.navigate().refresh();
			return true;
		}
		return false;
	}

	@Step("Uploading Benefits file")
	public boolean uploadFile(String file) throws AWTException {
		String filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\" + file + ".xlsx";
		robot = new Robot();
		StringSelection stringSelection = new StringSelection(filePath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

		robot.delay(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

		return verifyFileName(file + ".xlsx");
	}

	public void clickHeader() {
		hdrbenefitBulkUpdate.click();
		hdrbenefitBulkUpdate.click();
		hdrbenefitBulkUpdate.click();
		hdrbenefitBulkUpdate.click();
		hdrbenefitBulkUpdate.click();
	}

	@Step("Refresh the page and verify Project Status")
	public boolean verifybenefitStatus(String projectID) {
		int count = 0;
		try {
			while (!verifyStatus(getProjectID(), "BULKUPDATED")) {
				// OneframeLogger("Benefit is still in processing state, refreshing the page");
				clickHeader();
				oneframeDriver.navigate().refresh();
				count++;

				if (count == 8) {
					break;
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Step("Refresh the page and verify Project Status")
	public boolean verifybenefitStatusVal(String projectID) {
		int count = 0;
		try {
			while (!verifyStatus(getProjectID(), "COMPLETED")) {
				// OneframeLogger("Benefit is still in processing state, refreshing the page");
				clickHeader();
				oneframeDriver.navigate().refresh();
				count++;

				if (count == 13) {
					break;
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public int getRowCount(String file) {
		int x = 0;

		OneframeLogger("Reading File: " + file + ".xlsx");
		ExcelFile xlFile1 = new ExcelFile("TestData", file + ".xlsx");
		x = xlFile1.OpenWorkBook().OpenWorkSheet("Sheet1").getTotalRowCount();
		xlFile1.CloseExcelFile();
		return x;
	}

	@Step("Select and Get Asignee value from Asignee dropdown")
	public String selectAndGetAsigneeValue(String asignee) {
		try {
			if (WaitForObject(drdAsignee)) {
				drdAsignee.click();
				String clientVal = selectDropdownValues(asignee);
				OneframeLogger("The Selected Asignee Dropdown value is : " + clientVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Asignee dropdown ");

		}
		return drdAsignee.getText();
	}

	@Step("Select and Get Status value from Asignee dropdown")
	public String selectAndGetStatusValue(String status) {
		try {
			if (WaitForObject(drdStatus)) {
				drdStatus.click();
				String statusval = selectDropdownValues(status);
				OneframeLogger("The Selected Status Dropdown value is : " + statusval);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Status dropdown ");

		}
		return drdAsignee.getText();
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[normalize-space()='%s']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		return dropdownvalue.getText();
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-container\"]"));
		ClickWebObject(overlayElement);
	}

	public boolean verifyStatus(String expectedStatus) {
		boolean flg = false;
		hdrbenefitBulkUpdate.click();
		hdrbenefitBulkUpdate.click();
		hdrbenefitBulkUpdate.click();
		for (WebElement ele : tableColumnStatus) {
			// WaitForObject(ele);
			highlightElement(ele);
			if (ele.getText().trim().equalsIgnoreCase(expectedStatus)) {
				flg = true;
				OneframeLogger("Expected Status matches with Actual Status. Actual value: " + ele.getText().trim()
						+ " Expected value: " + expectedStatus);
			} else {
				OneframeLogger("Expected Status did not match with Actual Status. Actual value: " + ele.getText().trim()
						+ " Expected value: " + expectedStatus);
				return false;
			}
		}

		return flg;
	}

	public boolean verifyAsignee(String expectedStatus) {
		boolean flg = false;
		WaitForApplicationToLoadCompletely();
		for (WebElement ele : tableColumnAsignee) {
			// WaitForObject(ele);
			highlightElement(ele);
			if (ele.getText().trim().equalsIgnoreCase(expectedStatus)) {
				flg = true;
				OneframeLogger("Expected Asignee matches with Actual Asignee. Actual value: " + ele.getText().trim()
						+ " Expected value: " + expectedStatus);
			} else {
				OneframeLogger("Expected Asignee did not match with Actual Asignee. Actual value: "
						+ ele.getText().trim() + " Expected value: " + expectedStatus);
				return false;
			}
		}

		return flg;
	}

	@Step("Click on Clear filter button")
	public void clickClearFilterButton() {
		ObjectExist(btnClearFilter);
		btnClearFilter.click();
		OneframeLogger("Clicked on Clear filter button");
		hdrbenefitBulkUpdate.click();
		hdrbenefitBulkUpdate.click();
		hdrbenefitBulkUpdate.click();
	}

	public void refreshPage() {

		try {
			Thread.sleep(5000);
			oneframeDriver.navigate().refresh();
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Step("Click on Export link in Completed Page")
	public void clickExportLink() throws InterruptedException {
		WaitForObjectVisibility(lnkExport);
		lnkExport.click();
		OneframeLogger("Clicked on Export link");
		completedPage();
		Thread.sleep(7000);
	}

	@Step("Click on text Completed Page")
	public void completedPage() {
		WaitForObjectVisibility(txtCompletedPage);
		txtCompletedPage.click();
		txtCompletedPage.click();
		txtCompletedPage.click();
		txtCompletedPage.click();
		txtCompletedPage.click();
		txtCompletedPage.click();
		txtCompletedPage.click();
		txtCompletedPage.click();

	}

}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PropertyResource
{
    @JsonProperty("field_id")
    private Long fieldId;
    @JsonProperty("field_name")
    private String fieldName;
    @JsonProperty("field_value")
    private String fieldValue;
    @JsonProperty("field_value_name")
    private String fieldValueName;
    
    public PropertyResource() {
        this.fieldId = null;
        this.fieldName = null;
        this.fieldValue = null;
        this.fieldValueName = null;
    }
    
    public PropertyResource fieldId(final Long fieldId) {
        this.fieldId = fieldId;
        return this;
    }
    
    public Long getFieldId() {
        return this.fieldId;
    }
    
    public void setFieldId(final Long fieldId) {
        this.fieldId = fieldId;
    }
    
    public PropertyResource fieldName(final String fieldName) {
        this.fieldName = fieldName;
        return this;
    }
    
    public String getFieldName() {
        return this.fieldName;
    }
    
    public void setFieldName(final String fieldName) {
        this.fieldName = fieldName;
    }
    
    public PropertyResource fieldValue(final String fieldValue) {
        this.fieldValue = fieldValue;
        return this;
    }
    
    public String getFieldValue() {
        return this.fieldValue;
    }
    
    public void setFieldValue(final String fieldValue) {
        this.fieldValue = fieldValue;
    }
    
    public PropertyResource fieldValueName(final String fieldValueName) {
        this.fieldValueName = fieldValueName;
        return this;
    }
    
    public String getFieldValueName() {
        return this.fieldValueName;
    }
    
    public void setFieldValueName(final String fieldValueName) {
        this.fieldValueName = fieldValueName;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final PropertyResource propertyResource = (PropertyResource)o;
        return Objects.equals(this.fieldId, propertyResource.fieldId) && Objects.equals(this.fieldName, propertyResource.fieldName) && Objects.equals(this.fieldValue, propertyResource.fieldValue) && Objects.equals(this.fieldValueName, propertyResource.fieldValueName);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.fieldId, this.fieldName, this.fieldValue, this.fieldValueName);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class PropertyResource {\n");
        sb.append("    fieldId: ").append(this.toIndentedString(this.fieldId)).append("\n");
        sb.append("    fieldName: ").append(this.toIndentedString(this.fieldName)).append("\n");
        sb.append("    fieldValue: ").append(this.toIndentedString(this.fieldValue)).append("\n");
        sb.append("    fieldValueName: ").append(this.toIndentedString(this.fieldValueName)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import org.testng.Assert;
import org.testng.Reporter;
import anthem.irx.oneframe.utilities.DateTimeProcessor;
import java.awt.GraphicsConfiguration;
import java.awt.AWTException;
import java.io.IOException;
import java.awt.Rectangle;
import org.monte.media.math.Rational;
import org.monte.media.VideoFormatKeys;
import org.monte.media.Format;
import org.monte.media.FormatKeys;
import java.awt.GraphicsEnvironment;
import java.io.File;
import anthem.irx.oneframe.utilities.MonteScreenRecorder;

public class OneframeLogger
{
    MonteScreenRecorder videoLogger;
    String consoleIndenLevels;
    
    public OneframeLogger() {
        Log("[ONEFRAME][OFLOGGER] Oneframelogger VLOG is initialized");
        if (this.videoLogger == null) {
            final File videoFolder = new File(OneframeConstants.VIDEOLOG_FOLDER);
            final GraphicsConfiguration grxConf = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
            try {
                this.videoLogger = new MonteScreenRecorder(grxConf, null, new Format(new Object[] { FormatKeys.MediaTypeKey, FormatKeys.MediaType.FILE, FormatKeys.MimeTypeKey, "video/avi" }), new Format(new Object[] { FormatKeys.MediaTypeKey, FormatKeys.MediaType.VIDEO, FormatKeys.EncodingKey, "MJPG", VideoFormatKeys.CompressorNameKey, "MJPG", VideoFormatKeys.DepthKey, 24, FormatKeys.FrameRateKey, Rational.valueOf(15.0), VideoFormatKeys.QualityKey, 0.2f, FormatKeys.KeyFrameIntervalKey, 900 }), new Format(new Object[] { FormatKeys.MediaTypeKey, FormatKeys.MediaType.VIDEO, FormatKeys.EncodingKey, "black", FormatKeys.FrameRateKey, Rational.valueOf(8.0) }), null, videoFolder);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            catch (AWTException e2) {
                e2.printStackTrace();
            }
        }
    }
    
    private static void ReporterLog(final String LogMessage) {
        Reporter.log(DateTimeProcessor.getCurrentDateTime(getDateTimeformat()).toUpperCase() + " - " + LogMessage + "<br>");
        OneframeContainer.testLogsArr.add(LogMessage);
    }
    
    public static void Log(final String LogMessage) {
        if (LogMessage.startsWith("[ONEFRAME]")) {
            if (OneframeContainer.ofcLoggerTestLogLevel.equalsIgnoreCase("oneframedebugmode")) {
                Log(LogMessage.replace("[ONEFRAME]", ""));
            }
        }
        else {
            System.out.println(DateTimeProcessor.getCurrentDateTime(getDateTimeformat()).toUpperCase() + "> " + LogMessage);
            ReporterLog(LogMessage);
        }
    }
    
    public static void ErrorLog(final String LogMessage) {
        if (LogMessage.startsWith("[ONEFRAME]")) {
            if (OneframeContainer.ofcLoggerTestLogLevel.equalsIgnoreCase("oneframedebugmode")) {
                ErrorLog(LogMessage.replace("[ONEFRAME]", ""));
            }
        }
        else {
            System.err.println(DateTimeProcessor.getCurrentDateTime(getDateTimeformat()).toUpperCase() + "> " + LogMessage);
            ReporterLog(LogMessage);
        }
    }
    
    public static void throwException(final String ExceptionMessage) {
        ErrorLog(ExceptionMessage);
        Assert.fail(ExceptionMessage);
    }
    
    public static void throwException(final String ExceptionMessage, final Throwable realCause) {
        ErrorLog(ExceptionMessage);
        Assert.fail(ExceptionMessage, realCause);
    }
    
    private static String getDateTimeformat() {
        return "ddMMM|hh:mm:ssa";
    }
    
    public void startVideoRecording(final String testScriptName) {
        this.videoLogger.setTestScenarioID(OneframeContainer.getCurrentTestCaseID());
        this.videoLogger.setScriptName(testScriptName);
        try {
            this.videoLogger.start();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void stopVideoRecording() {
        try {
            this.videoLogger.stop();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void cleanUp() {
        if (this.videoLogger != null) {
            this.videoLogger = null;
        }
    }
}

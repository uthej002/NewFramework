package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitDetailsPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreateAndSubmitBenefitWithAddNotes extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitDetailsPage details;

	@BeforeClass
	@Step("Initializing Test Script for Validate Create and Submit Benefit with Add Notes")
	public void setUp() {
		InitializeLaunchPad("IBPW_840");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		details = new IBPBenefitDetailsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"Mandates" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Create and Submit Benefit with Add Notes", dataProvider = "TestData")
	@Description("Validate Create and Submit Benefit with Add Notes")
	public void ValidateAddNotesInBenefit(String TestCaseID, String TestStatus, String Benefit, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String Mandates)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			//sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			benefitpage.verifyCreateaBenefitButtonDisplay();
			benefitpage.clickCreateaBenefitButton();
			sa.assertTrue(createbenefitpage.verifyCreateBenefit(), "Verified Create Benefit is displayed");
			sa.assertTrue(createbenefitpage.verifyBenefitHeader(), "Verified Benefit Header is displayed");

			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(createbenefitpage.selectClientDropdown(ClientId), "Verified and selected 'Client dropdown'");
			sa.assertTrue(createbenefitpage.selectLOBDropdown(LOBId), "Verified and selected 'LOB dropdown' ");
			sa.assertTrue(details.selectStateDropdown(StateId), "Verified and selected 'State dropdown'");
			createbenefitpage.selectMandates(Mandates);
			String NewBenefitId = createbenefitpage.clickRequestBenefitIDButtonGetBenefitID();
			createbenefitpage.clickBenefitHeader();
			createbenefitpage.ClickCBCreateButton();
			createbenefitpage.clickBenefitHeader();


			sa.assertTrue(details.verifyHistoryAndDocumentHeader(),
					"Verified History and documentation header is displayed");
			sa.assertTrue(details.verifyNotesHeader(), "Verified Notes header is displayed");
			sa.assertTrue(details.verifyNotesField(), "Verified Notes field is enabled");
			String notesVal = details.verifyAndEnterNotes();
			createbenefitpage.ClickSaveButton();
			sa.assertTrue(createbenefitpage.verifySavedMessage(), "Verified Saved message is displayed");
			sa.assertTrue(createbenefitpage.CheckCloseButtonisDisplayed(), "Verified Close button is displayed");
			createbenefitpage.ClickCloseButton();
			sa.assertTrue(createbenefitpage.ClickWFEExitAndSaveButton(),
					"Verified and clicked on Save and Exit button");
		//	sa.assertTrue(createbenefitpage.verifySavedMessage(), "Verified Saved message is displayed");

			sa.assertTrue(createbenefitpage.verifyVersionValue("0.1"), "Verified Version Value is displayed");
			benefitpage.clickEditButton();
			sa.assertTrue(createbenefitpage.CheckVerifyButtonisDisplayed(), "Verified the Verify Button is displayed");
			sa.assertTrue(createbenefitpage.verifyVersionValue("0.2"), "Verified Version Value is displayed");
			sa.assertTrue(details.verifyNotesValue(notesVal), "Verified Notes value is same as expected");
			String notesValue = details.verifyAndEnterNotes();
			createbenefitpage.ClickSaveButton();
		//	sa.assertTrue(createbenefitpage.verifySavedMessage(), "Verified Saved message is displayed");
			sa.assertTrue(details.verifyNotesValue(notesValue), "Verified Notes value is same as expected");

			sa.assertTrue(createbenefitpage.CheckVerifyButtonisDisplayed(), "Verified the Verify Button is displayed");
			createbenefitpage.ClickVerifyButtonforCreatedBenefit();
			// createbenefitpage.clickBenefitHeaderInDetailsPage();
			sa.assertTrue(createbenefitpage.VerifySubmiforCLientApprovalButtonisDisplayed(),
					"Verified Submit For Client Approval Button is displayed");
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(),
					"Verified Created Benefit header is displayed");
			sa.assertTrue(createbenefitpage.verifyVerStatus(), "Verified Version Status  is displayed");
			sa.assertTrue(createbenefitpage.verifyVersionValue(), "Verified Version Value is displayed");
			createbenefitpage.ClickSubmiforCLientApprovalButton();
			sa.assertTrue(benefitpage.verifybenefitBannerInRemediationClientApprovalMessage(),
					"Verified Benefit is submitted for review Message is displayed");
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitId);

			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");
			benefitpage.clickAssignToYourselfButton();
			sa.assertTrue(benefitpage.verifybenefitBannerAssignedYourselfMessage(),
					"Verified Benefit is assigned to you Message is displayed");
			sa.assertTrue(createbenefitpage.CheckCloseButtonisDisplayed(), "Verified Close Button is displayed");
			sa.assertTrue(benefitpage.verifySubmitbuttondisplay(), "Verified Submit Button is displayed");
			sa.assertTrue(benefitpage.verifyRejectbuttondisplay(), "Verified Reject Button is displayed");
			sa.assertTrue(benefitpage.verifyclientApprovalStatusdisplay(),
					"Verified Client Approval Status is displayed");
			benefitpage.clickSubmitButton();
			sa.assertTrue(benefitpage.verifybenefitBannerPBMMessage(),
					"Verified Benefit has submited to PBM Message is displayed");

			homepage.clickWelcomeMessage();
			homepage.clickWelcomeMessage();
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitId);

			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");

			createbenefitpage.clickBenefitHeaderInDetailsPage();
			createbenefitpage.clickVersionStatus();
			sa.assertTrue(createbenefitpage.verifyVersionStatusOfBen("SUBMITTED_PBM"),
					"Verified Version Status  is displayed");
			sa.assertTrue(createbenefitpage.verifyVersionValue("1.0"), "Verified Version Value is displayed");
			sa.assertTrue(details.verifyNotesValue(notesValue), "Verified Notes value is same as expected");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Create and Submit Benefit with Add Notes Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Create and Submit Benefit with Add Notes");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitStatsticsCountforImpactAnalysis extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;

	@BeforeClass
	@Step("Initializing Test Script for validating the Benefits Statics displayed")
	public void setUp() {
		InitializeLaunchPad("IBPW_66");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","LibraryName","RuleName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "IBPW_66 Validate the display of Benefits Stastics", dataProvider = "TestData")
	@Description("Validate the display of Benefits Stastics")
	public void ValidateBenefitsStastics(String TestCaseID, String TestStatus,String LibraryName,String RuleName) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickStagingLink();          
			//rulebuilderstaging.clickRuleName(LibraryName, RuleName);
			//ruleid.clickLatestVersionofRuleID();
			rulebuilderstaging.clickLibrary(LibraryName);
			//ruleid.getLatestVersionID(LibraryName, RuleName);
            String versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
			ruleid.clickLatestVersionofRuleID(versionId);
			sa.assertTrue(ruleid.verifyPromoteButtonDisplay(), "Verified Promote Button is displayed");	
			sa.assertTrue(ruleid.verifyBenefitCount(), "Verified Benefit Count is equal to the All types of Benefits");
			sa.assertTrue(ruleid.verifyBenefitsStaticsDisplay(), "Verified Benefits Stastics is displayed");
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate the display of Benefits Stastics successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate the display of Benefits Stastics");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}




}

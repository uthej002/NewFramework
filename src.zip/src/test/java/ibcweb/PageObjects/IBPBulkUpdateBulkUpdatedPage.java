
package ibcweb.PageObjects;

import java.lang.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.text.DecimalFormat;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.CSVFile;
import io.qameta.allure.Step;

public class IBPBulkUpdateBulkUpdatedPage extends OneframeContainer {
	
	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();
	
	@FindBy(xpath="//div[@class='tabs-container']/h4")
	WebElement txtBulkUpdated;
	
	@FindBy(xpath="//div[@class='tabs-container']/h3")
	WebElement txtUnlockInProgress;
	
	@FindBy(xpath="//div[@class='tabs-container']/h3")
	WebElement txtBulkUpdateInProgress;
	
	@FindBy(xpath="//div[@class='tabs-container']/h5")
	WebElement lnkExportUpdates;
	
	@FindBy(xpath="//span[text()=' Back ']/..")
	WebElement btnBack;
	
	@FindBy(xpath="//span[text()=' Unlock Benefits ']/..")
	WebElement btnUnlockbenefits;
	
	@FindBy(xpath="//span[text()=' Submit To Adjudication ']/..")
	WebElement btnSubmitToAdjudication;
	
	@FindBy(xpath="//ingeniorx-ws-confirmation/h3")
	WebElement hdrUnlockbenefits;
	
	@FindBy(xpath="//ingeniorx-ws-confirmation/div")
	WebElement txtMessage;
	
//	@FindBy(xpath="")
//	WebElement confirmationMessage;
	
	@FindBy(xpath="//span[text()='No']/..")
	WebElement btnNo;
	
	@FindBy(xpath="//span[text()='Yes']/..")
	WebElement btnYes;
	
	@FindBy(xpath="//span[text()=' Go Back ']/..")
	WebElement btnGoBack;
	
// Initializing the Page Objects:
	public IBPBulkUpdateBulkUpdatedPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions
	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify Bulk Update In Progress Text message is displayed")
	public boolean verifyBulkUpdatInProgressTextMessage(String projectID) {
		boolean flag = false;
		String expectedValue = projectID + " bulk update is processing...";
		
		if (ObjectExist(txtBulkUpdateInProgress)) {
			if (txtBulkUpdateInProgress.getText().trim().equalsIgnoreCase(expectedValue)) {
				flag = true;
				highlightElement(txtBulkUpdateInProgress);
				OneframeLogger(projectID + " bulk update is processing...' text is displayed");
			}
		}
		else {
			OneframeLogger(projectID + " bulk update is processing...' text is displayed");
		}
		return flag;
	}
	
	@Step("Verify Bulk Updated Text message is displayed")
	public boolean verifyBulkUpdatedTextMessage(String projectID) {
		boolean flag = false;
		String expectedValue = projectID + " benefits are bulk updated.";
		
		if (ObjectExist(txtBulkUpdated)) {
			if (txtBulkUpdated.getText().trim().equalsIgnoreCase(expectedValue)) {
				flag = true;
				highlightElement(txtBulkUpdated);
				OneframeLogger(projectID + " benefits are bulk updated' text is displayed");
			}
		}
		else {
			OneframeLogger(projectID + " benefits are bulk updated' text is not displayed");
		}
		return flag;
	}
	
	@Step("Verify Unlock in Progress Text message is displayed")
	public boolean verifyUnlockInProgressTextMessage(String projectID) {
		boolean flag = false;
		String expectedValue = projectID + " Unlocking in Progress";
		
		if (ObjectExist(txtUnlockInProgress)) {
			if (txtUnlockInProgress.getText().trim().equalsIgnoreCase(expectedValue)) {
				flag = true;
				highlightElement(txtUnlockInProgress);
				OneframeLogger(projectID + " Unlocking in Progress' text is displayed");
			}
		}
		else {
			OneframeLogger(projectID + " Unlocking in Progress' text is not displayed");
		}
		return flag;
	}
	
	@Step("Verify Completed Text message is displayed")
	public boolean verifyCompletedTextMessage(String projectID) {
		boolean flag = false;
		String expectedValue = projectID + " is completed";
		
		if (ObjectExist(txtBulkUpdated)) {
			if (txtBulkUpdated.getText().trim().equalsIgnoreCase(expectedValue)) {
				flag = true;
				highlightElement(txtBulkUpdated);
				OneframeLogger(projectID + " is completed");
			}
		}
		else {
			OneframeLogger(projectID + " 'is completed ' text is not displayed");
		}
		return flag;
	}
	
	@Step("Verify Export Updates link is displayed")
	public boolean verifyExportUpdatesLink() {
		boolean flag = false;
		
		if (ObjectExist(lnkExportUpdates)) {
				flag = true;
				highlightElement(lnkExportUpdates);		
		}
		return flag;
	}
	
	@Step("Click Export Updates link")
	public void clickExportUpdatesLink() {
		if (ObjectExist(lnkExportUpdates)) {
				ClickWebObject(lnkExportUpdates);	
				OneframeLogger("Clicked on Export Updates Link");
		}
	}
	
	@Step("Verify Unlock Benefits button is displayed")
	public boolean verifyUnlockBenefitsButton() {
		boolean flag = false;
		
		if (btnUnlockbenefits.isEnabled()) {
				flag = true;
				highlightElement(btnUnlockbenefits);
		}
		return flag;
	}
	
	@Step("Verify Submit To Adjudication button is displayed")
	public boolean verifySubmitToAdjudication() {
		boolean flag = false;
		
		if (btnSubmitToAdjudication.isEnabled()) {
				flag = true;
				highlightElement(lnkExportUpdates);	
		}
		return flag;
	}
	
	@Step("Click on Unlock Benefits button")
	public void clickUnlockBenefitsButton() {
		if (btnUnlockbenefits.isEnabled()) {
				highlightElement(btnUnlockbenefits);
				ClickWebObject(btnUnlockbenefits);
				OneframeLogger("Clicked on Unlock Benefits Button");
		}
	}
	
	@Step("Click Submit To Adjudication button")
	public void clickSubmitToAdjudication() {
		if (btnSubmitToAdjudication.isEnabled()) {
				highlightElement(lnkExportUpdates);	
				ClickWebObject(btnSubmitToAdjudication);
				OneframeLogger("Clicked on Submit To Adjudication Button");
		}
	}
	
	@Step("Click on Yes Button")
	public void clickOnYesButton() {
		try {
			if (ObjectExist(btnYes)) {
				ClickWebObject(btnYes);
				OneframeLogger("Clicked on Yes Button");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}
	
	@Step("Click on Back Button")
	public void clickOnBackButton() {
		try {
			if (ObjectExist(btnBack)) {
				ClickWebObject(btnBack);
				OneframeLogger("Clicked on Back Button");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}
	
	@Step("Validating Data in excel against the data in the UI")
	public boolean excelValidations(ArrayList<ArrayList> expectedContent, String projectID) throws InterruptedException {
		boolean flg = false;
		CSVFile csvFile1;
		String fileName = null;
		DecimalFormat df = new DecimalFormat("#.##");
		//String fileName = "BulkUpdate_General_" + projectID + "_" +java.time.LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS).toString().replace(":", "_");
		Thread.sleep(5000);
		Path dir = Paths.get(System.getProperty("user.dir")+"\\src\\test\\resources\\RunTime");
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*.csv"))
        {
           
            for(Path p: stream)
            {  
                System.out.println(p.getFileName());
                fileName = p.getFileName().toString();
            }
        }
        catch(Exception e)
        {
            System.out.println("problems locating directory");
        }
		System.out.println(fileName);
		
		
		//swapping the values to match the order in excel sheet
		for(ArrayList list: expectedContent) {
			Object tmp = list.get(6);
			list.remove(6);
			list.add(7, tmp);
			double newVersion = Double.valueOf((String) list.get(4)) + 0.01;
			list.add(5, String.valueOf(df.format(newVersion)));
		}
		
		String[] expectedColHeaders = new String[]{
				"Benefit Plan ID", 
				"Client", 
				"LOB", 
				"State", 
				"Version Before Update", 
				"Version After Update", 
				"High Dollar Retail Before Update", 
				"High Dollar Retail After Update",
				"High Dollar Home Delivery Before Update",
				"High Dollar Home Delivery After Update"};
		
		try {
			csvFile1 = new CSVFile("RunTime", fileName);
			csvFile1.OpenFile().validateColumnHeaders(expectedColHeaders);
		}
		catch(Exception e) {
			csvFile1 = new CSVFile("RunTime", fileName);
			csvFile1.OpenFile().validateColumnHeaders(expectedColHeaders);
		}

		for(int j=0; j<expectedContent.size(); j++) {			
			String[] actualRowContent = csvFile1.getRowContentByRowNumber(j+2);			
			
			for(int i=0; i<expectedColHeaders.length; i++) {				
				if(actualRowContent[i].equalsIgnoreCase((String) expectedContent.get(j).get(i))) {
					OneframeLogger("Actual Value: " +actualRowContent[i]+ " | Expected Value: " +expectedContent.get(j).get(i));
					flg = true;
				}
				else {
					OneframeLogger("Actual Value: " +actualRowContent[i]+ " | Expected Value: " +expectedContent.get(j).get(i));
					flg = false;
					return flg;
				}
			}

		}
		
	return flg;
	}
	
	
	@Step("Click on Go Back Button")
	public void clickOnGoBackButton() {
		try {
			if (ObjectExist(btnGoBack)) {
				ClickWebObject(btnGoBack);
				OneframeLogger("Clicked on Go Back Button");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}
	
}

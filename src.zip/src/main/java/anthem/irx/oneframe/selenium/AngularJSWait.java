package anthem.irx.oneframe.selenium;

import anthem.irx.oneframe.core.OneframeContainer;
import java.util.function.Function;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AngularJSWait extends OneframeContainer {
  private static WebDriver AngularJSDriver;
  
  private static WebDriverWait AngularJSWait;
  
  private static JavascriptExecutor JSExecutor;
  
  private static int WaitTimeOut = 15;
  
  public static void setDriver(WebDriver driver) {
    AngularJSDriver = driver;
    AngularJSWait = new WebDriverWait(AngularJSDriver, WaitTimeOut);
    JSExecutor = (JavascriptExecutor)AngularJSDriver;
  }
  
  public static void waitForJQueryLoad() {
    ExpectedCondition<Boolean> jQueryLoad = driver -> Boolean.valueOf((((Long)((JavascriptExecutor)AngularJSDriver).executeScript("return jQuery.active", new Object[0])).longValue() == 0L));
    boolean jqueryReady = ((Boolean)JSExecutor.executeScript("return jQuery.active==0", new Object[0])).booleanValue();
    if (!jqueryReady)
      AngularJSWait.until((Function)jQueryLoad); 
  }
  
  public static void waitForAngularLoad() {
    WebDriverWait wait = new WebDriverWait(AngularJSDriver, WaitTimeOut);
    JavascriptExecutor jsExec = (JavascriptExecutor)AngularJSDriver;
    String angularReadyScript = "return angular.element(document).injector().get('$http').pendingRequests.length === 0";
    String paramString = null;
	ExpectedCondition<Boolean> angularLoad = driver -> Boolean.valueOf(((JavascriptExecutor)driver).executeScript(paramString, new Object[0]).toString());
    boolean angularReady = Boolean.valueOf(jsExec.executeScript(angularReadyScript, new Object[0]).toString()).booleanValue();
    if (!angularReady)
      wait.until((Function)angularLoad); 
  }
  
  public static void waitUntilJSReady() {
    WebDriverWait wait = new WebDriverWait(AngularJSDriver, WaitTimeOut);
    JavascriptExecutor jsExec = (JavascriptExecutor)AngularJSDriver;
    ExpectedCondition<Boolean> jsLoad = driver -> Boolean.valueOf(((JavascriptExecutor)AngularJSDriver).executeScript("return document.readyState", new Object[0]).toString().equals("complete"));
    boolean jsReady = Boolean.valueOf(jsExec.executeScript("return document.readyState", new Object[0]).toString().equals("complete")).booleanValue();
    if (!jsReady)
      wait.until((Function)jsLoad); 
  }
  
  public static void waitUntilJQueryReady() {
    JavascriptExecutor jsExec = (JavascriptExecutor)AngularJSDriver;
    Boolean jQueryDefined = (Boolean)jsExec.executeScript("return typeof jQuery != 'undefined'", new Object[0]);
    if (jQueryDefined.booleanValue() == true) {
      sleep(10L);
      waitForJQueryLoad();
      waitUntilJSReady();
      sleep(10L);
    } else {
      OneframeLogger("[ONEFRAME]jQuery is not defined on this site!");
    } 
  }
  
  public static void waitUntilAngularReady() {
    JavascriptExecutor jsExec = (JavascriptExecutor)AngularJSDriver;
    Boolean angularUnDefined = (Boolean)jsExec.executeScript("return window.angular === undefined", new Object[0]);
    if (!angularUnDefined.booleanValue()) {
      Boolean angularInjectorUnDefined = (Boolean)jsExec.executeScript("return angular.element(document).injector() === undefined", new Object[0]);
      if (!angularInjectorUnDefined.booleanValue()) {
        sleep(10L);
        waitForAngularLoad();
        waitUntilJSReady();
        sleep(10L);
      } else {
        OneframeLogger("[ONEFRAME]Angular injector is not defined on this site!");
      } 
    } else {
      OneframeLogger("[ONEFRAME]Angular is not defined on this site!");
    } 
  }
  
  public static void waitJQueryAngular() {
    waitUntilJQueryReady();
    if (AngularAppStatus.equalsIgnoreCase("yes"))
      waitUntilAngularReady(); 
  }
  
  public static void sleep(long milis) {
    try {
      Thread.sleep(milis);
    } catch (InterruptedException e) {
      e.printStackTrace();
    } 
  }
}
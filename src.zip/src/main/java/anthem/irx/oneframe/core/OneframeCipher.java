package anthem.irx.oneframe.core;

import anthem.irx.oneframe.utilities.ConfigFileReader;
import anthem.irx.oneframe.utilities.CryptoBox;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class OneframeCipher {
  private static final String ENCRYPT_ALGO = "AES/GCM/NoPadding";
  
  private static final int TAG_LENGTH_BIT = 128;
  
  private static final int IV_LENGTH_BYTE = 12;
  
  private static final int SALT_LENGTH_BYTE = 16;
  
  private static final Charset UTF_8 = StandardCharsets.UTF_8;
  
  private static final String OUTPUT_FORMAT = "%-30s:%s";
  
  public static final String ENCRYPTION_PASS = "1framPa$$4&crypt";
  
  private static String encrypt(byte[] passwordText) throws Exception {
    byte[] salt = CryptoBox.getRandomBytes(16);
    byte[] iv = CryptoBox.getRandomBytes(12);
    SecretKey aesKeyFromPassword = CryptoBox.getAESKeyFromPassword("1framPa$$4&crypt".toCharArray(), salt);
    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    cipher.init(1, aesKeyFromPassword, new GCMParameterSpec(128, iv));
    byte[] cipherText = cipher.doFinal(passwordText);
    byte[] cipherTextWithIvSalt = ByteBuffer.allocate(iv.length + salt.length + cipherText.length).put(iv).put(salt).put(cipherText).array();
    return Base64.getEncoder().encodeToString(cipherTextWithIvSalt);
  }
  
  private static String decrypt(String encryptedText) throws Exception {
    byte[] decode = Base64.getDecoder().decode(encryptedText.getBytes(UTF_8));
    ByteBuffer bb = ByteBuffer.wrap(decode);
    byte[] iv = new byte[12];
    bb.get(iv);
    byte[] salt = new byte[16];
    bb.get(salt);
    byte[] cipherText = new byte[bb.remaining()];
    bb.get(cipherText);
    SecretKey aesKeyFromPassword = CryptoBox.getAESKeyFromPassword("1framPa$$4&crypt".toCharArray(), salt);
    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    cipher.init(2, aesKeyFromPassword, new GCMParameterSpec(128, iv));
    byte[] plainText = cipher.doFinal(cipherText);
    return new String(plainText, UTF_8);
  }
  
  public static String encryptPassword(String plainPass) throws Exception {
    String encryptedText = encrypt(plainPass.getBytes(UTF_8));
    OneframeContainer.OneframeLogger(encryptedText);
    return encryptedText;
  }
  
  public static String decryptPassword(String encryptedPass) throws Exception {
    String decryptedText = decrypt(encryptedPass);
    return decryptedText;
  }
  
  public static void encryptCredentialFilePasswords() {
    String credPwdKey = "ingeniorx.US.password";
    ConfigFileReader credentialFile = new ConfigFileReader(OneframeConstants.CREDENTIAL_CONFIG_FILE);
    try {
      String credPwdValue = credentialFile.getProperty(credPwdKey).trim();
      String credEncryPwd = encryptPassword(credPwdValue);
      credentialFile.setProperty(credPwdKey, credEncryPwd);
      OneframeContainer.OneframeLogger("Password encrypted successfully");
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateRuleIDisUpdatedinStagging extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;

	@BeforeClass
	@Step("Initializing Test Script for validating Rule ID is updated in Staging area")
	public void setUp() {
		InitializeLaunchPad("IBPW_22");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","LibraryName","RuleName","UpdatedRuleName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Rule ID is updated in Staging area", dataProvider = "TestData")
	@Description("Validate Rule ID is updated in Staging area")
	public void ValidateEditFunctionofVersions(String TestCaseID, String TestStatus,String LibraryName,String RuleName,String UpdatedRuleName) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickStagingLink();          
            //rulebuilderstaging.clickRuleName(LibraryName, RuleName);
			//ruleid.clickLatestVersionofRuleID();
            rulebuilderstaging.clickLibrary(LibraryName);
          //ruleid.getLatestVersionID(LibraryName, RuleName);
            String versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
           // rulebuilderstaging.clickRuleName(LibraryName, RuleName);
			ruleid.clickLatestVersionofRuleID(versionId);
			ruleid.clickEditButton();
			ruleid.updateRuleName();
			sa.assertTrue(ruleid.clickUpdateRuleButton(), "Verified RuleID has been updated");
			sa.assertTrue(rulebuilderstaging.verifyRuleIDTitleDisplay(), "Verified Rule ID Title is displayed");
			homepage.clickRuleBuilder();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Rule ID is updated in Staging area Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Rule ID is updated in Staging area");
		}
		
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

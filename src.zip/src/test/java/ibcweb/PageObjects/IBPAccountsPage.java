
package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import io.qameta.allure.Step;

public class IBPAccountsPage extends OneframeContainer {

	@FindBy(xpath = "//input[@placeholder='Find a user']")
	WebElement txtUserSearch;

	@FindBy(xpath = "//td[contains(@class, 'mat-cell cdk-cell cdk-column-domainId ')]")
	WebElement lnkDomainID;

	@FindBy(xpath = "//h3[text()='User Details']")
	WebElement hdrUserDetails;

	@FindBy(xpath = "//h3[text()='Role']")
	WebElement hdrRole;

	@FindBy(xpath = "//span[text()='Platform Admin']")
	WebElement txtPlatformAdmin;

	@FindBy(xpath = "//mat-slide-toggle[@id='mat-slide-toggle-1']/label/div/input")
	WebElement tglPlatformAdmin;

	@FindBy(xpath = "//span[contains(.,'Content Manager')]")
	WebElement txtContentManager;

	@FindBy(xpath = "//mat-slide-toggle[@id='mat-slide-toggle-2']/label/div/input")
	WebElement tglContentManager;

	@FindBy(xpath = "//span[contains(.,'Benefit Coder')]")
	WebElement txtBenefitCoder;

	@FindBy(xpath = "//mat-slide-toggle[@id='mat-slide-toggle-3']/label/div/input")
	WebElement tglBenefitCoder;

	@FindBy(xpath = "//span[contains(.,'Benefit Viewer')]")
	WebElement txtBenefitViewer;

	@FindBy(xpath = "//mat-slide-toggle[@id='mat-slide-toggle-4']/label/div/input")
	WebElement tglBenefitViewer;

	@FindBy(xpath = "//span[contains(.,'Manager')]")
	WebElement txtManager;

	@FindBy(xpath = "//mat-slide-toggle[@id='mat-slide-toggle-5']/label/div/input")
	WebElement tglManager;

	@FindBy(xpath = "//mat-icon[@class='mat-icon notranslate right-arrow mat-icon-no-color']")
	WebElement btnBack;

	// Initializing the Page Objects:
	public IBPAccountsPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Enter Username Text")
	public void EnterUserName(String un) {  
		WaitForApplicationToLoadCompletely();

		try {
			if (ObjectExist(txtUserSearch)) {
				EnterText(txtUserSearch, un);
				txtUserSearch.sendKeys(Keys.ENTER);
				OneframeLogger("Username Is Entered");
			} else {
				OneframeLogger("Username Is Not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Click on DomainID")
	public void clickonDomainID() {
		try {
			if (ObjectExist(lnkDomainID)) {
				ClickWebObject(lnkDomainID);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("DomainID is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("DomainID is not Clicked");
		}
	}

	@Step("Verify User Details header is displayed")
	public boolean verifyUserDetailsHeaderdisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrUserDetails);
		try {
			if (hdrUserDetails.isDisplayed()) {
				highlightElement(hdrUserDetails);
				OneframeLogger("User Details is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Submit button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Role header is displayed")
	public boolean verifyRoleHeaderdisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrRole);
		try {
			if (hdrRole.isDisplayed()) {
				highlightElement(hdrRole);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Plarform Admin Toggle is enabled")
	public boolean verifyPlatformAdminToggleButton() {
		boolean blnRC = false;
		WaitForObjectVisibility(txtPlatformAdmin);
		highlightElement(txtPlatformAdmin);
		WaitForObjectVisibility(tglPlatformAdmin);
		if (tglPlatformAdmin.getAttribute("aria-checked").equalsIgnoreCase("true")) {
			highlightElement(txtPlatformAdmin);
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Content Manager Toggle is enabled")
	public boolean verifyContentManagerToggleButton() {
		boolean blnRC = false;
		WaitForObjectVisibility(txtContentManager);
		highlightElement(txtContentManager);
		WaitForObjectVisibility(tglContentManager);
		if (tglContentManager.getAttribute("aria-checked").equalsIgnoreCase("true")) {
			highlightElement(tglContentManager);
			OneframeLogger("The Content Manager button is enabled");
			blnRC = true;
		} else {
			blnRC = false;
			OneframeLogger("The Content Manager button is not enabled");
		}
		return blnRC;
	}

	@Step("Verify Benefit Coder Toggle is enabled")
	public boolean verifyBenefitCoderToggleButton() {
		boolean blnRC = false;
		WaitForObjectVisibility(txtBenefitCoder);
		highlightElement(txtBenefitCoder);
		WaitForObjectVisibility(tglBenefitCoder);
		if (tglBenefitCoder.getAttribute("aria-checked").equalsIgnoreCase("true")) {
			highlightElement(tglBenefitCoder);
			OneframeLogger("The Benefit Coder button is enabled");
			blnRC = true;
		} else {
			blnRC = false;
			OneframeLogger("The Benefit Coder button is not enabled");
		}
		return blnRC;
	}

	@Step("Verify Benefit Viewer Toggle is enabled")
	public boolean verifyBenefitViewerToggleButton() {
		boolean blnRC = false;
		WaitForObjectVisibility(txtBenefitViewer);
		highlightElement(txtBenefitViewer);
		WaitForObjectVisibility(tglBenefitViewer);
		if (tglBenefitViewer.getAttribute("aria-checked").equalsIgnoreCase("true")) {
			highlightElement(tglBenefitViewer);
			OneframeLogger("The Benefit Viewer button is enabled");
			blnRC = true;
		} else {
			blnRC = false;
			OneframeLogger("The Benefit Viewer button is not enabled");
		}
		return blnRC;
	}

	@Step("Verify Manager Toggle is enabled")
	public boolean verifyManagerToggleButton() {
		boolean blnRC = false;
		WaitForObjectVisibility(txtManager);
		highlightElement(txtManager);
		WaitForObjectVisibility(tglManager);
		if (tglManager.getAttribute("aria-checked").equalsIgnoreCase("true")) {
			highlightElement(tglManager);
			OneframeLogger("The Manager button is enabled");
			blnRC = true;
		} else {
			blnRC = false;
			OneframeLogger("The Manager button is not enabled");
		}
		return blnRC;
	}

	@Step("Click on Back")
	public void clickonBack() {
		try {
			if (ObjectExist(btnBack)) {
				ClickWebObject(btnBack);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Back Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Back Button is not Clicked");
		}
	}
}

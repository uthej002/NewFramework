// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import java.util.Iterator;
import anthem.irx.oneframe.core.OneframeContainer;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.WinUser;
import java.util.ArrayList;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.Native;
import com.sun.jna.platform.win32.User32;

public class NativeOperations
{
    public static String getActiveWindowTitle() {
        final WinDef.HWND activeWindow = User32.INSTANCE.GetForegroundWindow();
        final int titleLength = User32.INSTANCE.GetWindowTextLength(activeWindow) + 1;
        final char[] title = new char[titleLength];
        User32.INSTANCE.GetWindowText(activeWindow, title, titleLength);
        return Native.toString(title);
    }
    
    public static boolean minimizeActiveWindow() {
        final WinDef.HWND activeWindow = User32.INSTANCE.GetForegroundWindow();
        return User32.INSTANCE.CloseWindow(activeWindow);
    }
    
    public static void closeActiveWindow() {
        final WinDef.HWND activeWindow = User32.INSTANCE.GetForegroundWindow();
        closeWindow(activeWindow);
    }
    
    public static boolean findWindow(final String WindowTitle) {
        final WinDef.HWND hwnd = User32.INSTANCE.FindWindow((String)null, WindowTitle);
        return hwnd != null;
    }
    
    public static ArrayList<String> getCurrrentWindows() {
        final ArrayList<String> windowTitles = new ArrayList<String>();
        final User32 user32 = User32.INSTANCE;
        user32.EnumWindows((WinUser.WNDENUMPROC)new WinUser.WNDENUMPROC() {
            int count = 0;
            
            public boolean callback(final WinDef.HWND hWnd, final Pointer arg1) {
                final char[] windowText = new char[512];
                user32.GetWindowText(hWnd, windowText, 512);
                final String wText = Native.toString(windowText);
                final WinDef.RECT rectangle = new WinDef.RECT();
                user32.GetWindowRect(hWnd, rectangle);
                if (wText.isEmpty() || !User32.INSTANCE.IsWindowVisible(hWnd) || rectangle.left <= -32000) {
                    return true;
                }
                windowTitles.add(wText);
                return true;
            }
        }, (Pointer)null);
        return windowTitles;
    }
    
    public static void printCurrentWindows() {
        final ArrayList<String> windowTitles = getCurrrentWindows();
        for (final String title : windowTitles) {
            OneframeContainer.OneframeLogger(title);
        }
    }
    
    public static void maximizeWindow(final String WindowTitle) {
        final WinDef.HWND hwnd = User32.INSTANCE.FindWindow((String)null, WindowTitle);
        User32.INSTANCE.ShowWindow(hwnd, 3);
        User32.INSTANCE.SetForegroundWindow(hwnd);
    }
    
    public static void setFocusOnWindow(final String WindowTitle) {
        final WinDef.HWND hwnd = User32.INSTANCE.FindWindow((String)null, WindowTitle);
        User32.INSTANCE.ShowWindow(hwnd, 10);
        User32.INSTANCE.SetForegroundWindow(hwnd);
    }
    
    public static void closeWindow(final String WindowTitle) {
        final WinDef.HWND hwnd = User32.INSTANCE.FindWindow((String)null, WindowTitle);
        closeWindow(hwnd);
    }
    
    public static void quitWindow(final String WindowTitle) {
        final WinDef.HWND hwnd = User32.INSTANCE.FindWindow((String)null, WindowTitle);
        quitWindow(hwnd);
    }
    
    private static void closeWindow(final WinDef.HWND ofhwnd) {
        User32.INSTANCE.PostMessage(ofhwnd, 16, (WinDef.WPARAM)null, (WinDef.LPARAM)null);
    }
    
    private static void quitWindow(final WinDef.HWND ofhwnd) {
        User32.INSTANCE.PostMessage(ofhwnd, 18, (WinDef.WPARAM)null, (WinDef.LPARAM)null);
    }
}

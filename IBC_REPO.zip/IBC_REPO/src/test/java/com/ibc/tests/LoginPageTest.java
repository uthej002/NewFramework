package com.ibc.tests;

import com.ibc.base.DriverBase;
import com.ibc.config.ConfigFileReader;
import com.ibc.pages.CreateBenefitPage;
import com.ibc.pages.HomePage;
import com.ibc.pages.LoginPage;
import com.ibc.pages.SearchResultsPage;
import com.ibc.util.LoggerUtil;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginPageTest {
	private LoginPage loginPage;
	private ConfigFileReader configFileReader;
	private HomePage homePage;
	private SearchResultsPage searchResultsPage;
	private CreateBenefitPage createBenefitPage;
	private WebDriver driver;
	

	@BeforeClass
	public void setup() {
		
		driver=DriverBase.getInstance().getDriver();
		configFileReader = ConfigFileReader.getInstance();
		loginPage = new LoginPage();
		homePage = new HomePage();
		searchResultsPage = new SearchResultsPage();
		createBenefitPage = new CreateBenefitPage();
		loginPage.navigateToUrl(configFileReader.getBaseURL());
		loginPage.login(configFileReader.getUserName(), configFileReader.getPassword());
	}
	
	@Test
	public void loginTest1() {
		
		homePage.searchBenefit("abcd");
		homePage.waitForSpinnerToDisappear();
		searchResultsPage.verifySearchResultsCount("0");
		searchResultsPage.clickCreateABenefitButton();
		createBenefitPage.CreateABenefit();
		//homePage.logout();
	}
	
	@Test
	public void loginTest2() {
		
		homePage.searchBenefit("qwer");
		homePage.waitForSpinnerToDisappear();
		searchResultsPage.verifySearchResultsCount("0");
		searchResultsPage.clickCreateABenefitButton();
		createBenefitPage.CreateABenefit();
		//homePage.logout();
	}
	
	
	@AfterClass
	public void quit() {
		driver.quit();
	}

}

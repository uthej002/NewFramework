package anthem.irx.oneframe.core;

import anthem.irx.oneframe.selenium.WebObjectHandler;
import anthem.irx.oneframe.utilities.DateTimeProcessor;
import com.aventstack.extentreports.Status;
import java.util.Collection;
import org.testng.IExecutionListener;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class OneframeListener implements ITestListener, ISuiteListener, IInvokedMethodListener, IExecutionListener {
  private static OneframeLogger oflogger;
  
  public void onExecutionStart() {
    WebObjectHandler.readOneframeConfiguration();
    WebObjectHandler.OneframeLogger("[ONEFRAME][Oneframe Listener] Test Execution start - TestNG Runner");
  }
  
  public void onExecutionFinish() {
    WebObjectHandler.OneframeLogger("[ONEFRAME][OL] Test Execution complete - TestNG Runner");
  }
  
  public void onTestStart(ITestResult result) {
    String className = result.getTestClass().getName();
    WebObjectHandler.OneframeLogger("[ONEFRAME][OL][OnTS] Starting Test @ " + className);
    WebObjectHandler.OneframeLogger("[ONEFRAME][OL][OnTS] Start Time :" + result.getTestContext().getStartDate().toString());
  }
  
  public void onTestSuccess(ITestResult result) {
    WebObjectHandler.OneframeLogger("[ONEFRAME][OL][OnTSu] Executed Test : " + result.getMethod().getMethodName() + " : Test Result -> PASSED");
    WebObjectHandler.gTestResult = "PASS";
    WebObjectHandler.ofReporter.CompleteTest(Status.PASS, result.getMethod().getDescription());
  }
  
  public void onTestFailure(ITestResult result) {
    String testName = result.getMethod().getMethodName();
    String base64Screenshot = "";
    String logMessage1 = "UNABLE TO GET FAILURE REASON OR ERRORS";
    WebObjectHandler.gTestResult = "FAIL";
    try {
      base64Screenshot = WebObjectHandler.takeScreenshotOnDemand();
      WebObjectHandler.OneframeLogger("[ONEFRAME][OL][OnTestFailure][Failed @ Method Name] -> [" + result.getMethod().getMethodName() + "]");
      if (result.getThrowable() != null) {
        logMessage1 = "Method [".concat(testName).concat("] failed with error [").concat(getFailureReason(result));
        WebObjectHandler.OneframeLogger("[ONEFRAME][OL][OnTestFailure][ERROR] -> " + getFailureReason(result));
      } 
      if (base64Screenshot.equalsIgnoreCase(WebObjectHandler.glblScreenshotString)) {
        WebObjectHandler.ofReporter.LogFailTestStep("Test Method [" + testName + "] Failed \n Error : " + logMessage1);
      } else {
        WebObjectHandler.glblScreenshotString = base64Screenshot;
        if (WebObjectHandler.glblScreenshotString != "") {
          WebObjectHandler.ofReporter.LogFailTestStep("Test or method " + testName + "Failed", base64Screenshot);
        } else {
          WebObjectHandler.ofReporter.LogFailTestStep("Test or method " + testName + "Failed");
        } 
      } 
    } catch (Exception ex) {
      WebObjectHandler.OneframeLogger(ex.getLocalizedMessage());
      WebObjectHandler.OneframeLogger(result.getThrowable().getLocalizedMessage());
    } 
  }
  
  public void onTestSkipped(ITestResult result) {
    WebObjectHandler.gTestResult = "TEST SKIPPED";
    WebObjectHandler.ofReporter.CompleteTest(Status.SKIP, result.getTestClass().getTestName());
    WebObjectHandler.OneframeLogger("[ONEFRAME][OF-LSTNR] Test Skipped : " + result.getTestName() + " : " + result.getTestClass());
  }
  
  public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}
  
  public void onStart(ITestContext context) {
    String className = context.getCurrentXmlTest().getClass().getCanonicalName();
    String testScriptName = context.getCurrentXmlTest().getName();
    WebObjectHandler.OneframeLogger("[ONEFRAME][OL][OnStart] Begin test execution of tests in class [" + className + "]");
    WebObjectHandler.ofReporter.CreateTest(testScriptName, testScriptName);
  }
  
  public void onFinish(ITestContext context) {
    String className = context.getName();
    WebObjectHandler.OneframeLogger("[ONEFRAME][Oneframe Listener] Executed all tests in class " + className);
  }
  
  public void onStart(ISuite suite) {
    WebObjectHandler.OneframeLogger("[ONEFRAME][OL][onSS] Executing test suite [" + suite.getName() + "] on the 'Oneframe' automation framework");
    oflogger = new OneframeLogger();
    WebObjectHandler.ofReporter = new OneframeReporter();
    WebObjectHandler.ofReporter.createExtentReport(suite.getName() + "_" + DateTimeProcessor.getCurrentDateTime());
    WebObjectHandler.OneframeLogger("[ONEFRAME][OL][onSS] oneframelogger and onframereporter initialized");
  }
  
  public void onFinish(ISuite suite) {
    WebObjectHandler.OneframeLogger("[ONEFRAME][Oneframe Listener][SoS] Completed executing test suite [" + suite.getName() + "] on the 'Oneframe' automation framework");
    WebObjectHandler.ofReporter.FinishExtentReport();
    oflogger.cleanUp();
  }
  
  public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
    String MethodName = method.getTestMethod().getMethodName();
    if (method.isTestMethod()) {
      WebObjectHandler.OneframeLogger("[ONEFRAME][OL][BoM] Test Name - " + MethodName);
      WebObjectHandler.OneframeLogger("[ONEFRAME][OL][BoM] Test Description - " + testResult.getMethod().getDescription());
     // this;
      oflogger.startVideoRecording(MethodName);
    } else {
      WebObjectHandler.OneframeLogger("[ONEFRAME][OL][BoM] Execute Method => [" + testResult.getInstanceName() + "].[" + MethodName + "]");
    } 
  }
  
  public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
    String MethodName = method.getTestMethod().getMethodName();
    if (testResult.getStatus() != 1)
      WebObjectHandler.OneframeLogger("[ONEFRAME][OL][EoM] Method [" + MethodName + "] failed due to " + getFailureReason(testResult)); 
    if (method.isTestMethod()) {
      WebObjectHandler.OneframeLogger("[ONEFRAME][Oneframe Listener][EoM] Test Method Name - " + MethodName + "()");
      WebObjectHandler.OneframeLogger("[ONEFRAME][Oneframe Listener][EoM] Test Description - " + testResult.getMethod().getDescription());
     // this;
      oflogger.stopVideoRecording();
    } else {
      WebObjectHandler.OneframeLogger("[ONEFRAME][OL][EoM] End of Method - [" + testResult.getInstanceName() + "].[" + MethodName + "()]");
    } 
  }
  
  protected String getFailureReason(ITestResult result) {
    String errorMessage = "";
    String message = "";
    if (result.getThrowable() != null) {
      Throwable thr = result.getThrowable();
      errorMessage = getFullStackTrace(thr);
      message = thr.getMessage();
      result.getTestContext().setAttribute("TestFailureMessage", message);
    } 
    if (errorMessage.isEmpty()) {
      Collection<ITestResult> results = result.getTestContext().getSkippedConfigurations().getAllResults();
      for (ITestResult resultItem : results) {
        String methodName = resultItem.getMethod().getMethodName();
        if (methodName.equals("executeBeforeTestMethod"))
          errorMessage = getFullStackTrace(resultItem.getThrowable()); 
      } 
    } 
    return errorMessage;
  }
  
  private String getFullStackTrace(Throwable thr) {
    String stackTrace = "";
    if (thr != null) {
      stackTrace = thr.getMessage() + "\n";
      StackTraceElement[] elems = thr.getStackTrace();
      for (StackTraceElement elem : elems)
        stackTrace = stackTrace + "\n" + elem.toString(); 
    } 
    return stackTrace;
  }
}

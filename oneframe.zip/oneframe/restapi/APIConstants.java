// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.restapi;

public final class APIConstants
{
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String API_KEY = "apikey";
    public static final String AUTHORIZATION = "authorization";
    public static final String APPLICATION_JSON = "application/json";
    public static final String APPLICATION_FORM_URLENCODED = "application/x-www-form-urlencoded";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String TOKEN_TYPE = "token_type";
    public static final String REFRESH_TOKEN = "refresh_token";
    public static final String EXPIRES_IN = "expires_in";
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateWFERejectButton extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
    IBPHomePage homepage;
    IBPBenefitPage benefitpage;
    IBPCreateBenefitPage createbenefitpage ;

	@BeforeClass
	@Step("Initializing Test Script for validating Reject Button For the Created Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_55");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "NewBenefitId","Value","Feedback"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Reject button For the Created Benefit", dataProvider = "TestData")
	@Description("Validate Reject button For the Created Benefit")
	public void ValidateVerifyButtonFortheCreatedBenefit(String TestCaseID, String TestStatus,String NewBenefitId,String value,String feedback) throws AWTException, InterruptedException, IOException {	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitId);
			sa.assertTrue(benefitpage.verifySearchResults(), "Benefit Results is displayed");
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Given Benefit header is displayed");
			benefitpage.clickRejectButton();
			sa.assertTrue(benefitpage.verifyclientFeedbackHeaderdisplay(), "Verified Client Feedback header is displayed");
			benefitpage.selectClientFeedbackDropdown(value);
			benefitpage.enterClientReviewFeedback(feedback);
			benefitpage.clickAddButton();
			benefitpage.clickClientRejectButton();
			sa.assertTrue(benefitpage.verifyNotificationMsgRejectedBenefit(), "The Rejected Benefit Notification Message is displayed");
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate the Reject button For the Created Benefit Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate the Reject button For the Created Benefit UnSuccessfully");
		}
	}


	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}



}

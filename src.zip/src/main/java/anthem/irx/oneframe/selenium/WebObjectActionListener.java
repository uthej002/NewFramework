package anthem.irx.oneframe.selenium;

import anthem.irx.oneframe.core.OneframeContainer;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.AbstractWebDriverEventListener;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class WebObjectActionListener extends AbstractWebDriverEventListener {
  public static WebElement CurrentWebElement;
  
  public static String CurrentAction;
  
  public static String CurrentActionValue;
  
  public static int ErrorHandlerFlag = 0;
  
  public static int ALCounter = 0;
  
  public void beforeAlertAccept(WebDriver driver) {
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Alert Displayed" + driver.toString());
  }
  
  public void afterAlertAccept(WebDriver driver) {
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Alert accepted" + driver.toString());
  }
  
  public void afterAlertDismiss(WebDriver driver) {
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Alert dismissed" + driver.toString());
  }
  
  public void beforeAlertDismiss(WebDriver driver) {}
  
  public void beforeNavigateTo(String url, WebDriver driver) {
    if (driver.getTitle() == null) {
      String PageTitleOrURL = driver.getCurrentUrl();
    } else {
      String PageTitleOrURL = driver.getTitle();
    } 
    OneframeContainer.OneframeLogger("Navigating to [ " + url + " ]");
  }
  
  public void afterNavigateTo(String url, WebDriver driver) {
    String PageTitleOrURL;
    if (driver.getTitle() == null) {
      PageTitleOrURL = driver.getCurrentUrl();
    } else {
      PageTitleOrURL = driver.getTitle();
    } 
    OneframeContainer.OneframeLogger(PageTitleOrURL + " Page is displayed");
    WebObjectHandler.AttachScreenshotOnDemand(PageTitleOrURL);
  }
  
  public void beforeNavigateBack(WebDriver driver) {
    OneframeContainer.OneframeLogger(" Navigating back to - " + driver.getTitle());
  }
  
  public void afterNavigateBack(WebDriver driver) {
    OneframeContainer.OneframeLogger(driver.getTitle() + " page is displayed");
  }
  
  public void beforeNavigateForward(WebDriver driver) {
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] - before Navigate forward ] - " + driver.toString());
  }
  
  public void afterNavigateForward(WebDriver driver) {
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] - after Navigate forward ] - " + driver.toString());
  }
  
  public void beforeNavigateRefresh(WebDriver driver) {
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] - before page refresh ] - " + driver.toString());
  }
  
  public void afterNavigateRefresh(WebDriver driver) {
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] - After page refresh ] - " + driver.toString());
  }
  
  public void beforeFindBy(By by, WebElement element, WebDriver driver) {
    StoreCurrentElementAndAction(element, "FIND");
  }
  
  public void afterFindBy(By by, WebElement element, WebDriver driver) {
    StoreCurrentElementAndAction(element, "FIND");
  }
  
  public void beforeClickOn(WebElement element, WebDriver driver) {
    highlightElement(element);
    StoreCurrentElementAndAction(element, "CLICK");
  }
  
  public void afterClickOn(WebElement element, WebDriver driver) {
    StoreCurrentElementAndAction(element, "CLICK");
  }
  
  public void beforeChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {
    StoreCurrentElementAndAction(element, "ENTER");
    CurrentActionValue = keysToSend.toString();
  }
  
  public void afterChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {
    highlightElement(element);
    StoreCurrentElementAndAction(element, "ENTER");
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener][Text Entered] = '" + element.getAttribute("value") + "' on " + element.getAttribute("type") + " field > " + element.getAttribute("id"));
  }
  
  public void beforeScript(String script, WebDriver driver) {}
  
  public void afterScript(String script, WebDriver driver) {}
  
  public void beforeSwitchToWindow(String windowName, WebDriver driver) {}
  
  public void afterSwitchToWindow(String windowName, WebDriver driver) {
    OneframeContainer.OneframeLogger("\t Switched to window - " + driver.getTitle());
  }
  
  public <X> void beforeGetScreenshotAs(OutputType<X> target) {}
  
  public <X> void afterGetScreenshotAs(OutputType<X> target, X screenshot) {}
  
  public void beforeGetText(WebElement element, WebDriver driver) {
    StoreCurrentElementAndAction(element, "GetText");
  }
  
  public void afterGetText(WebElement element, WebDriver driver, String text) {
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Read text from web element ID : [" + WebObjectHandler.GetObjectInformation(element) + "] Text : " + text);
  }
  
  public void onException(Throwable throwable, WebDriver driver) {
    if (throwable instanceof org.openqa.selenium.NoSuchElementException);
    if (throwable instanceof org.openqa.selenium.StaleElementReferenceException);
    if (throwable instanceof org.openqa.selenium.TimeoutException);
    if (throwable instanceof org.openqa.selenium.WebDriverException);
    if (throwable instanceof org.openqa.selenium.UnhandledAlertException)
      OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] An Alert box poped up and was not handled by the script"); 
    if (throwable instanceof org.openqa.selenium.ElementClickInterceptedException)
      OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Click Intercepted> " + throwable.getMessage()); 
    if (throwable instanceof org.openqa.selenium.ElementNotInteractableException)
      OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener] Element Not Interactable> " + throwable.getMessage()); 
    if (throwable instanceof Exception);
  }
  
  private void StoreCurrentElementAndAction(WebElement webObject, String WebAction) {
    CurrentWebElement = webObject;
    CurrentAction = WebAction;
  }
  
  private void HandleUnexpectedWindowPopUp() {
    String ApplicationKey = OneframeContainer.TSAppEnvKey.substring(0, 6);
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Attempting to resolve unexpected popup or blocking web element...");
    if (ApplicationKey.equalsIgnoreCase("RCPWEB") && 
      WebObjectHandler.ObjectExist(WebObjectHandler.FindObjectByXpath("//*[@id='fsrInvite']"))) {
      WebObjectHandler.ClickWebObject(WebObjectHandler.FindObjectByXpath("//*[@id='fsrFocusFirst']"));
      OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Closed RCP Customer Feedback popup window");
    } 
    if (ApplicationKey.equalsIgnoreCase("IRXWEB")) {
      OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Application detected - IngenioRx Member Portal...");
      if (WebObjectHandler.FindObjectByLocatorNoWait(By.className("fsrBanner")) != null) {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Popup/window detected - IngenioRx Customer feedback popup window...");
        if (WebObjectHandler.FindObjectByLocator(By.xpath("//button[@id='fsrFocusFirst']")) != null) {
          WebObjectHandler.MouseOverAndClickOnWebElement(WebObjectHandler.FindObjectByLocatorNoWait(By.xpath("//button[@id='fsrFocusFirst']")));
          OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Closed IngenioRx Customer Feedback popup window");
        } else {
          OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Unable to close the target popup/window, script execution may fail");
        } 
      } else {
        OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Uknown popup appeared on the page or unable to click on the object");
      } 
    } 
  }
  
  private void DismissAlertOnWebBrowser() {
    Dimension window = OneframeContainer.oneframeDriver.manage().window().getSize();
    (new Actions((WebDriver)OneframeContainer.oneframeDriver))
      .moveByOffset(window.getHeight() / 2, window.getWidth() / 2)
      .click()
      .sendKeys(new CharSequence[] { (CharSequence)Keys.ESCAPE }).build()
      .perform();
  }
  
  private void ClickOnIRXApplicationTopBanner() {
    WebObjectHandler.ClickWebObject(WebObjectHandler.FindObjectByXpath("//*[@id='mbr-page-wrapper']/data-top-of-page-cmp/div/div[1]/div/div[2]"));
    OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Avoided the popup window...");
  }
  
  public static void highlightElement(WebElement webObject) {
    String originalStyle = webObject.getAttribute("style");
    try {
      EventFiringWebDriver eventFiringWebDriver = OneframeContainer.oneframeDriver;
      eventFiringWebDriver.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])", new Object[] { webObject, "style", originalStyle + "border: 2px solid red;" });
      WebObjectHandler.makeScreenshotOnDemand();
      eventFiringWebDriver.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])", new Object[] { webObject, "style", originalStyle });
    } catch (Throwable t) {
      OneframeContainer.OneframeLogger("[ONEFRAME][SE-Listener]Exception occurred while highighting : " + t.getMessage());
    } 
  }
}
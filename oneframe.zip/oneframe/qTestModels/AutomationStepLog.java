// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AutomationStepLog
{
    @JsonProperty("test_step_log_id")
    private Long testStepLogId;
    @JsonProperty("actual_result")
    private String actualResult;
    @JsonProperty("status")
    private String status;
    
    public AutomationStepLog() {
        this.testStepLogId = null;
        this.actualResult = null;
        this.status = null;
    }
    
    public AutomationStepLog testStepLogId(final Long testStepLogId) {
        this.testStepLogId = testStepLogId;
        return this;
    }
    
    public Long getTestStepLogId() {
        return this.testStepLogId;
    }
    
    public void setTestStepLogId(final Long testStepLogId) {
        this.testStepLogId = testStepLogId;
    }
    
    public AutomationStepLog actualResult(final String actualResult) {
        this.actualResult = actualResult;
        return this;
    }
    
    public String getActualResult() {
        return this.actualResult;
    }
    
    public void setActualResult(final String actualResult) {
        this.actualResult = actualResult;
    }
    
    public AutomationStepLog status(final String status) {
        this.status = status;
        return this;
    }
    
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(final String status) {
        this.status = status;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final AutomationStepLog automationStepLog = (AutomationStepLog)o;
        return Objects.equals(this.testStepLogId, automationStepLog.testStepLogId) && Objects.equals(this.actualResult, automationStepLog.actualResult) && Objects.equals(this.status, automationStepLog.status);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.testStepLogId, this.actualResult, this.status);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class AutomationStepLog {\n");
        sb.append("    testStepLogId: ").append(this.toIndentedString(this.testStepLogId)).append("\n");
        sb.append("    actualResult: ").append(this.toIndentedString(this.actualResult)).append("\n");
        sb.append("    status: ").append(this.toIndentedString(this.status)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

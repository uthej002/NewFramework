package ibcweb.TestScripts;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.geom.GeneralPath;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.CSVFile;
import anthem.irx.oneframe.utilities.ExcelFile;
import ibcweb.PageObjects.IBPBulkSubmitPage;
import ibcweb.PageObjects.IBPBulkUpdateBulkUpdatedPage;
import ibcweb.PageObjects.IBPBulkUpdatePage;
import ibcweb.PageObjects.IBPBulkUpdateReviewPage;
import ibcweb.PageObjects.IBPBulkUpdateWorkInProgressPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class ValidateSearchFunctionalityBulkSubmit extends OneframeContainer {
	
		IBPWelcomePage welcomePage;
		IBPLoginPage   loginpage;
		IBPHomePage homepage;
		IBPBulkUpdatePage bulkUpdatePage;
		IBPBulkSubmitPage bulkSubmitPage;
		
		// move to page object
		String highDollarRetialBeforeUpdate;
		String highDollarHomeDeliveryBeforeUpdate;

	@BeforeClass
	@Step("Initializing Test Script for validating Butterscotch App Login")
	public void setUp() {
		InitializeLaunchPad("IBPW_918");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		bulkUpdatePage = new IBPBulkUpdatePage();
		bulkSubmitPage = new IBPBulkSubmitPage();
	}

	@DataProvider(name = "LoginTestData")
	public Object[][] getLoginTestDataTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "validSearchText", "invalidSearchText", "bulkUpdateValidSearchText"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Search functionality bulk submit", dataProvider = "LoginTestData")
	@Description("Validate search functionality in bulk submit")
	public void validateSearchFunctionality(String TestCaseID, String TestStatus, String validSearchText, String invalidSearchText, String bulkUpdateValidSearchText) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			bulkUpdatePage.clickBulkProcess();
			bulkUpdatePage.clickBulkUpdate();
			
			
			sa.assertTrue(bulkSubmitPage.enterTextIntoSearchBar(bulkUpdateValidSearchText), "Entered Text: " +validSearchText);
			sa.assertTrue(bulkSubmitPage.verifyStatus(bulkUpdateValidSearchText, "COMPLETED"), "Project Status is Completed");	
			
			sa.assertTrue(bulkSubmitPage.enterTextIntoSearchBar(invalidSearchText), "Entered Text: " +invalidSearchText);
			sa.assertTrue(bulkSubmitPage.verifySearchResultsAreEmpty(), "Search results are empty");
			
			sa.assertTrue(bulkSubmitPage.enterTextIntoSearchBar("AH91660"), "Entered Text: AH91660");
			sa.assertTrue(bulkSubmitPage.verifySearchResultsAreEmpty(), "Search results are empty");
			
			sa.assertTrue(bulkSubmitPage.enterTextIntoSearchBar("BULKUPDATED"), "Entered Text: COMPLETED");
			sa.assertTrue(bulkSubmitPage.verifySearchResultsAreEmpty(), "Search results are empty");
			
			bulkUpdatePage.clickBulkProcess();
			bulkUpdatePage.clickBulkSubmit();
			bulkUpdatePage.refreshPage();
			
			sa.assertTrue(bulkSubmitPage.enterTextIntoSearchBar(validSearchText), "Entered Text: " +validSearchText);
			sa.assertTrue(bulkSubmitPage.verifyStatus(validSearchText, "COMPLETED"), "Project Status is Completed");	
			
			sa.assertTrue(bulkSubmitPage.enterTextIntoSearchBar(invalidSearchText), "Entered Text: " +invalidSearchText);
			sa.assertTrue(bulkSubmitPage.verifySearchResultsAreEmpty(), "Search results are empty");
			
			sa.assertTrue(bulkSubmitPage.enterTextIntoSearchBar("AH91660"), "Entered Text: AH91660");
			sa.assertTrue(bulkSubmitPage.verifySearchResultsAreEmpty(), "Search results are empty");
			
			sa.assertTrue(bulkSubmitPage.enterTextIntoSearchBar("COMPLETED"), "Entered Text: COMPLETED");
			sa.assertTrue(bulkSubmitPage.verifySearchResultsAreEmpty(), "Search results are empty");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			
			OneframeLogger("Validate Butterscotch App Login Succseefully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate Butterscotch App Login");
		}
		
		homepage.clickLogout();
		
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}
	
	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

package anthem.irx.oneframe.core;

import anthem.irx.oneframe.selenium.DriverType;
import anthem.irx.oneframe.selenium.WebDriverFactory;
import anthem.irx.oneframe.selenium.WebDriverManager;
import anthem.irx.oneframe.selenium.WebObjectActionListener;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import anthem.irx.oneframe.utilities.ConfigFileReader;
import anthem.irx.oneframe.utilities.ExcelDB;
import anthem.irx.oneframe.utilities.ExcelIOStream;
import com.codoid.products.exception.FilloException;
import io.qameta.allure.Step;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.events.WebDriverEventListener;
import org.testng.annotations.Listeners;

@Listeners({OneframeListener.class})
public class OneframeContainer extends OneframeConstants {
  public static EventFiringWebDriver oneframeDriver;
  
  public static WebDriver OFWebDriver;
  
  public static WebObjectActionListener oneframeListener;
  
  protected static String ApplicationURL;
  
  protected static WebDriverManager drivermanager;
  
  protected static boolean ReadyToLaunch = false;
  
  public static OneframeReporter ofReporter;
  
  public static String TSAppEnvKeyURL;
  
  public static String TSAngularEnvKey;
  
  public static String TSCredLoginKey;
  
  public static String AngularAppStatus;
  
  public static HashMap<String, HashMap<String, String>> AppConfigDBMap;
  
  private HashMap<String, String> AppConfigAWSMap;
  
  public static HashMap<String, String> TSScriptConfigurations;
  
  public static Object[][] TSTestData;
  
  public static String NodeUserName;
  
  public static String NodeIPAddress;
  
  public static String NodeHostName;
  
  public static String ofUserEmailID;
  
  public static String ofUserID;
  
  public static String ofUserPassword;
  
  public static boolean ofcqTestEnabled;
  
  public static boolean ofcqTestResultUpload;
  
  public static boolean ofcVideoLogEnabled;
  
  public static String ofcVideloLogQuality;
  
  public static String ofcLoggerTestLogLevel = "oneframedebugmode";
  
  public static boolean ofcExtentReportEnabled;
  
  public static String ofcExtentReportLocation;
  
  public static String ofcAutomationType;
  
  public static boolean loadedOneframeProperties = false;
  
  public static String ofcQTestHost;
  
  public static String ofcQTestAuthToken;
  
  public static String ofcQTestRelease;
  
  public static String ofcQTestTestCycle;
  
  public static String ofcQTestTestSuite;
  
  public static boolean loadedqTestProperties = false;
  
  public static String glblScreenshotString = "";
  
  public static String ofcLoginFrmCredEnabled = "NO";
  
  public static String ofcQTestProjName;
  
  public static String TestSuiteName;
  
  public static String TSReleaseName;
  
  public static boolean TSParallelExec;
  
  public static int TSThreadCount;
  
  public static String TestSuiteFile;
  
  public static String TSScriptConfigSheet;
  
  public static String TSPackageName;
  
  public static String TSXMLFileOutput;
  
  public static String TSListenerClass;
  
  public static String TestScenarioID;
  
  public static String TSqTestTCID;
  
  public static String TSTestScenarioName;
  
  public static String TSScriptName;
  
  public static String TSScriptParameters;
  
  public static String TSTags;
  
  public static String TSRunFlag;
  
  public static String TSAutomationType;
  
  public static String TSAppEnvKey;
  
  public static String TSExecEnvironment;
  
  public static String TSTDSDocument;
  
  public static String TSTDSResultDocument;
  
  public static String ScriptTDSFileName;
  
  public static String ScriptTDSFile;
  
  public static String TSDataSheetKey;
  
  public static String TSDisable2FA;
  
  public static String TSBrowser;
  
  public static String TSExecutionMode;
  
  public static String TSDriverType;
  
  public static String ScenarioAppKey;
  
  public static String ScenarioBrowser;
  
  public static int MaxWaitTime;
  
  public static int IntervalTime;
  
  public static int ScriptRegulatorLvl;
  
  public static int PageLoadTimeOut;
  
  public static String gTestResult = "NOT EXECUTED";
  
  public static String gTestCaseID = "NOT ASSIGNED";
  
  public static String gTestScript = "NOT ASSIGNED";
  
  public static int gTestIteration;
  
  public static String ExceptionSubStr = "(Session info: chrome";
  
  public static String glblCurrObjDetails = "NOT ASSIGNED";

  
  private void CheckAndSetupFrameworkFolders() {
    OneframeLogger("Yet to be implemented");
  }
  
  private void BackupResourceAndTestOutputFolders() {
    OneframeLogger("Yet to be implemented");
  }
  
  @Step("Initializing Oneframe Components")
  public void InitializeLaunchPad(String ScenarioID) {
    TestScenarioID = ScenarioID;
    gTestIteration = 0;
    loadFrameworkConfigurations();
    loadLaunchConfigurations();
    if (ofcLoginFrmCredEnabled.equalsIgnoreCase("yes"))
      checkUserCredential(); 
    loadHostInformation();
    if (TSAutomationType.toLowerCase().contains("web") && 
      GetDriverfromtheFactory())
      ReadyToLaunch = true; 
  }
  
  private void checkUserCredential() {
    ReadCredentialConfiguration();
    if (ofUserEmailID.isEmpty() || ofUserID.isEmpty() || ofUserPassword.isEmpty()) {
      OneframeErrorLogger("User credential file is not setup....please follow the below steps");
      OneframeErrorLogger("1. Setup the 'Credential.properties' file under '" + CONFIG_FOLDER + "' folder");
      OneframeErrorLogger("2. Run 'oneframe.TestLaunchers.EncryptOneframeCredentials.java' to encrypt the password");
      OneframeErrorLogger("Exiting");
      System.exit(1);
    } else {
      try {
        OneframeLogger("[ONEFRAME]User ID and Password read from credential properties");
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public String getUserIDfromCredentialProperties() {
    if (ofUserID.isEmpty())
      return null; 
    return ofUserID;
  }
  
  public String getPwdfromCredentialProperties() {
    if (ofUserPassword.isEmpty())
      return null; 
    try {
      return OneframeCipher.decryptPassword(ofUserPassword);
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    } 
  }
  
  public void CloseExcelDBConnection() {
    ExcelDB.CloseExcelDBConnection();
  }
  
  public void CloseLaunchPad() {
    ReturnDriverTotheFactory();
    CloseExcelDBConnection();
    WebObjectHandler.ResetWebHandlerObjects();
  }
  
  @Step("Creating WebDriver for execution")
  public boolean GetDriverfromtheFactory() {
    switch (TSBrowser.toLowerCase()) {
      case "chrome":
        drivermanager = WebDriverFactory.getDriverManager(DriverType.CHROME);
        OFWebDriver = drivermanager.getWebDriver();
        OneframeLogger("[ONEFRAME]Oneframe Web Driver Initialized...");
        oneframeDriver = new EventFiringWebDriver(OFWebDriver);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver wrapped as EventFiringWebDriver...");
        oneframeListener = new WebObjectActionListener();
        oneframeDriver.register((WebDriverEventListener)oneframeListener);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver registered with Action Listener...");
        return true;
      case "chrome_mobile_emulator":
        drivermanager = WebDriverFactory.getDriverManager(DriverType.CHROME_MOB_EMULATOR);
        OFWebDriver = drivermanager.getWebDriver();
        OneframeLogger("[ONEFRAME]Oneframe Web Driver Initialized...");
        oneframeDriver = new EventFiringWebDriver(OFWebDriver);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver wrapped as EventFiringWebDriver...");
        oneframeListener = new WebObjectActionListener();
        oneframeDriver.register((WebDriverEventListener)oneframeListener);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver registered with Action Listener...");
        return true;
      case "chrome_headless":
        drivermanager = WebDriverFactory.getDriverManager(DriverType.CHROME_HEADLESS);
        OFWebDriver = drivermanager.getWebDriver();
        OneframeLogger("[ONEFRAME]Oneframe Web Driver Initialized...");
        oneframeDriver = new EventFiringWebDriver(OFWebDriver);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver wrapped as EventFiringWebDriver...");
        oneframeListener = new WebObjectActionListener();
        oneframeDriver.register((WebDriverEventListener)oneframeListener);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver registered with Action Listener...");
        return true;
      case "firefox":
        drivermanager = WebDriverFactory.getDriverManager(DriverType.FIREFOX);
        OFWebDriver = drivermanager.getWebDriver();
        OneframeLogger("[ONEFRAME]Oneframe Web Driver Initialized...");
        oneframeDriver = new EventFiringWebDriver(OFWebDriver);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver wrapped as EventFiringWebDriver...");
        oneframeListener = new WebObjectActionListener();
        oneframeDriver.register((WebDriverEventListener)oneframeListener);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver registered with Action Listener...");
        return true;
      case "internet_explorer":
        drivermanager = WebDriverFactory.getDriverManager(DriverType.IE);
        OFWebDriver = drivermanager.getWebDriver();
        OneframeLogger("[ONEFRAME]Oneframe Web Driver Initialized...");
        oneframeDriver = new EventFiringWebDriver(OFWebDriver);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver wrapped as EventFiringWebDriver...");
        oneframeListener = new WebObjectActionListener();
        oneframeDriver.register((WebDriverEventListener)oneframeListener);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver registered with Action Listener...");
        return true;
      case "edge":
        drivermanager = WebDriverFactory.getDriverManager(DriverType.EDGE);
        OFWebDriver = drivermanager.getWebDriver();
        OneframeLogger("[ONEFRAME]Oneframe Web Driver Initialized...");
        oneframeDriver = new EventFiringWebDriver(OFWebDriver);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver wrapped as EventFiringWebDriver...");
        oneframeListener = new WebObjectActionListener();
        oneframeDriver.register((WebDriverEventListener)oneframeListener);
        OneframeLogger("[ONEFRAME]Oneframe Web Driver registered with Action Listener...");
        return true;
    } 
    OneframeLogger(TSBrowser + " is not available in the Driver Factory");
    OFWebDriver = drivermanager.getWebDriver();
    OneframeLogger("[ONEFRAME]Oneframe Web Driver Initialized...");
    oneframeDriver = new EventFiringWebDriver(OFWebDriver);
    OneframeLogger("[ONEFRAME]Oneframe Web Driver wrapped as EventFiringWebDriver...");
    oneframeListener = new WebObjectActionListener();
    oneframeDriver.register((WebDriverEventListener)oneframeListener);
    OneframeLogger("[ONEFRAME]Oneframe Web Driver registered with Action Listener...");
    return true;
  }
  
  private void ReturnDriverTotheFactory() {
    oneframeDriver.quit();
    OneframeLogger("[ONEFRAME]Quit oneframe EventDriven WebDriver");
    OFWebDriver.quit();
    OneframeLogger("[ONEFRAME]Quit oneframe WebDriver");
    drivermanager.quitWebDriver();
    OneframeLogger("[ONEFRAME]Quit Chrome Driver");
  }
  
  @Step("Starting Application")
  protected boolean StartApplication() {
    OneframeLogger("[ONEFRAME]Ready to Launch : " + ReadyToLaunch);
    if (ReadyToLaunch) {
      oneframeDriver.get(ApplicationURL);
      oneframeDriver.manage().deleteAllCookies();
    } 
    return true;
  }
  
  @Step("Load framework configurations")
  private void loadFrameworkConfigurations() {
    readOneframeConfiguration();
    readQtestConfiguration();
  }
  
  @Step("Load script configurations")
  private void loadLaunchConfigurations() {
    ReadTestBedConfiguration();
    ReadTestSuiteScriptConfiguration();
    ReadApplicationConfigurations();
    ReadScriptExecutionVariables();
  }
  
  private String getEnvironmentFromAppKey(String AppKey) {
    String environment = "Not Specified";
    if (AppKey.contains("SIT"))
      environment = "SIT"; 
    if (AppKey.contains("UAT"))
      environment = "UAT"; 
    if (AppKey.contains("PRE-PROD"))
      environment = "PRE-PROD"; 
    if (AppKey.contains("PROD"))
      environment = "PROD"; 
    if (AppKey.contains("CI"))
      environment = "CI"; 
    return environment;
  }
  
  public static void readOneframeConfiguration() {
    if (!loadedOneframeProperties) {
      ConfigFileReader OneframeConfiguration = new ConfigFileReader(ONEFRAME_CONFIG_FILE);
      ofcqTestEnabled = Boolean.parseBoolean(OneframeConfiguration.getProperty("qTest.Integration.Enable"));
      ofcqTestResultUpload = Boolean.parseBoolean(OneframeConfiguration.getProperty("qTest.TestResult.Upload"));
      ofcVideoLogEnabled = Boolean.parseBoolean(OneframeConfiguration.getProperty("logger.videolog.Enable"));
      ofcVideloLogQuality = OneframeConfiguration.getProperty("logger.videolog.Quality");
      ofcLoggerTestLogLevel = OneframeConfiguration.getProperty("logger.testlog.level");
      ofcExtentReportEnabled = Boolean.parseBoolean(OneframeConfiguration.getProperty("logger.ExtentReport.Enable"));
      ofcExtentReportLocation = OneframeConfiguration.getProperty("logger.ExtentReport.Location");
      loadedOneframeProperties = true;
    } 
  }
  
  public static String getOneframeTestLogLevel() {
    return ofcLoggerTestLogLevel;
  }
  
  public void readQtestConfiguration() {
    ConfigFileReader QtestConfiguration = new ConfigFileReader(QTEST_CONFIG_FILE);
    ofcQTestHost = QtestConfiguration.getProperty("qTest.host");
    ofcQTestAuthToken = QtestConfiguration.getProperty("qTest.api.auth.Bearertoken");
    ofcQTestRelease = QtestConfiguration.getProperty("qTest.Project.Release");
    ofcQTestTestCycle = QtestConfiguration.getProperty("qTest.Project.TestCycle");
    ofcQTestTestSuite = QtestConfiguration.getProperty("qTest.Project.TestSuite");
    loadedqTestProperties = true;
  }
  
  public void ReadCredentialConfiguration() {
    ConfigFileReader OneframeConfiguration = new ConfigFileReader(CREDENTIAL_CONFIG_FILE);
    ofUserEmailID = OneframeConfiguration.getProperty("ingeniorx.email.id");
    ofUserID = OneframeConfiguration.getProperty("ingeniorx.US.username");
    ofUserPassword = OneframeConfiguration.getProperty("ingeniorx.US.password");
  }
  
  public void ReadTestBedConfiguration() {
    try {
      ConfigFileReader OneframeConfiguration = new ConfigFileReader(TEST_BED_CONFIG_FILE);
      TestSuiteName = OneframeConfiguration.getProperty("TestBed.TestSuite.Name");
      TSReleaseName = OneframeConfiguration.getProperty("TestBed.TestSuite.Release");
      TSParallelExec = Boolean.parseBoolean(OneframeConfiguration.getProperty("TestBed.TestSuite.ParallelExecution"));
      TSThreadCount = Integer.parseInt(OneframeConfiguration.getProperty("TestBed.TestSuite.ThreadCount"));
      TestSuiteFile = OneframeConfiguration.getProperty("TestBed.TestSuite.File");
      TestSuiteFile = getTestSuiteFile();
      TSScriptConfigSheet = OneframeConfiguration.getProperty("TestBed.TestSuite.Sheet");
      TSPackageName = OneframeConfiguration.getProperty("TestBed.TestSuite.Package");
      TSXMLFileOutput = OneframeConfiguration.getProperty("TestBed.TestSuite.XMLOutput");
      TSListenerClass = OneframeConfiguration.getProperty("TestBed.TestSuite.TestListener");
      OneframeLogger("[ONEFRAME]Read Test Bed configurations..........Done");
    } catch (RuntimeException RTE) {
      OneframeLogger(RTE.getMessage());
    } 
  }
  
  public static Object[][] GetTestDatafromTDS(List<String> TestDataColumns) {
    try {
      TSTestData = (Object[][])ExcelDB.getDatafromExcel(ScriptTDSFile, TSDataSheetKey, TestScenarioID, TestDataColumns);
    } catch (FilloException E) {
      OneframeLogger(E.getMessage());
    } 
    return TSTestData;
  }
  
  public static void SetTestRunVariables(String TestCaseID) {
    gTestCaseID = TestCaseID;
    gTestIteration++;
    OneframeLogger("Iteration : " + gTestIteration + " | Test Case ID : " + TestCaseID);
    OneframeLogger("[ONEFRAME][TEST RUN VARIABLES ARE SET]");
  }
  
  public static String getCurrentTestScenarioID() {
    return TestScenarioID;
  }
  
  public static String getCurrentTestCaseID() {
    return gTestCaseID;
  }
  
  public static String getCurrentTestScriptName() {
    return gTestScript;
  }
  
  public static void UpdateTestResultsToTDS() {
    ExcelDB.UpdateTestResultToExcel(ScriptTDSFile, TSDataSheetKey, gTestCaseID, gTestResult);
    OneframeLogger("Updated test results to TDS");
  }
  
  public static void UpdateDataCapturedFromExecutionToTDS() {}
  
  public static void ResetTestResults() {
    gTestResult = "NOT EXECUTED";
  }
  
  private void ReadApplicationConfigurations() {
    TSAngularEnvKey = TSAppEnvKey + ".angular";
    TSAppEnvKeyURL = TSAppEnvKey + ".url";
    TSCredLoginKey = TSAppEnvKey + ".login.use.credfile";
    ConfigFileReader ApplicationConfiguration = new ConfigFileReader(APPLICATION_CONFIG_FILE);
    if (TSAutomationType.toLowerCase().contains("web")) {
      if (TSDisable2FA.equalsIgnoreCase("no")) {
        ApplicationURL = ApplicationConfiguration.getProperty(TSAppEnvKeyURL);
      } else {
        ApplicationURL = ApplicationConfiguration.getProperty(TSAppEnvKey + ".2FA.url");
      } 
      AngularAppStatus = ApplicationConfiguration.getProperty(TSAngularEnvKey);
      ofcLoginFrmCredEnabled = ApplicationConfiguration.getProperty(TSCredLoginKey);
    } 
    if (ofcqTestEnabled)
      ofcQTestProjName = ApplicationConfiguration.getProperty(TSAppEnvKey + ".qTest.Project"); 
    String[] dbRefArray = { "db1", "db2", "db3", "db4", "db5" };
    AppConfigDBMap = new HashMap<>();
    for (String dbref : dbRefArray) {
      if (!AppConfigDBMap.containsKey(dbref))
        AppConfigDBMap.put(dbref, new HashMap<>()); 
    } 
    for (String dbref : dbRefArray) {
      if (ApplicationConfiguration.checkPropertyExists(TSAppEnvKey + "." + dbref + ".dburl")) {
        OneframeLogger("[ONEFRAME]Database configuration for " + dbref);
        String tdbref = ApplicationConfiguration.getProperty(TSAppEnvKey + "." + dbref + ".dburl");
        ((HashMap<String, String>)AppConfigDBMap.get(dbref)).put(".dburl", tdbref);
        tdbref = ApplicationConfiguration.getProperty(TSAppEnvKey + "." + dbref + ".username");
        ((HashMap<String, String>)AppConfigDBMap.get(dbref)).put(".username", tdbref);
        tdbref = ApplicationConfiguration.getProperty(TSAppEnvKey + "." + dbref + ".password");
        ((HashMap<String, String>)AppConfigDBMap.get(dbref)).put(".password", tdbref);
      } 
    } 
    if (ApplicationConfiguration.checkPropertyExists(TSAppEnvKey + ".aws.url"))
      this.AppConfigAWSMap = new HashMap<>(); 
  }
  
  private void ReadScriptExecutionVariables() {
    ConfigFileReader OneframeConfiguration = new ConfigFileReader(SCRIPTEXE_CONFIG_FILE);
    MaxWaitTime = Integer.parseInt(OneframeConfiguration.getProperty("Action.MaxWaitTime"));
    IntervalTime = Integer.parseInt(OneframeConfiguration.getProperty("Action.IntervalTime"));
    PageLoadTimeOut = Integer.parseInt(OneframeConfiguration.getProperty("Driver.PageLoadTimeout"));
    ScriptRegulatorLvl = Integer.parseInt(OneframeConfiguration.getProperty("Execution.RegulatorLevel"));
  }
  
  private void loadHostInformation() {
    NodeUserName = System.getProperty("user.name");
    try {
      NodeIPAddress = InetAddress.getLocalHost().getHostAddress();
      NodeHostName = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {
      e.printStackTrace();
    } 
  }
  
  public static void PrintAllDriverCookies() {
    for (Cookie ck : oneframeDriver.manage().getCookies())
      OneframeLogger("[ONEFRAME]Name - " + ck.getName() + ";" + ck.getValue() + ";" + ck.getDomain() + ";" + ck.getPath() + ";" + ck.getExpiry() + ";" + ck.isSecure()); 
  }
  
  public static void DeleteAllDriverCookies() {
    oneframeDriver.manage().deleteAllCookies();
  }
  
  public static void DeleteDriverCookiesByName(String CookieName) {}
  
  public static void OneframeLogger(String LogMessage) {
    if (LogMessage.indexOf(ExceptionSubStr) > 0) {
      OneframeLogger.Log(getCondensedExceptionMessage(LogMessage));
    } else {
      OneframeLogger.Log(LogMessage);
    } 
  }
  
  public static void OneframeErrorLogger(String ErrorLogMessage) {
    if (ErrorLogMessage.indexOf(ExceptionSubStr) > 0) {
      OneframeLogger.ErrorLog(getCondensedExceptionMessage(ErrorLogMessage));
    } else {
      OneframeLogger.ErrorLog(ErrorLogMessage);
    } 
  }
  
  public static void OneframeLogger(Collection<String> LogMessage) {
    OneframeLogger.Log(LogMessage.toString());
  }
  
  public static void OneframeLogger(String[] LogMessages) {
    for (String logMessage : LogMessages)
      OneframeLogger(logMessage); 
  }
  
  public static void OneframeLogger(String[] LogMessages1, String[] LogMessages2) {
    for (int i = 0; i < LogMessages1.length; i++)
      OneframeLogger(LogMessages1[i] + " - " + LogMessages2[i]); 
  }
  
  public static void OneframeLogger(String[][] LogMessages) {
    for (int i = 0; i < LogMessages.length; i++) {
      String arrLog = "";
      for (int j = 0; j < (LogMessages[0]).length; j++)
        arrLog = arrLog.concat(LogMessages[i][j]).concat("|"); 
      OneframeLogger("|" + arrLog);
    } 
  }
  
  public static void OneframeLogger(int LogMessage) {
    OneframeLogger.Log(Integer.toString(LogMessage));
  }
  
  public static String getCondensedExceptionMessage(String ExceptionMessage) {
    return ExceptionMessage.substring(0, ExceptionMessage.indexOf(ExceptionSubStr) - 2);
  }
  
  private void ReadTestSuiteScriptConfiguration() {
    ExcelIOStream excelDoc = new ExcelIOStream(TestSuiteFile);
    TSScriptConfigurations = excelDoc.readScriptConfiguration(TestScenarioID);
    TSqTestTCID = getqTestTCIDfromScriptConfig();
    TSTestScenarioName = getTestScenarioNamefromScriptConfig();
    TSScriptName = getScriptNamefromScriptConfig();
    TSScriptParameters = getScriptParametersfromScriptConfig();
    TSTags = getTagsfromScriptConfig();
    TSRunFlag = getRunFlagfromScriptConfig();
    TSAutomationType = getAutomationTypefromScriptConfig();
    TSAppEnvKey = getAppEnvKeyfromScriptConfig();
    TSExecEnvironment = getEnvironmentFromAppKey(TSAppEnvKey);
    TSTDSDocument = getTDSDocumentfromScriptConfig();
    ScriptTDSFile = getScriptTDSFile();
    TSDataSheetKey = getDataSheetKeyfromScriptConfig();
    if (TSAutomationType.equalsIgnoreCase("web")) {
      TSDisable2FA = getDisable2FAfromScriptConfig();
      TSBrowser = getBrowserfromScriptConfig();
      TSExecutionMode = getExecutionModefromScriptConfig();
      TSDriverType = getDriverTypefromScriptConfig();
    } 
    OneframeLogger("[ONEFRAME]Read test suite script configuration..........Done");
  }
  
  public static String getScriptTDSFile() {
    ScriptTDSFile = getTDSDocumentfromScriptConfig();
    return TESTDATA_FOLDER + ScriptTDSFile.trim() + ".xlsx";
  }
  
  public static String getTestSuiteFile() {
    String ofTestSuiteFile = TESTSUITES_FOLDER + TestSuiteFile;
    return ofTestSuiteFile;
  }
  
  public static String getqTestTCIDfromScriptConfig() {
    return TSScriptConfigurations.get("qTestTCID");
  }
  
  public static String getTestScenarioNamefromScriptConfig() {
    return TSScriptConfigurations.get("TestScenarioName");
  }
  
  public static String getScriptNamefromScriptConfig() {
    return TSScriptConfigurations.get("ScriptName");
  }
  
  public static String getScriptParametersfromScriptConfig() {
    return TSScriptConfigurations.get("ScriptParameters");
  }
  
  public static String getTagsfromScriptConfig() {
    return TSScriptConfigurations.get("Tags");
  }
  
  public static String getRunFlagfromScriptConfig() {
    return TSScriptConfigurations.get("RunFlag");
  }
  
  public static String getAutomationTypefromScriptConfig() {
    return TSScriptConfigurations.get("AutomationType");
  }
  
  public static String getAppEnvKeyfromScriptConfig() {
    return TSScriptConfigurations.get("AppEnvKey");
  }
  
  public static String getTDSDocumentfromScriptConfig() {
    return TSScriptConfigurations.get("TDSDocument");
  }
  
  public static String getDataSheetKeyfromScriptConfig() {
    return TSScriptConfigurations.get("DataSheetKey");
  }
  
  public static String getDisable2FAfromScriptConfig() {
    return TSScriptConfigurations.get("Disable2FA");
  }
  
  public static String getBrowserfromScriptConfig() {
    return TSScriptConfigurations.get("Browser");
  }
  
  public static String getExecutionModefromScriptConfig() {
    return TSScriptConfigurations.get("ExecutionMode");
  }
  
  public static String getDriverTypefromScriptConfig() {
    return TSScriptConfigurations.get("DriverType");
  }
}

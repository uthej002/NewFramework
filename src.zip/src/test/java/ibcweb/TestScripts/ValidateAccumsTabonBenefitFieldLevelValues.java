package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumsTabonBenefitFieldLevelValues extends OneframeContainer{
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating Field Level Values in Accums Tab on Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_106");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "Benefit" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Field Level Values in Accums Tab on Benefit", dataProvider = "TestData")
	@Description("Validate Field Level Values in Accums Tab on Benefit")
	public void ValidateFieldValuesinAccumsTab(String TestCaseID, String TestStatus, String Benefit)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");
			accumsbenefitpage.clickOnAccumsTab();
			sa.assertTrue(accumsbenefitpage.verifyAccumsContentDisplay(), "Verified Accums Content is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyDeductibleToggle(), "Verified Apply Deductible Toggle is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyMOPToggle(), "Verified Apply MOP Toggle is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyFamilyLabel(), "Verified Family Label is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyMembersLabel(), "Verified Members Label is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyFamilyDeductibleInNetworkField(), "Verified Family Deductible In Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyFamilyDeductibleOutNetworkField(), "Verified Family Deductible Out Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyIndividualDeductibleInNetworkField(), "Verified Individual Deductible In Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyIndividualDeductibleOutNetworkField(), "Verified Individual Deductible Out Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyIntegrateMedicalLabel(), "Verified Apply Integrated Medical Label is displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyIntegratedMedicalInNetworkField(), "Verified Apply Integrated Medical In Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyIntegratedMedicalOutNetworkField(), "Verified Apply Integrated Medical Out Network TextField is displayed");
			accumsbenefitpage.clickOnMOPToggle();
			sa.assertTrue(accumsbenefitpage.verifyFamilyMOPInNetworkField(), "Verified Family MOP In Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyFamilyMOPOutNetworkField(), "Verified Family MOP Out Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyIndividualMOPInNetworkField(), "Verified Individual MOP In Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyIndividualMOPOutNetworkField(), "Verified Individual MOP Out Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyIntegrateMedicalLabel(), "Verified Apply Integrated Medical Label is displayed");
			sa.assertTrue(accumsbenefitpage.verifyMedicalDeductibleMOPOInNetworkField(), "Verified Apply Integrated Medical MOP In Network TextField is displayed");
			sa.assertTrue(accumsbenefitpage.verifyMedicalDeductibleMOPOutNetworkField(), "Verified Apply Integrated Medical MOP Out Network TextField is displayed");
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Field level values in Accums Tab on Benefit successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Field level values in Accums Tab on Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

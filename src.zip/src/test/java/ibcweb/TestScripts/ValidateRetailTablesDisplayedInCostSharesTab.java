package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPBenefitCostSharesPage;
import ibcweb.PageObjects.IBPBenefitNetworksPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateRetailTablesDisplayedInCostSharesTab extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitNetworksPage networksPage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitCostSharesPage costsharesPage;

	@BeforeClass
	@Step("Initializing Test Script for validating headers and buttons in Network tab on Benefit Details page")
	public void setUp() {
		InitializeLaunchPad("IBPW_147");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		networksPage = new IBPBenefitNetworksPage();
		createbenefitpage = new IBPCreateBenefitPage();
		costsharesPage = new IBPBenefitCostSharesPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "Benefit" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate headers and buttons in Network tab on Benefit Details page", dataProvider = "TestData")
	@Description("Validate headers and buttons in Network tab on Benefit Details page")
	public void ValidateNetworkTabIsActiveAndHasContentsInBenefitDetailsPage(String TestCaseID, String TestStatus, String Benefit)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {	
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");
			sa.assertTrue(networksPage.clickNetworksTab(), "Clicked on Networks Tab");
			sa.assertTrue(networksPage.verifyNetworksSetupHeaderIsDisplayed() , "Verified Networks setup header is displayed");
			sa.assertTrue(createbenefitpage.ClickEditButtoninWFE(), "Clicked on Edit Button");
			
			
			//uncheck all checkboxes and verify costshares main tab is empty
			sa.assertTrue(networksPage.clickNetworksTab(), "Clicked on Networks Tab");
			sa.assertTrue(networksPage.uncheckRetailAndHomeDeliveryCheckboxes(), "Unchecked Retail & Home Delivery checkboxes");
			sa.assertTrue(costsharesPage.clickCostSharesTab(), "Clicked on Cost Shares Tab");
			sa.assertFalse(costsharesPage.verifyNetworkListIsEmpty(), "Network list under Main subtab is empty");
			
			
			//check all retail boxes and verify retails tables are displayed
			sa.assertTrue(networksPage.clickNetworksTab(), "Clicked on Networks Tab");
			List<String> networks = networksPage.checkAllCheckboxes("retail");
			sa.assertTrue(costsharesPage.clickCostSharesTab(), "Clicked on Cost Shares Tab");
			sa.assertTrue(costsharesPage.verifyGivenTableIsDisplayed(networks, "retail"), "Retail Column is displayed for Networks");
			
			
			//check all home delivery and verify home delivery tables are displayed
			sa.assertTrue(networksPage.clickNetworksTab(), "Clicked on Networks Tab");
			sa.assertTrue(networksPage.uncheckRetailAndHomeDeliveryCheckboxes(), "Unchecked Retail & Home Delivery checkboxes");
			networks = networksPage.checkAllCheckboxes("home delivery");
			sa.assertTrue(costsharesPage.clickCostSharesTab(), "Clicked on Cost Shares Tab");
			sa.assertTrue(costsharesPage.verifyGivenTableIsDisplayed(networks, "home Delivery"), "home delivery Column is displayed for Networks");
			
			
			//check all boxes and verify retail and home delivery tables are displayed
			sa.assertTrue(networksPage.clickNetworksTab(), "Clicked on Networks Tab");
			sa.assertTrue(networksPage.uncheckRetailAndHomeDeliveryCheckboxes(), "Unchecked Retail & Home Delivery checkboxes");
			List<String> homeDeliveryNetworks = networksPage.checkAllCheckboxes("home delivery");
			networks = networksPage.checkAllCheckboxes("retail");
			sa.assertTrue(costsharesPage.clickCostSharesTab(), "Clicked on Cost Shares Tab");
			sa.assertTrue(costsharesPage.verifyGivenTableIsDisplayed(homeDeliveryNetworks, "home Delivery"), "home delivery Column is displayed for Networks");
			sa.assertTrue(costsharesPage.verifyGivenTableIsDisplayed(networks, "retail"), "Retail Column is displayed for Networks");
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated enable and disable toggles and respective tabs display in Accums Tab on Benefit successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate enable and disable toggles and respective tabs display in Accums Tab on Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

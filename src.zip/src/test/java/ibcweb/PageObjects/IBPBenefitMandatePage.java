package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.FindObjectByLocatorNoWait;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPBenefitMandatePage extends OneframeContainer {
	OneframeSoftAssert sa = new OneframeSoftAssert();
	@FindBy(xpath = "//div[text()=' Mandates ']")
	WebElement tabMandates;

	@FindBy(xpath = "//div[text()='Federal']/..")
	WebElement subtabFederal;

	@FindBy(xpath = "//div[text()='State']/..")
	WebElement subtabState;

	@FindBy(xpath = "//ingeniorx-ws-program-overrides/h3")
	List<WebElement> hdrModifiedStrategy;

	@FindBy(xpath = "//*[@aria-label='accums']")
	WebElement tabAccum;

	@FindBy(xpath = "//mat-select[@data-automation-id='custom-accum-infos']//span/span")
	WebElement txtProgramAccum;

	@FindBy(xpath = "//*[@aria-label='networks']")
	WebElement tabNetworks;

	@FindBy(xpath = "//*[text()=' Home Delivery ']")
	WebElement hdrHomeDelivery;

	@FindBy(xpath = "//*[text()=' Retail ']")
	WebElement hdrRetail;

	@FindBy(xpath = "//*[text()=' Home Delivery ']/../../tr[3]/td[3]/div[1]/div/div/div/mat-form-field/div/div/div[3]/input[@formcontrolname='maxDaySupply']")
	WebElement txtMaxSupplyHomeDelivery;

	@FindBy(xpath = "//*[text()=' Retail ']/../../tr[3]/td[2]/div[1]/div/div/div/mat-form-field/div/div/div[3]/input[@formcontrolname='maxDaySupply']")
	WebElement txtMaxSupplyRetail;

	public IBPBenefitMandatePage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on Mandates Tab")
	public void clickMandatesTab() {
		try {
			if (WaitForObjectVisibility(tabMandates)) {
				ClickWebObject(tabMandates);
				OneframeLogger("Clicked on Mandates tabs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Mandates tab is not Clicked");
		}
	}

	@Step("Click on Federal Tab")
	public void clickFederalTab() {
		try {
			if (WaitForObjectVisibility(subtabFederal)) {
				ClickWebObject(subtabFederal);
				OneframeLogger("Clicked on Federal tabs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Federal tab is not Clicked");
		}
	}

	@Step("Click on State Tab")
	public void clickStateTab() {
		try {
			if (WaitForObjectVisibility(subtabState)) {
				ClickWebObject(subtabState);
				OneframeLogger("Clicked on State tabs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("State tab is not Clicked");
		}
	}

	@Step("Verify Modified Strategy header is displayed")
	public boolean verifyModifiedStrategyHeaderIsDisplayed() {
		boolean flg = false;

		String activeState = subtabFederal.getAttribute("aria-selected");

		if (activeState.equalsIgnoreCase("true")) {
			for (WebElement ele : hdrModifiedStrategy) {
				if (WaitForObjectVisibility(ele)) {
					highlightElement(ele);
					flg = true;
				} else {
					return false;
				}
			}
		} else {
			flg = false;
			OneframeLogger("Focus is not on Federal Tab");
		}

		return flg;
	}

	@Step("Validate and Click on benefit details page sub tab options")
	public void verifyAndClickSubTabOption(String mandateName) {

		String xpath = "//div[normalize-space()='" + mandateName + "']";
		WebElement expectedHeader = oneframeDriver.findElement(By.xpath(xpath));
		ScrollToElement(expectedHeader);

		if (WaitForObject(expectedHeader)) {
			highlightElement(expectedHeader);
			ClickWebObject(expectedHeader);
		} else {
			OneframeLogger("Unable to see Sub tab header option");
		}
		sa.assertEquals(expectedHeader.getText(), mandateName, "Validated and clicked on " + mandateName);
	}

	@Step("Verify Sub Tab Header is displayed")
	public void verifySubTabHeader(String mandateName) {

		String xpath = "//h3[normalize-space()='" + mandateName + "']";
		//String xpath = "//h3[contains(text(),' " + mandateName + " ')]";
		WebElement expectedHeader = oneframeDriver.findElement(By.xpath(xpath));

		if (WaitForObject(expectedHeader)) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to see Sub tab header");
		}
		if(expectedHeader.getText().contains(mandateName)) {
			sa.assertTrue(true);
		}
		else {
			sa.assertTrue(false);
		}
	//	sa.assertEquals(expectedHeader.getText(), mandateName, "Verified header " + mandateName);

	}

	@Step("Click on Sub Tab header")
	public void clickonSubTabHeader(String mandateName) {
		String xpath = "//h3[contains(text(),' " + mandateName + " ')]";
		WebElement expectedHeader = oneframeDriver.findElement(By.xpath(xpath));
		try {
			if (WaitForObjectVisibility(expectedHeader)) {
				ClickWebObject(expectedHeader);
				OneframeLogger("Sub Tab header clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Sub Tab header is not clicked");
		}
	}

	@Step("Click on Accum Tab")
	public void clickonAccumTab() {
		try {
			if (WaitForObjectVisibility(tabAccum)) {
				ClickWebObject(tabAccum);
				OneframeLogger("Clicked on Accum tabs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Accum tab is not Clicked");
		}
	}

	@Step("Verify Program Accum Value is displayed")
	public boolean verifyProgramAccum(String expectedtext) {
		boolean flg = false;

		if (WaitForObjectVisibility(txtProgramAccum)) {
			highlightElement(txtProgramAccum);
			if (txtProgramAccum.getText().trim().equalsIgnoreCase(expectedtext)) {
				flg = true;
			}

		} else {
			flg = false;
		}
		return flg;
	}

	@Step("Click on Networks Tab")
	public void clickonNetworksTab() {
		try {
			if (WaitForObjectVisibility(tabNetworks)) {
				ClickWebObject(tabNetworks);
				OneframeLogger("Clicked on Networks tabs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Networks tab is not Clicked");
		}
	}

	@Step("Verify the Home Delivery Header is displayed")
	public boolean verifyHomeDeliveryHeaderisDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObject(hdrHomeDelivery)) {
				OneframeLogger("Home Delivery Header is Displayed");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Home Delivery Header is not Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify the Retail Header is displayed")
	public boolean verifyRetailHeaderisDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObject(hdrRetail)) {
				OneframeLogger("Retail Header is Displayed");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Retail Header is not Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify the Max day supply Home Delivery is displayed")
	public boolean verifyMaxDaySupplyHomeDeliveryDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObject(hdrHomeDelivery)) {
				OneframeLogger("Max Day Supply Home Delivery is : " + txtMaxSupplyHomeDelivery.getAttribute("value"));
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Max Day Supply Home Delivery is not Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify the Max day supply Home Delivery is displayed")
	public boolean verifyMaxDaySupplyRetailDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObject(hdrHomeDelivery)) {
				OneframeLogger("Max Day Supply Retail is : " + txtMaxSupplyRetail.getAttribute("value"));
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Max Day Supply Retail is not Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("verify Mandates Sub tab option is not displayed")
	public void verifyMandateSubTabOptionIsNotPresent(String mandateName) {
		boolean bln = false;
		if (FindObjectByLocatorNoWait(By.xpath("//div[normalize-space()='" + mandateName + "']")) != null) {
			bln = false;
		} else {
			bln = true;
		}
		sa.assertTrue(bln,
				"Validated California 250 Dollar Out of Network Copay Max Mandate ASO is not displayed in State Mandate");

	}
	
	@Step("Verify Sub Tab Header is displayed")
	public void verify4TierSubTabHeader(String mandateName) {

		//String xpath = "//h3[normalize-space()='" + mandateName + "']";
		String xpath = "//h3[contains(text(),' " + mandateName + " ')]";
		WebElement expectedHeader = oneframeDriver.findElement(By.xpath(xpath));

		if (WaitForObject(expectedHeader)) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to see Sub tab header");
		}
		if(expectedHeader.getText().contains(mandateName)) {
			sa.assertTrue(true);
		}
		else {
			sa.assertTrue(false);
		}
	//	sa.assertEquals(expectedHeader.getText(), mandateName, "Verified header " + mandateName);

	}

}

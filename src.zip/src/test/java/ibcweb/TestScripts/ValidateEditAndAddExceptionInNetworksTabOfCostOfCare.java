package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateEditAndAddExceptionInNetworksTabOfCostOfCare extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validate Edit and Add Exception in Networks Tab of Cost of care")
	public void setUp() {
		InitializeLaunchPad("IBPW_767");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ProgramName" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit and Add Exception in Networks Tab of Cost of care", dataProvider = "TestData")
	@Description("Validate Edit and Add Exception in Networks Tab of Cost of care")
	public void ValidateCostOfCareEditAndCancelFunctionality(String TestCaseID, String TestStatus, String ProgramName)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");

			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "Verified 'Programs' header");
			librariesprogramspage.clickCostofCareofPrograms();
			librariesprogramspage.clickProgramsHeader();
			sa.assertTrue(mandate.verifyAndClickProgramName(ProgramName),
					"Verified and clicked Program name");
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			sa.assertTrue(librariesprogramspage.verifyDynamicLayersDisbaled(),
					"Verified BOB and dynamic layer is disabled");
			sa.assertTrue(librariesprogramspage.verifyNetworkTabIsEnabledAndClicked(),
					"Verified Network tab is Enabled and clicked");
			sa.assertTrue(librariesprogramspage.verifyMaxDaySupplyFieldIsDisplayed(),
					"Verified Max day Supply field is displayed");
			sa.assertTrue(librariesprogramspage.verifyRefillTooSoonFieldIsDisplayed(),
					"Verified Refill Too Soon field is displayed");
			sa.assertTrue(librariesprogramspage.verifyNumberOfGraceFillsFieldIsDisplayed(),
					"Verified Number of Grace fills field is displayed");
			sa.assertTrue(librariesprogramspage.verifyNumberOfFillsDropdownIsDisplayed(),
					"Verified Number of fills dropdown is displayed");
			String networkName = librariesprogramspage.verifyAndAddException();
			librariesprogramspage.clickSaveChangesButton();
			sa.assertTrue(librariesprogramspage.verifyChangesSavedText(), "Verified 'Save Changes text' is displayed");
			sa.assertTrue(librariesprogramspage.verifyNetworkNameIsAddedInAddExceptionsNetwork(networkName),
					"Verified Network Name is added in Add Exceptions network list is same as expected");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit and Add Exception in Networks Tab of Cost of care is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Edit and Add Exception in Networks Tab of Cost of care Functionality");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

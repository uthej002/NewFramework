package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

public class IBPLibrariesProgramsPage extends OneframeContainer {

	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//button[contains(@class,' mat-button mat-button-base ')]//span[text()=' Therapeutic ']")
	WebElement btnTherapeutic;

	@FindBy(xpath = "//*[@formcontrolname='terminationDate']")
	WebElement txtTermDate;

	@FindBy(xpath = "//a[@routerlink=\"/admin/library/programs\"]")
	WebElement btnView;

	@FindBy(xpath = "//div[@class='mat-title title' and text()='Programs']")
	WebElement hdrPrograms;

	@FindBy(xpath = "//span[text()=' Add a Program ']")
	WebElement btnAddProgram;
	
	@FindBy(xpath = "//span[text()=' Add a Specialty ']")
	WebElement btnAddSpecialtyProgram;

	@FindBy(xpath = "//div[@class='content__heading' and text()='Add New Program']")
	WebElement hdrAddNewProgram;

	@FindBy(xpath = "//mat-select[@id='mat-select-10']/div/div[2]")
	WebElement drdAutoApply;

	@FindBy(xpath = "//mat-select[@formcontrolname='clients']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdClient;

	@FindBy(xpath = "//mat-select[@formcontrolname='lobs']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdLob;
	
	@FindBy(xpath="//h3[text()='Formulary Data']")
	WebElement hdrFormularyData;

	@FindBy(xpath = "//mat-select[@formcontrolname='states']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdState;

	@FindBy(xpath = "//span[text()=' Cost of Care ']")
	WebElement lnkCostofCare;

	@FindBy(xpath = "//span[text()=' Specialty ']")
	WebElement lnkSpeciality;

	@FindBy(xpath = "//input[@formcontrolname='name']")
	WebElement programNameField;

	@FindBy(xpath = "//button[@data-automation-id='programCreateAddBtn']")
	WebElement addProgram;

	@FindBy(xpath = "//*[@svgicon=\"edit\"]")
	WebElement btnEdit;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell center cdk-column-client mat-column-client ng-star-inserted\"]")
	List<WebElement> lstCostOfCareClientRecords;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell left left--w-15 cdk-column-programName mat-column-programName ng-star-inserted\"]")
	List<WebElement> lstProgramNameRecords;
	
	@FindBy(xpath = "//*[@formcontrolname='description']")
	WebElement descriptionField;

	@FindBy(xpath = "//*[@class=\"mat-paginator-icon\"]")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;
	
	@FindBy(xpath = "//*[@class=\"mat-cell cdk-cell left left--w-15 cdk-column-programName mat-column-programName ng-star-inserted\"]")
	List<WebElement> programList;

	@FindBy(xpath = "//td[contains(@class, 'mat-cell cdk-cell left left--w-15 cdk-column-programName mat-column-programName ')]")
	List<WebElement> lstPrograms;

	@FindBy(xpath = "//div[text()='Program Details']")
	WebElement txtProgramDetails;

	@FindBy(xpath = "//mat-select[@role='listbox']")
	List<WebElement> dropdownsValues;

	@FindBy(xpath = "//div[@aria-label='networks']")
	WebElement txtNetworkTab;

	@FindBy(xpath = "//mat-select[@formcontrolname='networkOverrides']")
	WebElement networkOverrideDropdown;

	@FindBy(xpath = "//*[@data-automation-id='costShareOverrides']")
	WebElement costShareOverrideField;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> dropdownValues;

	@FindBy(xpath = "//input[@formcontrolname='maxDaySupply']")
	List<WebElement> txtMaxDaySupply;

	@FindBy(xpath = "//input[@formcontrolname='refillTooSoon']")
	List<WebElement> txtRefillTooSoon;

	@FindBy(xpath = "//input[@formcontrolname='fillLimit']")
	List<WebElement> txtNumberOfGraceFills;

	@FindBy(xpath = "//mat-select[@placeholder='Select']")
	List<WebElement> drdNumberOfFills;

	@FindBy(xpath = "//*[contains(text(),' Add Exception Networks ')]")
	WebElement btnAddException;

	@FindBy(xpath = "//div[@class='header__title']")
	WebElement hdrAddNetwork;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted']")
	List<WebElement> lstNetworkName;

	@FindBy(xpath = "//span[@class=\"except-title\"]")
	WebElement txtExcept;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-networkName mat-column-networkName ng-star-inserted']")
	List<WebElement> lstNetworkNameFromAddNetwork;

	@FindBy(xpath = "//span[contains(text(),' Add Network ')]")
	WebElement btnAddNetwork;

	@FindBy(xpath = "//span[contains(text(),'Changes Saved')]")
	WebElement txtChangesSaved;

	@FindBy(xpath = "//*[text()='Save changes']")
	WebElement btnSaveChanges;

	@FindBy(xpath = "//input[@formcontrolname='description']")
	WebElement programDescField;

	@FindBy(xpath = "//*[text()=' Add Drug List ']")
	WebElement btnAddDrugList;

	@FindBy(xpath = "//tr[@class='mat-row cdk-row ng-star-inserted']")
	List<WebElement> lstDrugDetails;

	@FindBy(xpath = "//*[@class='header__title' and text() = ' Add Drug List ' ]")
	WebElement txtAddDrugList;

	@FindBy(xpath = "//th[text()='DRUG LIST ID']")
	WebElement txtDrugListId;

	@FindBy(xpath = "//div[@class='footer']/button[2]")
	WebElement btnAddDrugListId;

	@FindBy(xpath = "//h3[text()='Drug List']")
	WebElement txtDrugList;
	
	@FindBy(xpath="//*[text()='Except']")
	WebElement txtHeaderExcept;

	@FindBy(xpath = "//span[text()=' Add Program ']")
	WebElement btnAddTherapeuticProgram;

	@FindBy(xpath = "//*[@svgicon='remove']")
	WebElement btnRemoveDrug;

	@FindBy(xpath = "//span[text()=' Remove ']")
	WebElement btnRemove;

	@FindBy(xpath = "//*[@data-automation-id='createMandates']")
	List<WebElement> dynamicLayerFields;

	@FindBy(xpath = "//mat-icon[@svgicon='filter']")
	WebElement btnFilter;

	@FindBy(xpath = "//mat-select[@formcontrolname='client']")
	WebElement FilterClient;

	@FindBy(xpath = "//mat-select[@formcontrolname='lob']")
	WebElement FilterLob;

	@FindBy(xpath = "//mat-select[@formcontrolname='state']")
	WebElement FilterState;

	@FindBy(xpath = "//div[@class='filter__text']")
	WebElement txtFilterBy;

	@FindBy(xpath = "//span[text()='Apply filter']")
	WebElement btnApplyFilter;

	@FindBy(xpath = "//mat-option[@role='option']/span")
	List<WebElement> dropdownFilterValues;

	@FindBy(xpath = "//mat-select")
	List<WebElement> filters;

	@FindBy(xpath = "//span[text()='Clear filter']/..")
	WebElement btnClearFilter;

	@FindBy(xpath = "//input[@formcontrolname='effectiveDate']")
	WebElement txtEffectiveDate;

	@FindBy(xpath = "//button[@data-automation-id='programCreateAddBtn']")
	WebElement btnDisableAddProgram;

	@FindBy(xpath = "//span[text()=' Cancel ']")
	WebElement btnCancel;

	@FindBy(xpath = "//h3[@class='mat-dialog-title' and text()='Leave without Saving?']")
	WebElement hdrCancelPopup;

	@FindBy(xpath = "//div[@class='mat-dialog-content' and text()='You started creating your program.']")
	WebElement txtCancelPopupContent;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()='Leave']")
	WebElement btnLeave;

	@FindBy(xpath = "//*[@svgicon='remove']")
	List<WebElement> btnRemoveException;

	@FindBy(xpath = "//span[text()='Remove']")
	WebElement blnRemoveException;

	@FindBy(xpath = "//div[@role='tab' and @aria-disabled='true' and @aria-label]/div")
	List<WebElement> tabDisbaledValues;

	@FindBy(xpath = "//div[@role='tab' and @aria-disabled='false' and @aria-label]/div")
	List<WebElement> tabEnabledValues;

	@FindBy(xpath = "//div[text()='Networks']")
	WebElement tabNetworks;

	@FindBy(xpath = "//div[text()='General']")
	WebElement tabGeneral;

	@FindBy(xpath = "//h3[text()='All Networks']")
	WebElement hdrAllNetworks;

	@FindBy(xpath = "//mat-checkbox[@data-automation-id='includePrograms1']")
	WebElement cbkAllNetworks;

	@FindBy(xpath = "//input[@data-automation-id='maxDaySupplyPrograms1']")
	WebElement txtRetailMaxDaySupply;

	@FindBy(xpath = "//input[@data-automation-id='refillTooSoonPrograms1']")
	WebElement txtRetailRefillToSoon;

	@FindBy(xpath = "//input[@data-automation-id='fillLimit1']")
	WebElement txtRetailNumberofFiles;

	@FindBy(xpath = "//div[@class='mat-slide-toggle-thumb']")
	List<WebElement> tglProgramCustomizationtoggles;

	@FindBy(xpath = "//h3[text()='Program Customization']")
	WebElement hdrProgramCustomization;

	@FindBy(xpath = "//span[text()=' Back ']")
	WebElement btnBack;

	@FindBy(xpath = "//div[@aria-label='costSharesPrograms']")
	WebElement costShareTab;

	@FindBy(xpath = "//*[@class=\"mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin\"]")
	WebElement customSteppingToggle;

	@FindBy(xpath = "//*[text()=\"INN Retail\"]//following::div[1]")
	WebElement drdInnRetail;

	@FindBy(xpath = "//*[text()=\"INN Home Delivery\"]//following::div[1]")
	WebElement drdInnHomeDelivery;

	@FindBy(xpath = "//*[text()=\"OON Retail\"]//following::div[1]")
	WebElement drdONNRetail;

	@FindBy(xpath = "//th[text()='CVS CODE']")
	WebElement txtCvsCode;

	@FindBy(xpath = "//th[text()='DRUG LIST NAME']")
	WebElement txtDrugListName;

	@FindBy(xpath = "//th[text()='DESCRIPTION']")
	WebElement txtDescription;

	@FindBy(xpath = "//th[text()='OWNED BY']")
	WebElement txtOwnedBy;

	@FindBy(xpath = "//th[text()='ADJ. SYS STATUS']")
	WebElement txtAdjSysStatus;

	@FindBy(xpath = "//th[text()='EFFECTIVE DATE']")
	WebElement effDate;

	@FindBy(xpath = "//th[text()='TERMINATION DATE']")
	WebElement TerminationDate;

	@FindBy(xpath = "//thead[@role='rowgroup']/tr/th")
	List<WebElement> lstDruglistFields;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td")
	List<WebElement> lstDruglistValues;

	@FindBy(xpath = "//*[@formcontrolname='costShareStructure']")
	WebElement drdCostShareStructure;

	@FindBy(xpath = "//*[@formcontrolname='costShareTierStructure']")
	WebElement drdCostShareTierStructure;

	@FindBy(xpath = "//*[@placeholder='Select']")
	List<WebElement> drdCostShareDetails;

	@FindBy(xpath = "//*[text()='Cost Share Tier Structure']")
	WebElement txtCostShareTierStructure;

	@FindBy(xpath = "//a[@routerlink=\"/admin/library/bob/dynamic-layer\"]")
	WebElement btnViewBlockOfBusiness;

	@FindBy(xpath = "//div[@class='mat-title title' and text()='Block of Business']")
	WebElement hdrBlockofBusiness;

	@FindBy(xpath = "//div[@class='mat-slide-toggle-thumb']")
	List<WebElement> tglSpecialtytoggles;

	@FindBy(css = "button[aria-label='Change sorting for programName']")
	WebElement programNameColumnHeader;

	@FindBy(css = "button[aria-label='Change sorting for effectiveDate']")
	WebElement effectiveDateColumnHeader;

	@FindBy(xpath = "//button[@aria-label='Change sorting for programName']/../..")
	WebElement sortCondition;

	@FindBy(xpath = "//tbody/tr/td[3]")
	List<WebElement> programNames;

	@FindBy(xpath = "//button[@aria-label='Change sorting for effectiveDate']/../..")
	WebElement sortConditionEffectiveDate;

	@FindBy(xpath = "//tbody/tr")
	List<WebElement> tableRows;

	@FindBy(xpath = "//*[text()=' Ancillary Charges Apply Based on DAW rules ']")
	WebElement txtAncillaryCharges;

	@FindBy(xpath = "//div[@aria-label='accums']")
	WebElement accumTab;

	@FindBy(xpath = "//*[text()='INN Retail']")
	List<WebElement> txtINNRetail;

	@FindBy(xpath = "//*[text()='INN Home Delivery']")
	List<WebElement> txtINNHomeDelivery;

	@FindBy(xpath = "//*[text()='OON Retail']")
	List<WebElement> txtOONRetail;

	@FindBy(xpath = "//*[@formcontrolname='nonSellableDate']")
	WebElement txtNonSellableDate;

	@FindBy(xpath = "//mat-select[@formcontrolname='generalOverrides']")
	WebElement generalOverrideDropdown;

	@FindBy(xpath = "//mat-select[@formcontrolname='costShareOverrides']")
	WebElement drpdwnCostShare;

	@FindBy(xpath = "//mat-select[@formcontrolname='accumsOverrides']")
	WebElement drpdwnAccums;

	@FindBy(xpath = "//*[@data-automation-id='priority']")
	WebElement enterPriority;

	@FindBy(xpath = "//*[@formcontrolname='details']")
	WebElement detailsField;

	@FindBy(xpath = "//*[@formcontrolname='category']")
	WebElement drpdownCategory;

	@FindBy(xpath = "//*[@formcontrolname='subcategory']")
	WebElement drpdownSubCategory;

	@FindBy(xpath = "//*[text()='Cancel']")
	WebElement btnCostofcareCancel;

	@FindBy(xpath = "//*[@formcontrolname='retailHighDollarAmount']")
	WebElement txtEnterRetailhighDollar;

	@FindBy(xpath = "//*[@formcontrolname='mailHighDollarAmount']")
	WebElement txtEnterMailHighDollar;

	@FindBy(xpath = "//mat-select[@formcontrolname='channel']")
	WebElement drpDwnChannel;

	@FindBy(xpath = "//*[@formcontrolname='umQuantityLimit']")
	WebElement txtEnterQuantityLimit;

	@FindBy(xpath = "//mat-select[@formcontrolname='umQuantityLimitationTimePeriod']")
	WebElement drpDwnQuantityPeriod;

	@FindBy(xpath = "//*[@formcontrolname='daySupply']")
	WebElement txtEnterdaySupply;

	@FindBy(xpath = "//*[@formcontrolname='minSupplyDays']")
	WebElement txtEnterInititalDaysSupply;

	@FindBy(xpath = "//*[@formcontrolname='lookbackDays']")
	WebElement txtEnterlookbackDays;

	@FindBy(xpath = "//*[@formcontrolname='maxFillDaysSupply']")
	WebElement txtEntermaxFillDaysSupply;

	@FindBy(xpath = "//*[@formcontrolname='lowerAgeLimit']")
	WebElement txtEnterlowerAgeLimit;

	@FindBy(xpath = "//*[@formcontrolname='upperAgeLimit']")
	WebElement txtEnterupperAgeLimit;

	@FindBy(xpath = "//mat-select[@formcontrolname='underLimitCoverage']")
	WebElement drpDwnUnderAgeRestriction;

	@FindBy(xpath = "//mat-select[@formcontrolname='overLimitCoverage']")
	WebElement drpDwnOverAgeRestriction;

	@FindBy(xpath = "//mat-select[@formcontrolname='withinLimitCoverage']")
	WebElement drpDwnBetweenAgeRestriction;

	@FindBy(xpath = "//mat-select[@formcontrolname='afterFillLimit']")
	List<WebElement> drpDwnSelect;

	@FindBy(xpath = "//mat-checkbox[@data-automation-id='includePrograms2']")
	WebElement cbkAllNetworks2;

	@FindBy(xpath = "//input[@data-automation-id='maxDaySupplyPrograms2']")
	WebElement txtHomeMaxDaySupply;

	@FindBy(xpath = "//input[@data-automation-id='refillTooSoonPrograms2']")
	WebElement txtHomeRefillToSoon;

	@FindBy(xpath = "//input[@data-automation-id='fillLimit2']")
	WebElement txtHomeNumberofFiles;

	@FindBy(xpath = "//*[text()=' Add Specific Networks ']")
	WebElement btnAddSpecificNetwork;

	@FindBy(xpath = "//div[@class='footer']/button[2]")
	WebElement btnSpecificAddNetwork;

	@FindBy(xpath = "//span[text()='Remove']")
	WebElement btnRemoveNetwork;

	@FindBy(xpath = "//mat-select[@formcontrolname='programAccumOption']")
	WebElement drpDwnProgramAccum;

	@FindBy(xpath = "//*[@formcontrolname='accumValue']")
	List<WebElement> enterAccumValue;

	@FindBy(xpath = "(//mat-select[@formcontrolname='accumulateType'])[1]")
	WebElement drpDwnAccumulateType1;

	@FindBy(xpath = "(//mat-select[@formcontrolname='accumulateType'])[2]")
	WebElement drpDwnAccumulateType2;

	@FindBy(xpath = "(//mat-select[@formcontrolname='accumulateType'])[3]")
	WebElement drpDwnAccumulateType3;

	@FindBy(xpath = "//mat-select[@formcontrolname='enabled']")
	List<WebElement> drpDwnSelectEnabled;

	@FindBy(xpath = "(//mat-select[@formcontrolname='option'])[1]")
	WebElement drpDwnSelectOption1;

	@FindBy(xpath = "(//mat-select[@formcontrolname='option'])[2]")
	WebElement drpDwnSelectOption2;

	@FindBy(xpath = "//mat-select[@formcontrolname='benefitPeriod']")
	WebElement drpDwnBenefitPeriod;

	@FindBy(xpath = "//*[text()='Apply Integrated Medical']")
	List<WebElement> txtApplyMedical;

	@FindBy(css = "button[aria-label='Change sorting for terminationDate']")
	WebElement terminationDateColumnHeader;

	@FindBy(xpath = "//button[@aria-label='Change sorting for terminationDate']/../..")
	WebElement sortConditionTerminationDate;
	
	@FindBy(xpath = "//*[text()=' Add a Specialty ']")
	WebElement btnAddSpecialityProgram;

	@FindBy(xpath = "//*[contains(text(),'was succesfully created')]")
	WebElement txtCreatedSpecialtyPrgm;
	
	// Initializing the Page Objects:
	public IBPLibrariesProgramsPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click View button of Programs")
	public void clickViewButtonofPrograms() {
		try {
			if (WaitForObjectVisibility(btnView)) {
				ClickWebObject(btnView);
				OneframeLogger("Clicked on View button of Programs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("View button of Programs is not Clicked");
		}
	}

	@Step("Enter Term date")
	public void EnterTermDate(String TermDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtTermDate)) {
				ClickWebObject(txtTermDate);
				EnterText(txtTermDate, TermDate);
				OneframeLogger("Term Date has been Entered : " + txtTermDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Term Date has been Entered");
		}
	}

	@Step("Verify Programs header is displayed")
	public boolean verifyProgramsHeader() {
		boolean flag = false;
		if (WaitForObjectVisibility(hdrPrograms)) {
			if (hdrPrograms.getText().equalsIgnoreCase("Programs")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click Programs header")
	public void clickProgramsHeader() {
		WaitForObjectVisibility(hdrPrograms);
		hdrPrograms.click();
		hdrPrograms.click();
		hdrPrograms.click();
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Enter and Get Program Name")
	public String enterAndGetProgramName(String programNm) {
		if (WaitForObject(programNameField)) {
			ClickWebObject(programNameField);
			String program = programNm;
			int randomNumber = getRandomNumber();
			String programName = program + randomNumber;
			programNameField.sendKeys(programName);
			OneframeLogger("The Program Name is : " + programNameField.getAttribute("value"));
		}
		return programNameField.getAttribute("value");
	}

	public boolean enterProgramName(String programNm) {
		boolean bln = false;
		if (WaitForObject(programNameField)) {
			ClickWebObject(programNameField);
			String program = programNm + " Program";
			int randomNumber = getRandomNumber();
			String programName = program + randomNumber;
			programNameField.sendKeys(programName);
			OneframeLogger("The Program Name is : " + programNameField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Enter Program Description")
	public boolean enterProgramDescription(String programDesc) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(programDescField)) {
			ClickWebObject(programDescField);
			programDescField.sendKeys(programDesc);
			OneframeLogger("The Mandate Name is : " + programDescField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Verify Add New Program header is displayed")
	public boolean verifyAddNewProgramHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAddNewProgram)) {
			if (hdrAddNewProgram.getText().equalsIgnoreCase("Add New Program")) {
				flag = true;
			}
		}
		return flag;
	}

	public void clickAddNewProgram() {
		ClickWebObject(hdrAddNewProgram);
		ClickWebObject(hdrAddNewProgram);
		ClickWebObject(hdrAddNewProgram);
	}

	@Step("Click on Add Program Button")
	public void clickAddProgram() {

		try {
			if (WaitForObject(addProgram)) {
				ClickWebObject(addProgram);
				OneframeLogger("Clicked on Add Program Button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Program button is not Clicked");
		}
	}
	
	@Step("Enter Description")
	public boolean enterDescription(String mandateDesc) {
		boolean bln = false;
		if (WaitForObject(descriptionField)) {
			ClickWebObject(descriptionField);
			String mandateDescription = mandateDesc + " Description";
			int randomNumber = getRandomNumber();
			String mandateName = mandateDescription + randomNumber;
			descriptionField.sendKeys(mandateName);
			OneframeLogger("The Mandate Name is : " + descriptionField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Click Add Program of Programs")
	public boolean clickAddProgramofPrograms() {
		try {
			if (WaitForObject(btnAddProgram)) {
				ClickWebObject(btnAddProgram);
				OneframeLogger("Clicked on Add Program of Programs");
				return true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Program of Programs is not Clicked: " + e);
		}
		return false;
	}
	
	@Step("Click Add Specialty Program button")
	public boolean clickAddSpecialtyProgram() {
		try {
			if (WaitForObject(btnAddSpecialtyProgram)) {
				ClickWebObject(btnAddSpecialtyProgram);
				OneframeLogger("Clicked on Add Specialty Program button");
				return true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("AAdd Specialty Program button is not Clicked: " + e);
		}
		return false;
	}

	@Step("Select Auto Apply Dropdown")
	public boolean verifyAutoApplyDropdown() {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply)) {
				highlightElement(drdAutoApply);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Cost of Care button from Programs Library")
	public void clickCostofCareofPrograms() {
		try {
			if (WaitForObjectVisibility(lnkCostofCare)) {
				ClickWebObject(lnkCostofCare);
				OneframeLogger("Clicked on cost of care from Programs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cost of care from Programs is not Clicked");
		}
	}

	@Step("Click Speciality button from Programs Library")
	public void clickOnSpeciality() {
		try {
			if (WaitForObjectVisibility(lnkSpeciality)) {
				ClickWebObject(lnkSpeciality);
				OneframeLogger("Clicked on speciality from Programs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Speciality from Programs is not Clicked");
		}
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
		WebElement secondElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(secondElement);
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
		//WebElement sec=oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-backdrop cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing\"]"));
		//ClickWebObject(sec);

	}

	@Step("Select Value Client from dropdown")
	public boolean selectClientropdown(String client) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdClient)) {
				ClickWebObject(drdClient);
				selectDropdownValues(client);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from client dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Value LOB from dropdown")
	public boolean selectLobdropdown(String lob) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdLob)) {
				ClickWebObject(drdLob);
				selectDropdownValues(lob);
				// drdLob.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from lob dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Value LOB from dropdown")
	public boolean selLobdropdown(String lob) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdLob)) {
				ClickWebObject(drdLob);
				selectDropdownValue(lob);
			
				Robot rt = new Robot();
				rt.keyPress(KeyEvent.VK_TAB);
				
				
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from lob dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Value State from dropdown")
	public boolean selectStatedropdown(String state) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdState)) {
				ClickWebObject(drdState);
				selectDropdownValues(state);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from state dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify and Click on Edit button")
	public boolean verifyAndClickEditButton() {
		WaitForApplicationToLoadCompletely();
		boolean bln = false;
		if (WaitForObjectVisibility(btnEdit)) {
			btnEdit.click();
			bln = true;
		}
		return bln;
	}

	@Step("Verify and Click Program Name")
	public boolean verifyAndClickProgramName(String programName) throws InterruptedException {
		boolean bln = false;
		WaitForApplicationToLoadCompletely();
		Thread.sleep(3000);
		try {
			String xpath = "//td[contains(text(),'"+programName+"')]";
			String records = null;
			WaitForObjectVisibility(txtPageNumber);
			if(WaitForObject(txtPageNumber)) {
				records = txtPageNumber.getText();
			}
			String[] recordCnt = records.split(" ");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());
			int numberOfPages = Math.round(totalRecords/10) + 1;
			
			if(numberOfPages != 0) {
				for(int i=0; i<numberOfPages; i++) {
					try {
						WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
						OneframeLogger("Latest Version is CLicked : " +ele.getText());
						if(WaitForObjectVisibility(ele)) {
							ClickWebObject(ele);
							return true;
						}
					}
					catch (NoSuchElementException e) {
						 ClickWebObject(lstPageTraverseChevronButton.get(1));
						 ClickWebObject(txtPageNumber); 
						 ClickWebObject(txtPageNumber);
						 WaitForApplicationToLoadCompletely();
					}
					
				}
			}
			
		
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to get Program Name");
			bln = false;
		}
		return bln;
	}

	@Step("Verify Program Name field is Enabled or not")
	public boolean verifyProgramNameIsEnabledOrNot() {
		boolean bln = false;
		txtDrugList.click();
		txtDrugList.click();
		if (WaitForObjectVisibility(programNameField)) {
			if (programNameField.isEnabled()) {
				bln = true;
			} else {
				bln = false;
			}
		}
		return bln;
	}

	@Step("Click header of Programs")
	public void clickProgramsheader() {
		ClickWebObject(hdrPrograms);
		ClickWebObject(hdrPrograms);
	}

	@Step("Select any record from Libraries Prorams Section")
	public boolean selectLibrariesProgramsRecord() throws InterruptedException {
		clickProgramsheader();
		clickProgramsheader();
		clickProgramsheader();
		clickProgramsheader();
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPerPage <= totalRecords) {
				for (int i = 0; i < lstPrograms.size(); i++) {
					if (lstPrograms.get(i).getText().contains("TESTAUTO")) {
						ClickWebObject(lstPrograms.get(i));
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException exc) {
		}
		return bln;
	}

	@Step("Verify Program Details header is displayed")
	public boolean verifyProgramDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(txtProgramDetails)) {
			ClickWebObject(txtProgramDetails);
			if (txtProgramDetails.getText().equalsIgnoreCase("Program Details")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Select Dynamic Layer and BOB Dropdowns are disabled")
	public boolean verifyDynamicLayersDisbaled() throws Throwable {
		Thread.sleep(3000);
		boolean blnRC = false;
		try {
			WaitForObjectVisibility(dropdownsValues.get(2));
			blnRC = true;
			for (int i = 2; i < dropdownsValues.size(); i++) {
				if (dropdownsValues.get(i).getAttribute("aria-disabled").toString().equals("true")) {
					ClickWebObject(dropdownsValues.get(i));
					blnRC = blnRC && true;
					if (i == 12) {
						break;
					}
				} else {
					blnRC = false;
				}
			}
		} catch (NoSuchElementException NSE) {
			OneframeLogger("Dropdown not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Network tab is Enabled or not")
	public boolean verifyNetworkTabIsEnabledAndClicked() {
		boolean bln = false;
		if (ObjectExist(txtNetworkTab)) {
			if (txtNetworkTab.getAttribute("aria-disabled").equalsIgnoreCase("false")) {
				txtNetworkTab.click();
				OneframeLogger("Network tab is Enabled");
				bln = true;
			} else {
				boolean bool = verifyNetworkOverrideDropdown();
				txtNetworkTab.click();
				bln = true;
				bln = bool && bln;
			}
		}
		return bln;
	}

	@Step("Verify Cost Share tab is Enabled or not")
	public boolean verifyCostShareTabIsEnabledAndClicked(String costShare) {
		boolean bln = false;
		if (WaitForObjectVisibility(costShareTab)) {
			if (costShareTab.getAttribute("aria-disabled").equalsIgnoreCase("false")) {
				costShareTab.click();
				OneframeLogger("Cost Share tab is Enabled");
				bln = true;
			} else {
				boolean bool = selectCostShareOverrideDropdown(costShare);
				costShareTab.click();
				bln = true;
				bln = bool && bln;
			}
		}
		return bln;
	}

	@Step("Select Network Override Dropdown")
	public boolean verifyNetworkOverrideDropdown() {
		boolean bln = false;
		if (ObjectExist(networkOverrideDropdown)) {
			networkOverrideDropdown.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select CostShare Override Dropdown")
	public boolean selectCostShareOverrideDropdown(String costShareOverride) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(costShareOverrideField)) {
				ClickWebObject(costShareOverrideField);
				selectDropdownValue(costShareOverride);
				// clickOverlayElement();
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select CostShare Override dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Max day Supply field is displayed")
	public boolean verifyMaxDaySupplyFieldIsDisplayed() {
		boolean bln = false;
		for (int i = 0; i < txtMaxDaySupply.size(); i++) {
			txtMaxDaySupply.get(i).click();
			bln = true;
		}
		return bln;
	}

	@Step("Verify Refill Too Soon field is displayed")
	public boolean verifyRefillTooSoonFieldIsDisplayed() {
		boolean bln = false;
		for (int i = 0; i < txtRefillTooSoon.size(); i++) {
			txtRefillTooSoon.get(i).click();
			bln = true;
		}
		return bln;
	}

	@Step("Verify Number of Grace fills field is displayed")
	public boolean verifyNumberOfGraceFillsFieldIsDisplayed() {
		boolean bln = false;
		for (int i = 0; i < txtNumberOfGraceFills.size(); i++) {
			txtNumberOfGraceFills.get(i).click();
			bln = true;
		}
		return bln;
	}

	@Step("Verify Number of fills dropdown is displayed")
	public boolean verifyNumberOfFillsDropdownIsDisplayed() {
		boolean bln = false;
		for (int i = 0; i < drdNumberOfFills.size(); i++) {
			highlightElement(drdNumberOfFills.get(i));
			bln = true;
		}
		return bln;
	}

	@Step("Click Add Exception button")
	public void clickAddExceptionButton() {
		ObjectExist(btnAddException);
		btnAddException.click();
		OneframeLogger("Clicked Add Exception button");
	}

	@Step("Click Add network header")
	public void clickAddNetwork() {
		hdrAddNetwork.click();
		hdrAddNetwork.click();
	}

	@Step("Get Network Name in Exception list")
	public List<String> getNetworkNameInExceptionList() {
		List<String> ls = new ArrayList<String>();
		for (int i = 0; i < lstNetworkName.size(); i++) {
			if (WaitForObject(lstNetworkName.get(i))) {
				highlightElement(lstNetworkName.get(i));
				lstNetworkName.get(i).isDisplayed();
				ls.add(lstNetworkName.get(i).getText());
				OneframeLogger("Network Name present in Add Exception list : " + ls);
			}
		}
		return ls;
	}

	@Step("Click a Network Name from Add Network in Exceptions")
	public String clickANetworkNameFromList(List<String> NetworkName) {
		String networkName = null;
		ObjectExist(lstNetworkNameFromAddNetwork.get(0));
		outer: for (int i = 0; i < lstNetworkNameFromAddNetwork.size(); i++) {
			try {
				if (!lstNetworkNameFromAddNetwork.get(i).getText().equalsIgnoreCase(NetworkName.get(0))) {
					WaitForObject(lstNetworkNameFromAddNetwork.get(i));
					ClickWebObject(lstNetworkNameFromAddNetwork.get(i));
					OneframeLogger("Clicked on Network name in Add network");
					networkName = lstNetworkNameFromAddNetwork.get(i).getText();
					OneframeLogger("Network name added from Add Network list is : " + networkName);
					break outer;
				}
			} catch (StaleElementReferenceException exc) {
				OneframeLogger("Unable to click Network list");
			}
		}
		return networkName;

	}

	@Step("Click a network from Add Network list")
	public String clickNetworkNameFromAddNetworkList() {
		hdrAddNetwork.click();
		hdrAddNetwork.click();
		hdrAddNetwork.click();
		WaitForObjectToBeClickable(lstNetworkNameFromAddNetwork.get(0));
		lstNetworkNameFromAddNetwork.get(0).click();
		String networkName = lstNetworkNameFromAddNetwork.get(0).getText();
		OneframeLogger("Network name added from Add Network list is : " + networkName);
		return networkName;
	}

	@Step("Verify Add Exception")
	public String verifyAndAddException() {
		if (FindObjectByLocatorNoWait(By
				.xpath("//td[@class='mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted']")) != null) {
			clickRemoveException();
			clickAddExceptionButton();
			clickAddNetwork();
			String networkNm = clickNetworkNameFromAddNetworkList();
			clickAddNetworkButton();
			return networkNm;
		} else {
			clickAddExceptionButton();
			clickAddNetwork();
			String networkNm = clickNetworkNameFromAddNetworkList();
			clickAddNetworkButton();
			return networkNm;
		}
	}

	@Step("Click on Add Network button")
	public void clickAddNetworkButton() {
		WaitForObject(btnAddNetwork);
		ScrollToElement(hdrAddNetwork);
		ClickWebObject(btnAddNetwork);
		OneframeLogger("Clicked on Add Network button");
	}

	@Step("Verify Network Name is added in Add Exceptions Network")
	public boolean verifyNetworkNameIsAddedInAddExceptionsNetwork(String networkName) throws InterruptedException {
		boolean bln = false;
		//hdrAddNewProgram.click();
		txtHeaderExcept.click();
		txtHeaderExcept.click();
		txtHeaderExcept.click();
		txtHeaderExcept.click();
		txtHeaderExcept.click();
		Thread.sleep(5000);
		WaitForObjectVisibility(lstNetworkName.get(0));
		for (int i = 0; i < lstNetworkName.size(); i++) {
			if (lstNetworkName.get(i).getText().equalsIgnoreCase(networkName)) {
				bln = true;
			} else {
				continue;
			}
		}
		return bln;
	}

	@Step("Verify Text Save Changes is displayed")
	public boolean verifyChangesSavedText() {
		boolean bln = false;
		if (ObjectExist(txtChangesSaved)) {
			txtChangesSaved.isDisplayed();
			highlightElement(txtChangesSaved);
			OneframeLogger("Changes saved text is displayed");
			bln = true;
		}
		return bln;
	}

	@Step("Click Save Changes button from Cost Share Structure Details")
	public void clickSaveChangesButton() {
		WaitForObjectVisibility(btnSaveChanges);
		ClickWebObject(btnSaveChanges);
		OneframeLogger("Save Changes button clicked");
	}

	@Step("Enter and Get Program Description")
	public String enterAndGetProgramDescription(String programDesc) throws InterruptedException {
		if (WaitForObject(programDescField)) {
			ClickWebObject(programDescField);
			/*
			 * String mandate = programDesc + " Program"; int randomNumber =
			 * getRandomNumber(); String mandateName = mandate + randomNumber;
			 */
			programDescField.sendKeys(programDesc);
			OneframeLogger("The Mandate Name is : " + programDescField.getAttribute("value"));
		}

		return programDescField.getAttribute("value");
	}

	@Step("Click Add Drug List button under Therapeutic Program")
	public boolean clickOnAddDrugList() {

		if (WaitForObject(btnAddDrugList)) {
			ClickWebObject(btnAddDrugList);
			OneframeLogger("Clicked on Add Drug List button under Therapeutic Program");
			return true;
		}
		return false;

	}

	@Step("Verify Drug List Header and Drug List Id under Add Drug List button")
	public boolean verifyDrugListHdr() {

		if (WaitForObject(txtAddDrugList)) {
			ClickWebObject(txtAddDrugList);
			ClickWebObject(txtDrugListId);

			OneframeLogger("Verify Drug List and Drug List Id under Add Drug List button");
			return true;
		}
		return false;

	}

	@Step("Click Drug Details under Add Drug List button")
	public boolean click1stDruglst() {

		if (WaitForObject(lstDrugDetails.get(0))) {
			ClickWebObject(lstDrugDetails.get(0));
			OneframeLogger("Clicked Drug Details under Add Drug List button");
			return true;
		}
		return false;

	}

	@Step("Click Add Drug List button under Add Drug List Page")
	public boolean clickAddDruglistBtn() {

		if (WaitForObject(btnAddDrugListId)) {
			ClickWebObject(btnAddDrugListId);
			OneframeLogger("Clicked Add Drug List button under Add Drug List Page");
			return true;
		}
		return false;

	}

	@Step("Click Add Therapeutic Program")
	public boolean clickAddTherapeuticProgram() {
		ClickWebObject(txtDrugList);
		if (WaitForObject(btnAddTherapeuticProgram)) {
			ClickWebObject(btnAddTherapeuticProgram);
			OneframeLogger("Clicked Add Therapeutic Program");
			return true;
		}
		return false;

	}

	@Step("Click on Remove Drug option")
	public boolean clickRemoveDrug() {
		ClickWebObject(txtDrugList);
		if (WaitForObject(btnRemoveDrug)) {
			ClickWebObject(btnRemoveDrug);
			OneframeLogger("Clicked on Remove Drug option");
			return true;
		}
		return false;

	}

	@Step("Click on Remove Button in pop up window")
	public boolean clickRemoveButton() {

		if (WaitForObject(btnRemove)) {
			ClickWebObject(btnRemove);
			OneframeLogger("Clicked on Remove Button in pop up window");
			return true;
		}
		return false;

	}

	@Step("Click on Filter button")
	public void clickFilterButton() {
		WaitForObjectToBeClickable(btnFilter);
		btnFilter.click();
		OneframeLogger("Clicked on Filter button");
	}

	@Step("Verify Filter By text is displayed")
	public boolean verifyFilterText() {
		boolean flag = false;
		if (ObjectExist(txtFilterBy)) {
			txtFilterBy.isDisplayed();
			ClickWebObject(txtFilterBy);
			OneframeLogger("Filter By Text is displayed");
			flag = true;
		}
		return flag;
	}

	@Step("Click on Apply Filter button")
	public void clickApplyFilterButton() {

		if (WaitForObjectVisibility(btnApplyFilter)) {
			btnApplyFilter.click();
			OneframeLogger("Clicked on Apply Filter button");
		}

	}

	@Step("Click on Clear Filter button")
	public void clickClearFilterButton() {
		if (WaitForObjectVisibility(btnClearFilter)) {
			btnClearFilter.click();
			OneframeLogger("Clicked on Clear Filter button");
		}
	}

	@Step("Select values from FilterDropdowns")
	public String selectValuesFromFilter() throws Throwable {
		Robot rt = new Robot();
		if (ObjectExist(FilterClient)) {
			FilterClient.click();
			dropdownFilterValues.get(0).click();
			rt.keyPress(KeyEvent.VK_TAB);
			OneframeLogger("Selected first value from Client dropdown : " + FilterClient.getText());
			FilterLob.click();
			dropdownFilterValues.get(0).click();
			rt.keyPress(KeyEvent.VK_TAB);
			OneframeLogger("Selected first value from Lob dropdown : " + FilterLob.getText());
		}
		return FilterClient.getText() + "," + FilterLob.getText();
	}

	@Step("Verify whether selected Client and LOB has displayed")
	public boolean verifySelectedValuesDisplayed(String values) throws Throwable {
		boolean blnRC = false;
		ClickWebObject(hdrPrograms);
		ClickWebObject(hdrPrograms);
		String[] valuesList = values.split(",");
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("-");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			String element = String
					.format("//td[contains(@class, 'mat-cell cdk-cell center cdk-column-client mat-column-client ')]");
			List<WebElement> ClientValue = oneframeDriver.findElements(By.xpath(element));
			String elementOne = String
					.format("//td[contains(@class, 'mat-cell cdk-cell center cdk-column-lob mat-column-lob ')]");
			List<WebElement> LOBValue = oneframeDriver.findElements(By.xpath(elementOne));
			// outer: while (recordsPresentPerPage <= totalRecords) {
			for (int i = 0; i < ClientValue.size(); i++) {
				if (WaitForObjectVisibility(ClientValue.get(i))
						&& ClientValue.get(i).getText().contains(valuesList[0])) {
					highlightElement(ClientValue.get(i));
					OneframeLogger("The Actual Client Value " + valuesList[0] + " matched with expected Client Value "
							+ ClientValue.get(i).getText());
					if (WaitForObjectVisibility(LOBValue.get(i)) && LOBValue.get(i).getText().contains(valuesList[1])) {
						highlightElement(LOBValue.get(i));
						OneframeLogger("The Actual LOB Value " + valuesList[1] + " matched with expected LOB Value "
								+ LOBValue.get(i).getText());
						blnRC = true;
					} else {
						blnRC = false;
						break;
					}
				} else {
					blnRC = false;
					break;
				}
			}
			// if (totalRecords != recordsPresentPerPage) {
			// ClickWebObject(lstPageTraverseChevronButton.get(1));
			// ClickWebObject(txtPageNumber);
			// ClickWebObject(txtPageNumber);
			// }
			// String record = txtPageNumber.getText();
			// recordCnt = record.split("Ã¢â‚¬â€œ");
			// totalRecordCnt = recordCnt[1].split("of");
			// totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			// recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			// }
			// ScrollToElement(hdrPrograms);
		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Business Unit Dropdown")
	public boolean selectBusinessUnitDropdown(String BusinessUnit) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(2))) {
				ClickWebObject(dynamicLayerFields.get(2));
				selectDropdownMultipleValues(BusinessUnit);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Unit dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select CDHP Type Dropdown")
	public boolean selectCDHPTypeDropdown(String CDHP) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(3))) {
				ClickWebObject(dynamicLayerFields.get(3));
				selectDropdownMultipleValues(CDHP);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select CDHP type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Formulary Dropdown")
	public boolean selectFormularyDropdown(String formulary) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(4))) {
				ClickWebObject(dynamicLayerFields.get(4));
				selectDropdownMultipleValues(formulary);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Formulary dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Funding Type Dropdown")
	public boolean selectFundingTypeDropdown(String FundingType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(5))) {
				ClickWebObject(dynamicLayerFields.get(5));
				selectDropdownMultipleValues(FundingType);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Funding Type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Market Segment Dropdown")
	public boolean selectMarketSegmentDropdown(String MarketSegment) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(6))) {
				ClickWebObject(dynamicLayerFields.get(6));
				selectDropdownMultipleValues(MarketSegment);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Market Segment dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Product Type Dropdown")
	public boolean selectProductTypeDropdown(String ProductType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(dynamicLayerFields.get(7))) {
				ClickWebObject(dynamicLayerFields.get(7));
				selectDropdownMultipleValues(ProductType);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Product type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(overlayElement);
	}

	@Step("Select the Multiple values from dropdowns")
	public void selectDropdownMultipleValues(String value) {
		String[] valuesList = value.split(",");
		for (String item : valuesList) {
			String elementOne = String.format(
					"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[text()=' %s ']",
					item);
			WebElement dropdownvalueOne = oneframeDriver.findElement(By.xpath(elementOne));
			WaitForObjectVisibility(dropdownvalueOne);
			ClickWebObject(dropdownvalueOne);
		}
		OneframeLogger("The Selected Dropdown values are " + value);
	}

	@Step("Verify Add and Rmeove Drug List for existing program ")
	public void verifyAddandRemoveDruglist() {
		verifyAndClickEditButton();

		if (FindObjectByLocatorNoWait(
				By.xpath("//td[@class = 'mat-cell cdk-cell cdk-column-id mat-column-id ng-star-inserted']")) != null) {

			clickRemoveDrug();
			clickRemoveButton();
			clickOnAddDrugList();
			verifyDrugListHdr();
			click1stDruglst();
			clickAddDruglistBtn();
			OneframeLogger("Drug List Added for Existing program ");
			clickRemoveDrug();
			clickRemoveButton();

		} else {
			clickOnAddDrugList();
			verifyDrugListHdr();
			click1stDruglst();
			clickAddDruglistBtn();
			OneframeLogger("Drug List Added for Existing program ");
			clickRemoveDrug();
			clickRemoveButton();

		}

	}

	@Step("Verify and Add Drug List for existing program ")
	public void verifyAndAddDruglist() {
		verifyAndClickEditButton();

		if (FindObjectByLocatorNoWait(
				By.xpath("//td[@class = 'mat-cell cdk-cell cdk-column-id mat-column-id ng-star-inserted']")) != null) {

			clickRemoveDrug();
			clickRemoveButton();
			clickOnAddDrugList();
			verifyDrugListHdr();
			click1stDruglst();
			clickAddDruglistBtn();
			OneframeLogger("Drug List Added for Existing program ");

		} else {
			clickOnAddDrugList();
			verifyDrugListHdr();
			click1stDruglst();
			clickAddDruglistBtn();
			OneframeLogger("Drug List Added for Existing program ");

		}
	}

	@Step("Verify Add Program button is Disabled ")
	public boolean verifyAddProgramBtnDisable() {

		if (programNameField.getAttribute("value").equals("") && txtEffectiveDate.getAttribute("value").equals("")
				&& drdClient.getAttribute("value") == null && drdLob.getAttribute("value") == null
				&& drdState.getAttribute("value") == null && programDescField.getAttribute("value").equals("")) {

			if (btnDisableAddProgram.getAttribute("disabled").equalsIgnoreCase("true")) {
				OneframeLogger("Mandatory Filed valuess are not provided ");
				OneframeLogger("Add Program Button is disabled ");
				return true;
			} else {
				return false;
			}
		}

		return false;
	}

	@Step("Click on Cancel button")
	public void clickCancelButton() {
		btnCancel.click();
		OneframeLogger("Clicked on Cancel button");
	}

	@Step("Verify Cancel Popup header is displayed")
	public boolean verifyCancelPopupHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCancelPopup)) {
			ClickWebObject(hdrCancelPopup);
			if (hdrCancelPopup.getText().equalsIgnoreCase("Leave without Saving?")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Cancel Popup content text is displayed")
	public boolean verifyCancelPopupContentTxt() {
		boolean flag = false;
		if (ObjectExist(txtCancelPopupContent)) {
			ClickWebObject(txtCancelPopupContent);
			if (txtCancelPopupContent.getText().equalsIgnoreCase("You started creating your program.")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click on Leave button")
	public void clickLeaveButton() {
		btnLeave.click();
		OneframeLogger("Clicked on Leave button");
	}

	@Step("Click on Remove Exception option")
	public boolean clickRemoveException() {
		for (int i = 0; i < btnRemoveException.size(); i++) {
			if (WaitForObject(btnRemoveException.get(i))) {
				ClickWebObject(btnRemoveException.get(i));
				clickRemoveButtonException();
				OneframeLogger("Clicked on Remove Exception option");
				return true;
			}
		}
		return false;
	}

	@Step("Click on Remove Button in pop up window")
	public boolean clickRemoveButtonException() {
		if (WaitForObject(blnRemoveException)) {
			ClickWebObject(blnRemoveException);
			OneframeLogger("Clicked on Remove Button in pop up Remove window");
			return true;
		}
		return false;
	}

	@Step("Verify Remove Exception")
	public void verifyRemoveAndAddException() {
		if (FindObjectByLocatorNoWait(By
				.xpath("//td[@class='mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted']")) != null) {
			clickRemoveException();
		} else {
			clickAddExceptionButton();
			clickAddNetwork();
			clickNetworkNameFromAddNetworkList();
			clickAddNetworkButton();
			clickRemoveException();
		}
	}

	@Step("Verify Exception is removed in Network Tab")
	public boolean verifyExceptionIsRemoved() {
		boolean bln = false;
		txtHeaderExcept.click();
		txtHeaderExcept.click();
		txtHeaderExcept.click();
		if (FindObjectByLocatorNoWait(By
				.xpath("//td[@class='mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted']")) != null) {
			bln = true;
		} else {
			bln = false;
		}
		return bln;
	}

	@Step("Edit and Get Program Name in Cost of care")
	public String editAndGetTextProgramName() {
		ObjectExist(programNameField);
		ClickWebObject(programNameField);
		while (!programNameField.getAttribute("value").equalsIgnoreCase("")) {
			programNameField.sendKeys(Keys.BACK_SPACE);
		}
		String name = "TESTAUTO";
		int randomNumber = getRandomNumber();
		String programName = name + randomNumber;
		programNameField.sendKeys(programName);
		OneframeLogger("The Program name is : " + programNameField.getAttribute("value"));
		return programNameField.getAttribute("value");
	}

	@Step("Verify the edited Program name is same")
	public boolean verifyEditedProgramNameIsSame(String programName) {
		boolean bln = false;
		ObjectExist(programNameField);
		highlightElement(programNameField);
		String programNmField = programNameField.getAttribute("value");
		if (programNmField.equalsIgnoreCase(programName)) {
			bln = true;
		}
		return bln;
	}

	@Step("Click on Except text")
	public void clickExceptText() {
		txtExcept.click();
		txtExcept.click();
	}

	@Step("Select General/Accums/Network/Costshares tabs are disabled")
	public boolean verifyTabsDisbaled() {
		List<String> actualTabNames = new ArrayList<String>(Arrays.asList());
		List<String> expectedTabNames = new ArrayList<String>(
				Arrays.asList("General", "Networks", "Cost Shares", "Accum"));
		WaitForObjectVisibility(tabDisbaledValues.get(0));
		for (int i = 0; i < tabDisbaledValues.size(); i++) {
			ClickWebObject(tabDisbaledValues.get(i));
			actualTabNames.add(tabDisbaledValues.get(i).getText());
		}
		return actualTabNames.equals(expectedTabNames);
	}

	@Step("Select General/Accums/Network/Costshares tabs are enabled")
	public boolean verifyTabsEnabled() throws Throwable {
		boolean blnRC = false;
		List<String> expectedTabNames = new ArrayList<String>(
				Arrays.asList("general", "networks", "costSharesPrograms", "accums"));
		int size = tabEnabledValues.size();
		if (size == 5)
			blnRC = true;
		for (int i = 1; i < size; i++) {
			ClickWebObject(oneframeDriver.findElement(By.xpath(String.format(
					"//div[@role='tab' and @aria-disabled='false' and @aria-label and @aria-label=\"%s\"]/div",
					expectedTabNames.get(i - 1)))));
			blnRC = blnRC && true;
		}
		return blnRC;
	}

	@Step("Click Network Tab of Programs")
	public void clickNetworkTab() {
		try {
			if (WaitForObject(tabNetworks)) {
				ClickWebObject(tabNetworks);
				OneframeLogger("Clicked on Networks Tab of Programs");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Network Tab of Programs is not Clicked");
		}
	}

	@Step("Verify All Networks header is displayed")
	public boolean verifyAllNetworksHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAllNetworks)) {
			if (hdrAllNetworks.getText().equalsIgnoreCase("All Networks")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Check the checkbox fo All Networks")
	public void clickAllNetworksCheckbox() {
		try {
			if (WaitForObject(cbkAllNetworks)) {
				ClickWebObject(cbkAllNetworks);
				OneframeLogger("Clicked on All Networks of Include Checkbox");
			} else {
				OneframeLogger("Unable to click on All Networks of Include Checkbox");
			}
		} catch (TimeoutException e) {
			OneframeLogger("All Networks of Checkbox is not Clicked");
		}
	}

	@Step("Verify whether user can able to add the retail values under All Networks section")
	public boolean verifyandEnterRetailValues() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtRetailMaxDaySupply)) {
				String maxDaySupply = Integer.toString(getRandomNumber());
				txtRetailMaxDaySupply.sendKeys(maxDaySupply);
				OneframeLogger("The Entered Max Day supply value is : " + txtRetailMaxDaySupply.getAttribute("value"));
				String refilltosoon = Integer.toString(getRandomNumber());
				txtRetailRefillToSoon.sendKeys(refilltosoon);
				OneframeLogger("The Entered Refill to Soon value is : " + txtRetailRefillToSoon.getAttribute("value"));
				String numberofFiles = Integer.toString(getRandomNumber());
				txtRetailNumberofFiles.sendKeys(numberofFiles);
				OneframeLogger("The Entered Number of Days value is : " + txtRetailNumberofFiles.getAttribute("value"));
				blnRC = true;
			}
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Program Customization header is displayed")
	public boolean verifyProgramCustomizationHeader() {
		boolean flag = false;
		if (ObjectExist(hdrProgramCustomization)) {
			if (hdrProgramCustomization.getText().equalsIgnoreCase("Program Customization")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click on the Locks toggle under Program Customization")
	public boolean verifyLocksToggglesEnabled() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglProgramCustomizationtoggles.get(0))) {
				ClickWebObject(tglProgramCustomizationtoggles.get(5));
				OneframeLogger(
						"The Lock Details,Lock General,Lock Netwroks,Lock Costshares,Lock Accums Toggles are enabled");
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Click on Cost Share tab")
	public void clickCostShareTab() {
		WaitForObjectVisibility(costShareTab);
		costShareTab.click();
		OneframeLogger("Clicked on cost share tab");
	}

	@Step("Click on Custom Stepping toggle")
	public void clickCustomSteppingToggle() {
		WaitForObjectVisibility(costShareTab);
		customSteppingToggle.click();
		OneframeLogger("Clicked on custom Stepping toggle button");
	}

	@Step("Verify Cost Share Tab INN Retail Dropdown values")
	public boolean verifyCostShareTabINNRetailDropdownValue(String dropdownValue) throws InterruptedException {
		boolean blnRC = false;
		ArrayList<String> drdValue = new ArrayList<>(Arrays.asList());
		ArrayList<String> listOne = new ArrayList<>(Arrays.asList());
		drdValue.add(dropdownValue);
		if (WaitForObjectVisibility(drdInnRetail)) {
			drdInnRetail.click();
			for (int i = 0; i < dropdownValues.size(); i++) {
				listOne.add(dropdownValues.get(i).getText());
			}
			if (listOne.size() > 0)
				blnRC = true;
			for (String drdVal : drdValue) {
				if (listOne.contains(drdVal)) {
					blnRC = blnRC & true;
				}
			}
			OneframeLogger("dropdown values provided from TDS: " + drdValue);
			OneframeLogger("dropdown values is same as expected: " + listOne);
			clickOverlayElement();
		}

		return blnRC;
	}

	@Step("Verify Cost Share Tab INN Home Delivery Dropdown values")
	public boolean verifyCostShareTabINNHomeDeliveryDropdownValue(String dropdownValue) throws InterruptedException {
		boolean blnRC = false;
		ArrayList<String> drdValue = new ArrayList<>(Arrays.asList());
		ArrayList<String> listOne = new ArrayList<>(Arrays.asList());
		drdValue.add(dropdownValue);
		if (WaitForObjectVisibility(drdInnHomeDelivery)) {
			drdInnHomeDelivery.click();
			for (int i = 0; i < dropdownValues.size(); i++) {
				listOne.add(dropdownValues.get(i).getText());
			}
			if (listOne.size() > 0)
				blnRC = true;
			for (String drdVal : drdValue) {
				if (listOne.contains(drdVal)) {
					blnRC = blnRC & true;
				}
			}
			OneframeLogger("dropdown values provided from TDS: " + drdValue);
			OneframeLogger("dropdown values is same as expected: " + listOne);
			clickOverlayElement();
		}

		return blnRC;
	}

	@Step("Verify Cost Share Tab ONN retail Dropdown values")
	public boolean verifyCostShareTabONNRetailDropdownValue(String dropdownValue) throws InterruptedException {
		boolean blnRC = false;
		ArrayList<String> drdValue = new ArrayList<>(Arrays.asList());
		ArrayList<String> listOne = new ArrayList<>(Arrays.asList());
		drdValue.add(dropdownValue);
		if (WaitForObjectVisibility(drdONNRetail)) {
			drdONNRetail.click();
			for (int i = 0; i < dropdownValues.size(); i++) {
				listOne.add(dropdownValues.get(i).getText());
			}
			if (listOne.size() > 0)
				blnRC = true;
			for (String drdVal : drdValue) {
				if (listOne.contains(drdVal)) {
					blnRC = blnRC & true;
				}
			}
			OneframeLogger("dropdown values provided from TDS: " + drdValue);
			OneframeLogger("dropdown values is same as expected: " + listOne);
			clickOverlayElement();
		}

		return blnRC;
	}

	@Step("Verify Drug List Field Values are displayed")
	public void verifyDrugListFieldValues() {
		ClickWebObject(txtDrugList);
		for (int i = 0; i < 8; i++) {
			OneframeLogger(lstDruglistFields.get(i).getText() + " : " + lstDruglistValues.get(i).getText());
		}
	}

	@Step("Select Cost Share Structure dropdown")
	public boolean selectCostShareStructureDropdown(String costShareStructure) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdCostShareStructure)) {
				ClickWebObject(drdCostShareStructure);
				selectDropdownValue(costShareStructure);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Cost Share Structure dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Cost Share Tier Structure dropdown")
	public boolean selectCostShareTierStructureDropdown(String costShareTierStructure) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdCostShareTierStructure)) {
				ClickWebObject(drdCostShareTierStructure);
				selectDropdownValue(costShareTierStructure);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Cost Share Tier Structure dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Custom Cost Share dropdown")
	public void selectCustomCostShareDropdown(String customCostShare, String customSteppingCostShare) {
		if (WaitForObjectVisibility(drdCostShareDetails.get(0))) {
			for (int i = 2; i < drdCostShareDetails.size(); i++) {
				if (i < 14) {
					ClickWebObject(drdCostShareDetails.get(i));
					selectDropdownValue(customCostShare);
				} else {
					ClickWebObject(drdCostShareDetails.get(i));
					selectDropdownValue(customSteppingCostShare);
				}
			}
		}
	}

	@Step("Verify Custom Cost Share dropdown")
	public void verifyCustomCostShareDropdown(String customCostShare, String customSteppingCostShare) {
		if (WaitForObjectVisibility(drdCostShareDetails.get(0))) {
			for (int i = 2; i < drdCostShareDetails.size(); i++) {
				if (i < 14) {
					sa.assertEquals(drdCostShareDetails.get(i).getText(), customCostShare,
							"Verified Cost Share Dropdown Details value");

				} else {
					sa.assertEquals(drdCostShareDetails.get(i).getText(), customSteppingCostShare,
							"Verified Cost Share Dropdown Details value");
				}
			}

		}
	}

	@Step("Click on Cost Share Tier Structure header")
	public void clickCostShareTierStructureHeader() {
		WaitForObjectVisibility(txtCostShareTierStructure);
		txtCostShareTierStructure.click();
		txtCostShareTierStructure.click();
		txtCostShareTierStructure.click();
		txtCostShareTierStructure.click();
	}

	@Step("Click View button of Block of Business")
	public void clickViewButtonofBlockofBusiness() {
		try {
			if (WaitForObjectVisibility(btnViewBlockOfBusiness)) {
				ClickWebObject(btnViewBlockOfBusiness);
				OneframeLogger("Clicked on View button of Block of Business");
			}
		} catch (TimeoutException e) {
			OneframeLogger("View button of Block of Business is not Clicked");
		}
	}

	@Step("Verify Block of Business header is displayed")
	public boolean verifyBlockofBusinessHeader() {
		boolean flag = false;
		if (WaitForObjectVisibility(hdrBlockofBusiness)) {
			if (hdrBlockofBusiness.getText().equalsIgnoreCase("Block of Business")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click General Tab in Specialty Program")
	public void clickOnGeneralTab() {
		try {
			if (WaitForObjectVisibility(tabGeneral)) {
				ClickWebObject(tabGeneral);
				OneframeLogger("Clicked on General Tab in Specialty Program");
			}
		} catch (TimeoutException e) {
			OneframeLogger("General Tab in Speciality Program is not Clicked");
		}
	}

	@Step("Verify All Networks Toggle is displayed in Specialty Networks tab")
	public boolean verifyAllNetworksTogggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglSpecialtytoggles.get(0))) {

				OneframeLogger("All Networks Toggle is displayed in Specialty Networks tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify Specific Toggle is dsisplayed in Specialty Networks tab")
	public boolean verifySpecificNetworksTogggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglSpecialtytoggles.get(1))) {

				OneframeLogger("Specific Networks Toggle is displayed in Specialty Networks tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Click on Program Name column Name Header")
	public boolean clickProgramNameColumnHeader() {
		try {
			if (WaitForObjectVisibility(programNameColumnHeader)) {
				ClickWebObject(programNameColumnHeader);
				OneframeLogger("Clicked on Program Name Column Header");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Program Name Column Header");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Verify Ascending sort is applied on the table")
	public boolean verifyAscendingSortIsApplied() {
		try {
			WaitForApplicationToLoadCompletely();
			if (WaitForObjectVisibility(sortCondition)
					&& sortCondition.getAttribute("aria-sort").equalsIgnoreCase("ascending")) {
				OneframeLogger("Table content is sorted in Ascending Order");
				return true;
			} else {
				OneframeLogger("Table content is sorted in Descending Order");
				return false;
			}
		} catch (Exception e) {
			OneframeLogger("Table content is Not Sorted");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Fetch Program Names from the First Page")
	public List<String> getProgramNamesFromPageOne() {
		List<String> actualProgramNames = new ArrayList<String>();
		WaitForApplicationToLoadCompletely();
		ClickWebObject(hdrPrograms);
		ClickWebObject(hdrPrograms);
		ClickWebObject(hdrPrograms);
		try {
			if (programNames.size() > 1) {
				for (WebElement ele : programNames) {
					highlightElement(ele);
					actualProgramNames.add(ele.getText().trim());
					OneframeLogger(ele.getText());
				}
			}
		} catch (Exception e) {
			OneframeLogger("Unable to fetch program names from the page");
			OneframeLogger(e.toString());
		}

		return actualProgramNames;
	}

	@Step("Verify Table data is sorted")
	public boolean verifyElementsAreSorted(List<String> expectedProgramNames, List<String> actualProgramNames) {
		try {
			for (int i = 0; i < actualProgramNames.size(); i++) {
				sa.assertEquals(actualProgramNames.get(i).toLowerCase(), expectedProgramNames.get(i).toLowerCase(),
						"Expected & Actual text matches");
				// OneframeLogger("Actual Program Name: " +actualProgramNames.get(i)+ ",
				// Expected Program Name: " +expectedProgramNames.get(i));
				if (!actualProgramNames.get(i).equalsIgnoreCase(expectedProgramNames.get(i))) {
					return false;
				}
			}
			return true;
		} catch (Exception e) {
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Clicked on Effective Date column header")
	public boolean clickEffectiveDateColumnHeader() {
		try {
			if (WaitForObjectVisibility(effectiveDateColumnHeader)) {
				ClickWebObject(effectiveDateColumnHeader);
				OneframeLogger("Clicked on Effective Date Column Header");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Effective Date Column Header");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Verify Ascending sort is applied on the column Effective Date")
	public boolean verifyAscendingSortIsAppliedOnEffectiveDate() {
		try {
			WaitForApplicationToLoadCompletely();
			if (WaitForObjectVisibility(sortConditionEffectiveDate)
					&& sortConditionEffectiveDate.getAttribute("aria-sort").equalsIgnoreCase("ascending")) {
				OneframeLogger("Table content is sorted in Ascending Order");
				return true;
			} else {
				OneframeLogger("Table content is sorted in Descending Order");
				return false;
			}
		} catch (Exception e) {
			OneframeLogger("Table content is Not Sorted");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Fetch Program Names & Effective Date from the First Page")
	public List<String> getEffectiveDateFromPageOne() {
		List<String> actualProgramNames = new ArrayList<String>();
		WaitForApplicationToLoadCompletely();
		ClickWebObject(hdrPrograms);
		ClickWebObject(hdrPrograms);
		ClickWebObject(hdrPrograms);
		try {
			if (programNames.size() > 1) {
				for (WebElement row : tableRows) {
					highlightElement(row.findElement(By.xpath("./td[5]")));
					String effectiveDate = row.findElement(By.xpath("./td[5]")).getText().trim();
					actualProgramNames.add(effectiveDate);
					OneframeLogger(effectiveDate);
				}
			}
		} catch (Exception e) {
			OneframeLogger("Unable to fetch program names from the page");
			OneframeLogger(e.toString());
		}

		return actualProgramNames;
	}

	@Step("Verify Table data is sorted in Ascending Order")
	public void verifyElementsAreSortedByEffectiveDate(List<String> expectedProgramNames,
			List<String> actualProgramNames) {
		ClickWebObject(hdrPrograms);
		ClickWebObject(hdrPrograms);
		ClickWebObject(hdrPrograms);
		for (int i = 0; i < actualProgramNames.size(); i++) {
			sa.assertEquals(expectedProgramNames.get(i), actualProgramNames.get(i), "Expected & Actual text matches");
			// OneframeLogger("Actual Program Name: " +actualProgramNames.get(i)+ ",
			// Expected Program Name: " +expectedProgramNames.get(i));
		}

	}

	@Step("Verify  Ancillary Charges Apply Based on DAW rules Toggle is displayed in Specialty Program Cost Shares tab")
	public boolean verifyAncillaryTogggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglSpecialtytoggles.get(0))) {

				OneframeLogger("All Networks Toggle is displayed in Specialty Program Cost Shares tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify Custom Stepping Toggle is displayed in Specialty Program Cost Shares tab")
	public boolean verifyCustomSteppingTogggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglSpecialtytoggles.get(1))) {

				OneframeLogger("Custom Stepping Toggle is displayed in Specialty Program Cost Shares tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify Ancillary Charges Apply Based on DAW rules text is displayed")
	public boolean verifyAncillaryChargesTxt() {
		boolean flag = false;
		if (ObjectExist(txtAncillaryCharges)) {
			if (txtAncillaryCharges.getText().equalsIgnoreCase(" Ancillary Charges Apply Based on DAW rules ")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click on Accum tab")
	public void clickAccumTab() {
		WaitForObjectVisibility(accumTab);
		accumTab.click();
		OneframeLogger("Clicked on Accum tab");
	}

	@Step("Verify Apply Program Deductible Toggle is displayed in Specialty Program Accum tab")
	public boolean verifyProgramDedTogggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglSpecialtytoggles.get(0))) {

				OneframeLogger("Apply Program Deductible Toggle is displayed in Specialty Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify Apply Program MoP Toggle is displayed in Specialty Program Accum tab")
	public boolean verifyApplyProgramMopTogggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglSpecialtytoggles.get(1))) {

				OneframeLogger("Apply Program MoP Toggle is displayed in Specialty Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify Apply Program PSL Toggle is displayed in Specialty Program Accum tab")
	public boolean verifyApplyProgramPSLTogggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglSpecialtytoggles.get(2))) {

				OneframeLogger("Apply Program PSL Toggle is displayed in Specialty Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;

	}

	@Step("Verify INN Retail Label is displayed under Apply Program Deductible in Accum tab")
	public boolean verifyApplyPrgmDedINNRetailDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNRetail.get(0))) {
				highlightElement(txtINNRetail.get(0));
				OneframeLogger("INN Retail Label is displayed under Apply Program Deductible in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify INN Retail Label is displayed under Apply Program MoP in Accum tab")
	public boolean verifyApplyPrgmMopINNRetailDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNRetail.get(1))) {
				highlightElement(txtINNRetail.get(1));
				OneframeLogger("INN Retail Label is displayed under Apply Program MoP in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify INN Retail Label is displayed under Apply Program PSL in Accum tab")
	public boolean verifyApplyPrgmPSLINNRetailDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNRetail.get(2))) {
				highlightElement(txtINNRetail.get(2));
				OneframeLogger("INN Retail Label is displayed under Apply Program PSL in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify INN Home Delivery Label is displayed under Apply Program Deductible in Accum tab")
	public boolean verifyApplyPrgmDedINNHomeDeliveryDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNHomeDelivery.get(0))) {
				highlightElement(txtINNRetail.get(0));
				OneframeLogger("INN Home Delivery Label is displayed under Apply Program Deductible in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify INN Home Delivery Label is displayed under Apply Program MoP in Accum tab")
	public boolean verifyApplyPrgmMopINNHomeDeliveryDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNHomeDelivery.get(1))) {
				highlightElement(txtINNRetail.get(1));
				OneframeLogger("INN Home Delivery Label is displayed under Apply Program MoP in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify INN Home Delivery Label is displayed under Apply Program PSL in Accum tab")
	public boolean verifyApplyPrgmPSLINNHomeDeliveryDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNHomeDelivery.get(2))) {
				highlightElement(txtINNRetail.get(2));
				OneframeLogger("INN Home Delivery Label is displayed under Apply Program PSL in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify ONN Retail Label is displayed under Apply Program Deductible in Accum tab")
	public boolean verifyApplyPrgmDedONNRetailDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNRetail.get(0))) {
				highlightElement(txtINNRetail.get(0));
				OneframeLogger("ONN Retail Label is displayed under Apply Program Deductible in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify ONN Retail Label is displayed under Apply Program MoP in Accum tab")
	public boolean verifyApplyPrgmMopONNRetailDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNRetail.get(1))) {
				highlightElement(txtINNRetail.get(1));
				OneframeLogger("ONN Retail Label is displayed under Apply Program MoP in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify ONN Retail Label is displayed under Apply Program PSL in Accum tab")
	public boolean verifyApplyPrgmPSLONNRetailDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNRetail.get(2))) {
				highlightElement(txtINNRetail.get(2));
				OneframeLogger("ONN Retail Label is displayed under Apply Program PSL in Accum tab");

				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Enter Termination date")
	public void EnterTerminationDate(String TermDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtTermDate)) {
				ClickWebObject(txtTermDate);
				EnterText(txtTermDate, TermDate);
				OneframeLogger("Term Date has been Entered : " + txtTermDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Term Date has been Entered");
		}
	}

	@Step("Enter Non Sellable date")
	public void EnterNonSellableDate(String NonSellableDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtNonSellableDate)) {
				ClickWebObject(txtNonSellableDate);
				EnterText(txtNonSellableDate, NonSellableDate);
				OneframeLogger("Non Sellable Date has been Entered : " + txtNonSellableDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Non Sellable Date has been Entered");
		}
	}

	@Step("Select General Override Dropdown")
	public boolean SelectGeneralOverrideDropdown() {
		boolean bln = false;
		if (ObjectExist(generalOverrideDropdown)) {
			generalOverrideDropdown.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Cost Share Override Dropdown")
	public boolean SelectCostShareOverrideDropdown() {
		boolean bln = false;
		if (ObjectExist(drpdwnCostShare)) {
			drpdwnCostShare.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Accums Override Dropdown")
	public boolean SelectAccumsOverrideDropdown() {
		boolean bln = false;
		if (ObjectExist(drpdwnAccums)) {
			drpdwnAccums.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Get Random Number")
	public int getRandomNum() {
		int min = 00002;
		int max = 99999;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Get Random Number")
	public int getRandomNumbers() {
		int min = 0;
		int max = 99;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Edit Priority value in Program Details")
	public String editPriorityField() {
		ObjectExist(enterPriority);
		ClickWebObject(enterPriority);
		while (!enterPriority.getAttribute("value").equalsIgnoreCase("")) {
			enterPriority.sendKeys(Keys.BACK_SPACE);
		}

		int randomNumber = getRandomNumbers();
		String Priority = Integer.toString(randomNumber);
		enterPriority.sendKeys(Priority);
		OneframeLogger("The Priority is : " + enterPriority.getAttribute("value"));
		return enterPriority.getAttribute("value");

	}

	@Step("Edit Program Description in Program Details")
	public String editProgramDescription() {
		ObjectExist(programDescField);
		ClickWebObject(programDescField);
		while (!programDescField.getAttribute("value").equalsIgnoreCase("")) {
			programDescField.sendKeys(Keys.BACK_SPACE);
		}
		String name = "AUTO";
		int randomNumber = getRandomNumbers();
		String PrgmDesc = name + randomNumber;
		programDescField.sendKeys(PrgmDesc);
		OneframeLogger("The Program Description is : " + programDescField.getAttribute("value"));
		return programDescField.getAttribute("value");

	}

	@Step("Edit Details field in Program Details")
	public String editDetailsinProgramDetails() {
		ObjectExist(detailsField);
		ClickWebObject(detailsField);
		while (!detailsField.getAttribute("value").equalsIgnoreCase("")) {
			detailsField.sendKeys(Keys.BACK_SPACE);
		}
		String name = "AUTO";
		int randomNumber = getRandomNumbers();
		String PrgmDesc = name + randomNumber;
		detailsField.sendKeys(PrgmDesc);
		OneframeLogger("The Details value is : " + detailsField.getAttribute("value"));
		return detailsField.getAttribute("value");

	}

	@Step("Verify Category select dropdown is disabled")
	public boolean verifyCategoryDropdownIsDisabled() {
		boolean bln = false;
		if (ObjectExist(drpdownCategory)) {
			drpdownCategory.click();
			if (drpdownCategory.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
				OneframeLogger("Category select dropdown is disabled");
				bln = true;
			} else {
				OneframeLogger("Category select dropdown is enabled");

			}
		}
		return bln;
	}

	@Step("Verify Subcategory select dropdown is disabled")
	public boolean verifySubCategoryDropdownIsDisabled() {
		boolean bln = false;
		if (ObjectExist(drpdownSubCategory)) {
			drpdownSubCategory.click();
			if (drpdownSubCategory.getAttribute("aria-disabled").equalsIgnoreCase("true")) {
				OneframeLogger("Subcategory select dropdown is disabled");
				bln = true;
			} else {
				OneframeLogger("Subcategory select dropdown is enabled");

			}
		}
		return bln;
	}

	@Step("Edit Program Name in Program Details")
	public String editProgramName() {
		ObjectExist(programNameField);
		ClickWebObject(programNameField);
		while (!programNameField.getAttribute("value").equalsIgnoreCase("")) {
			programNameField.sendKeys(Keys.BACK_SPACE);
		}
		String name = "AUTO";
		int randomNumber = getRandomNumbers();
		String PrgmDesc = name + randomNumber;
		programNameField.sendKeys(PrgmDesc);
		OneframeLogger("The Program Name is : " + programNameField.getAttribute("value"));
		return programNameField.getAttribute("value");

	}

	@Step("Click on Cancel button")
	public void clickCostofcareCancelButton() {
		btnCostofcareCancel.click();
		OneframeLogger("Clicked on Cancel button");
	}

	@Step("Enter Retail high Dollar Amount in Program Details")
	public String enterRetailhighDollar() {
		ObjectExist(txtEnterRetailhighDollar);
		ClickWebObject(txtEnterRetailhighDollar);

		int randomNumber = getRandomNumbers();
		String RetailHigh = Integer.toString(randomNumber);
		txtEnterRetailhighDollar.sendKeys(RetailHigh);
		OneframeLogger("The Retail High Dollar Amount is : " + txtEnterRetailhighDollar.getAttribute("value"));
		return txtEnterRetailhighDollar.getAttribute("value");

	}

	@Step("Enter Mail High Dollar Amount in Program Details")
	public String enterMailhighDollar() {
		ObjectExist(txtEnterMailHighDollar);
		ClickWebObject(txtEnterMailHighDollar);

		int randomNumber = getRandomNumbers();
		String MailHigh = Integer.toString(randomNumber);
		txtEnterMailHighDollar.sendKeys(MailHigh);
		OneframeLogger("The Retail High Dollar Amount is : " + txtEnterMailHighDollar.getAttribute("value"));
		return txtEnterMailHighDollar.getAttribute("value");

	}

	@Step("Select Channel Name Dropdown")
	public boolean selectChannelNameDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnChannel)) {
			drpDwnChannel.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Enter Quantity Limit in Program Details")
	public String enterQuantityLimit() {
		ObjectExist(txtEnterQuantityLimit);
		ClickWebObject(txtEnterQuantityLimit);

		int randomNumber = getRandomNumbers();
		String QuantityLmt = Integer.toString(randomNumber);
		txtEnterQuantityLimit.sendKeys(QuantityLmt);
		OneframeLogger("The Quantity Limit is : " + txtEnterQuantityLimit.getAttribute("value"));
		return txtEnterQuantityLimit.getAttribute("value");

	}

	@Step("Select Quantity Limitation Time Period Dropdown")
	public boolean selectQuantityLimitatonDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnQuantityPeriod)) {
			drpDwnQuantityPeriod.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Enter Days Supply in Program Details")
	public String enterDaysSupply() {
		ObjectExist(txtEnterdaySupply);
		ClickWebObject(txtEnterdaySupply);

		int randomNumber = getRandomNumbers();
		String MailHigh = Integer.toString(randomNumber);
		txtEnterdaySupply.sendKeys(MailHigh);
		OneframeLogger("Days Supply is : " + txtEnterdaySupply.getAttribute("value"));
		return txtEnterdaySupply.getAttribute("value");

	}

	@Step("Enter Initial Fill Days Supply in Program Details")
	public String enterInitialFillDaysSupply() {
		ObjectExist(txtEnterInititalDaysSupply);
		ClickWebObject(txtEnterInititalDaysSupply);

		int randomNumber = getRandomNumbers();
		String InitialFill = Integer.toString(randomNumber);
		txtEnterInititalDaysSupply.sendKeys(InitialFill);
		OneframeLogger("Days Supply is : " + txtEnterInititalDaysSupply.getAttribute("value"));
		return txtEnterInititalDaysSupply.getAttribute("value");

	}

	@Step("Enter LooKback Days Supply in Program Details")
	public String enterLookBackDays() {
		ObjectExist(txtEnterlookbackDays);
		ClickWebObject(txtEnterlookbackDays);

		int randomNumber = getRandomNumbers();
		String Lookback = Integer.toString(randomNumber);
		txtEnterlookbackDays.sendKeys(Lookback);
		OneframeLogger("Look BackDays Supply is : " + txtEnterlookbackDays.getAttribute("value"));
		return txtEnterlookbackDays.getAttribute("value");

	}

	@Step("Enter Max Fill Days Supply in Program Details")
	public String enterMaxFillDaysSupply() {
		ObjectExist(txtEntermaxFillDaysSupply);
		ClickWebObject(txtEntermaxFillDaysSupply);

		int randomNumber = getRandomNumbers();
		String MaxFill = Integer.toString(randomNumber);
		txtEntermaxFillDaysSupply.sendKeys(MaxFill);
		OneframeLogger("Days Supply is : " + txtEntermaxFillDaysSupply.getAttribute("value"));
		return txtEntermaxFillDaysSupply.getAttribute("value");

	}

	@Step("Enter Lower Age Restriction in Program Details")
	public String enterLowerAge() {
		ObjectExist(txtEnterlowerAgeLimit);
		ClickWebObject(txtEnterlowerAgeLimit);

		int randomNumber = getRandomNumbers();
		String LowerAge = Integer.toString(randomNumber);
		txtEnterlowerAgeLimit.sendKeys(LowerAge);
		OneframeLogger("Lower Age Restriction is : " + txtEnterlowerAgeLimit.getAttribute("value"));
		return txtEnterlowerAgeLimit.getAttribute("value");

	}

	@Step("Enter Upper Age Restriction in Program Details")
	public String enterUpperAge() {
		ObjectExist(txtEnterupperAgeLimit);
		ClickWebObject(txtEnterupperAgeLimit);

		int randomNumber = getRandomNumbers();
		String UpperAge = Integer.toString(randomNumber);
		txtEnterupperAgeLimit.sendKeys(UpperAge);
		OneframeLogger("Upper Age Restriction is : " + txtEnterupperAgeLimit.getAttribute("value"));
		return txtEnterupperAgeLimit.getAttribute("value");

	}

	@Step("Select Under Age Dropdown Restriction Dropdown")
	public boolean selectUnderAgeDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnUnderAgeRestriction)) {
			drpDwnUnderAgeRestriction.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Over Age Dropdown Restriction Dropdown")
	public boolean selectOverAgeDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnOverAgeRestriction)) {
			drpDwnOverAgeRestriction.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Between Age Dropdown Restriction Dropdown")
	public boolean selectBetweenAgeDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnBetweenAgeRestriction)) {
			drpDwnBetweenAgeRestriction.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Between Age Dropdown Restriction Dropdown")
	public boolean selectRetailDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelect.get(0))) {
			drpDwnSelect.get(0).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Check the checkbox fo All Networks")
	public void clickAllNetworksCheckboxHome() {
		try {
			if (WaitForObject(cbkAllNetworks2)) {
				ClickWebObject(cbkAllNetworks2);
				OneframeLogger("Clicked on All Networks of Include Checkbox");
			} else {
				OneframeLogger("Unable to click on All Networks of Include Checkbox");
			}
		} catch (TimeoutException e) {
			OneframeLogger("All Networks of Checkbox is not Clicked");
		}
	}

	@Step("Verify whether user can able to add the retail values under All Networks section")
	public boolean verifyandEnterHomeValues() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtHomeMaxDaySupply)) {
				String maxDaySupply = Integer.toString(getRandomNumber());
				txtHomeMaxDaySupply.sendKeys(maxDaySupply);
				OneframeLogger("The Entered Max Day supply value is : " + txtHomeMaxDaySupply.getAttribute("value"));
				String refilltosoon = Integer.toString(getRandomNumber());
				txtHomeRefillToSoon.sendKeys(refilltosoon);
				OneframeLogger("The Entered Refill to Soon value is : " + txtHomeRefillToSoon.getAttribute("value"));
				String numberofFiles = Integer.toString(getRandomNumber());
				txtHomeNumberofFiles.sendKeys(numberofFiles);
				OneframeLogger("The Entered Number of Days value is : " + txtHomeNumberofFiles.getAttribute("value"));
				blnRC = true;
			}
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Specific Networks Toggle")
	public void clickonSpecificNetworkTgl() {

		try {
			if (WaitForObject(tglSpecialtytoggles.get(0))) {
				ClickWebObject(tglSpecialtytoggles.get(0));
				OneframeLogger("Clicked on Specific Networks Toggle");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Specific Networks Toggle is not Clicked");
		}
	}

	@Step("Select Between Age Dropdown Restriction Dropdown")
	public boolean selectHomeDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelect.get(1))) {
			drpDwnSelect.get(1).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Click on Add Specific Networks Button")
	public void clickonAddSpecificNetworkbtn() {

		try {
			if (WaitForObject(btnAddSpecificNetwork)) {
				ClickWebObject(btnAddSpecificNetwork);
				OneframeLogger("Clicked on Add Specific Networks Button");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Specific Networks Button is not Clicked");
		}
	}

	@Step("Click on first Network Details under Add Network button")
	public boolean click1stSpecificNetworklst() {
		ClickWebObject(hdrAddNetwork);
		ClickWebObject(hdrAddNetwork);
		ClickWebObject(hdrAddNetwork);
		if (WaitForObject(lstDrugDetails.get(0))) {
			ClickWebObject(lstDrugDetails.get(0));
			OneframeLogger("Clicked first Network Details under Add Network button");
			return true;
		}
		return false;

	}

	@Step("Click on Add Network button")
	public void clickAddSpecificNetworkButton() {
		WaitForObject(btnSpecificAddNetwork);
		// ScrollToElement(hdrAddNetwork);
		ClickWebObject(btnSpecificAddNetwork);
		OneframeLogger("Clicked on Add Network button");
	}

	@Step("Click on Remove Network option")
	public boolean clickRemoveNetwork() {
		if (WaitForObject(btnRemoveDrug)) {
			ClickWebObject(btnRemoveDrug);
			OneframeLogger("Clicked on Remove Network option");
			return true;
		}
		return false;

	}

	@Step("Click on Remove Button in pop up window")
	public boolean clickonRemoveButton() {

		if (WaitForObject(btnRemoveNetwork)) {
			ClickWebObject(btnRemoveNetwork);
			OneframeLogger("Clicked on Remove Button in pop up window");
			return true;
		}
		return false;

	}

	@Step("Verify Termination Date is edited in Drug Exception")
	public void EditTermDate(String TermDate) {
		ObjectExist(txtTermDate);
		ClickWebObject(txtTermDate);
		while (!txtTermDate.getAttribute("value").equalsIgnoreCase("")) {
			txtTermDate.sendKeys(Keys.BACK_SPACE);
		}
		try {
			if (ObjectExist(txtTermDate)) {
				txtTermDate.sendKeys(Keys.CONTROL + "a");
				txtTermDate.sendKeys(Keys.DELETE);
				txtTermDate.sendKeys(TermDate);
				OneframeLogger("Termination Date is updated and the value is " + TermDate);
			} else {
				OneframeLogger("Termination Date is not updated");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Verify Non Sellable Date is edited in Drug Exception")
	public void EditNonSellableDate(String NonSellableDate) {
		ObjectExist(txtNonSellableDate);
		ClickWebObject(txtNonSellableDate);
		while (!txtNonSellableDate.getAttribute("value").equalsIgnoreCase("")) {
			txtNonSellableDate.sendKeys(Keys.BACK_SPACE);
		}
		try {
			if (ObjectExist(txtNonSellableDate)) {
				txtNonSellableDate.sendKeys(Keys.CONTROL + "a");
				txtNonSellableDate.sendKeys(Keys.DELETE);
				txtNonSellableDate.sendKeys(NonSellableDate);
				OneframeLogger("Non Sellable Date is updated and the value is " + NonSellableDate);
			} else {
				OneframeLogger("Non Sellable Date is not updated");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Select Program Accum Dropdown")
	public boolean selectProgramAccumDropdown() {
		boolean bln = false;
		if (WaitForObjectVisibility(drpDwnProgramAccum)) {
			drpDwnProgramAccum.click();
			dropdownValues.get(0).click();
			drpDwnProgramAccum.sendKeys(Keys.ESCAPE);
			bln = true;
		}
		return bln;
	}

	@Step("Click on Apply Program Deductible Toggle")
	public void clickonApplyPrmgmDedToggle() {
		tglProgramCustomizationtoggles.get(0).click();
		OneframeLogger("Apply Program Deductible toggle is clicked");
	}

	@Step("Click on Apply Program MoP Toggle")
	public void clickonApplyPrmgmMoPToggle() {
		tglProgramCustomizationtoggles.get(1).click();
		OneframeLogger("Apply Program MoP toggle is clicked");
	}

	@Step("Click on Apply Program PSL Toggle")
	public void clickonApplyPrmgmPSLToggle() {
		tglProgramCustomizationtoggles.get(2).click();
		OneframeLogger("Apply Program MoP toggle is clicked");
	}

	@Step("Enter INN Retail Deductible value")
	public String enterINNRetailDed() {
		ObjectExist(enterAccumValue.get(0));
		ClickWebObject(enterAccumValue.get(0));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(0).sendKeys(Accum);
		OneframeLogger("INN Retail Deductible value is : " + enterAccumValue.get(0).getAttribute("value"));
		return enterAccumValue.get(0).getAttribute("value");

	}

	@Step("Enter INN Home Delivery Deductible value")
	public String enterHomeDlvryDed() {
		ObjectExist(enterAccumValue.get(1));
		ClickWebObject(enterAccumValue.get(1));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(1).sendKeys(Accum);
		OneframeLogger("INN Home Delivery Deductible value is : " + enterAccumValue.get(1).getAttribute("value"));
		return enterAccumValue.get(1).getAttribute("value");

	}

	@Step("Enter ONN Retail Deductible value")
	public String enterONNRetailDed() {
		ObjectExist(enterAccumValue.get(2));
		ClickWebObject(enterAccumValue.get(2));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(2).sendKeys(Accum);
		OneframeLogger("ONN Retail Deductible value is : " + enterAccumValue.get(2).getAttribute("value"));
		return enterAccumValue.get(2).getAttribute("value");

	}

	@Step("Enter INN Retail Family Deductible value")
	public String enterINNRetailDedFamily() {
		ObjectExist(enterAccumValue.get(3));
		ClickWebObject(enterAccumValue.get(3));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(3).sendKeys(Accum);
		OneframeLogger("INN Retail Family Deductible value is : " + enterAccumValue.get(3).getAttribute("value"));
		return enterAccumValue.get(3).getAttribute("value");

	}

	@Step("Enter INN Home Delivery Family Deductible value")
	public String enterHomeDlvryDedFamily() {
		ObjectExist(enterAccumValue.get(4));
		ClickWebObject(enterAccumValue.get(4));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(4).sendKeys(Accum);
		OneframeLogger(
				"INN Home Delivery Family Deductible value is : " + enterAccumValue.get(4).getAttribute("value"));
		return enterAccumValue.get(4).getAttribute("value");

	}

	@Step("Enter ONN Retail Family Deductible value")
	public String enterONNRetailDedFamily() {
		ObjectExist(enterAccumValue.get(5));
		ClickWebObject(enterAccumValue.get(5));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(5).sendKeys(Accum);
		OneframeLogger("ONN Retail Family Deductible value is : " + enterAccumValue.get(5).getAttribute("value"));
		return enterAccumValue.get(5).getAttribute("value");

	}

	@Step("Enter INN Retail MoP value")
	public String enterINNRetailMoP() {
		ObjectExist(enterAccumValue.get(6));
		ClickWebObject(enterAccumValue.get(6));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(6).sendKeys(Accum);
		OneframeLogger("INN Retail MoP value is : " + enterAccumValue.get(6).getAttribute("value"));
		return enterAccumValue.get(6).getAttribute("value");

	}

	@Step("Enter INN Home Delivery MoP value")
	public String enterHomeDlvryMoP() {
		ObjectExist(enterAccumValue.get(7));
		ClickWebObject(enterAccumValue.get(7));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(7).sendKeys(Accum);
		OneframeLogger("INN Home Delivery Deductible value is : " + enterAccumValue.get(7).getAttribute("value"));
		return enterAccumValue.get(7).getAttribute("value");

	}

	@Step("Enter ONN Retail MoP value")
	public String enterONNRetailMoP() {
		ObjectExist(enterAccumValue.get(8));
		ClickWebObject(enterAccumValue.get(8));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(8).sendKeys(Accum);
		OneframeLogger("ONN Retail Deductible value is : " + enterAccumValue.get(8).getAttribute("value"));
		return enterAccumValue.get(8).getAttribute("value");

	}

	@Step("Enter INN Retail Family Deductible value")
	public String enterINNRetailMoPFamily() {
		ObjectExist(enterAccumValue.get(9));
		ClickWebObject(enterAccumValue.get(9));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(9).sendKeys(Accum);
		OneframeLogger("INN Retail Family Deductible value is : " + enterAccumValue.get(9).getAttribute("value"));
		return enterAccumValue.get(9).getAttribute("value");

	}

	@Step("Enter INN Home Delivery Family Deductible value")
	public String enterHomeDlvryMoPFamily() {
		ObjectExist(enterAccumValue.get(10));
		ClickWebObject(enterAccumValue.get(10));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(10).sendKeys(Accum);
		OneframeLogger(
				"INN Home Delivery Family Deductible value is : " + enterAccumValue.get(10).getAttribute("value"));
		return enterAccumValue.get(10).getAttribute("value");

	}

	@Step("Enter ONN Retail Family Deductible value")
	public String enterONNRetailMoPFamily() {
		ObjectExist(enterAccumValue.get(11));
		ClickWebObject(enterAccumValue.get(11));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(11).sendKeys(Accum);
		OneframeLogger("ONN Retail Family Deductible value is : " + enterAccumValue.get(11).getAttribute("value"));
		return enterAccumValue.get(11).getAttribute("value");

	}

	@Step("Enter INN Retail MoP value")
	public String enterINNRetailPSL() {
		ObjectExist(enterAccumValue.get(12));
		ClickWebObject(enterAccumValue.get(12));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(12).sendKeys(Accum);
		OneframeLogger("INN Retail MoP value is : " + enterAccumValue.get(12).getAttribute("value"));
		return enterAccumValue.get(12).getAttribute("value");

	}

	@Step("Enter INN Home Delivery MoP value")
	public String enterHomeDlvryPSL() {
		ObjectExist(enterAccumValue.get(13));
		ClickWebObject(enterAccumValue.get(13));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(13).sendKeys(Accum);
		OneframeLogger("INN Home Delivery Deductible value is : " + enterAccumValue.get(13).getAttribute("value"));
		return enterAccumValue.get(13).getAttribute("value");

	}

	@Step("Enter ONN Retail MoP value")
	public String enterONNRetailPSL() {
		ObjectExist(enterAccumValue.get(14));
		ClickWebObject(enterAccumValue.get(14));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(14).sendKeys(Accum);
		OneframeLogger("ONN Retail Deductible value is : " + enterAccumValue.get(14).getAttribute("value"));
		return enterAccumValue.get(14).getAttribute("value");

	}

	@Step("Enter INN Retail Family Deductible value")
	public String enterINNRetailPSLFamily() {
		ObjectExist(enterAccumValue.get(15));
		ClickWebObject(enterAccumValue.get(15));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(15).sendKeys(Accum);
		OneframeLogger("INN Retail Family Deductible value is : " + enterAccumValue.get(15).getAttribute("value"));
		return enterAccumValue.get(15).getAttribute("value");

	}

	@Step("Enter INN Home Delivery Family Deductible value")
	public String enterHomeDlvryPSLFamily() {
		ObjectExist(enterAccumValue.get(16));
		ClickWebObject(enterAccumValue.get(16));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(16).sendKeys(Accum);
		OneframeLogger(
				"INN Home Delivery Family Deductible value is : " + enterAccumValue.get(16).getAttribute("value"));
		return enterAccumValue.get(16).getAttribute("value");

	}

	@Step("Enter ONN Retail Family Deductible value")
	public String enterONNRetailPSLFamily() {
		ObjectExist(enterAccumValue.get(17));
		ClickWebObject(enterAccumValue.get(17));

		int randomNumber = getRandomNumbers();
		String Accum = Integer.toString(randomNumber);
		enterAccumValue.get(17).sendKeys(Accum);
		OneframeLogger("ONN Retail Family Deductible value is : " + enterAccumValue.get(17).getAttribute("value"));
		return enterAccumValue.get(17).getAttribute("value");

	}

	@Step("Select INN Retail Deductible Accumulate plan level dropdown")
	public boolean selectINNDedDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(0))) {
			drpDwnSelectEnabled.get(0).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Home delivery Deductible Accumulate plan level dropdown")
	public boolean selectINNHomeDedDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(1))) {
			drpDwnSelectEnabled.get(1).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select ONN Retail Deductible Accumulate plan level dropdown")
	public boolean selectONNRetailDedDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(2))) {
			drpDwnSelectEnabled.get(2).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Retail  Deductible Integrated Medical dropdown")
	public boolean selectINNMedDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(3))) {
			drpDwnSelectEnabled.get(3).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Home delivery Deductible Integrated Medical dropdown")
	public boolean selectINNHomeMedDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(4))) {
			drpDwnSelectEnabled.get(4).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select ONN Retail Deductible Integrated Medical dropdown")
	public boolean selectONNRetailMedDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(5))) {
			drpDwnSelectEnabled.get(5).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Retail Deductible Accumulate plan level dropdown under Apply Program MoP")
	public boolean selectINNDedMoPDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(6))) {
			drpDwnSelectEnabled.get(6).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Home delivery Deductible Accumulate plan level dropdown under Apply Program MoP")
	public boolean selectINNHomeDedMoPDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(7))) {
			drpDwnSelectEnabled.get(7).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select ONN Retail Deductible Accumulate plan level dropdown under Apply Program MoP")
	public boolean selectONNRetailDedMoPDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(8))) {
			drpDwnSelectEnabled.get(8).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Retail  Deductible Integrated Medical dropdown under Apply Program MoP")
	public boolean selectINNMedMoPDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(9))) {
			drpDwnSelectEnabled.get(9).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Home delivery Deductible Integrated Medical dropdown under Apply Program MoP")
	public boolean selectINNHomeMedMoPDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(10))) {
			drpDwnSelectEnabled.get(10).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select ONN Retail Deductible Integrated Medical dropdown under Apply Program MoP")
	public boolean selectONNRetailMedMoPDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(11))) {
			drpDwnSelectEnabled.get(11).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Retail Deductible Accumulate plan level dropdown under Apply Program PSL")
	public boolean selectINNDedPSLDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(12))) {
			drpDwnSelectEnabled.get(12).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Home delivery Deductible Accumulate plan level dropdown under Apply Program PSL")
	public boolean selectINNHomeDedPSLDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(13))) {
			drpDwnSelectEnabled.get(13).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select ONN Retail Deductible Accumulate plan level dropdown under Apply Program PSL")
	public boolean selectONNRetailDedPSLDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(14))) {
			drpDwnSelectEnabled.get(14).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Retail  Deductible Integrated Medical dropdown under Apply Program PSL")
	public boolean selectINNMedPSLDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(15))) {
			drpDwnSelectEnabled.get(15).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select INN Home delivery Deductible Integrated Medical dropdown under Apply Program PSL")
	public boolean selectINNHomeMedPSLDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(16))) {
			drpDwnSelectEnabled.get(16).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select ONN Retail Deductible Integrated Medical dropdown under Apply Program PSL")
	public boolean selectONNRetailMedPSLDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectEnabled.get(17))) {
			drpDwnSelectEnabled.get(17).click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Deductible Buckets dropdown")
	public boolean selectDedBucketsDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnAccumulateType1)) {
			drpDwnAccumulateType1.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select MoP Buckets dropdown")
	public boolean selectMoPBucketsDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnAccumulateType2)) {
			drpDwnAccumulateType2.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select PSL Buckets dropdown")
	public boolean selectPSLBucketsDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnAccumulateType3)) {
			drpDwnAccumulateType3.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Cost Share Applies Post MoP met dropdown")
	public boolean selectCostShareMoPDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectOption1)) {
			drpDwnSelectOption1.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Cost Share Applies Post PSL met dropdown")
	public boolean selectCostSharePSLDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnSelectOption2)) {
			drpDwnSelectOption2.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Select Benefit Period dropdown")
	public boolean selectBenefitPeriodDropdown() {
		boolean bln = false;
		if (ObjectExist(drpDwnBenefitPeriod)) {
			drpDwnBenefitPeriod.click();
			dropdownValues.get(0).click();
			bln = true;
		}
		return bln;
	}

	@Step("Click on Apply Medical text")
	public void clickApplyMedicaltxt() {
		WaitForObjectVisibility(txtApplyMedical.get(0));
		try {
			txtApplyMedical.get(0).click();
			txtApplyMedical.get(0).click();
		} catch (Exception e) {

		}
		OneframeLogger("Clicked on Apply Medical text");
	}

	@Step("Values in Column {columnName} {when}")
	public List<String> getValuesFromColumn(String columnName, String when) throws InterruptedException {
		List<String> actualValues = new ArrayList<String>();
		WaitForApplicationToLoadCompletely();
		Thread.sleep(3000);
		int columnIndex = getIndexOfColumn(columnName);
		try {

			if (programNames.size() > 1 && columnIndex != -1) {
				for (WebElement row : tableRows) {
					highlightElement(row.findElement(By.xpath("./td[" + columnIndex + "]")));
					String effectiveDate = row.findElement(By.xpath("./td[" + columnIndex + "]")).getText().trim();
					if (columnName.equalsIgnoreCase("time filling")) {
						actualValues.add(effectiveDate.split(" ")[0].trim());
					} else if (columnName.contains("PAPER CLAIMS")) {
						actualValues.add(effectiveDate.replace(" ", "_"));
					} else {
						actualValues.add(effectiveDate);
					}
					OneframeLogger(effectiveDate);
				}
			}

		} catch (Exception e) {
			OneframeLogger("Unable to fetch program names from the page");
			OneframeLogger(e.toString());
		}

		return actualValues;
	}

	public int getIndexOfColumn(String columnName) {
		int columnIndex = -1;
		List<WebElement> columnList = oneframeDriver.findElements(By.xpath("//thead/tr/th"));

		for (int i = 0; i < columnList.size(); i++) {
			if (columnName.equalsIgnoreCase(columnList.get(i).getText().trim())) {
				return i + 1;
			}
		}

		return columnIndex;
	}

	@Step("Click on {columnName} column Name Header")
	public boolean clickColumnHeader(String columnName) {
		try {
			String xpath = String.format("//button[normalize-space()='%s']", columnName.toUpperCase());
			WebElement ele = oneframeDriver.findElement(By.xpath(xpath));

			ClickWebObject(ele);
			OneframeLogger("Clicked on " + columnName + " Column Header");
			return true;
		} catch (Exception e) {
			OneframeLogger("Unable to click on Program Name Column Header");
			OneframeLogger(e.toString());
		}
		return false;
	}
	
	@Step("Verify Programs is created")
	public boolean VerifyProgramsNameIsCreated(String mandateName) throws InterruptedException {
		boolean bln = false;
		try {
			clickProgramsheader();
			clickProgramsheader();
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split(" ");
			// String[] totalRecordCnt = recordCnt[4].split("of");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());
			int recordsPresentPerPage = Integer.parseInt(recordCnt[2].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < programList.size(); i++) {
					if (programList.get(i).getText().equalsIgnoreCase(mandateName)) {
						highlightElement(programList.get(i));
						OneframeLogger("Mandate is created : " + programList.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
//					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
					// clickMandatesHeader();
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split(" ");
				// totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(recordCnt[4].trim());
				recordsPresentPerPage = Integer.parseInt(recordCnt[2].trim());
			}
		} catch (StaleElementReferenceException exc) {

		}
		return bln;
	}
	
	@Step("Click Add a Specialty Program")
	public boolean clickAddaSpecialtyProgram() {
		try {
			if (WaitForObject(btnAddSpecialityProgram)) {
				ClickWebObject(btnAddSpecialityProgram);
				OneframeLogger("Clicked on Add a Specialty Program");
				return true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add a Specialty Program is not Clicked: " +e);
		}
		return false;
	}
	
	@Step("Verify Added message when Specialty program  is created")
	public boolean verifySpecialtyCreatedMessage() {
		boolean bln = false;
		if (ObjectExist(txtCreatedSpecialtyPrgm)) {
			highlightElement(txtCreatedSpecialtyPrgm);
			txtCreatedSpecialtyPrgm.isDisplayed();
			OneframeLogger(" Added Message is " + txtCreatedSpecialtyPrgm.getText());
			bln = true;
		}
		return bln;
	}
	

}

package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeConstants;
import anthem.irx.oneframe.core.OneframeContainer;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import java.util.ArrayList;
import java.util.List;
import org.testng.Assert;

public class ExcelDB extends OneframeConstants {
  private static Fillo fillo;
  
  private static Connection connection;
  
  public static Connection getExcelDBConnectionObject(String TDSFile) throws FilloException {
    OneframeContainer.OneframeLogger("[ONEFRAME]Excel DB | Fillo establishing connection Excel TDS File [ " + TDSFile + " ] ");
    fillo = new Fillo();
    connection = fillo.getConnection(TDSFile);
    return connection;
  }
  
  public static String[] getScriptConfigsFromTDS(String TDSFile, String sheetName, String ScenarioID) throws FilloException {
    OneframeContainer.OneframeLogger("[ONEFRAME]Reading script configurations from TDS File [ " + TDSFile + " ] Sheet : " + sheetName + " for scenario ID - " + ScenarioID);
    List<String> ScriptConfigs = new ArrayList<>();
    connection = getExcelDBConnectionObject(TDSFile);
    String strSelectQuerry = "select * from " + sheetName + " where TestScenarioID = '" + ScenarioID + "'";
    Recordset rs = connection.executeQuery(strSelectQuerry);
    int count = rs.getCount();
    OneframeContainer.OneframeLogger("[ONEFRAME]" + strSelectQuerry);
    OneframeContainer.OneframeLogger("[ONEFRAME]Test Cases/Data Count : " + count);
    Assert.assertEquals(count, 1);
    ScriptConfigs = rs.getFieldNames();
    OneframeContainer.OneframeLogger("[ONEFRAME]TDS Columns : " + ScriptConfigs);
    String[] data = new String[ScriptConfigs.size()];
    OneframeContainer.OneframeLogger(data.length);
    int j = 0;
    rs.moveFirst();
    for (String testColumn : ScriptConfigs) {
      data[j] = rs.getField(testColumn);
      j++;
    } 
    rs.close();
    connection.close();
    return data;
  }
  
  public static void CloseExcelDBConnection() {
    connection.close();
  }
  
  public static String[][] getDatafromExcel(String TDSFile, String sheetName, String TestCaseID, List<String> testData) throws FilloException {
    int count = 0;
    connection = getExcelDBConnectionObject(TDSFile);
    OneframeContainer.OneframeLogger("[ONEFRAME]" + TDSFile);
    String strSelectQuerry = "select * from " + sheetName + " where " + "TestCaseID" + " LIKE '" + TestCaseID + "_%' AND RunFlag = '" + "Yes" + "'";
    OneframeContainer.OneframeLogger("[ONEFRAME]" + strSelectQuerry);
    Recordset rs = connection.executeQuery(strSelectQuerry);
    count = rs.getCount();
    OneframeContainer.OneframeLogger("[ONEFRAME]Record Count " + count);
    String[][] data = new String[count][testData.size()];
    int i = 0;
    while (rs.next()) {
      int j = 0;
      for (String testColumn : testData) {
        data[i][j] = rs.getField(testColumn);
        OneframeContainer.OneframeLogger("[ONEFRAME]" + data[i][j]);
        j++;
      } 
      i++;
    } 
    rs.close();
    connection.close();
    return data;
  }
  
  public static boolean UpdateTestResultToExcel(String TDSFile, String TDSSheet, String TestCaseID, String TestCaseStatus) {
    try {
      connection = getExcelDBConnectionObject(TDSFile);
    } catch (FilloException E) {
      OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
    } 
    String strUpdateQuery = "Update " + TDSSheet + " Set TestStatus = '" + TestCaseStatus + "' where TestCaseID = '" + TestCaseID + "'";
    OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQuery);
    try {
      connection.executeUpdate(strUpdateQuery);
    } catch (FilloException E) {
      OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
    } 
    return true;
  }
  
  public static boolean UpdateTestDataToExcel(String TDSFile, String TDSSheet, String TestCaseID, String TestCaseStatus) {
    try {
      connection = getExcelDBConnectionObject(TDSFile);
    } catch (FilloException E) {
      OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
    } 
    String strUpdateQuery = "Update " + TDSSheet + " Set TestStatus = '" + TestCaseStatus + "' where TestCaseID = '" + TestCaseID + "'";
    OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQuery);
    try {
      connection.executeUpdate(strUpdateQuery);
    } catch (FilloException E) {
      OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
    } 
    return true;
  }
  
  public static boolean UpdateMobileTestResultToExcel(String TDSFile, String TDSSheet, String TestCaseID, String TestCaseStatus, String ReportiumURL) {
    try {
      connection = getExcelDBConnectionObject(TDSFile);
    } catch (FilloException E) {
      OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
    } 
    String strUpdateQuery = "Update " + TDSSheet + " Set TestStatus = '" + TestCaseStatus + "' where TestCaseID = '" + TestCaseID + "'";
    OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQuery);
    String strUpdateQueryReport = "Update " + TDSSheet + " Set ReportiumURL = '" + ReportiumURL + "' where TestCaseID = '" + TestCaseID + "'";
    OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQueryReport);
    try {
      connection.executeUpdate(strUpdateQuery);
      connection.executeUpdate(strUpdateQueryReport);
    } catch (FilloException E) {
      OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
    } 
    return true;
  }
}

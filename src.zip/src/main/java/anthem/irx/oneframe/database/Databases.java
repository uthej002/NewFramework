package anthem.irx.oneframe.database;

public enum Databases {
  MSSQL, RedShift, MongoDB, Oracle, MySQL;
}

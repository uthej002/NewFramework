package anthem.irx.oneframe.core;

import anthem.irx.oneframe.utilities.DateTimeProcessor;
import anthem.irx.oneframe.utilities.MonteScreenRecorder;
import java.awt.AWTException;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;
import org.monte.media.Format;
import org.monte.media.FormatKeys;
import org.monte.media.VideoFormatKeys;
import org.monte.media.math.Rational;
import org.testng.Assert;
import org.testng.Reporter;

public class OneframeLogger {
  MonteScreenRecorder videoLogger;
  
  String consoleIndenLevels;
  
  public OneframeLogger() {
    Log("[ONEFRAME][OFLOGGER] Oneframelogger VLOG is initialized");
    if (this.videoLogger == null) {
      File videoFolder = new File(OneframeConstants.VIDEOLOG_FOLDER);
      GraphicsConfiguration grxConf = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
      try {
        this
          
          .videoLogger = new MonteScreenRecorder(grxConf, null, new Format(new Object[] { FormatKeys.MediaTypeKey, FormatKeys.MediaType.FILE, FormatKeys.MimeTypeKey, "video/avi" } ), new Format(new Object[] { 
                FormatKeys.MediaTypeKey, FormatKeys.MediaType.VIDEO, FormatKeys.EncodingKey, "MJPG", VideoFormatKeys.CompressorNameKey, "MJPG", VideoFormatKeys.DepthKey, Integer.valueOf(24), FormatKeys.FrameRateKey, Rational.valueOf(15.0D), 
                VideoFormatKeys.QualityKey, Float.valueOf(0.2F), FormatKeys.KeyFrameIntervalKey, Integer.valueOf(900) } ), new Format(new Object[] { FormatKeys.MediaTypeKey, FormatKeys.MediaType.VIDEO, FormatKeys.EncodingKey, "black", FormatKeys.FrameRateKey, Rational.valueOf(8.0D) } ), null, videoFolder);
      } catch (IOException e) {
        e.printStackTrace();
      } catch (AWTException e) {
        e.printStackTrace();
      } 
    } 
  }
  
  private static void ReporterLog(String LogMessage) {
    Reporter.log(DateTimeProcessor.getCurrentDateTime(getDateTimeformat()).toUpperCase() + " - " + LogMessage + "<br>");
  }
  
  public static void Log(String LogMessage) {
    if (LogMessage.startsWith("[ONEFRAME]")) {
      if (OneframeContainer.ofcLoggerTestLogLevel.equalsIgnoreCase("oneframedebugmode"))
        Log(LogMessage.replace("[ONEFRAME]", "")); 
    } else {
      System.out.println(DateTimeProcessor.getCurrentDateTime(getDateTimeformat()).toUpperCase() + "> " + LogMessage);
      ReporterLog(LogMessage);
    } 
  }
  
  public static void ErrorLog(String LogMessage) {
    if (LogMessage.startsWith("[ONEFRAME]")) {
      if (OneframeContainer.ofcLoggerTestLogLevel.equalsIgnoreCase("oneframedebugmode"))
        ErrorLog(LogMessage.replace("[ONEFRAME]", "")); 
    } else {
      System.err.println(DateTimeProcessor.getCurrentDateTime(getDateTimeformat()).toUpperCase() + "> " + LogMessage);
      if (OneframeContainer.ofReporter != null && OneframeContainer.ofReporter.Logger != null && OneframeContainer.ofReporter.oneframeSpark != null)
        OneframeContainer.ofReporter.LogFailTestStep(LogMessage); 
      ReporterLog(LogMessage);
    } 
  }
  
  public static void throwException(String ExceptionMessage) {
    ErrorLog(ExceptionMessage);
    Assert.fail(ExceptionMessage);
  }
  
  public static void throwException(String ExceptionMessage, Throwable realCause) {
    ErrorLog(ExceptionMessage);
    Assert.fail(ExceptionMessage, realCause);
  }
  
  private static String getDateTimeformat() {
    return "ddMMM|hh:mm:ssa";
  }
  
  public void startVideoRecording(String testScriptName) {
    this.videoLogger.setTestScenarioID(OneframeContainer.getCurrentTestCaseID());
    this.videoLogger.setScriptName(testScriptName);
    try {
      this.videoLogger.start();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public void stopVideoRecording() {
    try {
      this.videoLogger.stop();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public void cleanUp() {
    if (this.videoLogger != null)
      this.videoLogger = null; 
  }
}

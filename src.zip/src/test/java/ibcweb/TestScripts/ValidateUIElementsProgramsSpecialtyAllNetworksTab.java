package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsCostOfCare;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLibrariesSpecialtyPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateUIElementsProgramsSpecialtyAllNetworksTab extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPLibrariesProgramsCostOfCare generalTab;
	IBPLibrariesMandatesPage mandate;

	@BeforeClass
	@Step("Initializing Test Script for Validating UI elements in programs -> Specialty -> Networks tab -> All Networks")
	public void setUp() {
		InitializeLaunchPad("IBPW_474");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		generalTab =  new IBPLibrariesProgramsCostOfCare();
		mandate = new IBPLibrariesMandatesPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate the UI elements in programs -> Specialty -> networks tab", dataProvider = "TestData")
	@Description("Validate the UI elements in programs -> Specialty -> networks tab")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus)throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickOnSpeciality();
			sa.assertTrue(librariesprogramspage.clickAddaSpecialtyProgram(), "Click on Add a speicalty button");
			sa.assertTrue(mandate.selectNetworkOverrideDropdown("Yes"), "Verified and Selected Network OverRide dropdown as 'Yes'");
			sa.assertTrue(generalTab.clickNetworksTab(), "Clicked on Networks Tab");
			sa.assertTrue(generalTab.validateTextIsDisplayed("All Networks"), "Validate text All Networks is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Specific Networks"), "Validate text Specific Networks is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Retail"), "Validate text Retail is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Home Delivery"), "Validate text Home Delivery is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("INCLUDE", 2), "Validate text INCLUDE is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("MAX DAY SUPPLY", 2), "Validate text MAX DAY SUPPLY is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("REFILL TOO SOON", 2), "Validate text REFILL TOO SOON is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("NUMBER OF GRACE FILLS", 2), "Validate text NUMBER OF GRACE FILLS is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("What happens after number of fills"), "Validate text What happens after number of fills is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("Except"), "Validate text Except is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("NETWORK NAME"), "Validate text NETWORK NAME is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("NETWORK CODE"), "Validate text NETWORK CODE is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("ADJUDICATION CODE"), "Validate text ADJUDICATION CODE is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("NETWORK TYPE"), "Validate text NETWORK TYPE is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("CLIENT"), "Validate text CLIENT is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("LOB"), "Validate text LOB is displayed");
			sa.assertTrue(generalTab.validateTextIsDisplayed("STATE"), "Validate text STATE is displayed");
			sa.assertTrue(generalTab.clickAddExceptionNetowrks(), "Clicked on Add Exception Networks Button");
			sa.assertTrue(generalTab.selectNetwork("CA90"), "Selected Network CA90");
			sa.assertTrue(generalTab.clickAddNetwork(), "Clicked on Add Network button");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if the General/Network/CostShares/Accum tabs are enabled after selecting General/Network/CostShares/Accum overrides as Yes in the form while creating a Cost of Care Program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to create a Cost of Care Program");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package APIUtilities;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;

import java.io.IOException;
import java.sql.Connection;
import java.util.Arrays;

import org.apache.tika.metadata.Database;
import org.bson.Document;
import org.testng.Assert;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.utilities.ConfigFileReader;

public class MongoDBConnection extends OneframeContainer {

	public static final String IBP_CONFIGURATION = "APIConfig.properties";
	public static final String IBP_CONFIG_FILE = CONFIG_FOLDER + IBP_CONFIGURATION;
	public static MongoDatabase database;

	public static ConfigFileReader OneframeConfiguration = new ConfigFileReader(IBP_CONFIG_FILE);
	public static int port = Integer.parseInt(OneframeConfiguration.getProperty("port"));

	@SuppressWarnings({ "deprecation", "resource" })
	public static void getDataBaseCollection() throws IOException {

		// Creating a Mongo Client

		MongoClientOptions.Builder builder = new MongoClientOptions.Builder();

		// build the connection options
		builder.maxConnectionIdleTime(60000);// set the max wait time in (ms)
		builder.sslEnabled(true);
		builder.socketKeepAlive(true);

		MongoClientOptions options = builder.build();
		
		// Creating a Mongo client 
//	      MongoClient mongo = new MongoClient( OneframeConfiguration.getProperty("server_address") , port ); 
	       
	      

		// Creating a Credentials
		MongoCredential credential;
		credential = MongoCredential.createCredential(OneframeConfiguration.getProperty("db_userid"),OneframeConfiguration.getProperty("dbname"),	
				OneframeConfiguration.getProperty("db_password").toCharArray());
		MongoClient mongoClient = new MongoClient(
				new ServerAddress(OneframeConfiguration.getProperty("server_address"), port), Arrays.asList(credential),
				options);
		OneframeLogger("Connected to the database successfully");
		
		// Accessing the Database
		 database = mongoClient.getDatabase(OneframeConfiguration.getProperty("dbname"));
		OneframeLogger("The Database Name is  "+database.getName());	
		OneframeLogger("Credentials ::"+ credential);
		
	}

	public static Document resultjsonDocument(Long id, String CollectionName) throws IOException {
		getDataBaseCollection();
		MongoCollection<Document> collectionName = database.getCollection(CollectionName);
		OneframeLogger("The Collection Name is  "+collectionName);
		Document document = collectionName.find(Filters.eq("_id", id)).first();
		if (document == null) {
			OneframeLogger("Document is not created");
		} else {
			OneframeLogger("Document created in DB");
			OneframeLogger("------------------------------------------");
			System.out.println(document);
		}
		OneframeLogger("------------------------------------------");

		return document;
	}
}

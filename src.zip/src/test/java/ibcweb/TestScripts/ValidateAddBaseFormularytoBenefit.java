package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAddBaseFormularytoBenefit extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitFormularyPage formulary;
	IBPAccumsBenefitPage accumsPage;

	@BeforeClass
	@Step("Initializing Test Script for Add Base formulary and save the formulary to existing benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_696");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		formulary = new IBPBenefitFormularyPage();
		accumsPage = new IBPAccumsBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "NewBenefitID" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Add Base formulary and save the formulary to existing benefit", dataProvider = "TestData")
	@Description("Validate Create Add Base formulary and save the formulary to existing benefit")
	public void ValidateAddNetFormularytoBenefit(String TestCaseID, String TestStatus, String NewBenefitID)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitID);
//			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			sa.assertTrue(createbenefitpage.verifyBenefitCreatedHeader(NewBenefitID),
					"Verified 'Benefit' header is same as expected");
			sa.assertTrue(formulary.clickFormularyTab(), "Clicked on Formulary Tab");
			createbenefitpage.ClickEditButtoninWFE();
			formulary.removeExistingNetFormulary();
			sa.assertTrue(formulary.addBaseFormulary(), "Verified the base formulary has been added to the beenfit");
			sa.assertTrue(formulary.addNetFormulary("10068"), "Verified the net formulary has been added to the beenfit");
			String numberOfTiers = formulary.getTierValue();
			sa.assertTrue(accumsPage.clickOnAccumsTab(), "Clicked on Accums Tab");
			sa.assertTrue(accumsPage.clickCostSharesApply(), "Clicked on Cost Shares Apply Tab");
			sa.assertTrue(accumsPage.verifyTierCount(numberOfTiers), "Tier value matches - Before Saving Benefit");
			
			sa.assertTrue(formulary.clickFormularyTab(), "Clicked on Formulary Tab");
			sa.assertTrue(formulary.removeExistingNetFormulary(), "Removed existing net formulary");
			
			createbenefitpage.ClickSaveButton();
			
			sa.assertTrue(formulary.clickFormularyTab(), "Clicked on Formulary Tab");
			sa.assertTrue(formulary.addBaseFormulary(), "Verified the base formulary has been added to the beenfit");
			sa.assertTrue(formulary.addNetFormulary("10069"), "Verified the net formulary has been added to the beenfit");
			numberOfTiers = formulary.getTierValue();
			sa.assertTrue(accumsPage.clickOnAccumsTab(), "Clicked on Accums Tab");
			sa.assertTrue(accumsPage.clickCostSharesApply(), "Clicked on Cost Shares Apply Tab");
			sa.assertTrue(accumsPage.verifyTierCount(numberOfTiers), "Tier value matches - Before Saving Benefit");
			
			sa.assertTrue(formulary.clickFormularyTab(), "Clicked on Formulary Tab");
			sa.assertTrue(formulary.removeExistingNetFormulary(), "Removed existing net formulary");
			
			sa.assertTrue(formulary.reloadPage(), "Reloading page");
			
			sa.assertTrue(accumsPage.clickOnAccumsTab(), "Clicked on Accums Tab");
			sa.assertTrue(accumsPage.clickCostSharesApply(), "Clicked on Cost Shares Apply Tab");
			sa.assertTrue(accumsPage.verifyTierCount("6"), "Tier value matches - Before Saving Benefit");
			
			sa.assertTrue(formulary.clickFormularyTab(), "Clicked on Formulary Tab");
			sa.assertTrue(formulary.addBaseFormulary(), "Verified the base formulary has been added to the beenfit");
			sa.assertTrue(formulary.addNetFormulary("10069"), "Verified the net formulary has been added to the beenfit");
			numberOfTiers = formulary.getTierValue();
			
			createbenefitpage.ClickWFECloseButton();
			createbenefitpage.ClickWFEExitAndSaveButton();
			sa.assertTrue(formulary.verifyNetFormularyFields(),
					"Verified the added net formulary values are displayed in the benefit");
			sa.assertTrue(accumsPage.clickOnAccumsTab(), "Clicked on Accums Tab");
			sa.assertTrue(accumsPage.clickCostSharesApply(), "Clicked on Cost Shares Apply Tab");
			sa.assertTrue(accumsPage.verifyTierCount(numberOfTiers), "Tier value matches - After Saving Benefit");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Add Base formulary and save the formulary to existing benefit Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Add Base formulary and save the formulary to existing benefit");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPContractCodePage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;

public class ValidateContractCodeSearchBoxFunction extends OneframeContainer {
	
	IBPHomePage homepage;
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPContractCodePage contractcodepage;
	
	@BeforeClass
	@Step("Initializing Test Script for Validating Search box in Contract Code")
	public void setUp() {
		InitializeLaunchPad("IBPW_906");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		contractcodepage = new IBPContractCodePage();
		}	
	
	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

			String[] fieldNames = { "TestCaseID", "TestStatus"};
			List<String> TestDataFields = Arrays.asList(fieldNames);
			return GetTestDatafromTDS(TestDataFields);
	}
	
	@Test(description = "Validate Search box in Contract Code", dataProvider = "TestData")
	@Description("Validate Search box in Contract Code")
	public void ValidateSearchContractCode(String TestCaseID, String TestStatus)throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
//			homepage.clickContractCode();			
			sa.assertTrue(contractcodepage.verifyContractCodesHeader(), "The Programs Section Page is displayed");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if the General/Network/CostShares/Accum tabs are enabled after selecting General/Network/CostShares/Accum overrides as Yes in the form while creating a Cost of Care Program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to create a Cost of Care Program");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}



}

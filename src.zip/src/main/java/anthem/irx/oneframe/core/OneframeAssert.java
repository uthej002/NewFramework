package anthem.irx.oneframe.core;

import org.testng.asserts.Assertion;
import org.testng.asserts.IAssert;

public class OneframeAssert extends Assertion {
  public void onAssertSuccess(IAssert<?> assertCommand) {
    OneframeContainer.gTestResult = "PASS";
    OneframeContainer.OneframeLogger(assertCommand.getMessage() + "| Test Status -> PASSED ");
  }
  
  public void onAssertFailure(IAssert<?> assertCommand, AssertionError ex) {
    OneframeContainer.gTestResult = "FAIL";
    String suffix = String.format("Expected : [%s] but Actual : [%s]", new Object[] { assertCommand.getExpected().toString(), assertCommand.getActual().toString() });
    OneframeContainer.OneframeErrorLogger(assertCommand.getMessage() + " | Test Status -> FAILED | " + suffix);
  }
}
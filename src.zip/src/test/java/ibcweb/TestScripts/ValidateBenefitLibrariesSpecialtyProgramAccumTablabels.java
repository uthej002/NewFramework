package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBenefitProgramsPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsCostOfCare;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesSpecialtyProgramAccumTablabels extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;
	IBPLibrariesBaseFormularies baseFormulary;
	IBPBenefitProgramsPage benefitProgramsPage;
	IBPLibrariesProgramsCostOfCare costOfCare;

	@BeforeClass
	@Step("Initializing Test Script for Validate Specialty Program Accum tab content")
	public void setUp() {
		InitializeLaunchPad("IBPW_448");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();
		baseFormulary = new IBPLibrariesBaseFormularies();
		benefitProgramsPage = new IBPBenefitProgramsPage();
		costOfCare = new IBPLibrariesProgramsCostOfCare();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate  Specialty Program Accum tab content", dataProvider = "TestData")
	@Description("Validate Specialty Program Accum tab content")
	public void ValidateSpecialtyAccumTablabels(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickOnSpeciality();
			benefitProgramsPage.clickonExistingSpecialtyProgram();
			librariesprogramspage.clickAccumTab();
			//librariesprogramspage.verifyAndClickEditButton();
			benefitProgramsPage.verifyAccumTablabelsAreDisplayed("Program Accum");
			benefitProgramsPage.verifyAccumTablabelsAreDisplayed("Custom Accums");
			benefitProgramsPage.verifyAccumTablabelsAreDisplayed("Apply Program Deductible");
			costOfCare.validateTextIsDisplayed("Individual dollar amounts", 3);
			costOfCare.validateTextIsDisplayed("Family dollar amounts", 3);
			costOfCare.validateTextIsDisplayed("Does it accumulate to plan level", 3);
			costOfCare.validateTextIsDisplayed("Apply Integrated Medical", 3);
			benefitProgramsPage.verifyAccumTablabelsAreDisplayed("Apply Program MoP");
			benefitProgramsPage.verifyAccumTablabelsAreDisplayed("Apply Program PSL");
			librariesprogramspage.verifyProgramDedTogggleDisplayed();
			librariesprogramspage.verifyApplyPrgmDedINNRetailDisplayed();
			librariesprogramspage.verifyApplyPrgmDedINNHomeDeliveryDisplayed();
			librariesprogramspage.verifyApplyPrgmDedONNRetailDisplayed();
			librariesprogramspage.verifyApplyProgramMopTogggleDisplayed();
			librariesprogramspage.verifyApplyPrgmMopINNRetailDisplayed();
			librariesprogramspage.verifyApplyPrgmMopINNHomeDeliveryDisplayed();
			librariesprogramspage.verifyApplyPrgmMopONNRetailDisplayed();
			librariesprogramspage.verifyApplyProgramPSLTogggleDisplayed();
			librariesprogramspage.verifyApplyPrgmPSLINNRetailDisplayed();
			librariesprogramspage.verifyApplyPrgmPSLINNHomeDeliveryDisplayed();
			librariesprogramspage.verifyApplyPrgmPSLONNRetailDisplayed();
			benefitProgramsPage.clickDownArrowButton();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Specialty Program Accum tab content Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Specialty Program Accum tab content");
		}

		homepage.clickLogout();
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

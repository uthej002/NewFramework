// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

import org.openqa.selenium.support.ui.ExpectedCondition;
import java.util.function.Function;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;
import anthem.irx.oneframe.core.OneframeContainer;

public class AngularJSWait extends OneframeContainer
{
    private static WebDriver AngularJSDriver;
    private static WebDriverWait AngularJSWait;
    private static JavascriptExecutor JSExecutor;
    private static int WaitTimeOut;
    
    public static void setDriver(final WebDriver driver) {
        anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver = driver;
        anthem.irx.oneframe.selenium.AngularJSWait.AngularJSWait = new WebDriverWait(anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver, (long)anthem.irx.oneframe.selenium.AngularJSWait.WaitTimeOut);
        anthem.irx.oneframe.selenium.AngularJSWait.JSExecutor = (JavascriptExecutor)anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver;
    }
    
    public static void waitForJQueryLoad() {
        final ExpectedCondition<Boolean> jQueryLoad = (ExpectedCondition<Boolean>)(driver -> (long)((JavascriptExecutor)anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver).executeScript("return jQuery.active", new Object[0]) == 0L);
        final boolean jqueryReady = (boolean)anthem.irx.oneframe.selenium.AngularJSWait.JSExecutor.executeScript("return jQuery.active==0", new Object[0]);
        if (!jqueryReady) {
            anthem.irx.oneframe.selenium.AngularJSWait.AngularJSWait.until((Function)jQueryLoad);
        }
    }
    
    public static void waitForAngularLoad() {
        final WebDriverWait wait = new WebDriverWait(anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver, (long)anthem.irx.oneframe.selenium.AngularJSWait.WaitTimeOut);
        final JavascriptExecutor jsExec = (JavascriptExecutor)anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver;
        final String angularReadyScript = "return angular.element(document).injector().get('$http').pendingRequests.length === 0";
        final ExpectedCondition<Boolean> angularLoad = (ExpectedCondition<Boolean>)(driver -> Boolean.valueOf(((JavascriptExecutor)driver).executeScript(angularReadyScript, new Object[0]).toString()));
        final boolean angularReady = Boolean.valueOf(jsExec.executeScript(angularReadyScript, new Object[0]).toString());
        if (!angularReady) {
            wait.until((Function)angularLoad);
        }
    }
    
    public static void waitUntilJSReady() {
        final WebDriverWait wait = new WebDriverWait(anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver, (long)anthem.irx.oneframe.selenium.AngularJSWait.WaitTimeOut);
        final JavascriptExecutor jsExec = (JavascriptExecutor)anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver;
        final ExpectedCondition<Boolean> jsLoad = (ExpectedCondition<Boolean>)(driver -> ((JavascriptExecutor)anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver).executeScript("return document.readyState", new Object[0]).toString().equals("complete"));
        final boolean jsReady = (boolean)jsExec.executeScript("return document.readyState", new Object[0]).toString().equals("complete");
        if (!jsReady) {
            wait.until((Function)jsLoad);
        }
    }
    
    public static void waitUntilJQueryReady() {
        final JavascriptExecutor jsExec = (JavascriptExecutor)anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver;
        final Boolean jQueryDefined = (Boolean)jsExec.executeScript("return typeof jQuery != 'undefined'", new Object[0]);
        if (jQueryDefined) {
            sleep(10L);
            waitForJQueryLoad();
            waitUntilJSReady();
            sleep(10L);
        }
        else {
            OneframeContainer.OneframeLogger("[ONEFRAME]jQuery is not defined on this site!");
        }
    }
    
    public static void waitUntilAngularReady() {
        final JavascriptExecutor jsExec = (JavascriptExecutor)anthem.irx.oneframe.selenium.AngularJSWait.AngularJSDriver;
        final Boolean angularUnDefined = (Boolean)jsExec.executeScript("return window.angular === undefined", new Object[0]);
        if (!angularUnDefined) {
            final Boolean angularInjectorUnDefined = (Boolean)jsExec.executeScript("return angular.element(document).injector() === undefined", new Object[0]);
            if (!angularInjectorUnDefined) {
                sleep(10L);
                waitForAngularLoad();
                waitUntilJSReady();
                sleep(10L);
            }
            else {
                OneframeContainer.OneframeLogger("[ONEFRAME]Angular injector is not defined on this site!");
            }
        }
        else {
            OneframeContainer.OneframeLogger("[ONEFRAME]Angular is not defined on this site!");
        }
    }
    
    public static void waitJQueryAngular() {
        waitUntilJQueryReady();
        if (anthem.irx.oneframe.selenium.AngularJSWait.AngularAppStatus.equalsIgnoreCase("yes")) {
            waitUntilAngularReady();
        }
    }
    
    public static void sleep(final long milis) {
        try {
            Thread.sleep(milis);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    static {
        anthem.irx.oneframe.selenium.AngularJSWait.WaitTimeOut = 15;
    }
}

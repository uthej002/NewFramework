package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;

import java.util.List;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class SamplePageObject extends OneframeContainer {
	OneframeAssert ha = new OneframeAssert();

	@FindBy(xpath = "//h1[contains(.,'Contact us')]")
	public WebElement hdrContactUs;
	
	@FindBy(className = "irx-home-menu")
	public WebElement btnHome;

	@FindBy(xpath = "//div[@class='col-xs-12 Uimargin-top-20']//h1[contains(text(),'Contact us')]")
	WebElement contactUsMsg;

	@FindBy(className = "memberServicesStyle")
	WebElement hdrMemberServices;

	@FindBy(className = "technicalSupportStyle")
	WebElement hdrTechnicalSupport;

	@FindBy(xpath = "//div[contains(.,'Pharmacy Claims Mailing Address')]")
	WebElement hdrPharmacyClaimsMailingAddress;

	@FindBy(className = "emergencytext")
	WebElement emergencytext;

	@FindBy(xpath = "//h1[@class='grievances']")
	WebElement lblGrievanceHeading;

	@FindBy(xpath = "//div[@class='grievances-texts ng-star-inserted']")
	WebElement txtGrievance;

	@FindBy(xpath = "//div[@class='medicarepartd']")
	WebElement hdrPartDMemeber;

	@FindBy(xpath = "//div[@class='sub-texts subtextstyle']")
	WebElement txtSubText;

	@FindBy(xpath = "//div[@class='col-sm-3']/div/div")
	List<WebElement> hdrMemberServiceTecSupportPharmacyClaimsMailinAddress;

	@FindBy(xpath = "//div[@class='row servicemargin']/div[2]/div/div/div")
	List<WebElement> textMemServiceNumContactUsMailingAddress;

	@FindBy(xpath = "//div[contains(text(),'s 1st Choice')]")
	WebElement lblAmericasFirstChoice;

	@FindBy(xpath = "//div[@class='choice healthsunmargin']")
	List<WebElement> lstHealthMarginHeading;

	@FindBy(xpath = "//div[@class='phonenumbermargin']/a")
	List<WebElement> lstHealthMarginNumber;

	@FindBy(xpath = "//div[@class='tty']")
	List<WebElement> lstHealthMargintty;

	@FindBy(xpath = "//a[text()='Contact us now']")
	WebElement lnkContactUs;

	// Initializing the Page Objects of Member Dashboard Page
	public SamplePageObject() {
		PageFactory.initElements(oneframeDriver, this);
	}

	@Step("Verify Contact Us header is displayed")
	public boolean verifyContactUsHeader() {
		OneframeLogger("Contact Us Header is displayed");
		ClickWebObject(hdrContactUs);
		return (ObjectExist(hdrContactUs));
	}

	
	@Step("Verify Contact Us URL is displayed")
	public boolean verifyContactUsURL() {
		boolean bln = false;
		try {
			if (ObjectExist(btnHome)) {
				String currentURl = oneframeDriver.getCurrentUrl();
				OneframeLogger("Contact Us URL is " + currentURl);
				ha.assertTrue(currentURl.contains("member/contact-us"),
						"Contact Us URL is as expected");
				bln = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Contact Us link is not displayed");
		}
		return bln;
	}

	@Step("Verify Contact Us message is displayed")
	public boolean verifyContactUsMessage() {
		boolean blnRc = false;
		try {
			if (ObjectExist(contactUsMsg)) {
				ClickWebObject(contactUsMsg);
				blnRc = true;
			}
		} catch (TimeoutException toException) {
			OneframeLogger("Contact us header not displayed");
		}
		return blnRc;
	}

	@Step("Verify Member Services header is displayed")
	public boolean verifyMemberServices() {
		OneframeLogger("Member Services header is displayed");
		ClickWebObject(hdrMemberServices);
		return (ObjectExist(hdrMemberServices));
	}

	@Step("Verify Technical Support header is displayed")
	public boolean verifyTechnicalSupport() {
		OneframeLogger("Technical Support header is displayed");
		ClickWebObject(hdrTechnicalSupport);
		return (ObjectExist(hdrTechnicalSupport));
	}

	/*
	 * @Step("Verify Pharmacy Claims Mailing Address header is displayed") public
	 * void verifyPharmacyClaimsMailingAddress() {
	 * WebObjectHandler.elementIsDisplayed(hdrPharmacyClaimsMailingAddress);
	 * WebObjectHandler.ClickWebObject(hdrPharmacyClaimsMailingAddress);
	 * OneframeLogger("Pharmacy Claims Mailing Address header is displayed"); }
	 */

	@Step("Verify Pharmacy Claims Mailing Address header is displayed")
	public boolean verifyPharmacyClaimsMailingAddress() {
		OneframeLogger("Pharmacy Claims Mailing Address header is displayed");
		ClickWebObject(hdrPharmacyClaimsMailingAddress);
		return (ObjectExist(hdrPharmacyClaimsMailingAddress));
	}

	@Step("Verify Emergency text is displayed")
	public boolean verifyEmergencytext() {
		OneframeLogger("Emergency text is displayed");
		ClickWebObject(emergencytext);
		return (ObjectExist(emergencytext));
	}

	public void verifyContactUsPageDetails() {
		verifyContactUsHeader();
		verifyContactUsMessage();
		verifyMemberServices();
		verifyTechnicalSupport();
		verifyPharmacyClaimsMailingAddress();
		verifyEmergencytext();

	}

	@Step("Verify How to File Grievances and Appeals heading")
	public void verifyGrievancesHeading() {
		WebObjectHandler.ObjectExist(lnkContactUs);
		ClickWebObject(hdrContactUs);
		WebObjectHandler.ScrollToElement(lblGrievanceHeading);
		WebObjectHandler.ClickWebObject(lblGrievanceHeading);
		ha.assertTrue(lblGrievanceHeading.getText().contentEquals("How to File Grievances and Appeals"),
				"How to File Grievances and Appeals is diplayed");
	}

	@Step("Verify How to File Grievances and Appeals text")
	public void verifyGrievancesText() {
		if(ObjectExist(lnkContactUs)) {
		String grievanceTxt = lblGrievanceHeading.getText() + txtGrievance.getText();
		ha.assertTrue(grievanceTxt.equalsIgnoreCase(
				"How to File Grievances and AppealsA grievance is a complaint about your service or benefits. An appeal is when you ask us to take another look at a decision we’ve made."),
				"Contact us grievance text is displayed");
		}
	}

	@Step("Verify How to File Grievances and Appeals text")
	public void verifyPartDMemeberHeaderAndSubText() {

		WebObjectHandler.ClickWebObject(hdrPartDMemeber);
		Assert.assertTrue(hdrPartDMemeber.getText().equalsIgnoreCase("Medicare Part D Members"),
				"Medicare Part D Members heading is not displayed");
		ha.assertTrue(
				txtSubText.getText().equalsIgnoreCase(
						"To file a Medicare Part D grievance or appeal, please call one of the following numbers:"),
				"Medicare Part D Members subtext displayed");
	}

	@Step("Verify How to File Grievances and Appeals text")
	public void verifyMemberServiceTecSupportPharmacyClaims() throws InterruptedException {

		String memberServiceHeader = "", technicalSupport = "", pharmacyClaimsMailingAddress = "";
		String memberServiceNumber = "", lnkContactUsNow = "", pOBoxAddress = "";

		
		WebObjectHandler.ObjectExist(lnkContactUs);
		ClickWebObject(hdrContactUs);
		
		for (int i = 0; i < hdrMemberServiceTecSupportPharmacyClaimsMailinAddress.size(); i++) {
			if (i < 2) {
				memberServiceHeader = hdrMemberServiceTecSupportPharmacyClaimsMailinAddress.get(i).getText()
						+ memberServiceHeader;
			} else if (i == 2) {
				technicalSupport = hdrMemberServiceTecSupportPharmacyClaimsMailinAddress.get(i).getText();
			} else if (i == 3) {
				pharmacyClaimsMailingAddress = hdrMemberServiceTecSupportPharmacyClaimsMailinAddress.get(i).getText();
			}
		}
		WebObjectHandler.ObjectExist(lnkContactUs);
		WebObjectHandler.ObjectExist(textMemServiceNumContactUsMailingAddress.get(2));
		WebObjectHandler.ClickWebObject(textMemServiceNumContactUsMailingAddress.get(2));
		for (int i = 0; i < textMemServiceNumContactUsMailingAddress.size(); i++) {
			if (i == 0) {
				memberServiceNumber = textMemServiceNumContactUsMailingAddress.get(i).getText();
			} else if (i == 1) {
				lnkContactUsNow = textMemServiceNumContactUsMailingAddress.get(i).getText();
			} else if (i == 2) {
				pOBoxAddress = textMemServiceNumContactUsMailingAddress.get(i).getText() + pOBoxAddress;
			}
		}
		ha.assertTrue(
				(memberServiceHeader.equalsIgnoreCase("24 hours a day, seven days a weekMember Services")
						&& memberServiceNumber.equalsIgnoreCase("1-833-236-6196\n(TTY/TDD: 711)"))
						&& (technicalSupport.equalsIgnoreCase("Technical Support")
								&& lnkContactUsNow.equalsIgnoreCase("Contact us now"))
						&& (pharmacyClaimsMailingAddress.equalsIgnoreCase("Pharmacy Claims Mailing Address")
								&& (pOBoxAddress.equalsIgnoreCase("PO Box 52136\nPhoenix, AZ 85072-2136"))),
				"Member services Content is displayed");
	}

	@Step("Verify Phone Numbers From Phone Number Margin")
	public void verifyPhoneNumbersFromPhoneNumberMargin() throws InterruptedException {
		WebObjectHandler.ClickWebObject(lstHealthMarginHeading.get(0));
		ha.assertTrue(
				lstHealthMarginNumber.get(0).getAttribute("href").contains("1-888-563-3289")
						&& lstHealthMarginNumber.get(1).getAttribute("href").contains("1-800-401-2740")
						&& lstHealthMarginNumber.get(2).getAttribute("href").contains("1-877-336-2069")
						&& lstHealthMarginNumber.get(3).getAttribute("href").contains("1-866-245-5360"),
				"Margin content is displayed");
	}

}

package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeConstants;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeLogger;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelFile {
  private File xlFile;
  
  private Workbook xlWorkBook;
  
  private Sheet xlSheet;
  
  private String xlCurrSheetName;
  
  private String xlCurrWorkBookName;
  
  private int totRowCount;
  
  private static OneframeSoftAssert ofSA;
  
  private FileInputStream inputStream;
  
  public ExcelFile(String xlResourceFolderPath, String xlFileName) {
    this.xlCurrWorkBookName = xlFileName;
    this.xlFile = new File(OneframeConstants.RESOURCES_FOLDER + "/" + xlResourceFolderPath + "/" + xlFileName);
    ofSA = new OneframeSoftAssert();
    try {
      this.inputStream = new FileInputStream(this.xlFile);
      this.xlWorkBook = WorkbookFactory.create(this.inputStream);
      OneframeContainer.OneframeLogger("Opened Excel workboox - " + xlFileName);
    } catch (EncryptedDocumentException|org.apache.poi.openxml4j.exceptions.InvalidFormatException|IOException e) {
      OneframeContainer.OneframeErrorLogger(e.getMessage());
    } 
  }
  
  public ExcelFile(String xlFilePathAndName) {
    this.xlCurrWorkBookName = xlFilePathAndName;
    this.xlFile = new File(xlFilePathAndName);
    ofSA = new OneframeSoftAssert();
    try {
      this.inputStream = new FileInputStream(this.xlFile);
      this.xlWorkBook = WorkbookFactory.create(this.inputStream);
      OneframeContainer.OneframeLogger("Opened Excel workboox - " + xlFilePathAndName);
    } catch (EncryptedDocumentException|org.apache.poi.openxml4j.exceptions.InvalidFormatException|IOException e) {
      OneframeContainer.OneframeErrorLogger(e.getMessage());
    } 
  }
  
  public ExcelFile OpenWorkBook() {
    if (this.xlWorkBook == null) {
      OneframeLogger.ErrorLog("Excel workbook is not initialized");
      System.exit(0);
    } 
    return this;
  }
  
  public ExcelFile OpenWorkSheet(String xlSheetName) {
    this.xlCurrSheetName = xlSheetName;
    this.xlSheet = this.xlWorkBook.getSheet(xlSheetName);
    if (this.xlSheet.getProtect()) {
      OneframeContainer.OneframeLogger("Excel worksheet [" + xlSheetName + "] is password protected");
      this.xlSheet.protectSheet(null);
      OneframeContainer.OneframeLogger("Password protection removed");
    } 
    OneframeContainer.OneframeLogger("Opened Excel worksheet - " + xlSheetName);
    return this;
  }
  
  private void OpenWorkSheet() {
    OpenWorkSheet(this.xlCurrSheetName);
  }
  
  private void CloseWorkSheet() {
    this.xlSheet = null;
    OneframeContainer.OneframeLogger("Closed Excel worksheet '" + this.xlCurrSheetName + "'");
  }
  
  private void CloseInputStream() {
    try {
      this.inputStream.close();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  private void CloseWorkBook() {
    try {
      this.xlWorkBook.close();
      this.xlWorkBook = null;
      OneframeContainer.OneframeLogger("Closed Excel workbook '" + this.xlCurrWorkBookName + "'");
    } catch (IOException e) {
      OneframeLogger.ErrorLog(e.getMessage());
    } 
  }
  
  public void CloseExcelFile() {
    CloseWorkSheet();
    CloseWorkBook();
  }
  
  public int getTotalRowCount() {
    return this.xlSheet.getPhysicalNumberOfRows();
  }
  
  public int getTotalColumnCount() {
    Row headerRow = this.xlSheet.getRow(0);
    return headerRow.getPhysicalNumberOfCells();
  }
  
  public String[] getRowContentByKeyValue(String KeyColumn, String KeyValue) {
    return getRowContentByRowNumber(getRowIdentifier(KeyColumn, KeyValue));
  }
  
  public String[][] getRowsContentByKeyValue(String KeyColumn, String KeyValue) {
    int RowIdentifier = 0;
    int cols = getTotalColumnCount();
    int rows = getRowsCountByKeyValue(KeyColumn, KeyValue);
    int TotalRows = getTotalRowCount();
    int keyColid = getColIndexByName(KeyColumn);
    int rowCounter = 0;
    String[][] RowsContent = new String[rows][cols];
    for (int i = 0; i < TotalRows; i++) {
      String colValue = ReadCellActRef(i, keyColid);
      if (colValue.contentEquals(KeyValue)) {
        RowIdentifier = i + 1;
        RowsContent[rowCounter] = getRowContentByRowNumber(RowIdentifier);
        rowCounter++;
      } 
    } 
    return RowsContent;
  }
  
  public int getRowsCountByKeyValue(String KeyColumn, String KeyValue) {
    int rowCounter = 0;
    int TotalRows = getTotalRowCount();
    int keyColid = getColIndexByName(KeyColumn);
    for (int i = 0; i < TotalRows; i++) {
      String colValue = ReadCellActRef(i, keyColid);
      if (colValue.contentEquals(KeyValue))
        rowCounter++; 
    } 
    return rowCounter;
  }
  
  public String[] getRowContentByRowNumber(int RowNumber) {
    if (RowNumber < 0) {
      OneframeContainer.OneframeLogger("Invalid Row or no matching row found for the key value");
      return null;
    } 
    String[] RowContent = new String[getTotalColumnCount()];
    int acRowRef = getCellRef(RowNumber);
    for (int i = 0; i < getTotalColumnCount(); i++)
      RowContent[i] = ReadCellActRef(acRowRef, i); 
    return RowContent;
  }
  
  private String ReadCellActRef(int RowNbr, int ColNbr) {
    DataFormatter formatter = new DataFormatter();
    Cell cell = this.xlSheet.getRow(RowNbr).getCell(ColNbr);
    return formatter.formatCellValue(cell);
  }
  
  public String ReadCell(int RowNbr, int ColNbr) {
    return ReadCellActRef(getCellRef(RowNbr), getCellRef(ColNbr));
  }
  
  public String ReadCell(int RowNbr, String ColumnName) {
    return ReadCell(RowNbr, getColIndexByName(ColumnName));
  }
  
  public String ReadCell(String KeyColumn, String KeyValue, String ColumnName) {
    return ReadCell(getRowIdentifier(KeyColumn, KeyValue), ColumnName);
  }
  
  public String[] getColumnHeaders() {
    int headerRow = 0;
    int totColumns = getTotalColumnCount();
    String[] ColHeaders = new String[totColumns];
    OneframeContainer.OneframeLogger("Total number of columns : " + totColumns);
    for (int i = 0; i < totColumns; i++) {
      String cellValue = ReadCellActRef(0, i);
      OneframeContainer.OneframeLogger("[ONEFRAME]Excel Row, Column (" + headerRow + "," + i + ") : " + cellValue);
      if (cellValue != "" || cellValue != null)
        ColHeaders[i] = cellValue; 
    } 
    return ColHeaders;
  }
  
  public ExcelFile PrintColumnHeaders() {
    int headerRow = 0;
    int totColumns = getTotalColumnCount();
    OneframeContainer.OneframeLogger("Total number of columns : " + totColumns);
    for (int i = 0; i < totColumns; i++) {
      String cellValue = ReadCellActRef(0, i);
      OneframeContainer.OneframeLogger("[ONEFRAME]Excel Row, Column (" + headerRow + "," + i + ") : " + cellValue);
      if (cellValue != "" || cellValue != null)
        OneframeContainer.OneframeLogger(cellValue); 
    } 
    return this;
  }
  
  private int getCellRef(int cellRef) {
    return cellRef - 1;
  }
  
  private int getRowIdentifier(String KeyColumn, String KeyValue) {
    int rowIdentifier = -1;
    int TotalRows = getTotalRowCount();
    int keyColid = getColIndexByName(KeyColumn);
    for (int i = 0; i < TotalRows; i++) {
      String colValue = ReadCellActRef(i, keyColid);
      if (colValue.contentEquals(KeyValue)) {
        rowIdentifier = i;
        break;
      } 
    } 
    return rowIdentifier;
  }
  
  private int getColIndexByName(String ColName) {
    int rowCount = this.xlSheet.getLastRowNum() - this.xlSheet.getFirstRowNum();
    Row xlHeaderRow = this.xlSheet.getRow(0);
    for (int j = 0; j < xlHeaderRow.getLastCellNum(); j++) {
      String actColName = ReadCellActRef(0, j);
      if (actColName.equalsIgnoreCase(ColName))
        return j; 
    } 
    OneframeLogger.Log("Column [" + ColName + "] not found in the Excel Sheet");
    return -1;
  }
  
  public ExcelFile WriteToCell(int row, int col, String CellValue) {
    Row xlDataRow = this.xlSheet.getRow(row);
    Cell cell = xlDataRow.getCell(col);
    cell.setCellValue(CellValue);
    return this;
  }
  
  public ExcelFile WriteToCell(String KeyColumn, String KeyValue, String ColumnName, String CellValue) throws IOException {
    return WriteToCell(getRowIdentifier(KeyColumn, KeyValue), ColumnName, CellValue);
  }
  
  public ExcelFile WriteToCell(int RowNbr, String ColumnName, String CellValue) throws IOException {
    return WriteToCell(RowNbr, getColIndexByName(ColumnName), CellValue);
  }
  
  public ExcelFile SaveChangesToExcelFile() {
    try {
      CloseInputStream();
      FileOutputStream outputStream = new FileOutputStream(this.xlFile);
      this.xlWorkBook.write(outputStream);
      outputStream.close();
      OneframeLogger.Log("Chanages are saved to the excel file");
    } catch (IOException e) {
      e.printStackTrace();
    } 
    return this;
  }
  
  private FileInputStream OpenXlFileAsInputStream() {
    try {
      this.inputStream = new FileInputStream(this.xlFile);
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } 
    return this.inputStream;
  }
  
  public ExcelFile validateColumnHeaders(String[] ExpectedColumns) {
    String[] actualColumns = getColumnHeaders();
    for (int i = 0; i < ExpectedColumns.length; i++)
      ofSA.assertEquals(actualColumns[i], ExpectedColumns[i], "Validate column header name for column(" + (i + 1) + ")"); 
    return this;
  }
  
  public ExcelFile validateColumn(int RowIdentifier, String ColumnName, String ExpectedValue) {
    String xlCellValue = ReadCell(RowIdentifier, ColumnName);
    ofSA.assertEquals(xlCellValue, ExpectedValue, "Validate column [" + ColumnName + "]");
    return this;
  }
  
  public ExcelFile validateColumn(String KeyColumn, String KeyValue, String ColumnName, String ExpectedValue) {
    String xlCellValue = ReadCell(KeyColumn, KeyValue, ColumnName);
    ofSA.assertEquals(xlCellValue, ExpectedValue, "Validate column [" + ColumnName + "]");
    return this;
  }
  
  public ExcelFile validateColumns(int RowIdentifier, String[] ColumnNames, String[] ExpectedValues) {
    return this;
  }
  
  public ExcelFile validateColumns(String KeyColumn, String KeyValue, String[] ColumnNames, String[] ExpectedValues) {
    return this;
  }
  
  protected void finalize() {
    CloseExcelFile();
    CloseInputStream();
  }
}
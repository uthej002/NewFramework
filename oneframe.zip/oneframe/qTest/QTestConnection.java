// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTest;

import java.io.IOException;
import org.qas.qtest.api.auth.PropertiesQTestCredentials;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import anthem.irx.oneframe.core.OneframeConstants;
import java.io.InputStream;
import org.qas.qtest.api.auth.QTestCredentials;

public class QTestConnection
{
    public QTestCredentials QTestCredential;
    InputStream qTestCredInputStream;
    
    public QTestConnection() {
        try {
            this.qTestCredInputStream = new FileInputStream(OneframeConstants.CONFIG_FOLDER + "qTestCredentials.properties");
        }
        catch (FileNotFoundException e1) {
            e1.printStackTrace();
        }
        try {
            this.QTestCredential = (QTestCredentials)new PropertiesQTestCredentials(this.qTestCredInputStream);
        }
        catch (IOException e2) {
            e2.printStackTrace();
        }
    }
}

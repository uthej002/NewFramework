package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesEditNetBaseFormulary extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPBenefitFormularyPage librariesFormularyPage;

	@BeforeClass
	@Step("Initializing Test Script for validating Benefit Libraries Base Edit Net Formulary")
	public void setUp() {
		InitializeLaunchPad("IBPW_412");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		librariesFormularyPage = new IBPBenefitFormularyPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefit Libraries Base Edit Net Formulary", dataProvider = "TestData")
	@Description("Validate Benefit Libraries Base Edit Net Formulary")
	public void ValidateLibrariesBaseEditNetFormulary(String TestCaseID, String TestStatus)throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesFormularyPage.clickViewButtonofFormularies();
			librariesFormularyPage.clickNetFormulariesButton();
			librariesFormularyPage.clickonFirstNetFormulary();
			librariesFormularyPage.verifyAndClickEditButton();
			librariesFormularyPage.verifyFormularyTextisEntered();
			
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Benefit Libraries Base Edit Net Formulary Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Benefit Libraries Base Edit Net Formulary");
		}

//		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

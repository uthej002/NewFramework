package ibcweb.PageObjects;

import java.lang.*;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;


import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.utilities.CSVFile;
import io.qameta.allure.Step;

public class IBPContractCodePage extends OneframeContainer {

	@FindBy(xpath="//h2[text()='Contract Codes']")
	WebElement hdrContractCodes;

	@FindBy(xpath="//div[text()= ' Contract Code ']")
	WebElement btnContractCode;

	@FindBy(xpath="//button[@class='mat-focus-indicator filter mat-icon-button mat-button-base']")
	WebElement btnFilter;

	@FindBy(xpath="//*[@placeholder='Contract Code']")
	WebElement contractCodeField;

	@FindBy(xpath="//*[@placeholder='Benefit Plan Id']")
	WebElement benefitPlanIdField;

	@FindBy(xpath="//b[text()='Apply filter']")
	WebElement btnApplyFilter;

	@FindBy(xpath="//th[text()='SOURCE SYSTEM']")
	WebElement txtSourceSystem;

	@FindBy(xpath="//tbody[@role='rowgroup']/tr")
	List <WebElement> lstFilterResults;

	@FindBy(xpath="//span[text()=' Add Contract Codes ']")
	WebElement btnAddContractCodes;

	@FindBy(xpath="//h3[text()='Add Contract Codes']")
	WebElement hdrAddContractCodes;

	@FindBy(xpath="//*[@placeholder='Enter Source System']")
	WebElement sourceSystemField;

	@FindBy(xpath="//*[@placeholder='Enter Contract Platform']")
	WebElement contractPlatformField;

	@FindBy(xpath="//*[@placeholder='Enter Contract Code']")
	WebElement enterContractCodeField;

	@FindBy(xpath="//*[@placeholder='Select Effective Date']")
	WebElement contractEffectiveDateField;

	@FindBy(xpath="//*[@placeholder='Select Term Date']")
	WebElement contractTermDateField;

	@FindBy(xpath="//*[@placeholder='Enter Benfit Plan ID']")
	WebElement enterBenefitPlanIdField;

	@FindBy(xpath="//*[@placeholder='Enter Plan Version']")
	WebElement benefitPlanVersionField;

	@FindBy(xpath="//*[@placeholder='Select Plan Effective Date']")
	WebElement planEffectiveDateField;

	@FindBy(xpath="//span[text()='Add Contract Codes']")
	WebElement btnSubmitAddContractCodes;

	@FindBy(xpath = "//*[@svgicon=\"edit\"]")
	WebElement btnEdit;

	@FindBy(xpath = "//*[@placeholder='Plan Effective Date']")
	WebElement editPlanEffectiveDate;

	@FindBy(xpath ="//*[text()=' Save changes ']")
	WebElement btnSaveChanges;

	@FindBy(xpath = "//h3[text()='Export']")
	WebElement btnExport;
	
	@FindBy(xpath = "//div[@class='mat-paginator-range-label']")
	WebElement txtPagination;
	
	@FindBy(xpath="//td[contains(@class,'mat-cell cdk-cell cdk-column-contractCode mat-column-contractCode ')]")
	List<WebElement> lstContractCodes;
	
	@FindBy(xpath="//input[@placeholder='Search']")
	WebElement txtSearch;


	// Initializing the Page Objects:
	public IBPContractCodePage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify Contract Code header is displayed")
	public boolean verifyContractCodesHeader() {
		boolean flag = false;
		if (ObjectExist(hdrContractCodes)) {
			if (hdrContractCodes.getText().equalsIgnoreCase("Contract Codes")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click on Contract Code")
	public void clickonContractCode() {
		try {
			if (ObjectExist(btnContractCode)) {
				ClickWebObject(btnContractCode);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Contract Code Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Contract Code Button is not Clicked");
		}
	}

	@Step("Click on Filter Button")
	public void clickonFilterBtn() {
		try {
			if (ObjectExist(btnFilter)) {
				ClickWebObject(btnFilter);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Filter Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Filter Button is not Clicked");
		}
	}

	@Step("Click on Apply filter Button")
	public void clickonApplyFilterBtn() {
		try {
			if (ObjectExist(btnApplyFilter)) {
				ClickWebObject(btnApplyFilter);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Apply filter Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Apply filter Button is not Clicked");
		}
	}	

	@Step("Enter Contract Code")
	public boolean enterContractCode(String ContractCode) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(contractCodeField)) {
			ClickWebObject(contractCodeField);
			contractCodeField.sendKeys(ContractCode);
			OneframeLogger("The Contract Code is : " + contractCodeField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}	

	@Step("Enter Benefit Plan Id")
	public boolean enterBenefitPlanId(String BenefitPlanId) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(benefitPlanIdField)) {
			ClickWebObject(benefitPlanIdField);
			benefitPlanIdField.sendKeys(BenefitPlanId);
			OneframeLogger("The Benefit Plan Id is : " + benefitPlanIdField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}	

	@Step("Verify Filter Results are dsiplayed")
	public boolean filterResults()  {
		boolean bln = false;
		ClickWebObject(txtSourceSystem);
		for(int i=0; i<lstFilterResults.size(); i++) {
			OneframeLogger("row: "+(i+1)+" : "+ lstFilterResults.get(i).getText() );
			bln = true;
		}
		return bln;
	}	

	@Step("Click on Add Contract Codes")
	public void clickonAddContractCodesBtn() {
		try {
			if (ObjectExist(btnAddContractCodes)) {
				ClickWebObject(btnAddContractCodes);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Add Contract Codes Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Contract Codes Button is not Clicked");
		}
	}

	@Step("Verify Add Contract Codes header is displayed")
	public boolean verifyAddContractCodesHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAddContractCodes)) {
			if (hdrAddContractCodes.getText().equalsIgnoreCase("Add Contract Codes")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Enter Source System")
	public boolean enterSourceSystem(String SourceSystem) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(sourceSystemField)) {
			ClickWebObject(sourceSystemField);
			sourceSystemField.sendKeys(SourceSystem);
			OneframeLogger("The Source System is : " + sourceSystemField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Enter Contract Platform")
	public boolean enterContractPlatform(String ContractPlatform) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(contractPlatformField)) {
			ClickWebObject(contractPlatformField);
			contractPlatformField.sendKeys(ContractPlatform);
			OneframeLogger("The Contract Platform is : " + contractPlatformField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}



	@Step("Enter Contract Effective Date")
	public boolean enterContractEffectiveDate(String EffectiveDate) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(contractEffectiveDateField)) {
			ClickWebObject(contractEffectiveDateField);
			contractEffectiveDateField.sendKeys(EffectiveDate);
			OneframeLogger("The Contract Effective Date is : " + contractEffectiveDateField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}


	@Step("Enter Contract Term Date")
	public boolean enterContractTermDate(String TermDate) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(contractTermDateField)) {
			ClickWebObject(contractTermDateField);
			contractTermDateField.sendKeys(TermDate);
			OneframeLogger("The Contract Term Date is : " + contractTermDateField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}


	@Step("Enter Benefit Plan ID")
	public boolean enterBenefitPlanID(String EnterBenefitPlanId) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(enterBenefitPlanIdField)) {
			ClickWebObject(enterBenefitPlanIdField);
			enterBenefitPlanIdField.sendKeys(EnterBenefitPlanId);
			OneframeLogger("The Benefit Plan ID is : " + enterBenefitPlanIdField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Enter Benefit Plan Version")
	public boolean enterBenefitPlanVersion(String BenefitPlanVersion) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(benefitPlanVersionField)) {
			ClickWebObject(benefitPlanVersionField);
			benefitPlanVersionField.sendKeys(BenefitPlanVersion);
			OneframeLogger("The Benefit Plan ID is : " + benefitPlanVersionField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Enter Plan Effective Date")
	public boolean enterPlanEffectiveDate(String PlanEffectiveDate) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(planEffectiveDateField)) {
			ClickWebObject(planEffectiveDateField);
			planEffectiveDateField.sendKeys(PlanEffectiveDate);
			OneframeLogger("The Benefit Plan ID is : " + planEffectiveDateField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Click on Add Contract Codes button")
	public void submitAddContractCodesBtn() throws InterruptedException {
		try {

			WaitForApplicationToLoadCompletely();
			if (ObjectExist(btnSubmitAddContractCodes)) {
				ClickWebObject(btnSubmitAddContractCodes);
				//WaitForApplicationToLoadCompletely();
				OneframeLogger("Add Contract Codes Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Contract Codes Button is not Clicked");
		}
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 1000;
		int max = 9999;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	public boolean enterContractCodetoAddContract(String EnterContractCode) {
		boolean bln = false;
		if (WaitForObject(enterContractCodeField)) {
			ClickWebObject(enterContractCodeField);
			int randomNumber = getRandomNumber();
			String contractCode = EnterContractCode + randomNumber;
			enterContractCodeField.sendKeys(contractCode);
			OneframeLogger("The Contract Code is : " + enterContractCodeField.getAttribute("value"));
			bln = true;
		}
		return bln;
	} 

	@Step("Verify Filter Results are dsiplayed")
	public void ClickcontractcodeSearchResults()  {

		ClickWebObject(txtSourceSystem);
		ClickWebObject(lstFilterResults.get(0));
		OneframeLogger("Clicked on first Contract Code " );		

	}	

	@Step("Click on Filter Button")
	public void clickonEditBtn() {
		try {
			if (ObjectExist(btnEdit)) {
				ClickWebObject(btnEdit);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Edit Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Edit Button is not Clicked");
		}
	} 	

	public boolean editSourceSystemValue() {
		boolean bln = false;
		if (WaitForObject(sourceSystemField)) {
			ClickWebObject(sourceSystemField);
			sourceSystemField.sendKeys(Keys.CONTROL + "a");

			sourceSystemField.sendKeys(Keys.DELETE);

			String SourceSystemValue = "AUTO";
			int randomNumber = getRandomNumber();
			String Sourcesystem = SourceSystemValue + randomNumber;
			sourceSystemField.sendKeys(Sourcesystem);
			OneframeLogger("The Source system value is : " + sourceSystemField.getAttribute("value"));
			bln = true;
		}
		return bln;
	} 	

	public boolean editContractPlatformValue() {
		boolean bln = false;
		if (WaitForObject(contractPlatformField)) {
			ClickWebObject(contractPlatformField);
			contractPlatformField.sendKeys(Keys.CONTROL + "a");
			contractPlatformField.sendKeys(Keys.DELETE);				
			String ContractPlatformValue = "AUTO";
			int randomNumber = getRandomNumber();
			String ContractPlatfrom = ContractPlatformValue + randomNumber;
			contractPlatformField.sendKeys(ContractPlatfrom);
			OneframeLogger("The Contract Platform value is : " + contractPlatformField.getAttribute("value"));
			bln = true;
		}
		return bln;
	} 	
	@Step("Get Random Calander")
	public String getRandomCalender() {

		int mindate = 01;
		int maxdate = 27;
		int minmonth = 01;
		int maxmonth = 12;
		int minyear = 2000;
		int maxyear = 2015;
		int b = (int) (Math.random() * (maxdate - mindate + 1) + mindate);
		int c = (int) (Math.random() * (maxmonth - minmonth + 1) + minmonth);
		int d = (int) (Math.random() * (maxyear - minyear + 1) + minyear);
		String Date = c+"/"+b+"/"+d;
		return Date;
	} 

	public boolean editPlanEffectiveDate() {
		boolean bln = false;
		if (WaitForObject(editPlanEffectiveDate)) {
			ClickWebObject(editPlanEffectiveDate);
			editPlanEffectiveDate.sendKeys(Keys.CONTROL + "a");
			editPlanEffectiveDate.sendKeys(Keys.DELETE);				
			String Date = getRandomCalender();
			editPlanEffectiveDate.sendKeys(Date);
			OneframeLogger("The Plan Effective Date value is : " + editPlanEffectiveDate.getAttribute("value"));
			bln = true;
		}
		return bln;
	} 		

	@Step("Click on Filter Button")
	public void ClickSaveChangesbtn() {
		try {
			if (ObjectExist(btnSaveChanges)) {
				ClickWebObject(btnSaveChanges);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Save Changes Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Save Changes Button is not Clicked");
		}
	} 

	@Step("Click on Export Button")
	public void clickonExportBtn() {
		try {
			if (ObjectExist(btnExport)) {
				ClickWebObject(btnExport);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Export Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Export Button is not Clicked");
		}
	}

	public boolean validateFileName() throws InterruptedException {
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		String fileName = "Contract Code Association Extract ";
		String fullFileName = fileName + date + ".csv";
		hdrContractCodes.click();
		hdrContractCodes.click();
		hdrContractCodes.click();
		hdrContractCodes.click();
		File dir = new File(System.getProperty("user.dir")+"\\src\\test\\resources\\RunTime");
		File[] dirContents = dir.listFiles();

		  for (int i = 0; i < dirContents.length; i++) {
		      if (dirContents[i].getName().equals(fullFileName)) {
		    	  OneframeLogger("Downloaded file name matched with expected file name");
		          dirContents[i].delete();
		          OneframeLogger("Deleted the downloaded file: " +dirContents[i].getName());
		          return true;
		      }
		  }
		
		  return false;
	}

	public boolean validateNumberOfRows() {
		hdrContractCodes.click();
		hdrContractCodes.click();
		hdrContractCodes.click();
		hdrContractCodes.click();
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		String fileName = "Contract Code Association Extract " + date + ".csv";
		CSVFile csvFile2 = new CSVFile("RunTime", fileName);
		int actualRowCount = csvFile2.OpenFile().getTotalRowCount() - 1;
		
		if(WaitForObject(txtPagination)) {
			String[] pagination = txtPagination.getText().trim().split(" ");
			int expectedRowCount = Integer.parseInt(pagination[4]);
			
			if(actualRowCount == expectedRowCount) {
				return true;
			}
		}
		csvFile2.CloseFile();
		return false;
	}
	
	@Step("Get first Contract Code value")
	public String getFirstRecordContractCodeValue() {
		ClickWebObject(hdrContractCodes);
		ClickWebObject(hdrContractCodes);
		if(WaitForObjectVisibility(lstContractCodes.get(0))) {
		highlightElement(lstContractCodes.get(0));
		}
		return lstContractCodes.get(0).getText();
		}
	
	@Step("Enter a value in Search bar")
	public boolean enterValueinSearch (String value) throws Throwable {
		boolean blnRC = false;
		Robot robot;
		try {
			if(WaitForObjectVisibility(txtSearch)) {
			   ClickWebObject(txtSearch);
			   EnterText(txtSearch, value);
			   OneframeLogger("The Contract Code has been Entered  " +value);
			   robot = new Robot();
			   robot.keyPress(KeyEvent.VK_ENTER);
			   robot.keyRelease(KeyEvent.VK_ENTER);
			   blnRC= true;
			}else {
				blnRC= false;
			}				
		}catch(NoSuchElementException NSE) {
			blnRC= false;
		}
		return blnRC;
	}
	
	public void clickContractHeader() {
		ClickWebObject(hdrContractCodes);
		ClickWebObject(hdrContractCodes);
		ClickWebObject(hdrContractCodes);
	}

	
	
	@Step("Verify Contract Code has matched as Expected")
	public boolean verifyContractCode(String contractCode) {
		boolean blnRC = false;
		clickContractHeader();
		try {
			for (int i = 0; i < lstContractCodes.size(); i++) {
				if (WaitForObjectVisibility(lstContractCodes.get(i))
						&& lstContractCodes.get(i).getText().equals(contractCode))
					highlightElement(lstContractCodes.get(i));
				OneframeLogger("The Actual Contract Code " + contractCode + " matched with expected Contract Code "
						+ lstContractCodes.get(i).getText());
				blnRC = true;
			}
		} catch (Exception e) {
		}
		return blnRC;
	}

	
	
}

package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateEditSpecialtyTabCostShareDropdownValues extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validate Edit Specialty tab Cost Share dropdown values")
	public void setUp() {
		InitializeLaunchPad("IBPW_546");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ProgramName", "CostShareOverride", "DropDownValues" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit Specialty tab Cost Share dropdown values", dataProvider = "TestData")
	@Description("Validate Edit Specialty tab Cost Share dropdown values")
	public void ValidateCostOfCareEditAndCancelFunctionality(String TestCaseID, String TestStatus, String ProgramName,
			String CostShareOverride, String DropDownValues) throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");

			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "Verified 'Programs' header");
			librariesprogramspage.clickOnSpeciality();
			librariesprogramspage.clickProgramsHeader();
			sa.assertTrue(librariesprogramspage.verifyAndClickProgramName(ProgramName),
					"Verified and clicked Program name");
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");

			sa.assertTrue(librariesprogramspage.verifyCostShareTabIsEnabledAndClicked(CostShareOverride),
					"Verified Cost Share tab is Enabled and clicked");

			librariesprogramspage.clickCustomSteppingToggle();
			sa.assertTrue(librariesprogramspage.verifyCostShareTabINNRetailDropdownValue(DropDownValues),
					"Validated  INN Retail Dropdown values is same as expected");
			sa.assertTrue(librariesprogramspage.verifyCostShareTabINNHomeDeliveryDropdownValue(DropDownValues),
					"Validated INN Home Delivery Dropdown values is same as expected");
			sa.assertTrue(librariesprogramspage.verifyCostShareTabONNRetailDropdownValue(DropDownValues),
					"Validated ONN Retail Dropdown values is same as expected");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit Specialty tab Cost Share dropdown values is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Edit Specialty tab Cost Share dropdown values");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

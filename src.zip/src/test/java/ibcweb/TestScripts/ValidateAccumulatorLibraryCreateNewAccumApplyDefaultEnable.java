package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesAccumulatorStructures;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumulatorLibraryCreateNewAccumApplyDefaultEnable extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesAccumulatorStructures librariesaccumulatorpage;

	@BeforeClass
	@Step("Initializing Test Script for Validating user is able to create the new accum structure along with apply default enable")
	public void setUp() {
		InitializeLaunchPad("IBPW_705");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesaccumulatorpage = new IBPLibrariesAccumulatorStructures();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","EffectiveDate","TermDate"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate user is able to create the new accum structure  along with  apply default enable", dataProvider = "TestData")
	@Description("Validate user is able to create the new accum structure  along with  apply default enable")
	public void ValidateEditNetworkNetworkLibrary(String TestCaseID, String TestStatus,String EffectiveDate,String TermDate)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesaccumulatorpage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			librariesaccumulatorpage.clickViewButtonOfAccumulatorStructures();
			sa.assertTrue(librariesaccumulatorpage.verifyAccumulatorStructuresHeader(),
					"Verified 'Accumulator Structures header' is displayed");
			librariesaccumulatorpage.clickAccumulatorStructuresTab();
			librariesaccumulatorpage.clickAccumulatorStructuresButton();
			sa.assertTrue(librariesaccumulatorpage.verifyAddAccumulatorStructureHeader(),
					"Verified 'Add New Accum Structure' header is Displayed");
	        String accumName = librariesaccumulatorpage.EnterAccumStructureName();		
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			librariesaccumulatorpage.EnterTermDate(TermDate);
			librariesaccumulatorpage.selectClientDropdown();
			librariesaccumulatorpage.selectLOBDropdown();
			librariesaccumulatorpage.selectStateDropdown();
			sa.assertTrue(librariesaccumulatorpage.verifyApplyDefaultsHeader(),
					"Verified 'Apply Defaults' header is Displayed");
			sa.assertTrue(librariesaccumulatorpage.clickCDHPToggle(),
					"Verified and clicked on Apply CDHP Toggle");
			librariesaccumulatorpage.clickCDHPTab();
			sa.assertTrue(librariesaccumulatorpage.selectFundedByDropdown(),
					"Verified and Selected Option from Funded By Dropdown");
			sa.assertTrue(librariesaccumulatorpage.selectPayerIDDropdown(),
					"Verified and Selected Option from Payer ID Dropdown");
			librariesaccumulatorpage.clickAddAccumButton();
			sa.assertTrue(librariesaccumulatorpage.VerifyAccumIsCreated(accumName),
					"Verified the 'New Accum' is created and present in the Accum List");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate user is able to create the new accum structure along with apply default enable Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to user is able to create the new accum structure along with apply default enable");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

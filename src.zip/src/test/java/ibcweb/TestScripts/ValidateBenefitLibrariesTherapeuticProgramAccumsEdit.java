package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBenefitProgramsPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsCostOfCare;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesTherapeuticProgramAccumsEdit extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;
	IBPLibrariesBaseFormularies baseFormulary;
	IBPBenefitProgramsPage benefitProgramsPage;
	IBPLibrariesProgramsCostOfCare costOfCare;

	@BeforeClass
	@Step("Initializing Test Script for Validate Edit Therapeutic Program Accums tab content")
	public void setUp() {
		InitializeLaunchPad("IBPW_513");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();
		baseFormulary = new IBPLibrariesBaseFormularies();
		benefitProgramsPage = new IBPBenefitProgramsPage();
		costOfCare = new IBPLibrariesProgramsCostOfCare();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit Therapeutic Program Accums tab content", dataProvider = "TestData")
	@Description("Validate Edit Therapeutic Program Accums tab content")
	public void ValidateEditTherapeuticAccumsTab(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			//librariesprogramspage.clickCostofCareofPrograms();
			benefitProgramsPage.clickonExistingTherapeuticProgram();
			librariesprogramspage.clickAccumTab();
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(),"Verified and clicked Edit Button");	
			sa.assertTrue(librariesprogramspage.selectProgramAccumDropdown(),"Verified Program Accum drop down value is selected");	
			librariesprogramspage.clickApplyMedicaltxt();
			librariesprogramspage.clickonApplyPrmgmDedToggle();
			librariesprogramspage.enterINNRetailDed();
			librariesprogramspage.enterHomeDlvryDed();
			librariesprogramspage.enterONNRetailDed();
			librariesprogramspage.enterINNRetailDedFamily();
			librariesprogramspage.enterHomeDlvryDedFamily();
			librariesprogramspage.enterONNRetailDedFamily();
			sa.assertTrue(librariesprogramspage.selectINNDedDropdown(),"Verified INN Retail plan level deductible drop down value is selected");	
			sa.assertTrue(librariesprogramspage.selectINNHomeDedDropdown(),"Verified INN Home plan level deductible drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectONNRetailDedDropdown(),"Verified ONN Retail plan level deductible drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectINNMedDropdown(),"Verified INN Retail Integrated Medical deductible drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectINNHomeMedDropdown(),"Verified INN Home Integrated Medical deductible drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectONNRetailMedDropdown(),"Verified ONN Retail Integrated Medical deductible drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectDedBucketsDropdown(),"Verified Deductible Buckets Accumulate drop down value is selected");
			librariesprogramspage.clickonApplyPrmgmMoPToggle();
			librariesprogramspage.enterINNRetailMoP();
			librariesprogramspage.enterHomeDlvryMoP();
			librariesprogramspage.enterONNRetailMoP();
			librariesprogramspage.enterINNRetailMoPFamily();
			librariesprogramspage.enterHomeDlvryMoPFamily();
			librariesprogramspage.enterONNRetailMoPFamily();
			sa.assertTrue(librariesprogramspage.selectINNDedMoPDropdown(),"Verified INN Retail plan level MoP drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectINNHomeDedMoPDropdown(),"Verified INN Home plan level MoP drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectONNRetailDedMoPDropdown(),"Verified ONN Retail plan level MoP drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectINNMedMoPDropdown(),"Verified INN Retail Integrated Medical MoP drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectINNHomeMedMoPDropdown(),"Verified INN Home Integrated Medical MoP drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectONNRetailMedMoPDropdown(),"Verified ONN Retail Integrated Medical MoP drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectCostShareMoPDropdown(),"Verified Cost Share MoP drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectMoPBucketsDropdown(),"Verified MoP Buckets Accumulate drop down value is selected");
			librariesprogramspage.clickonApplyPrmgmPSLToggle();
			librariesprogramspage.enterINNRetailPSL();
			librariesprogramspage.enterHomeDlvryPSL();
			librariesprogramspage.enterONNRetailPSL();
			librariesprogramspage.enterINNRetailPSLFamily();
			librariesprogramspage.enterHomeDlvryPSLFamily();
			librariesprogramspage.enterONNRetailPSLFamily();
			sa.assertTrue(librariesprogramspage.selectINNDedPSLDropdown(),"Verified INN Retail plan level PSL drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectINNHomeDedPSLDropdown(),"Verified INN Home plan level PSL drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectONNRetailDedPSLDropdown(),"Verified ONN Retail plan level PSL drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectINNMedPSLDropdown(),"Verified INN Retail Integrated Medical PSL drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectINNHomeMedPSLDropdown(),"Verified INN Home Integrated Medical PSL drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectONNRetailMedPSLDropdown(),"Verified ONN Retail Integrated Medical PSL drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectCostSharePSLDropdown(),"Verified Cost Share PSL drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectPSLBucketsDropdown(),"Verified PSL Buckets Accumulate drop down value is selected");
			sa.assertTrue(librariesprogramspage.selectBenefitPeriodDropdown(),"Verified Benefit Period drop down value is selected");
			librariesprogramspage.clickCostofcareCancelButton();
			librariesprogramspage.clickLeaveButton();
			benefitProgramsPage.clickDownArrowButton();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit Therapeutic Program Accums tab content Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Edit Therapeutic Program Accums tab content");
		}

		homepage.clickLogout();
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

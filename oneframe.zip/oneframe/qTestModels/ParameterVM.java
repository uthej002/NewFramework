// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ParameterVM
{
    @JsonProperty("parameterId")
    private Long parameterId;
    @JsonProperty("id")
    private String id;
    @JsonProperty("startIndex")
    private Integer startIndex;
    @JsonProperty("endIndex")
    private Integer endIndex;
    @JsonProperty("startWithoutPrefixIndex")
    private Integer startWithoutPrefixIndex;
    @JsonProperty("endWithoutSuffixIndex")
    private Integer endWithoutSuffixIndex;
    @JsonProperty("parameterName")
    private String parameterName;
    
    public ParameterVM() {
        this.parameterId = null;
        this.id = null;
        this.startIndex = null;
        this.endIndex = null;
        this.startWithoutPrefixIndex = null;
        this.endWithoutSuffixIndex = null;
        this.parameterName = null;
    }
    
    public ParameterVM parameterId(final Long parameterId) {
        this.parameterId = parameterId;
        return this;
    }
    
    public Long getParameterId() {
        return this.parameterId;
    }
    
    public void setParameterId(final Long parameterId) {
        this.parameterId = parameterId;
    }
    
    public ParameterVM id(final String id) {
        this.id = id;
        return this;
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public ParameterVM startIndex(final Integer startIndex) {
        this.startIndex = startIndex;
        return this;
    }
    
    public Integer getStartIndex() {
        return this.startIndex;
    }
    
    public void setStartIndex(final Integer startIndex) {
        this.startIndex = startIndex;
    }
    
    public ParameterVM endIndex(final Integer endIndex) {
        this.endIndex = endIndex;
        return this;
    }
    
    public Integer getEndIndex() {
        return this.endIndex;
    }
    
    public void setEndIndex(final Integer endIndex) {
        this.endIndex = endIndex;
    }
    
    public ParameterVM startWithoutPrefixIndex(final Integer startWithoutPrefixIndex) {
        this.startWithoutPrefixIndex = startWithoutPrefixIndex;
        return this;
    }
    
    public Integer getStartWithoutPrefixIndex() {
        return this.startWithoutPrefixIndex;
    }
    
    public void setStartWithoutPrefixIndex(final Integer startWithoutPrefixIndex) {
        this.startWithoutPrefixIndex = startWithoutPrefixIndex;
    }
    
    public ParameterVM endWithoutSuffixIndex(final Integer endWithoutSuffixIndex) {
        this.endWithoutSuffixIndex = endWithoutSuffixIndex;
        return this;
    }
    
    public Integer getEndWithoutSuffixIndex() {
        return this.endWithoutSuffixIndex;
    }
    
    public void setEndWithoutSuffixIndex(final Integer endWithoutSuffixIndex) {
        this.endWithoutSuffixIndex = endWithoutSuffixIndex;
    }
    
    public ParameterVM parameterName(final String parameterName) {
        this.parameterName = parameterName;
        return this;
    }
    
    public String getParameterName() {
        return this.parameterName;
    }
    
    public void setParameterName(final String parameterName) {
        this.parameterName = parameterName;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ParameterVM parameterVM = (ParameterVM)o;
        return Objects.equals(this.parameterId, parameterVM.parameterId) && Objects.equals(this.id, parameterVM.id) && Objects.equals(this.startIndex, parameterVM.startIndex) && Objects.equals(this.endIndex, parameterVM.endIndex) && Objects.equals(this.startWithoutPrefixIndex, parameterVM.startWithoutPrefixIndex) && Objects.equals(this.endWithoutSuffixIndex, parameterVM.endWithoutSuffixIndex) && Objects.equals(this.parameterName, parameterVM.parameterName);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.parameterId, this.id, this.startIndex, this.endIndex, this.startWithoutPrefixIndex, this.endWithoutSuffixIndex, this.parameterName);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class ParameterVM {\n");
        sb.append("    parameterId: ").append(this.toIndentedString(this.parameterId)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    startIndex: ").append(this.toIndentedString(this.startIndex)).append("\n");
        sb.append("    endIndex: ").append(this.toIndentedString(this.endIndex)).append("\n");
        sb.append("    startWithoutPrefixIndex: ").append(this.toIndentedString(this.startWithoutPrefixIndex)).append("\n");
        sb.append("    endWithoutSuffixIndex: ").append(this.toIndentedString(this.endWithoutSuffixIndex)).append("\n");
        sb.append("    parameterName: ").append(this.toIndentedString(this.parameterName)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesDrugExceptionsTabContent extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPBenefitFormularyPage librariesFormularyPage;

	@BeforeClass
	@Step("Initializing Test Script for validating Benefit Libraries Drug Exceptions Tab Content")
	public void setUp() {
		InitializeLaunchPad("IBPW_413");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		librariesFormularyPage = new IBPBenefitFormularyPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefit Libraries Drug Exceptions Tab Content", dataProvider = "TestData")
	@Description("Validate Benefit Libraries Drug Exceptions Tab Content")
	public void ValidateLibrariesDrugExceptionsTab(String TestCaseID, String TestStatus)throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesFormularyPage.clickViewButtonofFormularies();
			librariesFormularyPage.clickDrugExceptionsButton();
			librariesFormularyPage.clickCreateDrugExceptionButton();
			sa.assertTrue(librariesFormularyPage.verifyCreateADrugExceptionListHeader(),"Verified Create A Drug exception list header is displayed");
			sa.assertTrue(librariesFormularyPage.verifyListDataHeader(),"Verified List Data header is displayed");
			sa.assertTrue(librariesFormularyPage.verifyCVSCodeText(),"Verified CVS code text is displayed");
			sa.assertTrue(librariesFormularyPage.verifyDrugListNameText(),"Verified Drug List Name is displayed");
			sa.assertTrue(librariesFormularyPage.verifyDrugListDescText(),"Verified Drug List Description is displayed");
			sa.assertTrue(librariesFormularyPage.verifyManagedByText(),"Verified Managed By is displayed");
			sa.assertTrue(librariesFormularyPage.verifyAdjSysStatusText(),"Verified Adj. Sys Status is displayed");
			sa.assertTrue(librariesFormularyPage.verifyEffectiveDateText(),"Verified Effective Date is displayed");
			sa.assertTrue(librariesFormularyPage.verifyTerminationDateText(),"Verified Termination Date is displayed");
			sa.assertTrue(librariesFormularyPage.verifyClientText(),"Verified Client text is displayed");
			sa.assertTrue(librariesFormularyPage.verifyLOBText(),"Verified LOB is displayed");
			sa.assertTrue(librariesFormularyPage.verifyStateText(),"Verified State is displayed");
			sa.assertTrue(librariesFormularyPage.verifyManagedByText(),"Verified Managed By is displayed");
			librariesFormularyPage.verifyDrugExceptionManagedByDropdownValues();
			librariesFormularyPage.verifyAdjSysStatusDropdownValues();
			librariesFormularyPage.clickAddDrugExceptionListbutton();
			librariesFormularyPage.clickCancelButtonofEditFormularies();
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Benefit Libraries Drug Exceptions Tab Content Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Benefit Libraries Drug Exceptions Tab Content");
		}

      homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

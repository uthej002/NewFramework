package com.ibc.pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ibc.base.PageBase;

public class CreateBenefitPage extends PageBase {
    // Page Elements
	@FindBy(xpath = "//span[normalize-space()='Client']/../..//mat-select")
	WebElement arrowClient;
	
	@FindBy(xpath = "//div[contains(@class, 'mat-select-panel-wrap')]/div")
	WebElement drd;
	
    public CreateBenefitPage(){
        super();
        PageFactory.initElements(driver, this);
    }

   public void CreateABenefit() {
	   waitForElementToBeClickable(arrowClient);
	   clickElement(arrowClient);
	   pressEnterOnElement(arrowClient, Keys.ESCAPE);
	   //selectFromDropdown(drd, "Anthem");
   }
   
   
   
}


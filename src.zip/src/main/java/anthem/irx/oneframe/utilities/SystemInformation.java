package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeContainer;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class SystemInformation {
  public static String SystemName = null;
  
  public static String CanonicalSystemName = null;
  
  public static String HostAddress = null;
  
  public static String username = null;
  
  public static String OSName = null;
  
  public static String OSArchicture = null;
  
  public static String OSVersion = null;
  
  public static String JavaVersion = null;
  
  public SystemInformation() {
    try {
      username = System.getProperty("user.name");
      OSName = System.getProperty("os.name");
      OSArchicture = System.getProperty("os.arch");
      OSVersion = System.getProperty("os.version");
      SystemName = InetAddress.getLocalHost().getHostName();
      CanonicalSystemName = InetAddress.getLocalHost().getCanonicalHostName();
      HostAddress = InetAddress.getLocalHost().getHostAddress();
      JavaVersion = System.getProperty("java.version");
    } catch (UnknownHostException e) {
      e.printStackTrace();
    } 
  }
  
  public void printSystemInformation() {
    OneframeContainer.OneframeLogger("OS Name - " + OSName);
    OneframeContainer.OneframeLogger("OS Architecture - " + OSArchicture);
    OneframeContainer.OneframeLogger("OS Version - " + OSVersion);
    OneframeContainer.OneframeLogger("User Name - " + username);
    OneframeContainer.OneframeLogger("System Name - " + SystemName);
    OneframeContainer.OneframeLogger("IP Address - " + HostAddress);
    OneframeContainer.OneframeLogger("Java Version - " + JavaVersion);
  }
}

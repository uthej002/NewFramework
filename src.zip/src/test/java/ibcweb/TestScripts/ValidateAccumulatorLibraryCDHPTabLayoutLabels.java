package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesAccumulatorStructures;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumulatorLibraryCDHPTabLayoutLabels extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesAccumulatorStructures librariesaccumulatorpage;
	IBPAccumsBenefitPage accumsPage;
	IBPBenefitFormularyPage librariesFormularyPage;
	IBPLibrariesProgramsPage librariesprogramspage;

	@BeforeClass
	@Step("Initializing Test Script for Validate Accumulator Structure CDHP Tab Labels")
	public void setUp() {
		InitializeLaunchPad("IBPW_329");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesaccumulatorpage = new IBPLibrariesAccumulatorStructures();
		accumsPage = new IBPAccumsBenefitPage();
		librariesFormularyPage = new IBPBenefitFormularyPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Accumulator Structure CDHP Tab Labels", dataProvider = "TestData")

	@Description("Validate Accumulator Structure CDHP Tab Labels")
	public void ValidateAccumlatorStructreCDHPLabels(String TestCaseID, String TestStatus)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesaccumulatorpage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			librariesaccumulatorpage.clickViewButtonOfAccumulatorStructures();
			sa.assertTrue(librariesaccumulatorpage.verifyAccumulatorStructuresHeader(),
					"Verified 'Accumulator Structures header' is displayed");
			librariesaccumulatorpage.clickAccumulatorStructuresTab();
			librariesaccumulatorpage.clickonExistingAccumStructureCDHP();
			librariesaccumulatorpage.clickCDHPTab();
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("CDHP"), "Validated text CDHP is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Funded By"), "Validated text Funded By is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Payer ID"), "Validated text Payer ID is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("HRA Benefit"), "Validated text HRA Benefit is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("HRA applies to Pharmacy"), "Validated text HRA applies to Pharmacy is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Upfront deductible applies?"), "Validated text Upfront deductible applies? is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Apply HRA ($)"), "Validated text Apply HRA ($) is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Cross UFDED and Deductible Process"), "Validated text Cross UFDED and Deductible Process is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Split HRA"), "Validated text Split HRA is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Upfront Deductible"), "Validated text Upfront Deductible is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Deductible"), "Validated text Deductible is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("OOP"), "Validated text OOP is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Daw Penalty"), "Validated text Daw Penalty is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyFundedBydrpDwndisplayed(),"Validated Funded By dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyPayerIDdrpDwndisplayed(),"Validated Payer ID dropdown is displayed");
			librariesaccumulatorpage.clickHRABenefitCheckBox();
			sa.assertTrue(librariesaccumulatorpage.verifyHRAAppliestoPharmacydrpDwndisplayed(),"Validated HRA applies to Pharmacy dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyApplyUpfrontDeductibledrpDwndisplayed(),"Validated Apply Upfront Deductible dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyUpfrontDeductibledrpDwndisplayed(),"Validated Upfront Deductible dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyDeductibledrpDwndisplayed(),"Validated Deductible dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyapplyHraOopdrpDwndisplayed(),"Validated Apply HRA OOP dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyapplyHraDawdrpDwndisplayed(),"Validated Apply HRA Daw dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyCrossUfdeddrpDwndisplayed(),"Validated Cross UFDED Deductible Process dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifySplitHRAdrpDwndisplayed(),"Validated Split HRA dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifySplitHRAValuedisplayed(),"Validated Split HRA input Value field is displayed");
			librariesaccumulatorpage.clickAccumStructureCancelButton();
			librariesprogramspage.clickLeaveButton();
			librariesFormularyPage.clickDownArrowButton();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Accumulator Structure CDHP Tab Labels Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Accumulator Structure CDHP Tab Labels");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import org.monte.media.Registry;
import java.awt.AWTException;
import java.io.IOException;
import java.io.File;
import org.monte.media.Format;
import java.awt.Rectangle;
import java.awt.GraphicsConfiguration;
import org.monte.screenrecorder.ScreenRecorder;

public class MonteScreenRecorder extends ScreenRecorder
{
    private String testScenarioID;
    private String testScriptName;
    
    public MonteScreenRecorder(final GraphicsConfiguration cfg, final Rectangle captureArea, final Format fileFormat, final Format screenFormat, final Format mouseFormat, final Format audioFormat, final File movieFolder) throws IOException, AWTException {
        super(cfg, captureArea, fileFormat, screenFormat, mouseFormat, audioFormat, movieFolder);
    }
    
    public void setTestScenarioID(final String testScenarioID) {
        this.testScenarioID = testScenarioID;
    }
    
    public void setScriptName(final String testScriptName) {
        this.testScriptName = testScriptName;
    }
    
    protected File createMovieFile(final Format fileFormat) throws IOException {
        if (!this.movieFolder.exists()) {
            this.movieFolder.mkdirs();
        }
        else if (!this.movieFolder.isDirectory()) {
            throw new IOException("\"" + this.movieFolder + "\" is not a directory.");
        }
        final File dateFolder = new File(this.movieFolder + "\\" + DateTimeProcessor.getCurrentDate());
        if (!dateFolder.exists()) {
            dateFolder.mkdirs();
        }
        else if (!dateFolder.isDirectory()) {
            throw new IOException("\"" + dateFolder + "\" is not a directory.");
        }
        if (this.testScriptName.length() > 35) {
            this.testScriptName = this.testScriptName.substring(0, 35);
        }
        final File f = new File(dateFolder, this.testScenarioID + "_" + this.testScriptName + "_" + DateTimeProcessor.getCurrentDateTime("MMdd_HHmmss") + "." + Registry.getInstance().getExtension(fileFormat));
        return f;
    }
}

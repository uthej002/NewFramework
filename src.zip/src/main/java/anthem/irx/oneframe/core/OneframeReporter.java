package anthem.irx.oneframe.core;

import anthem.irx.oneframe.utilities.FileOpsHelper;
import anthem.irx.oneframe.utilities.SystemInformation;
import com.aventstack.extentreports.AnalysisStrategy;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.observer.ExtentObserver;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;
import java.io.File;

public class OneframeReporter {
  ExtentReports ExtentReport;
  
  ExtentSparkReporter oneframeSpark;
  
  ExtentTest Logger;
  
  public OneframeReporter createExtentReport(String ReportName) {
    SystemInformation sysinfo = new SystemInformation();
    this.ExtentReport = new ExtentReports();
    this.oneframeSpark = new ExtentSparkReporter(getExtentReportHtmlFileName(ReportName));
    this.ExtentReport.setAnalysisStrategy(AnalysisStrategy.TEST);
    this.ExtentReport.setSystemInfo("Browser", OneframeContainer.TSBrowser);
    this.ExtentReport.setSystemInfo("Environment", OneframeContainer.TSExecEnvironment);
    this.ExtentReport.setSystemInfo("Platform", SystemInformation.OSName);
    this.ExtentReport.setSystemInfo("OS Version", SystemInformation.OSVersion);
    this.ExtentReport.setSystemInfo("Host Name", SystemInformation.SystemName);
    this.ExtentReport.setSystemInfo("IP Address", SystemInformation.HostAddress);
    this.ExtentReport.setSystemInfo("Java Version", SystemInformation.JavaVersion);
    this.oneframeSpark.config().setTheme(Theme.STANDARD);
    this.oneframeSpark.config().setReportName(ReportName);
    this.oneframeSpark.config().setTimelineEnabled(true);
    this.oneframeSpark.config().setTimeStampFormat("dd/MM/yyyy HH:mm:ss");
    this.oneframeSpark.config().setDocumentTitle("Sample Document");
    this.oneframeSpark.config().setProtocol(Protocol.HTTPS);
    MarkupHelper.createLabel("Pass Test", ExtentColor.GREEN);
    this.ExtentReport.attachReporter(new ExtentObserver[] { (ExtentObserver)this.oneframeSpark });
    return this;
  }
  
  private File getExtentReportHtmlFileName(String FileName) {
    return FileOpsHelper.createFile(FileOpsHelper.createTodaysLogFolder("ExtentReports"), FileName + ".html");
  }
  
  public void CreateTest(String testName, String testDescription) {
    this.Logger = this.ExtentReport.createTest(testName, testDescription);
  }
  
  public void LogInfoTestStep(String LogMessage) {
    this.Logger.log(Status.INFO, LogMessage);
  }
  
  public void LogPassTestStep(String LogMessage) {
    this.Logger.log(Status.PASS, LogMessage);
  }
  
  public void LogFailTestStep(String LogMessage) {
    this.Logger.log(Status.FAIL, LogMessage);
  }
  
  public void LogFailTestStep(String LogMessage, String base64Screenshot) {
    MediaEntityBuilder screenshot = MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot);
    this.Logger.log(Status.FAIL, LogMessage, screenshot.build());
  }
  
  public void CompleteTest(Status testStatus, String testName) {
    this.Logger.log(testStatus, testName);
  }
  
  public void FinishExtentReport() {
    this.ExtentReport.flush();
  }
  
  public static File getSourcePathTestNGemailableReport() {
    File source = new File(OneframeConstants.TESTOUTPUT_FOLDER + "emailable-report.html");
    return source;
  }
}

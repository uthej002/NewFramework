// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AutomationTestStepLog
{
    @JsonProperty("description")
    private String description;
    @JsonProperty("expected_result")
    private String expectedResult;
    @JsonProperty("actual_result")
    private String actualResult;
    @JsonProperty("order")
    private Integer order;
    @JsonProperty("status")
    private String status;
    @JsonProperty("attachments")
    private List<AttachmentResource> attachments;
    @JsonProperty("defects")
    private List<LinkedDefectResource> defects;
    
    public AutomationTestStepLog() {
        this.description = null;
        this.expectedResult = null;
        this.actualResult = null;
        this.order = null;
        this.status = null;
        this.attachments = new ArrayList<AttachmentResource>();
        this.defects = new ArrayList<LinkedDefectResource>();
    }
    
    public AutomationTestStepLog description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public AutomationTestStepLog expectedResult(final String expectedResult) {
        this.expectedResult = expectedResult;
        return this;
    }
    
    public String getExpectedResult() {
        return this.expectedResult;
    }
    
    public void setExpectedResult(final String expectedResult) {
        this.expectedResult = expectedResult;
    }
    
    public AutomationTestStepLog actualResult(final String actualResult) {
        this.actualResult = actualResult;
        return this;
    }
    
    public String getActualResult() {
        return this.actualResult;
    }
    
    public void setActualResult(final String actualResult) {
        this.actualResult = actualResult;
    }
    
    public AutomationTestStepLog order(final Integer order) {
        this.order = order;
        return this;
    }
    
    public Integer getOrder() {
        return this.order;
    }
    
    public void setOrder(final Integer order) {
        this.order = order;
    }
    
    public AutomationTestStepLog status(final String status) {
        this.status = status;
        return this;
    }
    
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(final String status) {
        this.status = status;
    }
    
    public AutomationTestStepLog attachments(final List<AttachmentResource> attachments) {
        this.attachments = attachments;
        return this;
    }
    
    public AutomationTestStepLog addAttachmentsItem(final AttachmentResource attachmentsItem) {
        this.attachments.add(attachmentsItem);
        return this;
    }
    
    public List<AttachmentResource> getAttachments() {
        return this.attachments;
    }
    
    public void setAttachments(final List<AttachmentResource> attachments) {
        this.attachments = attachments;
    }
    
    public AutomationTestStepLog defects(final List<LinkedDefectResource> defects) {
        this.defects = defects;
        return this;
    }
    
    public AutomationTestStepLog addDefectsItem(final LinkedDefectResource defectsItem) {
        this.defects.add(defectsItem);
        return this;
    }
    
    public List<LinkedDefectResource> getDefects() {
        return this.defects;
    }
    
    public void setDefects(final List<LinkedDefectResource> defects) {
        this.defects = defects;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final AutomationTestStepLog automationTestStepLog = (AutomationTestStepLog)o;
        return Objects.equals(this.description, automationTestStepLog.description) && Objects.equals(this.expectedResult, automationTestStepLog.expectedResult) && Objects.equals(this.actualResult, automationTestStepLog.actualResult) && Objects.equals(this.order, automationTestStepLog.order) && Objects.equals(this.status, automationTestStepLog.status) && Objects.equals(this.attachments, automationTestStepLog.attachments) && Objects.equals(this.defects, automationTestStepLog.defects);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.description, this.expectedResult, this.actualResult, this.order, this.status, this.attachments, this.defects);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class AutomationTestStepLog {\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("    expectedResult: ").append(this.toIndentedString(this.expectedResult)).append("\n");
        sb.append("    actualResult: ").append(this.toIndentedString(this.actualResult)).append("\n");
        sb.append("    order: ").append(this.toIndentedString(this.order)).append("\n");
        sb.append("    status: ").append(this.toIndentedString(this.status)).append("\n");
        sb.append("    attachments: ").append(this.toIndentedString(this.attachments)).append("\n");
        sb.append("    defects: ").append(this.toIndentedString(this.defects)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

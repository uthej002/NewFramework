package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesAccumulatorStructures;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumulatorLibraryDeductibleTabLayoutLabels extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesAccumulatorStructures librariesaccumulatorpage;
	IBPAccumsBenefitPage accumsPage;
	IBPBenefitFormularyPage librariesFormularyPage;
	IBPLibrariesProgramsPage librariesprogramspage;

	@BeforeClass
	@Step("Initializing Test Script for Validate Accumulator Structure deductible Tab Labels")
	public void setUp() {
		InitializeLaunchPad("IBPW_338");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesaccumulatorpage = new IBPLibrariesAccumulatorStructures();
		accumsPage = new IBPAccumsBenefitPage();
		librariesFormularyPage = new IBPBenefitFormularyPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Accumulator Structure deductible Tab Labels", dataProvider = "TestData")

	@Description("Validate Accumulator Structure deductible Tab Labels")
	public void ValidateAccumlatorStructreDeductibleLabels(String TestCaseID, String TestStatus)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesaccumulatorpage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			librariesaccumulatorpage.clickViewButtonOfAccumulatorStructures();
			sa.assertTrue(librariesaccumulatorpage.verifyAccumulatorStructuresHeader(),
					"Verified 'Accumulator Structures header' is displayed");
			librariesaccumulatorpage.clickAccumulatorStructuresTab();
			librariesaccumulatorpage.clickonExistingAccumStructure();
			librariesaccumulatorpage.clickDeductibleTab();
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			sa.assertTrue(librariesaccumulatorpage.verifyDifferentHomeDeliveryToggleDisplayed(),"Validated Different Home Delivery Toggle is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyOutandInNetworksToggleDisplayed(),"Validated Out of Network and In Network Toggle is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("MEMBERS"), "Validated text MEMBERS is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Individual"), "Validated text Individual is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Family"), "Validated text Family is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Number of Members to Meet Accum"), "Validated text Number of Members to Meet Accum is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Apply Integrated Medical?"), "Validated text Apply Integrated Medical? is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("How does INN and OON Accumulate"), "Validated text How does INN and OON Accumulate is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Deductible applies to OOP"), "Validated text Deductible applies to OOP is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Embedded"), "Validated text Deductible applies to OOP is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Deductible with PSL"), "Validated text Deductible applies to OOP is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Post Deductible"), "Validated text Deductible applies to OOP is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Last Quarter Rollover"), "Validated text Deductible applies to OOP is displayed");
			sa.assertTrue(librariesaccumulatorpage.validateAccumStructureLabels("Cross Network"), "Validated text Deductible applies to OOP is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyInNetworkFielddisplayed(),"Validated InNetwork Field is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyOutofNetworkFielddisplayed(),"Validated Out of Network Field is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyFamilyInNetworkFielddisplayed(),"Validated Family InNetwork Field is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyFamilyOutofNetworkFielddisplayed(),"Validated Family Out of Network Field is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyNumberofMembersdrpDwndisplayed(),"Validated Number of Members to Meet Accum dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyApplyIntegratedINNdrpDwndisplayed(),"Validated Apply Integrated Medical IN Network dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyApplyIntegratedOONdrpDwndisplayed(),"Validated Apply Integrated Medical Out of Network dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyHowINNOONAccumulatedrpDwndisplayed(),"Validated How does INN and OON Accumulate dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyDedAppliesOOPdrpDwndisplayed(),"Validated Deductible applies to OOP dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyEmbeddeddrpDwndisplayed(),"Validated Embedded dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyDedPSLdrpDwndisplayed(),"Validated Deductible with PSL dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyLastQuarterRolloverdrpDwndisplayed(),"Validated Last Quarter Rollover dropdown is displayed");
			sa.assertTrue(librariesaccumulatorpage.verifyCrossNetworkdrpDwndisplayed(),"Validated Cross Network dropdown is displayed");
			librariesaccumulatorpage.clickAccumStructureCancelButton();
			librariesprogramspage.clickLeaveButton();
			librariesFormularyPage.clickDownArrowButton();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Accumulator Structure deductible Tab Labels Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Accumulator Structure deductible Tab Labels");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.EnterText;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;
import static anthem.irx.oneframe.selenium.WebObjectHandler.SelectDropDownListByValue;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForApplicationToLoadCompletely;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPLibrariesSpecialtyPage extends OneframeContainer {
	
	@FindBy(xpath = "//h3[text()='Drug List']")
	WebElement hdrDrugList;
	
	@FindBy(xpath = "//span[normalize-space()='Add Drug List']/..")
	WebElement btnAddDrugList;
	
	@FindBy(xpath = "//table//th[text()]")
	List<WebElement> tblDrugListHeaders;
	
	@FindBy(xpath = "//div[normalize-space()='Cost Shares' and text()]")
	WebElement costSharesTab;
	
	@FindBy(xpath = "//mat-slide-toggle[@formcontrolname='ancillaryApplyBasedOnDAW']")
	WebElement ancillaryToggle;	
	
	@FindBy(css = "[data-automation-id='selectCostShareStructurePrograms']")
	WebElement costShareStructureDropdown;
	
	@FindBy(xpath ="//mat-option/span")
	List<WebElement> costShareStructureDropdownValues;
	
	@FindBy(css = "mat-slide-toggle[formcontrolname=\"customStepping\"]")
	WebElement customSteppingToggle;
	
	@FindBy(css = "mat-select[data-automation-id=\"INN Retail\"]")
	WebElement innRetailInputBox;

	@FindBy(css = "mat-select[data-automation-id=\"INN Home Delivery\"]")
	WebElement innHomeDeliveryInputBox;
	
	@FindBy(css = "mat-select[data-automation-id=\"OON Retail\"]")
	WebElement onnRetailInputBox;
	
	@FindBy(xpath = "//div[contains(@class, 'cdk-overlay-backdrop')]")
	WebElement overlayElement;
	
	
	// Initializing the Page Objects:
	public IBPLibrariesSpecialtyPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}
	
	
	@Step("Verify Drug List header is displayed")
	public boolean verifyDrugListHeaderIsDisplayed() {
		boolean flg = false;
		
		try {
			if(hdrDrugList.isDisplayed()) {
				highlightElement(hdrDrugList);
				OneframeLogger("Drug List header is displayed: " +hdrDrugList.getText());
				flg = true;
			}
		} catch (Exception e) {
			OneframeLogger("Drug List header is not displayed: " +e);
		}
		
		return flg;
	}
	
	@Step("Verify Add Drug List button is displayed")
	public boolean verifyAddDrugListButtonIsDisplayed() {
		boolean flg = false;
		
		try {
			if(btnAddDrugList.isDisplayed()) {
				highlightElement(btnAddDrugList);
				OneframeLogger("Add Drug List button is displayed: " +btnAddDrugList.getText());
				flg = true;
			}
		} catch (Exception e) {
			OneframeLogger("Add Drug List button is not displayed: " +e);
		}
		
		return flg;
	}
	
	@Step("Verify Drug List table headers are displayed")
	public boolean verifyDrugListTableHeaders() {
		boolean flg = false;
		
		try {
			if(tblDrugListHeaders.size() == 9) {
				for(WebElement ele: tblDrugListHeaders) {		
					if(ele.isDisplayed()) {
						OneframeLogger("Table header '" +ele.getText()+ "' is displayed");
						highlightElement(ele);
					}
				}
				flg = true;
			}
			
		} catch (Exception e) {
			OneframeLogger("Table headers are not displayed: "+e);
		}
		
		return flg;
	}
	
	@Step("Click on Cost Shares Tab")
	public boolean clickCostSharesTab() {
		try {
			if(WaitForObjectVisibility(costSharesTab)) {
				ClickWebObject(costSharesTab);
				OneframeLogger("Clicked on Cost Shares Tab");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Cost Shares tab");
			OneframeLogger(e.toString());
		}
		
		return false;
	}

	@Step("Verify Ancillay Charges Apply toggle is enabled")
	public boolean verifyAncillayToggleIsEnabled() {
		try {
			if(WaitForObjectVisibility(ancillaryToggle)) {
				String eleClassText = ancillaryToggle.getAttribute("class");
				if(eleClassText.contains("mat-checked")) {
					OneframeLogger("Ancillary Checkbox is checked");
					return true;
				}
			}
		} catch (Exception e) {
			OneframeLogger("Ancillary Charges Apply toggle is not enabled");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Click on COst Share Structure Dropdown")
	public boolean clickCostShareStructureDropdown() {
		try {
			if(WaitForObjectVisibility(costShareStructureDropdown)) {
				ClickWebObject(costShareStructureDropdown);
				OneframeLogger("Clicked on COst Share Structure Dropdown");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Cost Share Structure dropdown");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Validate contents of Cost Share Structure Dropdown")
	public boolean validateCostShareStructureDropdownContens() {
		try {
			WebDriverWait wait = new WebDriverWait(oneframeDriver, 5);
			wait.until(ExpectedConditions.numberOfElementsToBe(By.xpath("//mat-option/span"), 3));
			
			if(costShareStructureDropdownValues.size() == 3) {
				List<String> actualValues = new ArrayList<String>();
				for(WebElement ele: costShareStructureDropdownValues) {
					actualValues.add(ele.getText().trim());
				}
				
				if(actualValues.containsAll(Arrays.asList("Does not apply to Plan", "Follow Plan", "Apply Custom Cost Shares"))) {
					OneframeLogger("Cost Share Structure dropdown contains the values: \n'Does not apply to Plan'\n'Follow Plan'\n'Apply Custom Cost Shares'");
					costShareStructureDropdown.sendKeys(Keys.ESCAPE);
					costShareStructureDropdown.sendKeys(Keys.ESCAPE);
					return true;
				}
			}
			
		} catch (Exception e) {
			costShareStructureDropdown.sendKeys(Keys.ESCAPE);
			costShareStructureDropdown.sendKeys(Keys.ESCAPE);
			OneframeLogger("Unable to click on Cost Share Structure dropdown");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Click on Custom Stepping Toggle")
	public boolean clickCustomSteppingToggle() {
		try {		
			if(WaitForObjectVisibility(customSteppingToggle)) {
				ClickWebObject(customSteppingToggle);
				OneframeLogger("Clicked on Custom Stepping Toggle");
				return true;
			}		
		} catch (Exception e) {
			OneframeLogger("Unable to click on Custom Stepping Toggle");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Verify INN Retail Input box is displayed")
	public boolean verifyInnRetailInputBoxIsDisplayed() {
		try {
			if(WaitForObjectVisibility(innRetailInputBox)){
				highlightElement(innRetailInputBox);
				OneframeLogger("INN Retail Input Box is visible");
				return true;
			}
		}
		catch (Exception e){
			OneframeLogger("INN Retail Input Box is not visible");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Verify INN Home Delivery Input box is displayed")
	public boolean verifyInnHomeDeliveryInputBoxIsDisplayed() {
		try {
			if(WaitForObjectVisibility(innHomeDeliveryInputBox)){
				highlightElement(innHomeDeliveryInputBox);
				OneframeLogger("INN Home Delivery Input Box is displayed");
				return true;
			}
		}
		catch (Exception e){
			OneframeLogger("INN Home Delivery Input box is not displayed");
			OneframeLogger(e.toString());
		}
		return false;
	}

	@Step("Verify ONN Retail Input box is displayed")
	public boolean verifyOnnRetailInputBoxIsDisplayed() {
		try {
			if(WaitForObjectVisibility(onnRetailInputBox)){
				highlightElement(onnRetailInputBox);
				OneframeLogger("ONN Retail Input box is displayed");
				return true;
			}
		}
		catch (Exception e){
			OneframeLogger("ONN Retail Input box is not displayed");
			OneframeLogger(e.toString());
		}
		return false;
	}
	
	
}

package ibcweb.TestScripts;



import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class ValidateWFEExitWithoutSavingButtoninCloseFunctionality extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
    IBPHomePage homepage;
    IBPBenefitPage benefitpage;
    IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating Exit Without Saving Button in CLose Button Functionality")
	public void setUp() {
		InitializeLaunchPad("IBPW_68");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Exit Without Saving Button in  Close Button Functionality", dataProvider = "TestData")
	@Description("Validate Exit Without Saving Button in  Close Button Functionality")
	public void ValidateExitWithoutSavingButtoninCloseFunctionality(String TestCaseID, String TestStatus, String Benefit) throws AWTException, InterruptedException, IOException {
		
	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Created Benefit header is Verified");
			sa.assertTrue(createbenefitpage.verifyVerStatus(), " Verified Version Status is verified");
			sa.assertTrue(createbenefitpage.verifyVersionValue(), " Verified Version Value is verified");
			createbenefitpage.ClickEditButtoninWFE();
			sa.assertTrue(createbenefitpage.CheckCloseButtonisDisplayed(), "Verified Close Button is Verified");
			sa.assertTrue(createbenefitpage.CheckSaveButtonisDisplayed(), "Verified Save Button is Verified");
			sa.assertTrue(createbenefitpage.verifyVersionValue(), "Verified Version Value is incremented");
	        createbenefitpage.ClickWFECloseButton();
			sa.assertTrue(createbenefitpage.VerifyCLosePopUpHeaderDisplayed(), "Verified Pop UP Header is Displayed");
			sa.assertTrue(createbenefitpage.VerifyExitWithoutSavingButtonDisplayed(), "Verified Exit Without Saving Button is Verified");		
			createbenefitpage.ClickWFEExitwithoutSavingButton();
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Created Benefit header is Verified");
			sa.assertTrue(createbenefitpage.verifyVerStatus(), "Verified Version Status is Verified");
			sa.assertTrue(createbenefitpage.verifyVersionValue(), "Verified Version Value is Verified");		
			gTestResult = RESULT_PASS;
			OneframeLogger(" Exit Without Saving Button in  Close Button Functionality is Validated Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Validate Exit Without Saving Button in  Close Button Functionality is not Successful");
		}
		sa.assertAll();
		homepage.clickLogout();
	}


	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

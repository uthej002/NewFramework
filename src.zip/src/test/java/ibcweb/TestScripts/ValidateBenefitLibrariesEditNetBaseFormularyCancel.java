package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesEditNetBaseFormularyCancel extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPBenefitFormularyPage librariesFormularyPage;

	@BeforeClass
	@Step("Initializing Test Script for validating Benefit Libraries Base Edit Net Formulary Cancel button")
	public void setUp() {
		InitializeLaunchPad("IBPW_401");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		librariesFormularyPage = new IBPBenefitFormularyPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefit Libraries Base Edit Net Formulary Cancel button", dataProvider = "TestData")
	@Description("Validate Benefit Libraries Base Edit Net Formulary Cancel button")
	public void ValidateLibrariesBaseEditNetFormularyCancel(String TestCaseID, String TestStatus)throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesFormularyPage.clickViewButtonofFormularies();
			librariesFormularyPage.clickNetFormulariesButton();
			librariesFormularyPage.clickonFirstNetFormulary();
			librariesFormularyPage.verifyAndClickEditButton();
			librariesFormularyPage.clickCancelButtonofEditFormularies();
			sa.assertTrue(librariesFormularyPage.verifyFormualryInputDisable(),"Verified Formualry Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyNetFormualryIDInputDisable(),"Verified Net Formulary ID Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyAdjudicationFormualryIDInputDisable(),"Verified Adjudication Formulary ID Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyTiersInputDisable(),"Verified #Tiers Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyCostShareTierInputDisable(),"Verified Cost Share Tier Structure Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyNetFormularyNameInputDisable(),"Verified Net Formulary Name Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyEffectiveDateInputDisable(),"Verified Effective Date Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyStopSaleDateInputDisable(),"Verified Stop Sale Date Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyTermDateInputDisable(),"Verified Term Date Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyClientInputDisable(),"Verified Client Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyLOBInputDisable(),"Verified LOB Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyStateInputDisable(),"Verified State Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyEmployerGroupInputDisable(),"Verified Employer Group Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyManagedByInputDisable(),"Verified Managed By Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyImplementationDateInputDisable(),"Verified Implementation Date Input field value is Disabled");
			sa.assertTrue(librariesFormularyPage.verifyFormularyLinkInputDisable(),"Verified Formulary Link Input field value is Disabled");		
			sa.assertTrue(librariesFormularyPage.verifyFormularyTagInputDisable(),"Verified Formulary Tag Input field value is Disabled");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Benefit Libraries Base Edit Net Formulary Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Benefit Libraries Base Edit Net Formulary");
		}

//		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

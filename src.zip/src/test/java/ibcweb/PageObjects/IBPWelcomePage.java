package ibcweb.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.util.List;

import io.qameta.allure.Step;

public class IBPWelcomePage extends OneframeContainer {
	OneframeSoftAssert sa = new OneframeSoftAssert();

	//
	@FindBy(xpath = "//div[@class='login__welcome']")
	WebElement txtWelcomelogo;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()=' Login with CarelonRx ID ']")
	WebElement btnLogin;

	@FindBy(xpath = "//a[text()='Help']")
	WebElement lnkHelp;

	@FindBy(xpath = "//a[text()='Contact']")
	WebElement lnkContact;

	@FindBy(xpath = "//div[@class='card__orange']")
	List<WebElement> txtClientReviewPendingWidget;

	@FindBy(xpath = "//ingeniorx-ws-my-tasks-widget/div/div")
	WebElement txtMyTasksWidget;

	@FindBy(xpath = "//ingeniorx-ws-remediation-widget/div/div/div[3]/mat-list-item/div/div[3]/div/div/div")
	WebElement txtRemediationRequiredWidget;

	@FindBy(xpath = "//ingeniorx-ws-all-users-widget/div/div")
	WebElement txtUsersWidget;

	@FindBy(xpath = "//div[@class='card__red']//h1[contains(text(),'My Tasks ')]")
	WebElement txtMyTasksHeader;

	@FindBy(xpath = "//ingeniorx-ws-my-tasks-widget/div/div/div/mat-list-item/div[@class='mat-list-item-content']")
	List<WebElement> lstMytasksSection;

	@FindBy(xpath = "//span[contains(.,'In Progress')]")
	WebElement hdrInProgress;

	@FindBy(xpath = "//div[@class=\"mat-title title\"]")
	WebElement hdrAfterClickViewAllLinkFromTaskWidgetSection;

	@FindBy(xpath = " //span[contains(.,'In Remediation')]")
	WebElement hdrInRemediation;

	@FindBy(xpath = "//span[contains(.,'In Client Review')]")
	WebElement hdrClientReview;

	@FindBy(xpath = "//button[@class='view-button']//b[text()='View All']")
	List<WebElement> lnkViewAll;

	@FindBy(xpath = "//div[7]/mat-list-item/div/div[3]/mat-list-item/div/div[3]/div[2]/br")
	List<WebElement> lstErrorCodes;

	@FindBy(xpath = "//div[7]/mat-list-item/div/div[3]/mat-list-item/div/div[3]/div[2]/b")
	List<WebElement> lstBenefitPlanID;

	@FindBy(xpath = "//div[7]/mat-list-item/div/div[3]/mat-list-item/div/div[3]/div[2]/b[2]")
	List<WebElement> lstClientData;

	@FindBy(xpath = "//div[7]/mat-list-item/div/div[3]/mat-list-item/div/div[3]/div[2]/b[3]")
	List<WebElement> lstEffectiveDates;

	@FindBy(xpath = "//*[@class=\"benefit-info-remediation\"]")
	List<WebElement> lstEachLineItems;

	@FindBy(xpath = "//mat-select[@data-automation-id='errorTypeInRemediation']")
	WebElement drdshowInRemedationSection;

	@FindBy(xpath = "//mat-select[@data-automation-id='errorTypeClientApproval']")
	WebElement drdShowClientApprovalSection;

	@FindBy(xpath = "//mat-select[@data-automation-id='errorType']")
	List<WebElement> drdShowRemediationRequiredSectionAndClientReviewPending;

	@FindBy(xpath = "//div[contains(@class,'ng-trigger ng-trigger-transformPanel mat-select-panel mat-primary')]")
	WebElement drdShowValuesInRemediationAndClientReviewPending;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-assignee mat-column-assignee ng-star-inserted\"]")
	List<WebElement> lstAssigneeLogged;

	@FindBy(xpath = "(//mat-paginator/div/div/div/div)[2]")
	WebElement txtPageNumber;

	@FindBy(xpath = "//*[@class=\"mat-paginator-icon\"]")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//simple-snack-bar/span")
	WebElement txtNotificationMessage;

	@FindBy(xpath = "//tr[@class='mat-row cdk-row ng-star-inserted']")
	List<WebElement> lstRemediationRequiredRecords;

	@FindBy(xpath = "//td[contains(@class,'mat-cell cdk-cell cdk-column-benefitPlanId ')]")
	List<WebElement> txtBenefitPlanID;

	@FindBy(xpath = "//ingeniorx-ws-remediation-widget/div/div/div[3]/mat-list-item/div/div[3]/div/div/div")
	List<WebElement> lstbtnAssignTaskYourself;

	@FindBy(xpath = "//ingeniorx-ws-client-widget/div/div/div[3]/mat-list-item/div/div[3]/div/div/div")
	List<WebElement> lstbtnAssignTaskYourselfClientReviewPending;

	@FindBy(xpath = "//h1[contains(text(),'Remediation Required ')]")
	WebElement hdrRemediationRequired;

	@FindBy(xpath = "//mat-list-item[contains(@class,'mat-list-item mat-focus-indicator remediation-row ng-star-inserted')]/div/div/div[2]/span[@class='no-padding']")
	List<WebElement> lstbtnAssignYourselfRemediationRequired;

	@FindBy(xpath = "//h1[contains(text(),'Client Review Pending ')]")
	WebElement hdrClientReviewPending;

	@FindBy(xpath = "//mat-icon[@class='mat-icon notranslate filter-off mat-icon-no-color']")
	WebElement btnFilter;

	@FindBy(xpath = "//*[@placeholder='Client']")
	WebElement drdFilterClient;

	@FindBy(xpath = "//*[@placeholder='Lob']")
	WebElement drdFilterLOB;

	@FindBy(xpath = "//*[@placeholder='State']")
	WebElement drdFilterState;

	@FindBy(xpath = "//*[@aria-label='Business Entity']")
	WebElement drdFilterBusinessEntity;

	@FindBy(xpath = "//*[@aria-label=\"Business Unit\"]")
	WebElement drdFilterBusinessUnit;

	@FindBy(xpath = "//mat-select[@aria-label='Client']")
	WebElement btnClientDropdown;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-client mat-column-client ng-star-inserted\"]")
	List<WebElement> lstClientValue;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-startDate mat-column-startDate ng-star-inserted\"]")
	List<WebElement> lstEffectiveDate;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-errorType mat-column-errorType ng-star-inserted\"]")
	List<WebElement> lstErrorType;

	@FindBy(xpath = "//input[@formcontrolname='effectiveDate']")
	WebElement txtEffectiveDate;

	@FindBy(xpath = "//mat-select[@aria-label='Error Type']")
	WebElement btnErrorType;

	@FindBy(xpath = "//div[@class=\"welcome-message\"]")
	WebElement txtWelcome;

	@FindBy(xpath = "//b[text()='Apply filter']")
	WebElement btnApplyFilter;

	@FindBy(xpath = "//*[text()=' Apply ']")
	WebElement btnApply;

	@FindBy(xpath = "//*[text()=' * Reassignment can be done at page level when atleast one benefit is selected ']")
	WebElement txtManagerDashboardMessage;

	@FindBy(xpath = "//div[text()='Manager Dashboard']")
	WebElement hdrMemberDashboard;

	@FindBy(xpath = "//table[@class=\"mat-table cdk-table mat-sort irx-listings\"]")
	WebElement txtBenefits;

	@FindBy(xpath = "//*[@class=\"mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin\"]")
	List<WebElement> lstBenefits;

	@FindBy(xpath = "//*[@class=\"mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin\"]/input")
	List<WebElement> lstBenefit;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-benefitPlanId mat-column-benefitPlanId ng-star-inserted\"]")
	List<WebElement> lstBenefitName;

	@FindBy(xpath = "//span[@class=\"mat-button-wrapper\" and text()=' Reassign ']")
	WebElement btnReassignManagerDashboard;

	@FindBy(xpath = "//*[text()='Are you sure you want to continue?']//following::span")
	List<WebElement> lstPopUpReassign;

	@FindBy(xpath = "//*[text()=' Proceed ']")
	WebElement btnProceed;

	@FindBy(xpath = "//*[@class=\"header__title\"]")
	WebElement hdrUserDetails;

	@FindBy(xpath = "//input[@placeholder=\"Find a user\"]")
	WebElement txtSearch;

	@FindBy(xpath = "//*[@class=\"header__title\"]//following::div[@class=\"mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin\"]")
	List<WebElement> txtUserDetailsCheckbox;

	@FindBy(xpath = "//*[@class=\"header__title\"]//following::span[1]")
	WebElement btnCancel;

	@FindBy(xpath = "//h3[text()='Dynamic Layer']//following::div[@class=\"mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin\"]")
	List<WebElement> txtDynamicLayerCheckbox;

	@FindBy(xpath = "//span[text()=' Select Columns ']")
	WebElement btnSelectColumns;

	@FindBy(xpath = "//h3[text()='Dynamic Layer']")
	WebElement hdrDynamicLayer;

	@FindBy(xpath = "//h1[text()='Manager Dashboard ']")
	WebElement hdrManagerDashboard;

	@FindBy(xpath = "//h1[text()='Manager Dashboard ']//following::b[1]")
	WebElement lnkViewAllManagerDashboard;

	@FindBy(xpath = "//*[@class=\"mat-paginator-icon\"]")
	List<WebElement> lnkPagination;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-client mat-column-client ng-star-inserted\"]")
	List<WebElement> lstClient;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-lob mat-column-lob ng-star-inserted\"]")
	List<WebElement> lstLOB;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-state mat-column-state ng-star-inserted\"]")
	List<WebElement> lstState;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-Business-Entity mat-column-Business-Entity ng-star-inserted\"]")
	List<WebElement> lstBusinessEntity;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-Business-Unit mat-column-Business-Unit ng-star-inserted\"]")
	List<WebElement> lstBusinessUnit;

	String benefitId;

	// Initializing the Page Objects:
	public IBPWelcomePage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify 'Welcome to IRx Benefit Central' is displayed on landing page")
	public boolean verifyButterscotchLogo() {
		if (CheckObjectExistence(txtWelcomelogo) != null) {
			return true;
		} else {
			return false;
		}
	}

	@Step("Check whether Login button is displayed")
	public boolean verifyLoginButtonDisplay() {
		WaitForObjectVisibility(btnLogin);
		return btnLogin.isDisplayed();
	}

	@Step("Click on button 'Login with IngenioRx ID'")
	public void ClickLoginButton() {
		WaitForObjectVisibility(btnLogin);
		ClickWebObject(btnLogin);
		OneframeLogger("Login Button is Clicked");
	}

	@Step("Check whether Help link is displayed")
	public boolean validateHelpLink() {
		return lnkHelp.isDisplayed();
	}

	@Step("Check whether Contact link is displayed")
	public boolean validateContactLink() {
		return lnkContact.isDisplayed();
	}

	@Step("Welcome")
	public void clickWelcomeHelloText() {
		WaitForObjectVisibility(txtWelcome);
		txtWelcome.click();
		txtWelcome.click();
		txtWelcome.click();
		txtWelcome.click();
		OneframeLogger(txtWelcome.getText() + " is clicked");
	}

	@Step("Verify whether My Tasks Widget is displayed")
	public boolean verifyMyTasksWidgetDisplay() {
		WaitForObjectVisibility(txtMyTasksWidget);
		ScrollToElement(txtMyTasksWidget);
		highlightElement(txtMyTasksWidget);
		return txtMyTasksWidget.isDisplayed();
	}

	@Step("Verify whether Remediation Required Widget is displayed")
	public boolean verifyRemediationRequiredWidgetDisplay() throws InterruptedException {
		Thread.sleep(3000);
		WaitForObjectVisibility(txtRemediationRequiredWidget);
		highlightElement(txtRemediationRequiredWidget);
		return txtRemediationRequiredWidget.isDisplayed();
	}

	@Step("Verify whether Client Review Pending Widget is displayed")
	public boolean verifyClientReviewPendingWidgetDisplay() throws InterruptedException {
		Thread.sleep(3000);
		ScrollToElement(txtClientReviewPendingWidget.get(1));
		WaitForObjectVisibility(txtClientReviewPendingWidget.get(1));
		highlightElement(txtClientReviewPendingWidget.get(1));
		return txtClientReviewPendingWidget.get(1).isDisplayed();
	}

	@Step("Verify whether Users Widget is displayed")
	public boolean verifyUsersWidgetDisplay() {
		WaitForObjectVisibility(txtUsersWidget);
		highlightElement(txtUsersWidget);
		return txtUsersWidget.isDisplayed();
	}

	@Step("Verify whether My Tasks Header is dsiplayed")
	public boolean verifyMyTasksHeaderDisplay() {
		WaitForObjectVisibility(txtMyTasksHeader);
		ScrollToElement(txtMyTasksHeader);
		highlightElement(txtMyTasksHeader);
		return txtMyTasksHeader.isDisplayed();
	}

	@Step("Verify Header is Displayed After clicking view All Link from My task widget")
	public boolean verifyHeaderIsDisplayedAfterClickingViewAllLinkFromTaskWidget(String header) {
		boolean bln = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(hdrAfterClickViewAllLinkFromTaskWidgetSection);
		ClickWebObject(hdrAfterClickViewAllLinkFromTaskWidgetSection);
		ClickWebObject(hdrAfterClickViewAllLinkFromTaskWidgetSection);
		ClickWebObject(hdrAfterClickViewAllLinkFromTaskWidgetSection);
		try {
			highlightElement(hdrAfterClickViewAllLinkFromTaskWidgetSection);
			if (hdrAfterClickViewAllLinkFromTaskWidgetSection.getText().contains(header))
				bln = true;
		} catch (Exception exc) {
			OneframeLogger("Exception occured");
		}
		return bln;
	}

	@Step("After click on View All Link Verify whether headers Sections are displayed")
	public void clickHeaderSections(String header) {
		WaitForObjectVisibility(hdrAfterClickViewAllLinkFromTaskWidgetSection);
		try {
			if (hdrAfterClickViewAllLinkFromTaskWidgetSection.getText().contains(header)) {
				ClickWebObject(hdrAfterClickViewAllLinkFromTaskWidgetSection);
				ClickWebObject(hdrAfterClickViewAllLinkFromTaskWidgetSection);
				ClickWebObject(hdrAfterClickViewAllLinkFromTaskWidgetSection);
				ClickWebObject(hdrAfterClickViewAllLinkFromTaskWidgetSection);
				// ClickWebObject(hdrAfterClickViewAllLinkFromTaskWidgetSection);
				// OneframeLogger(header + " header is clicked");
			}
		} catch (Exception e) {
			OneframeLogger(header + " header is not clicked");
		}
	}

	@Step("Verify whether In Progress Header is dsiplayed")
	public boolean verifyInProgressHeaderDisplay() {
		WaitForObjectVisibility(hdrInProgress);
		ScrollToElement(hdrInProgress);
		highlightElement(hdrInProgress);
		return hdrInProgress.isDisplayed();
	}

	@Step("Verify whether My Tasks Section is dsiplayed")
	public boolean verifyInProgressSectionDisplay() {
		WaitForObjectVisibility(lstMytasksSection.get(0));
		highlightElement(lstMytasksSection.get(0));
		return lstMytasksSection.get(0).isDisplayed();
	}

	@Step("Verify whether In Remediation Header is dsiplayed")
	public boolean verifyInRemediationHeaderDisplay() {
		WaitForObjectVisibility(hdrInRemediation);
		highlightElement(hdrInRemediation);
		return hdrInRemediation.isDisplayed();
	}

	@Step("Verify whether In Remediation Section is dsiplayed")
	public boolean verifyInRemediationSectionDisplay() {
		WaitForObjectVisibility(lstMytasksSection.get(1));
		highlightElement(lstMytasksSection.get(1));
		return lstMytasksSection.get(1).isDisplayed();
	}

	@Step("Verify whether In Client Reveiw Header is dsiplayed")
	public boolean verifyInClientReviewHeaderDisplay() {
		WaitForObjectVisibility(hdrClientReview);
		highlightElement(hdrClientReview);
		return hdrClientReview.isDisplayed();
	}

	@Step("Verify whether In Client Reveiw Section is dsiplayed")
	public boolean verifyInClientReviewSectionDisplay() {
		WaitForObjectVisibility(lstMytasksSection.get(2));
		highlightElement(lstMytasksSection.get(2));
		return lstMytasksSection.get(2).isDisplayed();
	}

	@Step("Verify Whether View All Button in InProgess Section is Displayed")
	public boolean verifyViewAllButtonDisplay() {
		WaitForObjectVisibility(lnkViewAll.get(1));
		highlightElement(lnkViewAll.get(1));
		return lnkViewAll.get(1).isDisplayed();
	}

	@Step("Click View All Button of In Process Section")
	public void clickViewAllButtonOfInProcessSection() {
		WaitForObjectVisibility(lnkViewAll.get(1));
		ClickWebObject(lnkViewAll.get(1));
		OneframeLogger("Clicked View All Button of In Process Section");
	}

	@Step("Verify Whether View All Button in InRemediation Section is Displayed")
	public boolean verifyViewAllButtonInRemediationDisplay() {
		WaitForObjectVisibility(lnkViewAll.get(2));
		highlightElement(lnkViewAll.get(2));
		return lnkViewAll.get(2).isDisplayed();
	}

	@Step("Click View All Button of In Remediation Section")
	public void clickViewAllButtonOfInRemediationSection() {
		WaitForObjectVisibility(lnkViewAll.get(2));
		ClickWebObject(lnkViewAll.get(2));
		OneframeLogger("Clicked View All Button of In Remediation Section");
	}

	@Step("Click View All Button of In Client Review Section")
	public void clickViewAllButtonOfInClientReviewSection() {
		WaitForObjectVisibility(lnkViewAll.get(3));
		ClickWebObject(lnkViewAll.get(3));
		OneframeLogger("Clicked View All Button of In Client Review Section");
	}

	@Step("Verify Whether View All Button in Client Reveiw Section is Displayed")
	public boolean verifyViewAllButtonClientReviewDisplay() {
		WaitForObjectVisibility(lnkViewAll.get(3));
		highlightElement(lnkViewAll.get(3));
		return lnkViewAll.get(3).isDisplayed();
	}

	@Step("Verify Whether View All Button in Remediation Required Section is Displayed")
	public boolean verifyViewAllButtonRemediationRequiredDisplay() {
		WaitForApplicationToLoadCompletely();
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		WaitForObjectVisibility(lnkViewAll.get(4));
		highlightElement(lnkViewAll.get(4));
		return lnkViewAll.get(4).isDisplayed();
	}

	@Step("Verify Benefit Plan ID,Effective Date,Client Data for Each Item is displayed")
	public boolean verifyEachLineItemDisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(lstEachLineItems.get(0));
		for (int i = 0; i < lstEachLineItems.size(); i++) {
			highlightElement(lstEachLineItems.get(i));
			if (!lstEachLineItems.get(i).isDisplayed()) {
				blnRC = false;
				break;
			}
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify Client Data in InProgress Section is displayed")
	public boolean verifyClientDataDisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(lstBenefitPlanID.get(0));
		for (int i = 0; i <= lstBenefitPlanID.size(); i++) {
			highlightElement(lstBenefitPlanID.get(i));
			if (!lstBenefitPlanID.get(i).isDisplayed()) {
				blnRC = false;
				break;
			}
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify Whether Show dropdown and its values in InRemediation Section is Displayed")
	public boolean verifyShowDropdownInRemediationDisplay() {
		WaitForObjectVisibility(drdshowInRemedationSection);
		ClickWebObject(drdshowInRemedationSection);
		highlightElement(drdShowValuesInRemediationAndClientReviewPending);
		ClickWebObject(drdShowValuesInRemediationAndClientReviewPending);
		return drdShowValuesInRemediationAndClientReviewPending.isDisplayed();
	}

	@Step("Verify Whether Show dropdown and its values in Client Review Section is Displayed")
	public boolean verifyShowDropdownClientReviewDisplay() {
		ScrollWebPageByPixel(300);
		WaitForObjectVisibility(drdShowClientApprovalSection);
		ClickWebObject(drdShowClientApprovalSection);
		highlightElement(drdShowValuesInRemediationAndClientReviewPending);
		ClickWebObject(drdShowValuesInRemediationAndClientReviewPending);
		return drdShowValuesInRemediationAndClientReviewPending.isDisplayed();
	}

	@Step("Verify Whether Show dropdown and its values in Remediation Required Section is Displayed")
	public boolean verifyShowDropdownRemediationRequiredDisplay() {
		WaitForObjectVisibility(drdShowRemediationRequiredSectionAndClientReviewPending.get(0));
		ClickWebObject(drdShowRemediationRequiredSectionAndClientReviewPending.get(0));
		highlightElement(drdShowValuesInRemediationAndClientReviewPending);
		ClickWebObject(drdShowValuesInRemediationAndClientReviewPending);
		return drdShowValuesInRemediationAndClientReviewPending.isDisplayed();
	}

	@Step("Verify Whether Show dropdown and its values in Client Review Pending is Displayed")
	public boolean verifyShowDropdownClientReviewPendingDisplay() {
		WaitForObjectVisibility(drdShowRemediationRequiredSectionAndClientReviewPending.get(1));
		ClickWebObject(drdShowRemediationRequiredSectionAndClientReviewPending.get(1));
		highlightElement(drdShowValuesInRemediationAndClientReviewPending);
		ClickWebObject(drdShowValuesInRemediationAndClientReviewPending);
		WaitForObjectVisibility(drdShowValuesInRemediationAndClientReviewPending);
		return drdShowValuesInRemediationAndClientReviewPending.isDisplayed();
	}

	@Step("Verify Assign Task Yourself Button in Remediation Required Section is displayed")
	public boolean verifyAssignTaskYourselfButtonDisplayRemediationRequired() {
		boolean blnRC = false;
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		ScrollToElement(lstbtnAssignTaskYourself.get(0));
		WaitForObjectVisibility(lstbtnAssignTaskYourself.get(0));
		for (int i = 0; i < lstbtnAssignTaskYourself.size(); i++) {
			highlightElement(lstbtnAssignTaskYourself.get(i));
			if (!lstbtnAssignTaskYourself.get(i).isDisplayed()) {
				blnRC = false;
				break;
			}
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify Assign Task Yourself Button in Client Review Pending Section is displayed")
	public boolean verifyAssignTaskYourselfButtonDisplayClientReviewPending() {
		boolean blnRC = false;
		WaitForObjectVisibility(lstbtnAssignTaskYourselfClientReviewPending.get(0));
		for (int i = 0; i < lstbtnAssignTaskYourselfClientReviewPending.size(); i++) {
			highlightElement(lstbtnAssignTaskYourselfClientReviewPending.get(i));
			if (!lstbtnAssignTaskYourselfClientReviewPending.get(i).isDisplayed()) {
				blnRC = false;
				break;
			}
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify page traversing and compare Assignee value with logged user")
	public boolean verifyPageTraversingAndCompareAssigneeValueWithLoggedUser(String header) {
		boolean bln = false;
		OneframeLogger("Verify page traversing and compare Assignee value with logged user");
		String strLoginID = getUserIDfromCredentialProperties();
		WaitForObjectVisibility(txtPageNumber);

		String records = txtPageNumber.getText();
		String[] recordCnt = records.split("–");
		String[] totalRecordCnt = recordCnt[1].split("of");
		int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
		int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
		outer: while (recordsPresentPerPage <= totalRecords) {
			for (int i = 0; i < lstAssigneeLogged.size(); i++) {
				if (lstAssigneeLogged.get(i).getText().equalsIgnoreCase(strLoginID)) {
					int j = i + 1;
					highlightElement(lstAssigneeLogged.get(i));
					OneframeLogger("Assignee value of " + j + " record " + lstAssigneeLogged.get(i).getText()
							+ " is equal to the user logged " + strLoginID);
				}
			}
			if (totalRecords != recordsPresentPerPage) {
				ClickWebObject(lstPageTraverseChevronButton.get(1));
				OneframeLogger("clicked next page chevron button");
				// WaitForApplicationToLoadCompletely();
				clickHeaderSections(header);
			} else {
				bln = true;
				break outer;
			}
			String record = txtPageNumber.getText();
			recordCnt = record.split("–");
			totalRecordCnt = recordCnt[1].split("of");
			totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
		}
		OneframeLogger("Total records :" + totalRecords);
		return bln;
	}

	@Step("Verify Benefit Plan ID in Home Page Sections")
	public boolean verifyBenefitPlanID(String header) {
		boolean bln = false;
		clickHeaderSections(header);
		clickHeaderSections(header);
		clickHeaderSections(header);
		clickHeaderSections(header);
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(txtPageNumber);

		String records = txtPageNumber.getText();
		OneframeLogger("The Records are " + records);
		String[] recordCnt = records.split(" ");
		// String[] totalRecordCnt = recordCnt[1].split("of");
		int totalRecords = Integer.parseInt(recordCnt[4].trim());
		int recordsPresentPerPage = Integer.parseInt(recordCnt[2].trim());
		OneframeLogger("Total records :" + totalRecords);
		outer: while (recordsPresentPerPage <= totalRecords) {
			for (int i = 0; i < txtBenefitPlanID.size(); i++) {
				if (txtBenefitPlanID.get(i).getText().equalsIgnoreCase(benefitId)) {
					highlightElement(txtBenefitPlanID.get(i));
					OneframeLogger("The Remediation Required or Client Review Pending Section BenefitID is " + benefitId
							+ " equal to the " + header + " Section BenefitID  " + txtBenefitPlanID.get(i).getText());
					bln = true;
					break outer;
				}
			}
			if (totalRecords != recordsPresentPerPage) {
				ClickWebObject(lstPageTraverseChevronButton.get(1));
				// OneframeLogger("clicked next page chevron button");
				// WaitForApplicationToLoadCompletely();
				clickHeaderSections(header);
			}
			String record = txtPageNumber.getText();
			recordCnt = records.split(" ");
			// totalRecordCnt = recordCnt[1].split("of");
			totalRecords = Integer.parseInt(recordCnt[4].trim());
			recordsPresentPerPage = Integer.parseInt(recordCnt[2].trim());
		}
		return bln;
	}

	@Step("Click View All Button in InRemediation Section is displayed")
	public void ClickViewAllButtonInRemediation() {
		try {
			WaitForApplicationToLoadCompletely();
			ClickWebObject(hdrInRemediation);
			ClickWebObject(hdrInRemediation);
			if (ObjectExist(lnkViewAll.get(2))) {
				ClickWebObject(lnkViewAll.get(2));
				OneframeLogger("View All Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("View All button not clicked");
		}
	}

	@Step("Click View All Button in InClientReview Section is displayed")
	public void ClickViewAllButtonInClientReview() {
		try {
			if (ObjectExist(lnkViewAll.get(3))) {
				ClickWebObject(lnkViewAll.get(3));
				OneframeLogger("View All Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("View All button not clicked");
		}
	}

	private String fetchBenefitID() {
		if (WaitForObjectVisibility(txtNotificationMessage))
			ClickWebObject(txtNotificationMessage);
		String message = txtNotificationMessage.getText();
		// OneframeLogger("The Message is "+message);
		String[] benefitID = message.split(" ");
		benefitId = benefitID[0];
		// OneframeLogger("The ID is "+benefitId);
		return benefitId;
	}

	@Step("Verify Assigned Benefit is not displayed in Client Review Pending Section")
	public boolean verifyAssignedBenefitClientReviewPending() {
		fetchBenefitID();
		OneframeLogger("The Benefit ID from Remediation Required is " + benefitId);
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		WaitForObjectVisibility(lstbtnAssignTaskYourselfClientReviewPending.get(0));
		for (int i = 0; i < lstbtnAssignTaskYourselfClientReviewPending.size(); i++) {
			if (lstbtnAssignTaskYourselfClientReviewPending.get(i).getText().contains(benefitId)) {
				return false;
			}
			if (i == lstbtnAssignTaskYourselfClientReviewPending.size() - 1) {
				return true;
			}
		}
		return false;
	}

	@Step("Click Assign Task Yourself Button in Remediation Required Section is displayed")
	public void ClickAssignTaskYourselfButtonDisplayRemediationRequired() {
		try {
			if (ObjectExist(lstbtnAssignTaskYourself.get(0))) {
				ClickWebObject(lstbtnAssignTaskYourself.get(0));
				OneframeLogger("Assign Task Yourself clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Assign Task Yourself clicked");
		}
	}

	@Step("Click Assign Task Yourself Button in Client Review Pending Section is displayed")
	public void ClickAssignTaskYourselfButtonDisplayClientReviewPending() {
		try {
			if (ObjectExist(lstbtnAssignTaskYourselfClientReviewPending.get(0))) {
				ClickWebObject(lstbtnAssignTaskYourselfClientReviewPending.get(0));
				OneframeLogger("Assign Task Yourself clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Assign Task Yourself clicked");
		}
	}

	@Step("Verify Assigned Benefit is not displayed in Remediation Required Section")
	public boolean verifyAssignedBenefitRemediationRequired() throws Throwable {
		String benefitId=fetchBenefitID();
		OneframeLogger("The Benefit ID from Remediation Required is " + benefitId);
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		Thread.sleep(5000);
//		WaitForObjectVisibility(lstbtnAssignYourselfRemediationRequired.get(0));
		for (int i = 0; i < lstbtnAssignYourselfRemediationRequired.size(); i++) {
			if (lstbtnAssignYourselfRemediationRequired.get(i).getText().contains(benefitId)) {
				return false;
			}
			if (i == lstbtnAssignYourselfRemediationRequired.size() - 1) {
				return true;
			}
		}
		return false;
	}

	@Step("Verify page traversing in Home Page Widgets")
	public boolean verifyPageTraversing(String header) {
		boolean bln = false;
		clickHeaderSections(header);
		clickHeaderSections(header);
		clickHeaderSections(header);
		clickHeaderSections(header);
		clickHeaderSections(header);
		clickHeaderSections(header);
		WaitForObjectVisibility(txtPageNumber);
		try {
			String records = txtPageNumber.getText();
			OneframeLogger("The Records are " + records);
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstRemediationRequiredRecords.size(); i++) {
					highlightElement(lstRemediationRequiredRecords.get(i));
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					// OneframeLogger("clicked next page chevron button");
					// WaitForApplicationToLoadCompletely();
					clickHeaderSections(header);
				} else {
					bln = true;
					break outer;
				}
				records = txtPageNumber.getText();
				recordCnt = records.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
			OneframeLogger("Total records :" + totalRecords);
		} catch (StaleElementReferenceException se) {
		}
		return bln;
	}

	@Step("Verify Whether View All Button in Client Review Pending Section is Displayed")
	public boolean verifyViewAllButtonClientReviewPendingDisplay() {
		ClickWebObject(hdrClientReviewPending);
		ClickWebObject(hdrClientReviewPending);
		ClickWebObject(hdrClientReviewPending);
		ClickWebObject(hdrClientReviewPending);
		WaitForObjectVisibility(lnkViewAll.get(5));
		highlightElement(lnkViewAll.get(5));
		return lnkViewAll.get(5).isDisplayed();
	}

	@Step("Click View All Button of Client Review Pending Section")
	public void clickViewAllButtonClientReviewPending() {
		WaitForObjectVisibility(lnkViewAll.get(5));
		ClickWebObject(hdrClientReviewPending);
		ClickWebObject(lnkViewAll.get(5));
		OneframeLogger("Clicked View All Button of Client Review pending Widget");
	}

	@Step("Click View All Button of Remediation Required Section")
	public void clickViewAllButtonRemediationRequired() {
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		ClickWebObject(hdrRemediationRequired);
		WaitForObjectVisibility(lnkViewAll.get(4));
		ClickWebObject(lnkViewAll.get(4));
		OneframeLogger("Clicked View All Button of Remediation Required Widget");
	}

	@Step("Click on Filter button")
	public void clickFilterIcon() {
		try {
			if (ObjectExist(btnFilter)) {
				ClickWebObject(btnFilter);
				OneframeLogger("Filter Icon is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Filter Icon is not clicked");
		}
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValues(String values) {
		String element = String.format(
				"//div[@class='cdk-overlay-pane']/div/div/mat-option[@role='option']/span[text()='%s']", values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
	}

	@Step("Select the values from dropdowns")
	public String selDropdownValues(String values) {
		String element = String.format(
				"//div[@class='cdk-overlay-pane']/div/div/mat-option[@role='option']/span[text()='%s']", values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String val = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + val);
		return val;
	}

	@Step("Select Client id Value from client dropdown")
	public boolean selectClientIdDropdown(String clientValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnClientDropdown)) {
				ClickWebObject(btnClientDropdown);
				selectDropdownValues(clientValue);
				btnClientDropdown.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (StaleElementReferenceException toException) {
			OneframeLogger("The Client Value has not been Selected from Client ID dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		return value;
	}

	@Step("Get first Client value")
	public String getFirstRecordClientValue() throws Throwable {
		Thread.sleep(5000);
		WaitForObjectVisibility(lstClientValue.get(0));
		highlightElement(lstClientValue.get(0));
		return lstClientValue.get(0).getText();
	}

	@Step("Get first Effective date")
	public String getFirstRecordEffectiveDate() throws Throwable {
		Thread.sleep(5000);
		WaitForObjectVisibility(lstEffectiveDate.get(0));
		highlightElement(lstEffectiveDate.get(0));
		return lstEffectiveDate.get(0).getText();

	}

	@Step("Get first Error type")
	public String getFirstRecordErrorType() {
		WaitForObjectVisibility(lstErrorType.get(0));
		highlightElement(lstErrorType.get(0));
		return lstErrorType.get(0).getText();
	}

	@Step("Select Effective Date Value from client dropdown")
	public boolean selectEffectiveDateDropdown(String date) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtEffectiveDate)) {
				ClickWebObject(txtEffectiveDate);
				EnterTextandTabOut(txtEffectiveDate, date);
				// selectDropdownValues(dateValue);
				// txtEffectiveDate.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Effective Date Value has not been Selected from Effective Date dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Error Type Value from client dropdown")
	public boolean selectErrorTypeDropdown(String errorType) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnErrorType)) {
				ClickWebObject(btnErrorType);
				selectDropdownValues(errorType);
				btnErrorType.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Error Type Value has not been Selected from Error Type dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Apply Filter button")
	public void clickApplyFilter() {
		try {
			if (ObjectExist(btnApplyFilter)) {
				ClickWebObject(btnApplyFilter);
				OneframeLogger("Apply Filter is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Apply Filter is not clicked");
		}
	}

	@Step("Verify Filter has been implemented as Expected")
	public boolean verifyFilterforEffectiveDate(String effectivedate, String header) {
		boolean blnRC = false;
		clickHeaderSections(header);
		clickHeaderSections(header);
		clickHeaderSections(header);
		// clickHeaderSections(header);
		// clickHeaderSections(header);
		try {
			String element = String.format(
					"//td[@class='mat-cell cdk-cell cdk-column-startDate mat-column-startDate ng-star-inserted']");
			List<WebElement> effectiveDateValue = oneframeDriver.findElements(By.xpath(element));
			for (int i = 0; i < effectiveDateValue.size(); i++) {
				if (WaitForObjectVisibility(effectiveDateValue.get(i))
						&& effectiveDateValue.get(i).getText().equals(effectivedate)) {
					highlightElement(effectiveDateValue.get(i));
					OneframeLogger("The Given Effective Date " + effectivedate
							+ " matched with expected Effective Date " + effectiveDateValue.get(i).getText());
					blnRC = true;
				}
			}
		} catch (Exception e) {
		}
		return blnRC;
	}

	@Step("Verify Manager Dashboard Message")
	public void verifyMessageInManagerDashboard() {
		WaitForObjectVisibility(txtManagerDashboardMessage);
		highlightElement(txtManagerDashboardMessage);
		sa.assertEquals(txtManagerDashboardMessage.getText(),
				"* Reassignment can be done at page level when atleast one benefit is selected",
				"Verified Manager Dashboard Message is same as expected");
		sa.assertAll();
	}

	@Step("Verify Header Manager Dashboard")
	public void verifyHeaderManagerDashboard() {
		WaitForObjectVisibility(hdrMemberDashboard);
		highlightElement(hdrMemberDashboard);
		sa.assertEquals(hdrMemberDashboard.getText(), "Manager Dashboard",
				"Verified Manager Dashboard header is same as expected");
		sa.assertAll();
	}

	@Step("click Manager dashboard header")
	public void clickManagerDashboard() {
		WaitForObjectVisibility(hdrMemberDashboard);
		hdrMemberDashboard.click();
		hdrMemberDashboard.click();
		hdrMemberDashboard.click();
		hdrMemberDashboard.click();

	}

	@Step("Verify Benefits are available")
	public void verifyBenefitIsPresent() {
		WaitForObjectVisibility(txtBenefits);
		if (txtBenefits.isDisplayed()) {
			highlightElement(txtBenefits);
			sa.assertTrue(true, "Validated Benefits are present in Manager Dashboard");
		} else {
			OneframeLogger("Benefits are not present in Manager Dashboard");
		}
	}

	@Step("Click on Benefits checkbox")
	public void clickBenefitsCheckbox() {
		WaitForObjectVisibility(lstBenefits.get(0));
		ClickWebObject(lstBenefits.get(1));
		OneframeLogger("Clicked on first Benefit checkbox");
	}

	@Step("Verify Benefit is Selected")
	public void verifyBenefitsCheckboxIsSelected(String value) {
		WaitForObjectVisibility(lstBenefit.get(0));
		sa.assertEquals(lstBenefit.get(1).getAttribute("aria-checked"), value,
				"Validated Benefits is selected in Manager Dashboard");
		sa.assertAll();
	}

	@Step("Verify Benefit is Deselected")
	public void verifyBenefitsCheckboxIsDeselected(String value) {
		WaitForObjectVisibility(lstBenefit.get(0));
		sa.assertEquals(lstBenefit.get(1).getAttribute("aria-checked"), value,
				"Validated Benefits is De-selected in Manager Dashboard");
		sa.assertAll();
	}

	@Step("Verify Reassign button is enabled")
	public void verifyReaasignButtonEnabled() {
		WaitForObjectVisibility(btnReassignManagerDashboard);
		if (btnReassignManagerDashboard.isEnabled()) {
			sa.assertTrue(true, "Verified Reassign button is enabled");
		} else {
			OneframeLogger("Reassign button is disabled");
		}
		sa.assertAll();
	}

	@Step("Click Reassign button")
	public void clickReaasignButton() {
		WaitForObjectVisibility(btnReassignManagerDashboard);
		btnReassignManagerDashboard.click();
		OneframeLogger("Clicked on Reassign button");
	}

	@Step("Click on Yes Popup")
	public void clickYesPopUpInManagerDashboard() {
		WaitForObjectVisibility(lstPopUpReassign.get(1));
		lstPopUpReassign.get(1).click();
		OneframeLogger("Clicked on 'Yes' button");
	}

	@Step("Click on No Popup")
	public void clickNoPopUpInManagerDashboard() {
		WaitForObjectVisibility(lstPopUpReassign.get(0));
		lstPopUpReassign.get(0).click();
		OneframeLogger("Clicked on 'No' button");
	}

	@Step("Click on Proceed button")
	public void clickProceedButton() {
		WaitForObjectVisibility(btnProceed);
		btnProceed.click();
		OneframeLogger("Clicked on 'Proceed' button");
	}

	@Step("Verify Proceed button is displayed")
	public void verifyProceedButton() {
		boolean bln = false;
		if (btnProceed.isDisplayed()) {
			bln = true;
		}
		sa.assertTrue(bln, "Validated Proceed button is displayed");
	}

	@Step("Get Benefit Name")
	public String getBenefitName() {
		WaitForObjectVisibility(lstBenefitName.get(0));
		String ben = lstBenefitName.get(0).getText();
		return ben;
	}

	@Step("Get AG ID")
	public String getAGId() {
		WaitForObjectVisibility(lstAssigneeLogged.get(0));
		String agid = lstAssigneeLogged.get(0).getText();
		return agid;
	}

	@Step("Verify User Details header")
	public void verifyUserDetailsHeader() {
		WaitForObjectVisibility(hdrUserDetails);
		highlightElement(hdrUserDetails);
		sa.assertEquals(hdrUserDetails.getText(), "User Details", "Verified User Details header");
		sa.assertAll();
	}

	@Step("Click on User Details header")
	public void clickUserDetailsHeader() {
		WaitForObjectVisibility(hdrUserDetails);
		ClickWebObject(hdrUserDetails);
		ClickWebObject(hdrUserDetails);
		ClickWebObject(hdrUserDetails);
	}

	@Step("Enter AG Id in User Details serach area")
	public String enterAndGetAGIdInUserDetails(String agId) {
		WaitForObjectVisibility(txtSearch);
		txtSearch.click();
		if (agId.equalsIgnoreCase("AG91784")) {
			EnterText(txtSearch, "AH91660");
			txtSearch.sendKeys(Keys.ENTER);
		} else if (agId.equalsIgnoreCase("AH91660")) {
			EnterText(txtSearch, "AG91784");
			txtSearch.sendKeys(Keys.ENTER);
		} else if (!agId.equalsIgnoreCase("AH91660") || !agId.equalsIgnoreCase("AG91784")) {
			EnterText(txtSearch, "AG91784");
			txtSearch.sendKeys(Keys.ENTER);
		}
		return txtSearch.getAttribute("value");
	}

	@Step("Enter AG Id in User Details serach area")
	public void enterAGIdInUserDetails(String agId) {
		WaitForObjectVisibility(txtSearch);
		txtSearch.click();
		EnterText(txtSearch, agId);
		txtSearch.sendKeys(Keys.ENTER);

	}

	@Step("Click on User Details first Checkbox")
	public void clickUserDetailsCheckbox() {
		WaitForObjectVisibility(txtUserDetailsCheckbox.get(0));
		txtUserDetailsCheckbox.get(0).click();
		OneframeLogger("Clicked on User Details first Checkbox");
	}

	@Step("Verify Benefit Assigned to the Assignee")
	public void verifyBenefitAssignedToAssignee(String benefit, String assignee) {
		WaitForObjectVisibility(lstBenefitName.get(0));
		hdrMemberDashboard.click();
		hdrMemberDashboard.click();
		if (lstBenefitName.get(0).getText().equalsIgnoreCase(benefit)) {
			highlightElement(lstAssigneeLogged.get(0));
			sa.assertEquals(lstAssigneeLogged.get(0).getText(), assignee,
					"Verified benefit assigned value is same as expected");
		} else {
			OneframeLogger("Benefit assigned to wrong assignee");
		}
		sa.assertAll();
	}

	@Step("Click on Cancel in User Details")
	public void clickCancelUserDetails() {
		WaitForObjectVisibility(btnCancel);
		btnCancel.click();
		OneframeLogger("Clicked on cancel in User Details");
	}

	@Step("Click on Manager Dashboard header in Home Page ")
	public void clickManagerDashboardHeaderHomePage() {
		WaitForObjectVisibility(hdrManagerDashboard);
		hdrManagerDashboard.click();
		hdrManagerDashboard.click();
		hdrManagerDashboard.click();
	}

	@Step("Click on Filter and check Filter By text")
	public void verifyFilterButtonIsDisabled() {
		boolean bln = false;
		WaitForObjectVisibility(btnFilter);
		btnFilter.click();
		if (FindObjectByLocatorNoWait(By.xpath("//div[text()='Filter by']")) != null) {
			bln = false;
		} else {
			bln = true;
		}
		sa.assertTrue(bln, "Validated Filter By text is not visible");
	}

	@Step("Verify Pagination Element is not displayed")
	public void verifyPaginationElementIsNotDisplayed() {
		boolean bln = false;

		if (FindObjectByLocatorNoWait(By.xpath("//div[@class=\"mat-paginator-range-label\"]")) != null) {
			bln = false;
		} else {
			bln = true;
		}
		sa.assertTrue(bln, "Validated Pagination Element is not visible");
	}

	@Step("Verify Dynamic Layer header")
	public void verifyDynamicLayerHeader() {
		WaitForObjectVisibility(hdrDynamicLayer);
		sa.assertEquals(hdrDynamicLayer.getText(), "Dynamic Layer",
				"Validated Dynamic layer header value is same as expected");
	}

	@Step("Select Dynamic Layer column by clicking Select Columns")
	public void selectDynamiClayerCheckbox() {
		WaitForObjectVisibility(btnSelectColumns);
		btnSelectColumns.click();
		verifyDynamicLayerHeader();
		for (int i = 0; i < txtDynamicLayerCheckbox.size(); i++) {
			txtDynamicLayerCheckbox.get(i).click();
		}
		btnApply.click();
	}

	@Step("Verify {dynamicLayer} labels is displayed")
	public void verifyDynamicLayerslabelsAreDisplayed(String dynamicLayer) {
		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()='%s']", dynamicLayer)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to see Dynamic layer labels");
		}
		sa.assertEquals(expectedHeader.getText(), dynamicLayer, "Validated Label is : " + dynamicLayer);
	}

	@Step("Verify Dynamic Layer Element are not displayed")
	public void verifyDynamicLayerElementIsNotDisplayed() {
		boolean bln = false;

		if (FindObjectByLocatorNoWait(By.xpath("//*[text() and normalize-space()='BUSINESS ENTITY']")) != null) {
			bln = false;
		} else {
			bln = true;
		}
		sa.assertTrue(bln, "Validated Dynamic Layer Element is not visible");
	}

	@Step("Click View All Button in Manager Dashboard Section is Displayed")
	public void clickViewAllButtonManagerDashboard() {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(lnkViewAllManagerDashboard);
		ClickWebObject(lnkViewAllManagerDashboard);
	}

	@Step("Click on Pagination button")
	public void clickPaginationButton() {
		WaitForObjectVisibility(lnkPagination.get(1));
		ClickWebObject(lnkPagination.get(1));
		OneframeLogger("Clicked on Next Pagination button");
		clickManagerDashboard();
		clickManagerDashboard();
		ClickWebObject(lnkPagination.get(0));
		OneframeLogger("Clicked on Previous Pagination button");
		clickManagerDashboard();
		clickManagerDashboard();
	}

	@Step("Select client Filter dropdown value ")
	public void selectClientDropdownValue(String client) {
		try {
			if (WaitForObjectVisibility(drdFilterClient)) {
				drdFilterClient.click();
				selectDropdownValues(client);
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Client dropdown ");

		}
	}

	@Step("Select and Get client Filter dropdownvalue ")
	public String selectAndGetClientDropdownValue(String client) {
		String clientVal = null;
		try {
			if (WaitForObjectVisibility(drdFilterClient)) {
				drdFilterClient.click();
				clientVal = selDropdownValues(client);
				OneframeLogger("The Selected client Dropdown value is : " + clientVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Client dropdown ");
		}
		return clientVal;
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-container\"]"));
		ClickWebObject(overlayElement);
	}

	@Step("Select and Get Lob Filter dropdown value")
	public String selectAndGetLobFilterDropdownValue(String lob) {
		String lobVal = null;
		try {
			if (WaitForObjectVisibility(drdFilterLOB)) {
				drdFilterLOB.click();
				lobVal = selDropdownValues(lob);
				OneframeLogger("The Selected lob Dropdown value is : " + lobVal);

			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Lob dropdown ");

		}
		return lobVal;
	}

	@Step("Select and Get State Filter dropdown value")
	public String selectAndGetStateFilterDropdownValue(String State) {
		String stateVal = null;
		try {
			if (WaitForObjectVisibility(drdFilterState)) {
				drdFilterState.click();
				stateVal = selDropdownValues(State);
				OneframeLogger("The Selected State Dropdown value is : " + stateVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select State dropdown ");
		}
		return stateVal;
	}

	@Step("Select and Get Business Entity Filter dropdown value")
	public String selectAndGetBusinessEntityFilterDropdownValue(String State) {
		try {
			if (WaitForObjectVisibility(drdFilterBusinessEntity)) {
				drdFilterBusinessEntity.click();
				String stateVal = selectDropdownValue(State);
				OneframeLogger("The Selected Business Entity Dropdown value is : " + stateVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Entity dropdown ");
		}
		return drdFilterBusinessEntity.getText();
	}

	@Step("Select and Get Business Unit Filter dropdown value")
	public String selectAndGetBusinessUnitFilterDropdownValue(String State) {
		try {
			if (WaitForObjectVisibility(drdFilterBusinessUnit)) {
				drdFilterBusinessUnit.click();
				String stateVal = selectDropdownValue(State);
				OneframeLogger("The Selected Business Unit Dropdown value is : " + stateVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Unit dropdown ");
		}
		return drdFilterBusinessUnit.getText();
	}

	@Step("Verify Client filter list is Same as Expected")
	public void verifyClientFilterList(String client) {
		WaitForObjectVisibility(lstClient.get(0));
		if (lstClient.get(0).getText().equalsIgnoreCase(client)) {
			highlightElement(lstClient.get(0));
		}
		sa.assertEquals(lstClient.get(0).getText(), client, "Verified Client value is same as expected");
	}

	@Step("Verify LOB filter list is Same as Expected")
	public void verifyLOBFilterList(String LOB) {
		WaitForObjectVisibility(lstLOB.get(0));
		if (lstLOB.get(0).getText().equalsIgnoreCase(LOB)) {
			highlightElement(lstLOB.get(0));
		}
		sa.assertEquals(lstLOB.get(0).getText(), LOB, "Verified LOB value is same as expected");
	}

	@Step("Verify State filter list is Same as Expected")
	public void verifyStateFilterList(String State) {
		WaitForObjectVisibility(lstState.get(0));
		if (lstState.get(0).getText().equalsIgnoreCase(State)) {
			highlightElement(lstState.get(0));
		}
		sa.assertEquals(lstState.get(0).getText(), State, "Verified State value is same as expected");
	}

	@Step("Verify Business Entity filter list is Same as Expected")
	public void verifyBusinessEntityFilterList(String BusinessEntity) {
		WaitForObjectVisibility(lstBusinessEntity.get(0));
		if (lstBusinessEntity.get(0).getText().equalsIgnoreCase(BusinessEntity)) {
			highlightElement(lstBusinessEntity.get(0));
		}
		sa.assertEquals(lstBusinessEntity.get(0).getText(), BusinessEntity,
				"Verified Business Entity value is same as expected");
	}

	@Step("Verify Business Unit filter list is Same as Expected")
	public void verifyBusinessUnitFilterList(String BusinessUnit) {
		WaitForObjectVisibility(lstBusinessUnit.get(0));
		if (lstBusinessUnit.get(0).getText().equalsIgnoreCase(BusinessUnit)) {
			highlightElement(lstBusinessUnit.get(0));
		}
		sa.assertEquals(lstBusinessUnit.get(0).getText(), BusinessUnit,
				"Verified Business Unit value is same as expected");
	}

}

package anthem.irx.oneframe.core;

import org.testng.asserts.IAssert;
import org.testng.asserts.SoftAssert;

public class OneframeSoftAssert extends SoftAssert {
  public void onAssertSuccess(IAssert<?> assertCommand) {
    OneframeContainer.gTestResult = "PASS";
    String suffix = String.format("Expected = '%s' | Actual = '%s'", new Object[] { assertCommand.getExpected().toString(), assertCommand.getActual().toString() });
    OneframeContainer.OneframeLogger(assertCommand.getMessage() + " | Test Status -> PASSED | " + suffix);
  }
  
  public void onAssertFailure(IAssert<?> assertCommand, AssertionError ex) {
    OneframeContainer.gTestResult = "FAIL";
    String suffix = String.format(" Expected = '%s' but Actual = '%s'", new Object[] { assertCommand.getExpected().toString(), assertCommand.getActual().toString() });
    OneframeContainer.OneframeErrorLogger(assertCommand.getMessage() + " | Test Status -> FAILED |" + suffix);
  }
}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.MediaEntityBuilder;
import anthem.irx.oneframe.utilities.FileOpsHelper;
import java.io.File;
import com.aventstack.extentreports.observer.ExtentObserver;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.AnalysisStrategy;
import anthem.irx.oneframe.utilities.SystemInformation;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.ExtentReports;

public class OneframeReporter
{
    ExtentReports ExtentReport;
    ExtentSparkReporter oneframeSpark;
    static ExtentTest Logger;
    
    public OneframeReporter createExtentReport(final String ReportName) {
        final SystemInformation sysinfo = new SystemInformation();
        this.ExtentReport = new ExtentReports();
        this.oneframeSpark = new ExtentSparkReporter(this.getExtentReportHtmlFileName(ReportName));
        this.ExtentReport.setAnalysisStrategy(AnalysisStrategy.TEST);
        this.ExtentReport.setSystemInfo("Browser", OneframeContainer.TSBrowser);
        this.ExtentReport.setSystemInfo("Environment", OneframeContainer.TSExecEnvironment);
        this.ExtentReport.setSystemInfo("Platform", SystemInformation.OSName);
        this.ExtentReport.setSystemInfo("OS Version", SystemInformation.OSVersion);
        this.ExtentReport.setSystemInfo("Host Name", SystemInformation.SystemName);
        this.ExtentReport.setSystemInfo("IP Address", SystemInformation.HostAddress);
        this.ExtentReport.setSystemInfo("Java Version", SystemInformation.JavaVersion);
        this.oneframeSpark.config().setTheme(Theme.STANDARD);
        this.oneframeSpark.config().setReportName(ReportName);
        this.oneframeSpark.config().setTimelineEnabled(true);
        this.oneframeSpark.config().setTimeStampFormat("dd/MM/yyyy HH:mm:ss");
        this.oneframeSpark.config().setDocumentTitle("Sample Document");
        this.oneframeSpark.config().setProtocol(Protocol.HTTPS);
        MarkupHelper.createLabel("Pass Test", ExtentColor.GREEN);
        this.ExtentReport.attachReporter(new ExtentObserver[] { (ExtentObserver)this.oneframeSpark });
        return this;
    }
    
    private File getExtentReportHtmlFileName(final String FileName) {
        return FileOpsHelper.createFile(FileOpsHelper.createTodaysLogFolder("ExtentReports"), FileName + ".html");
    }
    
    public void CreateNode(final String NodeName) {
        if (OneframeReporter.Logger != null) {
            OneframeReporter.Logger.createNode(NodeName);
        }
    }
    
    public void CreateNode(final String NodeName, final String Status, final String base64Screenshot) {
        if (OneframeReporter.Logger != null) {
            final ExtentTest nodeLogger = OneframeReporter.Logger.createNode(NodeName);
            if (!OneframeContainer.testLogsArr.isEmpty()) {
                for (int arrSize = OneframeContainer.testLogsArr.size(), i = 0; i < arrSize; ++i) {
                    final String testLog = OneframeContainer.testLogsArr.get(i);
                    if (testLog.contains("PASS") || testLog.contains(" | Test Step Status -> PASSED | ")) {
                        nodeLogger.pass(testLog);
                    }
                    else if (testLog.contains("FAILED") || testLog.contains(" | Test Step Status -> FAILED | ") || testLog.contains("BROKEN")) {
                        if (!base64Screenshot.isEmpty()) {
                            final MediaEntityBuilder screenshot = MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot);
                            nodeLogger.fail(testLog, screenshot.build());
                        }
                        else {
                            nodeLogger.fail(testLog);
                        }
                    }
                    else {
                        nodeLogger.info(testLog);
                    }
                }
            }
        }
    }
    
    public void CreateTest(final String testName, final String testDescription) {
        OneframeReporter.Logger = this.ExtentReport.createTest(testName, testDescription);
    }
    
    public void LogInfoTestStep(final String LogMessage) {
        if (OneframeReporter.Logger != null) {
            OneframeReporter.Logger.info(LogMessage);
        }
    }
    
    public void LogPassTestStep(final String LogMessage) {
        if (OneframeReporter.Logger != null) {
            OneframeReporter.Logger.log(Status.PASS, LogMessage);
        }
    }
    
    public void LogFailTestStep(final String LogMessage) {
        if (OneframeReporter.Logger != null) {
            OneframeReporter.Logger.log(Status.FAIL, LogMessage);
        }
    }
    
    public void LogFailTestStep(final Throwable throwableException) {
        if (OneframeReporter.Logger != null) {
            OneframeReporter.Logger.fail(throwableException);
        }
    }
    
    public void LogFailTestStep(final String LogMessage, final String base64Screenshot) {
        if (OneframeReporter.Logger != null) {
            final MediaEntityBuilder screenshot = MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot);
            OneframeReporter.Logger.log(Status.FAIL, LogMessage, screenshot.build());
        }
    }
    
    public void CompleteTest(final Status testStatus, final String testName) {
        if (OneframeReporter.Logger != null) {
            OneframeReporter.Logger.log(testStatus, testName);
        }
    }
    
    public void FinishExtentReport() {
        this.ExtentReport.flush();
    }
    
    public static File getSourcePathTestNGemailableReport() {
        final File source = new File(OneframeConstants.TESTOUTPUT_FOLDER + "emailable-report.html");
        return source;
    }
}

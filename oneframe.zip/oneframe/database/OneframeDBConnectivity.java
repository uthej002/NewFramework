// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.database;

public class OneframeDBConnectivity
{
    public OneframeDBConnectivity(Databases db) {
        db = Databases.MongoDB;
        switch (db) {
            case MongoDB: {}
        }
    }
}

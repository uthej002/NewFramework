package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateEditFunctionalityOfCOBPackage extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validating Edit Functionality of COB Package")
	public void setUp() {
		InitializeLaunchPad("IBPW_787");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "packageNameVal" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit Functionality of COB Package", dataProvider = "TestData")
	@Description("Validate Edit Functionality of COB Package")
	public void ValidateCOBDefaultDynamicLayer(String TestCaseID, String TestStatus, String packageNameVal)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			controls.clickViewButtonofControls();
			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'Controls' header is displayed");
			//controls.clickControlsHeader();
			controls.clickCOBPackageTab();
			controls.clickControlsHeader();
			// controls.clickFirstRecordCOBPackage();
			sa.assertTrue(controls.verifyAndClickPackageName(packageNameVal), "Verified and Clicked Package Name");
			sa.assertTrue(controls.verifyCOBPackageDetailsHeader(),
					"Verified 'COB Package Details' header is displayed");
			sa.assertTrue(controls.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			sa.assertTrue(controls.verifyPackageNameFieldIsEnabled(), "Verified 'Package Name field' is Enabled");
			String packageName = controls.editAndGetPackageName();
			sa.assertTrue(controls.verifyCancelButton(), "Verified 'Cancel button' is displayed");
			sa.assertTrue(controls.verifySaveChangesButton(), "Verified 'Save Changes button' is displayed");
			controls.clickCancelButton();
			sa.assertTrue(controls.verifyLeaveWithOutSavingHeader(),
					"Verified 'Leave With out Saving header' is displayed");
			sa.assertTrue(controls.verifyTextYouhaveMadeChanges(),
					"Verified text 'You have made changes' is displayed");
			sa.assertTrue(controls.verifyCancelButtonInLeavePage(),
					"Verified 'Cancel button in Leave Without Saving Page' is displayed");
			sa.assertTrue(controls.verifyLeaveButtonInLeavePage(),
					"Verified 'Leave button in Leave Without Saving Page' is displayed");
			controls.clickCancelButtonInLeavePage();
			sa.assertTrue(controls.verifyPackageNameFieldIsEnabled(), "Verified 'Package Name field' is Enabled");
			controls.clickCancelButton();
			controls.clickLeaveButtonInLeavePage();
			sa.assertTrue(!controls.verifyEditedPackageName(packageName),
					"Verified the 'Edited Package name is not same'");
			sa.assertTrue(controls.verifyAndClickEditButton(), "Verified and Clicked 'edit' button");
			sa.assertTrue(controls.verifyPackageNameFieldIsEnabled(), "Verified 'Package Name field' is Enabled");
			String packageNm = controls.editAndGetPackageName();
			controls.clickSaveChangesButton();
			sa.assertTrue(controls.verifyChangesSavedText(), "Verified 'Save Changes text' is displayed");
			controls.clickCOBPackageDetailsHeader();
			sa.assertTrue(controls.verifyEditedPackageName(packageNm),
					"Verified the 'Edited Package name is same' as expected");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit Functionality of COB Package is  Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Edit Functionality of COB Package");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

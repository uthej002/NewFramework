// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import anthem.irx.oneframe.utilities.CustomStringOps;
import io.qameta.allure.Step;

public class OneframeAssertion
{
    @Step("{TestStepDescription}")
    public static void AssertTestStep(final String TestStepDescription, final String expectedResult, final String actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    @Step("{TestStepDescription}")
    public static void AssertTestStep(final String TestStepDescription, final String[] expectedResult, final String[] actualResult) {
        OneframeContainer.sa.assertEquals((Object[])actualResult, (Object[])expectedResult, TestStepDescription);
    }
    
    @Step("{TestStepDescription}")
    public static void AssertTestStep(final String TestStepDescription, final boolean expectedResult, final boolean actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    @Step("{TestStepDescription}")
    public static void AssertTestStep(final String TestStepDescription, final int expectedResult, final int actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    @Step("{TestStepDescription}")
    public static void AssertTestStep(final String TestStepDescription, final long expectedResult, final long actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    @Step("{TestStepDescription}")
    public static void AssertTestStep(final String TestStepDescription, final Object expectedResult, final Object actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    public static void AssertResult(final String TestStepDescription, final String expectedResult, final String actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    public static void AssertResult(final String TestStepDescription, String expectedResult, String actualResult, final boolean IgnoreCaseSensitivity, final boolean IgnoreSpace) {
        if (IgnoreCaseSensitivity && IgnoreSpace) {
            actualResult = CustomStringOps.ofStringTrimmedAndLowerCase(actualResult);
            expectedResult = CustomStringOps.ofStringTrimmedAndLowerCase(expectedResult);
        }
        if (IgnoreCaseSensitivity && !IgnoreSpace) {
            actualResult = CustomStringOps.ofStringToLowercase(actualResult);
            expectedResult = CustomStringOps.ofStringToLowercase(expectedResult);
        }
        if (!IgnoreCaseSensitivity && IgnoreSpace) {
            actualResult = CustomStringOps.ofStringTrim(actualResult);
            expectedResult = CustomStringOps.ofStringTrim(expectedResult);
        }
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    public static void AssertResult(final String TestStepDescription, final String[] expectedResult, final String[] actualResult) {
        if (actualResult.length != expectedResult.length) {
            OneframeContainer.OneframeErrorLogger("Expected and Actual Result array size is not equal");
        }
        else {
            OneframeContainer.sa.assertEquals((Object[])actualResult, (Object[])expectedResult, TestStepDescription);
        }
    }
    
    public static void AssertResult(final String TestStepDescription, final String[] expectedResult, final String[] actualResult, final boolean IgnoreCaseSensitivity, final boolean IgnoreSpace) {
        if (actualResult.length != expectedResult.length) {
            OneframeContainer.OneframeErrorLogger("Expected and Actual Result array size is not equal");
        }
        else {
            for (int i = 0; i < expectedResult.length; ++i) {
                if (IgnoreCaseSensitivity && IgnoreSpace) {
                    actualResult[i] = CustomStringOps.ofStringTrimmedAndLowerCase(actualResult[i]);
                    expectedResult[i] = CustomStringOps.ofStringTrimmedAndLowerCase(expectedResult[i]);
                }
                if (IgnoreCaseSensitivity && !IgnoreSpace) {
                    actualResult[i] = CustomStringOps.ofStringToLowercase(actualResult[i]);
                    expectedResult[i] = CustomStringOps.ofStringToLowercase(expectedResult[i]);
                }
                if (!IgnoreCaseSensitivity && IgnoreSpace) {
                    actualResult[i] = CustomStringOps.ofStringTrim(actualResult[i]);
                    expectedResult[i] = CustomStringOps.ofStringTrim(expectedResult[i]);
                }
            }
        }
        OneframeContainer.sa.assertEquals((Object[])actualResult, (Object[])expectedResult, TestStepDescription);
    }
    
    public static void AssertResult(final String TestStepDescription, final boolean expectedResult, final boolean actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    public static void AssertResult(final String TestStepDescription, final int expectedResult, final int actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    public static void AssertResult(final String TestStepDescription, final long expectedResult, final long actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    public static void AssertResult(final String TestStepDescription, final Object expectedResult, final Object actualResult) {
        OneframeContainer.sa.assertEquals(actualResult, expectedResult, TestStepDescription);
    }
    
    public static void AssertTruetResult(final String TestStepDescription, final boolean actualResult) {
        OneframeContainer.sa.assertTrue(actualResult, TestStepDescription);
    }
    
    public static void AssertFalseResult(final String TestStepDescription, final boolean actualResult) {
        OneframeContainer.sa.assertFalse(actualResult, TestStepDescription);
    }
}

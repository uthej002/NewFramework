// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTest;

import org.qas.qtest.api.services.search.model.SearchResult;
import org.qas.qtest.api.internal.model.FieldValue;
import org.qas.qtest.api.services.design.model.TestCase;
import org.qas.qtest.api.services.search.model.SearchArtifactRequest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.qas.qtest.api.services.project.model.Project;
import org.qas.qtest.api.services.project.model.ListProjectRequest;
import org.qas.qtest.api.services.search.SearchServiceClient;
import org.qas.api.ClientConfiguration;
import org.qas.qtest.api.services.attachment.AttachmentServiceClient;
import org.qas.qtest.api.services.execution.TestExecutionServiceClient;
import org.qas.qtest.api.services.design.TestDesignServiceClient;
import org.qas.qtest.api.services.plan.TestPlanServiceClient;
import org.qas.qtest.api.services.project.ProjectServiceClient;
import anthem.irx.oneframe.core.OneframeContainer;
import org.qas.qtest.api.services.search.SearchService;
import org.qas.qtest.api.services.attachment.AttachmentService;
import org.qas.qtest.api.services.execution.TestExecutionService;
import org.qas.qtest.api.services.design.TestDesignService;
import org.qas.qtest.api.services.plan.TestPlanService;
import org.qas.qtest.api.services.project.ProjectService;

public class qTestManager
{
    QTestConnection qTestCon;
    String qTestEndPoint;
    ProjectService qTestProjectService;
    TestPlanService qTestTestPlanService;
    TestDesignService qTestTestDesignService;
    TestExecutionService qTestTestExecutionService;
    AttachmentService qTestAttachmentService;
    SearchService qTestSearchService;
    
    public qTestManager() {
        if (!OneframeContainer.loadedOneframeProperties && !OneframeContainer.loadedOneframeProperties) {
            OneframeContainer.OneframeLogger("Test is not executed via onframe launchpad");
            final OneframeContainer ofctemp = new OneframeContainer();
            OneframeContainer.readOneframeConfiguration();
        }
        if (OneframeContainer.ofcqTestEnabled) {
            this.qTestCon = new QTestConnection();
            (this.qTestProjectService = (ProjectService)new ProjectServiceClient(this.qTestCon.QTestCredential)).setEndpoint(OneframeContainer.ofcQTestHost);
            (this.qTestTestPlanService = (TestPlanService)new TestPlanServiceClient(this.qTestCon.QTestCredential)).setEndpoint(OneframeContainer.ofcQTestHost);
            (this.qTestTestDesignService = (TestDesignService)new TestDesignServiceClient(this.qTestCon.QTestCredential)).setEndpoint(OneframeContainer.ofcQTestHost);
            (this.qTestTestExecutionService = (TestExecutionService)new TestExecutionServiceClient(this.qTestCon.QTestCredential)).setEndpoint(OneframeContainer.ofcQTestHost);
            (this.qTestAttachmentService = (AttachmentService)new AttachmentServiceClient(this.qTestCon.QTestCredential)).setEndpoint(OneframeContainer.ofcQTestHost);
            (this.qTestSearchService = (SearchService)new SearchServiceClient(this.qTestCon.QTestCredential, new ClientConfiguration())).setEndpoint(OneframeContainer.ofcQTestHost);
        }
    }
    
    public long getQtestProjectID(final String qTestProjectName) {
        boolean projFound = false;
        long projId = -1L;
        final ListProjectRequest ProjectListRequest = new ListProjectRequest();
        final List<Project> qTestProjects = (List<Project>)this.qTestProjectService.listProject(ProjectListRequest);
        for (int i = 0; i < qTestProjects.size(); ++i) {
            if (qTestProjects.get(i).getName().equalsIgnoreCase(qTestProjectName)) {
                projFound = true;
                projId = qTestProjects.get(i).getId();
                break;
            }
        }
        if (projId == -1L) {
            OneframeContainer.OneframeErrorLogger("Project [" + qTestProjectName + "] not found in qTest");
        }
        return projId;
    }
    
    public HashMap<String, Object> getQTestCaseDetails(final long ProjectID, final String strAutomationContent) {
        final HashMap<String, Object> testCaseDetailsMap = new HashMap<String, Object>();
        final List<String> searchResultFields = Arrays.asList("id", "pid", "name", "description", "properties");
        final SearchArtifactRequest searchRequest = new SearchArtifactRequest();
        searchRequest.setProjectId(Long.valueOf(ProjectID));
        searchRequest.setFields((List)searchResultFields);
        searchRequest.setQuery("'Automation' = 'Yes' and 'Automation Content' = '" + strAutomationContent + "'");
        final SearchResult<TestCase> TestCaseResults = (SearchResult<TestCase>)this.qTestSearchService.searchTestCase(searchRequest);
        final int testCaseCt = (int)TestCaseResults.getTotal();
        if (testCaseCt < 1) {
            OneframeContainer.OneframeErrorLogger("Test case with automation content - [" + strAutomationContent + "] not found in qTest,fix qTest test cases");
            System.exit(1);
        }
        else {
            OneframeContainer.OneframeLogger("Test case with automation content - [" + strAutomationContent + "] found in qTest,fix qTest test cases");
        }
        final List<TestCase> testcaseDetails = (List<TestCase>)TestCaseResults.getItems();
        testCaseDetailsMap.put("TC_ID", testcaseDetails.get(0).getId());
        testCaseDetailsMap.put("TC_PID", testcaseDetails.get(0).getPid());
        testCaseDetailsMap.put("TC_name", testcaseDetails.get(0).getName());
        testCaseDetailsMap.put("TC_description", testcaseDetails.get(0).getDescription());
        final List<FieldValue> testCaseFieldValues = (List<FieldValue>)testcaseDetails.get(0).getFieldValues();
        for (int i = 0; i < testCaseFieldValues.size(); ++i) {
            final FieldValue tcProperties = testCaseFieldValues.get(i);
            if (tcProperties.getProperty("field_name").toString().equalsIgnoreCase("Automation Content")) {
                testCaseDetailsMap.put("TC_automation_content", tcProperties.getValue());
            }
        }
        return testCaseDetailsMap;
    }
    
    public long getQTestRunID(final long ProjectID, final long TC_id) {
        final long testRunID = 0L;
        return testRunID;
    }
}

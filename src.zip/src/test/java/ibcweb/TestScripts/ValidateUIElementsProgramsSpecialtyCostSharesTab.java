package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsCostOfCare;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLibrariesSpecialtyPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateUIElementsProgramsSpecialtyCostSharesTab extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesSpecialtyPage specialtyPage;
	IBPLibrariesProgramsCostOfCare costOfCareTab;
	
	@BeforeClass
	@Step("Initializing Test Script for Validating UI Elements in Libraries Programs Specialty CostShares Tab")
	public void setUp() {
		InitializeLaunchPad("IBPW_476");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		specialtyPage = new IBPLibrariesSpecialtyPage();
		costOfCareTab = new IBPLibrariesProgramsCostOfCare();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Pos Dur Details", dataProvider = "TestData")
	@Description("Validate Pos Dur Details")
	public void ValidatePosDurDetails(String TestCaseID, String TestStatus)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickOnSpeciality();
			//sa.assertTrue(librariesprogramspage.clickAddProgramofPrograms(), "Click on Add a speicalty button");
			sa.assertTrue(librariesprogramspage.clickAddaSpecialtyProgram(), "Click on Add a speicalty button");
			sa.assertTrue(mandate.selectCostShareOverrideDropdown("Yes"), "Verified and Selected Cost Share OverRide dropdown as 'Yes'");
			sa.assertTrue(specialtyPage.clickCostSharesTab(), "Clicked on CostShares Tab");
			sa.assertTrue(specialtyPage.verifyAncillayToggleIsEnabled(), "Verified Ancillary Charges Apply toggle is enabled");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Cost Share Structure"), "Verified Cost Share Structure heading is displayed");
			sa.assertTrue(specialtyPage.clickCostShareStructureDropdown(), "Clicked on CostShare Structure dropdown");
			sa.assertTrue(specialtyPage.validateCostShareStructureDropdownContens(), "Verified Cost Share Structure dropdown contains valid data");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Cost Share Tier Structure"), "Verified Cost Share Tier Structure heading is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Custom Stepping"), "Verified Custom Stepping heading is displayed");
			sa.assertTrue(specialtyPage.clickCustomSteppingToggle(), "Clicked on Custom Stepping Toggle");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("INN Retail"), "Verified INN Retail heading is displayed");
			sa.assertTrue(specialtyPage.verifyInnRetailInputBoxIsDisplayed(), "Verified INN Retail Input Box is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("INN Home Delivery"), "Verified INN Home Delivery heading is displayed");
			sa.assertTrue(specialtyPage.verifyInnHomeDeliveryInputBoxIsDisplayed(), "Verified INN Home Delivery Input Box is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("OON Retail"), "Verified OON Retail heading is displayed");
			sa.assertTrue(specialtyPage.verifyOnnRetailInputBoxIsDisplayed(), "Verified ONN Retail Input Box is displayed");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated UI Elements in Libraries Programs Specialty CostShares Tab");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate UI Elements in Libraries Programs Specialty CostShares Tab");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

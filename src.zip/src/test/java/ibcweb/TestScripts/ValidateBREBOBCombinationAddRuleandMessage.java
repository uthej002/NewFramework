package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBREBOBCombinationAddRuleandMessage extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;
	IBPRuleIDPage ruleidpage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Edit Rule Page")
	public void setUp() {
		InitializeLaunchPad("IBPW_832");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();
		ruleidpage = new IBPRuleIDPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {
		String[] fieldNames = { "TestCaseID", "TestStatus", "TestDescription", 
				 "ClientId", "LobId", "StateId" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Add Rule option disable", dataProvider = "TestData")
	@Description("Validate Add Rule option disable")
	public void ValidateEditRulePage(String TestCaseID, String TestStatus, String TestDescription,
			  String ClientId, String LobId, String StateId) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();	
			sa.assertTrue(addrulepage.selectClientIdDropdown(ClientId), "Client Dropdown has been selected");
			sa.assertTrue(addrulepage.selectLobIdDropdown(LobId), "Lob Dropdown has been selected");
			sa.assertTrue(addrulepage.selectStateIdDropdown(StateId), "State Dropdown has been selected");	
			sa.assertTrue(addrulepage.verifyAddRuleText(), "Verified Add Rule Text");
			sa.assertTrue(addrulepage.verifyDynamicRuleText(), "Verified Dynamic Rule Text");	
			sa.assertTrue(addrulepage.clickSelectDisbaledButton(), "Verified Select option is disabled");
			sa.assertTrue(addrulepage.clickAddRuleDisbaledButton(), "Verified Add Rule button is disabled");	
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Disbaled Add Rule button, Add rule text and Disabled Select option successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Disbaled Add Rule button, Add rule text and Disabled Select option");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}


}

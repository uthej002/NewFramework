// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

public enum DriverType
{
    CHROME, 
    CHROME_HEADLESS, 
    CHROME_MOB_EMULATOR, 
    FIREFOX, 
    FIREFOX_HEADLESS, 
    IE, 
    EDGE, 
    OPERA, 
    SAFARI;
}

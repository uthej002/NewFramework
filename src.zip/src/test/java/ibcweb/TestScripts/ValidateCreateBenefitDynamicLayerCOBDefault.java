package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitCostSharesPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreateBenefitDynamicLayerCOBDefault extends OneframeContainer {
	
	IBPWelcomePage welcomepage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitCostSharesPage benefitcostsharespage;
	
   @BeforeClass
   @Step("Intializing Test Script for Check if the exixsting cob default is pulled to benefit when benefit created with same BOB and dynamic layer combination")
   public void setUp() {
	   InitializeLaunchPad("IBPW_888");
	   welcomepage = new IBPWelcomePage();
	   loginpage =  new IBPLoginPage();
	   homepage = new IBPHomePage();
	   benefitpage = new IBPBenefitPage();
	   createbenefitpage = new IBPCreateBenefitPage();
	   benefitcostsharespage = new IBPBenefitCostSharesPage();
   }
   
   @DataProvider(name="TestData")
   public Object[][] getTestData(){
	   
	   String[] fieldNames = {"TestCaseID","TestStatus","Benefit", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType", "MarketSegment",
				"ProductType","COBPackage","COBMethod"};
	   List<String> TestDataFields = Arrays.asList(fieldNames);
	   return GetTestDatafromTDS(TestDataFields);	   
   }
   
   @Test(description ="Check if the exixsting cob default is pulled to benefit when benefit created with same BOB and dynamic layer combination",dataProvider="TestData")
   @Description("Check if the exixsting cob default is pulled to benefit when benefit created with same BOB and dynamic layer combination")
   public void createBenefitCOBDefault(String TestCaseID, String TestStatus, String Benefit, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String AutoApply, String BusinessEntity,
			String BusinessUnit, String CDHP, String Formulary, String FundingType, String MarketSegment,
			String ProductType, String COBPackage,String COBMethod) throws Throwable{
	   
	   OneframeSoftAssert sa = new OneframeSoftAssert();
	   SetTestRunVariables(TestCaseID);
	   StartApplication();	   
	   if(loginpage.MemberLogin()) {
		  homepage.verifyandclickSearchButton();
		  homepage.verifySearchBenefitTextBox();
		  homepage.EnterBenefit(Benefit);
		  sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			benefitpage.verifyCreateaBenefitButtonDisplay();
			benefitpage.clickCreateaBenefitButton();
			sa.assertTrue(createbenefitpage.verifyCreateBenefit(), "Verified 'Create Benefit button' is displayed");
			sa.assertTrue(createbenefitpage.verifyBenefitHeader(), "Verified 'Benefit Header' is displayed");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(createbenefitpage.selectClientDropdown(ClientId), "Verified and selected 'Client dropdown'");
			sa.assertTrue(createbenefitpage.selectLOBDropdown(LOBId), "Verified and selected 'LOB dropdown' ");
			sa.assertTrue(createbenefitpage.selectStateDropdown(StateId), "Verified and selected 'State dropdown'");
			createbenefitpage.clickBenefitHeader();
			sa.assertTrue(createbenefitpage.verifyAutoApplyDropdown(), "Verified 'Auto Apply dropdown' is displayed");
			createbenefitpage.selectBenefitAutoApplyDropdown(AutoApply);
			sa.assertTrue(createbenefitpage.selectBusinessEntityDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(createbenefitpage.selectBusinessUnitDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' dropdown");
			sa.assertTrue(createbenefitpage.selectCDHPTypeDropdown(CDHP), "Verified and Selected 'CDHP Type' dropdown");
			sa.assertTrue(createbenefitpage.selectFormularyDropdown(Formulary),
					"Verified and Selected 'Formulary' dropdown");
			sa.assertTrue(createbenefitpage.selectFundingTypeDropdown(FundingType),
					"Verified and Selected 'Funding Type' dropdown");
			sa.assertTrue(createbenefitpage.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' dropdown");
			sa.assertTrue(createbenefitpage.selectProductTypeDropdown(ProductType),
					"Verified and Selected 'Product Type' dropdown");
			sa.assertTrue(createbenefitpage.selectMandatesDropdownForDynamicLayer(),
					"Verified and Selected 'Mandates Dropdown'");
			createbenefitpage.clickRequestBenefitIDButtonGetBenefitID();
			createbenefitpage.ClickCBCreateButton();
			benefitcostsharespage.clickCostSharesTab();
			benefitcostsharespage.clickCOBSubTab();
		    sa.assertTrue(benefitcostsharespage.selectCobPackageDropdown(COBPackage),
					"Verified and Selected 'COB Package' dropdown");
		    sa.assertTrue(benefitcostsharespage.selectCobProcessingMethodDropdown(COBMethod),
					"Verified and Selected 'COB Processing Method' dropdown");
		    benefitcostsharespage.clickCostSharesheader();
		    sa.assertTrue(benefitcostsharespage.verifyCOBPackageValue(COBPackage),
					"Verified Existing COB Package value displayed in COB Package Dropdown");
		    sa.assertTrue(benefitcostsharespage.verifyCOBProcessingMethodValue(COBMethod),
					"Verified Existing COB Processing Method value displayed in COB Processing Method Dropdown");	   
	        sa.assertAll();
	        gTestResult=RESULT_PASS;
	        OneframeLogger("Validated exixsting cob default is pulled to benefit when benefit created with same BOB and dynamic layer combination Successfully");
	   }else {
		    gTestResult=RESULT_FAIL;
		    OneframeLogger("Unable to validate exixsting cob default is pulled to benefit when benefit created with same BOB and dynamic layer combination");
	   }
	        homepage.clickLogout();	   
   }
   
     @AfterMethod
     public void TestMethodClosure() {
    	   OneframeLogger("After Exceuting the Test");
    	   UpdateTestResultsToTDS();
    	   ResetTestResults();
     }
     
     @AfterClass
     @Step("Cleanup Test Lanchpad")
     public void TestClosureAfter() {
    	 CloseLaunchPad();
    	 OneframeLogger("AfterClass");   	 
     }
     
     @AfterTest
     public void TestClosure() {
    	 OneframeLogger("After Exceuting All Tests");
     }
     
}

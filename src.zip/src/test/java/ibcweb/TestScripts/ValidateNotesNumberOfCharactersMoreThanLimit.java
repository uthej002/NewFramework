package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitDetailsPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateNotesNumberOfCharactersMoreThanLimit extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPBenefitDetailsPage details;

	@BeforeClass
	@Step("Initializing Test Script for Validate Notes field does not take more than 256 characters")
	public void setUp() {
		InitializeLaunchPad("IBPW_851");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		details = new IBPBenefitDetailsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit", "Status", "Notes" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Notes field does not take more than 256 characters", dataProvider = "TestData")
	@Description("Validate Notes field does not take more than 256 characters")
	public void ValidateCreateBenefitDynamicLayer(String TestCaseID, String TestStatus, String Benefit, String Status,
			String Notes) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			benefitpage.clickSearchResults();
			sa.assertTrue(details.verifyAndClickBenefitWithInProgressStatus(Status),
					"Verified and clicked Benefit status in In-Progress");
			benefitpage.clickEditButton();
			sa.assertTrue(createbenefitpage.CheckVerifyButtonisDisplayed(), "Verified the Verify Button is displayed");
			sa.assertTrue(details.verifyHistoryAndDocumentHeader(),
					"Verified History and documentation header is displayed");
			sa.assertTrue(details.verifyNotesHeader(), "Verified Notes header is displayed");
			sa.assertTrue(details.verifyEnterNotes(Notes),
					"Verified Notes value can't be added more than 256 characters");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Notes field does not take more than 256 characters");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Notes field that does not take more than 256 characters");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

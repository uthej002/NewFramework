package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibraryCostofCareMultiselectDynamicLayerDropdowns extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPLibrariesMandatesPage mandate;

	@BeforeClass
	@Step("Initializing Test Script for Validate if the dynamic layer categories are multiselect other than the Auto Apply category while creating a Cost of Care Program.")
	public void setUp() {
		InitializeLaunchPad("IBPW_750");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		mandate =  new IBPLibrariesMandatesPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","ClientId", "EffectiveDate", "LOBId", "StateId",
				"AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType", "MarketSegment",
				"ProductType", "Other","TermDate","GeneralOverride", "NetworkOverride", "CostShareOverride", "AccumOverride"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate if the dynamic layer categories are multiselect other than the Auto Apply category while creating a Cost of Care Program.", dataProvider = "TestData")
	@Description("Validate if the dynamic layer categories are multiselect other than the Auto Apply category while creating a Cost of Care Program.")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus,String ClientId,
			String EffectiveDate, String LOBId, String StateId, String AutoApply, String BusinessEntity,
			String BusinessUnit, String CDHP, String Formulary, String FundingType, String MarketSegment,
			String ProductType, String Other,String TermDate,String GeneralOverride, String NetworkOverride, String CostShareOverride,
			String AccumOverride)throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickCostofCareofPrograms();
			librariesprogramspage.clickAddProgramofPrograms();
			sa.assertTrue(librariesprogramspage.verifyAddNewProgramHeader(), "The Add New Program Section Page is displayed");
			String programName = librariesprogramspage.enterAndGetProgramName("Cost of Care");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			librariesprogramspage.EnterTermDate(TermDate);
			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId), "The ClientID dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectLobdropdown(LOBId), "The LOB dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectStatedropdown(StateId), "The State dropdown has been selected");
			librariesprogramspage.clickAddNewProgram();
			sa.assertTrue(mandate.selectFederalAutoApplyDropdown(AutoApply),
					"Verified and Selected 'Auto Apply' dropdown");
			sa.assertTrue(mandate.selectBusinessEntityDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(librariesprogramspage.selectBusinessUnitDropdown(BusinessUnit),
					"Verified and Selected Mutliple Values 'Business Unit' dropdown");
			sa.assertTrue(librariesprogramspage.selectCDHPTypeDropdown(CDHP), "Verified and Selected Mutliple Values 'CDHP Type' dropdown");
			sa.assertTrue(librariesprogramspage.selectFormularyDropdown(Formulary), "Verified and Selected Mutliple Values 'Formulary' dropdown");
			sa.assertTrue(librariesprogramspage.selectFundingTypeDropdown(FundingType),
					"Verified and Selected Mutliple Values 'Funding Type' dropdown");
			sa.assertTrue(librariesprogramspage.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected Mutliple Values 'Market Segment' dropdown");
			sa.assertTrue(librariesprogramspage.selectProductTypeDropdown(ProductType),
					"Verified and Selected Mutliple Values 'Product Type' dropdown");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if the dynamic layer categories are multiselect other than the Auto Apply category while creating a Cost of Care Program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to create a Cost of Care Program if the dynamic layer categories are multiselect other than the Auto Apply category.");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

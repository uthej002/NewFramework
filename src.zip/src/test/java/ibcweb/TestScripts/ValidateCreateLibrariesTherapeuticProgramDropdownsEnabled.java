package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreateLibrariesTherapeuticProgramDropdownsEnabled extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPLibrariesMandatesPage mandate;

	@BeforeClass
	@Step("Initializing Test Script for Validating if the General/Network/CostShares/Accum tabs are enabled after selecting General/Network/CostShares/Accum overrides as Yes in the form while creating a Therapeutic Program.")
	public void setUp() {
		InitializeLaunchPad("IBPW_711");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		mandate =  new IBPLibrariesMandatesPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "EffectiveDate", "LOBId", "StateId","TermDate","GeneralOverride", "NetworkOverride", "CostShareOverride", "AccumOverride"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate if the General/Network/CostShares/Accum tabs are enabled after selecting General/Network/CostShares/Accum overrides as Yes in the form while creating a Therapeutic Program.", dataProvider = "TestData")
	@Description("Validate if the General/Network/CostShares/Accum tabs are enabled after selecting General/Network/CostShares/Accum overrides as Yes in the form while creating a Therapeutic Program.")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus, String ClientId,
			String EffectiveDate, String LOBId, String StateId,String TermDate,String GeneralOverride, String NetworkOverride, String CostShareOverride,
			String AccumOverride)throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickAddProgramofPrograms();
			sa.assertTrue(librariesprogramspage.verifyAddNewProgramHeader(), "The Add New Program Section Page is displayed");
			librariesprogramspage.enterAndGetProgramName("TestAuto");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			librariesprogramspage.EnterTermDate(TermDate);
			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId), "The ClientID dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectLobdropdown(LOBId), "The LOB dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectStatedropdown(StateId), "The State dropdown has been selected");
			sa.assertTrue(mandate.selectGeneralOverrideDropdownYes(GeneralOverride),
					"Verified and Selected General OverRide dropdown as 'Yes'");
			sa.assertTrue(mandate.selectNetworkOverrideDropdown(NetworkOverride),
					"Verified and Selected 'Network OverRide' dropdown as 'Yes'");
			sa.assertTrue(mandate.selectCostShareOverrideDropdown(CostShareOverride),
					"Verified and Selected 'CostShare OverRide' dropdown as 'Yes'");
			sa.assertTrue(mandate.selectAccumsOverrideDropdown(AccumOverride),
					"Verified and Selected 'Accums OverRide' dropdown as 'Yes'");
			sa.assertTrue(librariesprogramspage.verifyTabsEnabled(), "Verified General/Network/CostShares/Accum tabs are enabled ");			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if the General/Network/CostShares/Accum tabs are enabled after selecting General/Network/CostShares/Accum overrides as Yes in the form while creating a Therapeutic Program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to create a Therapeutic Program");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

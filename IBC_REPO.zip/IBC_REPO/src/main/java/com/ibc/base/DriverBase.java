package com.ibc.base;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.ibc.config.ConfigFileReader;

public class DriverBase {
	private static DriverBase instance = null;
	private WebDriver driver;
	private static ConfigFileReader configFileReader;

	private DriverBase() {
		configFileReader= new ConfigFileReader();
		String browser= configFileReader.getBrowser();
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + configFileReader.getBrowserPath());
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");
			driver = new FirefoxDriver();
		} else {
			throw new IllegalArgumentException("Invalid browser option: " + browser);
		}
	}
	public static DriverBase getInstance() {
		if (instance == null) {
			instance = new DriverBase();
		}
		return instance;
	}

	public WebDriver getDriver() {
		return driver;
	}
	
	public static void setInstanceNull() {
		instance = null;
	}

}


package ibcweb.TestScripts;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.geom.GeneralPath;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.CSVFile;
import anthem.irx.oneframe.utilities.ExcelFile;
import ibcweb.PageObjects.IBPBulkUpdateBulkUpdatedPage;
import ibcweb.PageObjects.IBPBulkUpdatePage;
import ibcweb.PageObjects.IBPBulkUpdateReviewPage;
import ibcweb.PageObjects.IBPBulkUpdateWorkInProgressPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class BulkUpdateForPerfEnv extends OneframeContainer {
	
		IBPWelcomePage welcomePage;
		IBPLoginPage   loginpage;
		IBPHomePage homepage;
		IBPBulkUpdatePage bulkUpdatePage;
		IBPBulkUpdateWorkInProgressPage workInProgressPage;
		IBPBulkUpdateBulkUpdatedPage bulkUpdatedPage;
		IBPBulkUpdateReviewPage reviewPage;
		// move to page object
		Robot robot;
		String highDollarRetialBeforeUpdate;
		String highDollarHomeDeliveryBeforeUpdate;

	@BeforeClass
	@Step("Initializing Test Script for validating Butterscotch App Login")
	public void setUp() {
		InitializeLaunchPad("IBPW_X1002");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		bulkUpdatePage = new IBPBulkUpdatePage();
		workInProgressPage = new IBPBulkUpdateWorkInProgressPage();
		reviewPage = new IBPBulkUpdateReviewPage();
		bulkUpdatedPage = new IBPBulkUpdateBulkUpdatedPage();
	}

	@DataProvider(name = "LoginTestData")
	public Object[][] getLoginTestDataTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Module", "DataSheetWithBenefits"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Create Bulk Update Project", dataProvider = "LoginTestData")
	@Description("Validate Create Bulk Update Project")
	public void ValidateCreateBulkUpdateProject(String TestCaseID, String TestStatus, String Module, String DataSheetWithBenefits) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			int numberOfRows = bulkUpdatePage.getRowCount(DataSheetWithBenefits);
			
			homepage.clickMenuButton();
			bulkUpdatePage.clickBulkProcess();
			bulkUpdatePage.clickBulkUpdate();
			
			//Creating a New Project
			bulkUpdatePage.clickOnCreateAProjectButton();
			sa.assertTrue(bulkUpdatePage.verifyCreateProjectHilightedInProgressBar(), "'Create Project' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatePage.verifyCreateAProjectHeader(), "'Create a Project' heading is displayed");
			sa.assertTrue(!bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is disabled");
			sa.assertTrue(bulkUpdatePage.verifyProjectDataHeading(), "'Project Data' heading is displayed");	
			sa.assertTrue(bulkUpdatePage.verifyProjectIDHeading(), "'Project ID' heading is displayed");
			sa.assertTrue(bulkUpdatePage.verifyProjectDescriptionHeading(), "'Description' heading is displayed");
			sa.assertTrue(bulkUpdatePage.verifyAndEnterProjectID("Test"), "Verified and entered project id");
			sa.assertTrue(bulkUpdatePage.verifyAndEnterProjectDescription("Test Auto Project Desc"), "Verified and entered project description");
			sa.assertTrue(workInProgressPage.selectModuleDropdown(Module) , "Selected Module as General Defaults");
			
			bulkUpdatePage.clickOnFileUploadButton();
			bulkUpdatePage.uploadFile(DataSheetWithBenefits);
			sa.assertTrue(bulkUpdatePage.verifySuccessfulUploadMessage(numberOfRows+" of "+numberOfRows+" benefits found"), "File upload");
			sa.assertTrue(bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is enabled");
//			bulkUpdatePage.clickOnCreateProjectButton();
//			bulkUpdatedPage.clickOnYesButton();			
//			sa.assertTrue(bulkUpdatePage.verifyProjectIsCreated(bulkUpdatePage.getProjectID()), "Project ID is found in the grid");
//			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "IN_PROGRESS"), "Project Status is In Progress");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			
			OneframeLogger("Validated Create Bulk Update Project Succseefully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Create Bulk Update Project");
		}
		
		homepage.clickLogout();
		
	}
	
	public static void setClipboardData(String str) {
        
    }

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}
	
	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

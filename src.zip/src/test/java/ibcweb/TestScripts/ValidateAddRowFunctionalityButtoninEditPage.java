package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAddRowFunctionalityButtoninEditPage extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for validating Add Row Button Functionality in Edit Page ")
	public void setUp() {
		InitializeLaunchPad("IBPW_46");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
		addrulepage = new IBPAddRulePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","LibraryName","RuleName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Add Row  Button  Functinality in Edit  Page", dataProvider = "TestData")
	@Description("Validate Add Row Button  Functinality in Edit Page")
	public void ValidateAddRowButtoninEditPage(String TestCaseID, String TestStatus, String LibraryName,String RuleName) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickStagingLink();          
      //      rulebuilderstaging.clickRuleName(LibraryName, RuleName);
		//	ruleid.clickLatestVersionofRuleID();
			rulebuilderstaging.clickLibrary(LibraryName);
			//ruleid.getLatestVersionID(LibraryName, RuleName);
            String versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
           // rulebuilderstaging.clickRuleName(LibraryName, RuleName);
			ruleid.clickLatestVersionofRuleID(versionId);
			ruleid.clickEditButton();
			sa.assertTrue(ruleid.clickEditAddRowButton(), "Verified Row is Added");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Add Row Button in Edit page Functinality is successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger(" Unable to validate Add Row Button in Edit Page Functinality");
		}
		
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

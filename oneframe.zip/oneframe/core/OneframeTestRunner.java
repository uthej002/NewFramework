// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.core;

import org.testng.TestNG;
import java.util.List;
import java.util.Arrays;
import java.util.Map;
import anthem.irx.oneframe.utilities.ExcelIOStream;
import anthem.irx.oneframe.utilities.FileOpsHelper;
import anthem.irx.oneframe.utilities.DateTimeProcessor;
import org.testng.xml.XmlTest;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import java.util.HashMap;

public class OneframeTestRunner extends OneframeContainer
{
    String[][] ScriptConfigurations;
    HashMap<String, String> ConfigIndexMap;
    XmlSuite ofTestSuite;
    XmlClass ofTestClass;
    XmlTest ofxmlTest;
    String pkgTestClass;
    String ofTestSuiteFile;
    int testScripts;
    
    public OneframeTestRunner() {
        this.ConfigIndexMap = new HashMap<String, String>();
        this.testScripts = 0;
    }
    
    public void CreateAndSaveTestSuiteXML() {
        this.createDynamicTestSuite();
        this.saveDynamicTestSuite();
    }
    
    private void saveDynamicTestSuite() {
        FileOpsHelper.writeToFile(this.ofTestSuiteFile = OneframeTestRunner.TESTSUITES_FOLDER + OneframeTestRunner.TSXMLFileOutput + "_" + DateTimeProcessor.getCurrentDateTime("MMddYYYY_hhmm") + ".xml", this.ofTestSuite.toXml());
        OneframeContainer.OneframeLogger("Test Suite [" + this.ofTestSuiteFile + "] saved to the 'Test Suites' folder");
    }
    
    private void createDynamicTestSuite() {
        this.ReadTestBedConfiguration();
        (this.ofTestSuite = new XmlSuite()).setName(OneframeTestRunner.TestSuiteName);
        this.ofTestSuite.addListener(OneframeTestRunner.TSListenerClass);
        if (OneframeTestRunner.TSParallelExec) {
            this.ofTestSuite.setParallel(XmlSuite.ParallelMode.TESTS);
            this.ofTestSuite.setThreadCount(OneframeTestRunner.TSThreadCount);
        }
        final ExcelIOStream ofTestSuiteXlsX = new ExcelIOStream(OneframeTestRunner.TestSuiteFile);
        this.ScriptConfigurations = ofTestSuiteXlsX.readScriptConfiguration();
        this.createConfigurationIndexMap();
        for (int irow = 1; irow < this.ScriptConfigurations.length; ++irow) {
            final Map<String, String> ofTestParameters = new HashMap<String, String>();
            if (this.ScriptConfigurations[irow][0] == "") {
                break;
            }
            if (this.ScriptConfigurations[irow][0] == null) {
                break;
            }
            this.pkgTestClass = OneframeTestRunner.TSPackageName + "." + this.ScriptConfigurations[irow][this.getConfigIndex("ScriptName")];
            this.ofTestClass = new XmlClass(this.pkgTestClass);
            ofTestParameters.put(this.ScriptConfigurations[0][this.getConfigIndex("TestScenarioID")], this.ScriptConfigurations[irow][this.getConfigIndex("TestScenarioID")]);
            try {
                final XmlTest ofxmlTest = new XmlTest(this.ofTestSuite);
                ofxmlTest.setParameters((Map)ofTestParameters);
                ofxmlTest.setName(this.getConfigValue(irow, "TestScenarioID") + "_" + this.getConfigValue(irow, "ScriptName"));
                ofxmlTest.setClasses((List)Arrays.asList(this.ofTestClass));
                OneframeContainer.OneframeLogger("[ONEFRAME]Adding test script [" + this.ofTestClass.getName() + "] to test suite.....Done");
                ++this.testScripts;
            }
            catch (Exception TNGE) {
                OneframeContainer.OneframeLogger("Unable to add test script : " + TNGE.getMessage());
            }
        }
        OneframeContainer.OneframeLogger("[ONEFRAME]Total Number of test scripts added to the test suite : " + this.testScripts);
    }
    
    private void executeSavedTestSuite() {
        final TestNG oftestNG = new TestNG();
        oftestNG.setXmlSuites((List)Arrays.asList(this.ofTestSuite));
        oftestNG.run();
    }
    
    public void executeConfiguredTestSuite() {
        this.createDynamicTestSuite();
        this.saveDynamicTestSuite();
        this.executeSavedTestSuite();
    }
    
    private void createConfigurationIndexMap() {
        for (int cfindex = 0; cfindex < this.ScriptConfigurations[0].length; ++cfindex) {
            this.ConfigIndexMap.put(this.ScriptConfigurations[0][cfindex], String.valueOf(cfindex));
        }
    }
    
    private int getConfigIndex(final String Config) {
        return Integer.parseInt(this.ConfigIndexMap.get(Config));
    }
    
    private String getConfigValue(final int irow, final String TSConfiguration) {
        return this.ScriptConfigurations[irow][this.getConfigIndex(TSConfiguration)];
    }
}

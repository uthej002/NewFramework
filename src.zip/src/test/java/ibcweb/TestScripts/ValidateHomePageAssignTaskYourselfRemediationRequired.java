package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateHomePageAssignTaskYourselfRemediationRequired extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
    IBPHomePage homepage;
    
    @BeforeClass
	@Step("Initializing Test Script for validate Home Page Assign Task Yourslef button display for Remediation Required Section")
	public void setUp() {
		InitializeLaunchPad("IBPW_82");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Home Page Assign Task Yourslef button display for Remediation Required Section", dataProvider = "TestData")
	@Description("Validate Home Page Assign Task Yourslef button display for Remediation Required Section")
	public void ValidateAssignTaskYourselfRemediationRequired(String TestCaseID, String TestStatus) throws AWTException, InterruptedException, IOException {	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			sa.assertTrue(welcomePage.verifyMyTasksWidgetDisplay(), "Verified My Task Widget is displayed");
			sa.assertTrue(welcomePage.verifyMyTasksHeaderDisplay(), "Verified My Task Header is displayed");
			sa.assertTrue(welcomePage.verifyRemediationRequiredWidgetDisplay(), "Verified Remediation Required Widget is displayed");
			sa.assertTrue(welcomePage.verifyAssignTaskYourselfButtonDisplayRemediationRequired(), "Verified Assign Task Yourslef button in Remediation Required Secion is displayed");			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Home Page Assign Task Yourslef button display for Remediation Required Section Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Home Page Assign Task Yourslef button display for Remediation Required Section");
		}
		sa.assertAll();
		homepage.clickMenuButton();
		homepage.clickLogout();
	}
	
	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}
}

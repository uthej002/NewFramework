package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBulkUpdatePage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesDrugExceptionsEditandSave extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPBenefitFormularyPage librariesFormularyPage;
	IBPBulkUpdatePage BulkUpdatePage;
	IBPLibrariesNetFormularies librariesNetFormulariesPage;

	@BeforeClass
	@Step("Initializing Test Script for validating Benefit Libraries Drug Exceptions Tab Edit data and save is enabled")
	public void setUp() {
		InitializeLaunchPad("IBPW_423");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		librariesFormularyPage = new IBPBenefitFormularyPage();
		BulkUpdatePage  = new IBPBulkUpdatePage();
		librariesNetFormulariesPage = new IBPLibrariesNetFormularies();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "EffectiveDate", "TermDate", "ClientId", "LOBId", "StateId"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefit Libraries Drug Exceptions Tab Edit data and save is enabled", dataProvider = "TestData")
	@Description("Validate Benefit Libraries Drug Exceptions Tab Edit data and save is enabled")
	public void ValidateLibrariesDrugExceptionsTabEditandSave(String TestCaseID, String TestStatus, String EffectiveDate , String TermDate, String ClientId, String LOBId, String StateId )throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesFormularyPage.clickViewButtonofFormularies();
			librariesFormularyPage.clickDrugExceptionsButton();
			librariesFormularyPage.clickonFirstDrugExceptionFormulary();
			librariesFormularyPage.verifyAuditButton();
			sa.assertTrue(librariesFormularyPage.verifyAndClickEditButton(),"Verified Edit Button is Clicked");
			String cvs = librariesFormularyPage.editAndGetTextCVSCode();
			String DrugList = librariesFormularyPage.editAndGetTextDrugList();
			String Description = librariesFormularyPage.editAndGetTextDescriptiont();
			librariesFormularyPage.SelectCVSManagedByDropdown();
			librariesFormularyPage.SelectAdjSysStatusDropdown();
			librariesFormularyPage.EditEffectiveDate(EffectiveDate);	
			librariesFormularyPage.EditTermDate(TermDate);
			librariesFormularyPage.clickSaveChangesButton();
			librariesFormularyPage.verifyCVSCodeValue(cvs);
			librariesFormularyPage.verifyDrugListValue(DrugList);
			librariesFormularyPage.verifyDescriptionValue(Description);
			librariesFormularyPage.verifyEffectiveDate(EffectiveDate);
			librariesFormularyPage.verifyTerminationDate(TermDate);
			librariesFormularyPage.clickDownArrowButton();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Benefit Libraries Drug Exceptions Tab Edit and save is enabled Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Benefit Libraries Drug Exceptions Tab Edit and save");
		}

      homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.ie.InternetExplorerOptions;

public class IEWebDriverManager extends WebDriverManager
{
    @Override
    protected void createWebDriver() {
        final InternetExplorerOptions options = new InternetExplorerOptions();
        System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "/src/main/resources/DriverBinaries/iedriver_win32/IEDriverServer.exe");
        options.enablePersistentHovering();
        options.ignoreZoomSettings();
        options.introduceFlakinessByIgnoringSecurityDomains();
        options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
        options.ignoreZoomSettings();
        this.driver = (WebDriver)new InternetExplorerDriver(options);
    }
}

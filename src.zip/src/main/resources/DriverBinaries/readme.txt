Gheko Driver Current Version 0.27.0 (64 bit) - Firefox Version - 79.0 (64 bit)
downloaded on 08/11/2020

Chrome Driver Current Version - 84.0.4147.30 (Official Build) (64-bit)
downloaded on - 07/24/2020

Previous Version - Version 81.0.4044.138 (Official Build) (64-bit)
downloaded on - 05/11/2020
package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.lang.*;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.ExcelFile;
import io.qameta.allure.Step;

public class IBPBenefitPage extends OneframeContainer {
	
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//div[@class='search-results']")
	WebElement txtSearchResults;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()= ' Create a Benefit ']")
	WebElement btnCreateaBenefit;

	@FindBy(xpath = "//h3[text()='Benefit header']")
	WebElement hdrBenefitHeader;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()= ' Bulk Edit ']")
	WebElement btnBulkEdit;

	@FindBy(xpath = "//span[text()=' Assign task to yourself ']")
	WebElement btnAssigntoYourself;

	@FindBy(xpath = "//span[text()=' Submit ']")
	WebElement btnSubmit;

	@FindBy(xpath = "//span[text()=' Reject ']")
	WebElement btnReject;

	@FindBy(xpath = "//span[text()='CLIENT_APPROVAL']")
	WebElement txtVersionStatusClientApproval;

	@FindBy(xpath = "//span[text()='IN_REMEDIATION']")
	WebElement txtVersionStatusInRemediation;

	@FindBy(xpath = "//span[@data-automation-id='headerVersionValue']")
	WebElement txtVersionStatus;

	@FindBy(xpath = "//h3[text()='Client Feedack']")
	WebElement hdrClientFeedback;

	@FindBy(xpath = "//mat-option[@role='option']")
	WebElement drdClientFeedbackObject;

	@FindBy(xpath = "//span[text()='Select']")
	WebElement btnSelect;

	@FindBy(xpath = "//textarea[@placeholder='Client Review Feedback']")
	WebElement txtClientReviewFeedback;

	@FindBy(xpath = "//h4[text()='Add']")
	WebElement btnAdd;

	@FindBy(xpath = "//span[text()='Reject']")
	WebElement btnClientReject;

	@FindBy(xpath = "//mat-list[@class='mat-list mat-list-base']")
	WebElement hdrClientWidget;

	@FindBy(xpath = "//span[contains(@class,'lockMessage')]")
	WebElement msgBenefitLockMessage;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text() = 'Cancel']")
	WebElement btnCancel;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text() = ' Cancel Benefit ']")
	WebElement btnCancelBenefit;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()= ' Edit ']")
	WebElement btnEdit;

	@FindBy(xpath = "//simple-snack-bar/span")
	WebElement txtNotificationMessage;

	@FindBy(xpath = "//div[@class='question-section-1' and text()=' Cancel Benefit ']")
	WebElement hdrCancelBenefitHeader;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and text()= ' Yes ']")
	WebElement btnYesOption;

	@FindBy(xpath = "//input[@formcontrolname='legacyBenefitPlanId']")
	WebElement txtLegacyBenefitPlanID;

	@FindBy(xpath = "//input[@formcontrolname='legacyBenefitPlanVersion']")
	WebElement txtLegacyBenefitPlanVersion;

	@FindBy(xpath = "//span[text()=' Save & Exit ']")
	WebElement btnSaveandExit;

	@FindBy(xpath = "//span[text()=' Close ']")
	WebElement btnClose;

	@FindBy(xpath = "//mat-list[@class=\"mat-list mat-list-base\"]']")
	WebElement hdrBenefitBuildErrorWidget;

	@FindBy(xpath = "//h3[text()='Benefit Build Errors']")
	WebElement hdrBenefitErrorHeader;

	@FindBy(xpath = "//div[@class='mat-tab-label-content' and text()=' Details ']")
	WebElement tabDetails;

	@FindBy(xpath = "//div[@class='mat-tab-label-content' and text()='Details']")
	WebElement subtabDetails;

	@FindBy(xpath = "//div[@class='mat-tab-label-content' and text()='General']/..")
	WebElement subtabGeneral;

	@FindBy(xpath = "//input[@formcontrolname='effectiveDate']//following-sibling::mat-datepicker-toggle/button")
	WebElement benefitVersionEffectiveDatePicker;

	@FindBy(xpath = "//input[@formcontrolname=\"endDate\"]//following-sibling::mat-datepicker-toggle/button")
	WebElement benefitVersionEndDatePicker;

	@FindBy(xpath = "//input[@formcontrolname='effectiveDate']")
	WebElement benefitVersionEffectiveDateField;

	@FindBy(xpath = "//input[@formcontrolname='endDate']")
	WebElement benefitVersionEndDateField;

	@FindBy(xpath = "//input[@formcontrolname='timelyFilling']")
	WebElement benefitTimelyFilling;

	@FindBy(xpath = "//input[@formcontrolname='retail']")
	WebElement benefitHighdollarlimitRetail;

	@FindBy(xpath = "//input[@formcontrolname='homeDelivery']")
	WebElement benefitHighdollarlimitHomeDelivery;

	@FindBy(xpath = "//input[@formcontrolname='vaHighDollarLimit']")
	WebElement benefitVeteransHighDollarLimit;

	@FindBy(xpath = "//mat-select[@formcontrolname='inn']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement btnPaperClaimsInNetwork;

	@FindBy(xpath = "//mat-select[@formcontrolname='oon']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement btnPaperClaimsOutNetwork;

	@FindBy(xpath = "//mat-select[@formcontrolname='followMeLogic']")
	WebElement btnFollowMeLogic;

	@FindBy(xpath = "//mat-select[@formcontrolname='foreignClaim']")
	WebElement btnForeignClaim;

	@FindBy(xpath = "//mat-slide-toggle[@id='mat-slide-toggle-1']/label/div/div")
	WebElement tglRebateStrategy;

	@FindBy(xpath = "//input[@formcontrolname='percent']")
	WebElement txtpercentvalue;

	@FindBy(xpath = "//mat-slide-toggle[@id='mat-slide-toggle-2']/label/div/div")
	WebElement tglPENCD;

	@FindBy(xpath = "//h1")
	WebElement hdrBenefitID;

	@FindBy(xpath = "//span[@data-automation-id='headerClientValue']")
	WebElement hdrClientValue;

	@FindBy(xpath = "//span[@data-automation-id='headerLobValue']")
	WebElement hdrLOBValue;

	@FindBy(xpath = "//span[@data-automation-id='headerStatebValue']")
	WebElement hdrState;

	@FindBy(xpath = "//span[@data-automation-id='headerEffectiveVersionValue']")
	WebElement hdrVersion;

	@FindBy(xpath = "//ingeniorx-ws-versions//mat-icon")
	WebElement dropDownIcon;

	@FindBy(xpath = "//textarea[@id='txtNotes']")
	WebElement notesArea;

	@FindBy(xpath = "//div[contains(@class, 'history')]/div/div[1]")
	WebElement lastVersion;
	
	@FindBy(css = "td.mat-column-duplicate button")
	List<WebElement> duplicateBenefitIconColumn;
	
	@FindBy(xpath = "//span[text()=' Duplicate ']/..")
	WebElement btnDuplicateBenefit;
		
	@FindBy(css = ".grid > .filter")
	WebElement benefitsFilterBySection;	
	
	@FindBy(css = ".table")
	WebElement benefitsTableSection;
	
	@FindBy(css = "[data-automation-id=\"benefitsFilterLob\"]")
	WebElement benefitsFilterByLOB;
	
	@FindBy(css = "[data-automation-id=\"benefitsFilterState\"]")
	WebElement benefitsFilterByState;
	
	@FindBy(css = "[data-automation-id=\"benefitsFilterEffectiveDate\"]")
	WebElement benefitsFilterByEffectiveDate;
	
	@FindBy(css = "[data-automation-id=\"benefitsFilterVersionStatus\"]")
	WebElement benefitsFilterByVerStatus;
	
	@FindBy(css = "[data-automation-id=\"benefitsFilterApply\"]")
	WebElement benefitsApplyFilterButton;
	
	@FindBy(xpath = "//th[normalize-space()='BENEFIT CODE']")
	WebElement benefitCodeColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='BENEFIT PLAN ID']")
	WebElement benefitPlanIdColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='CLIENT']")
	WebElement clientColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='LOB']")
	WebElement lobColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='STATE']")
	WebElement stateColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='EFFECTIVE DATE']")
	WebElement effectiveDateColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='STATUS']")
	WebElement statusColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='VER. CREATED ON']")
	WebElement verCreatedOnColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='VERSION']")
	WebElement versionColHeader;
	
	@FindBy(xpath = "//th[normalize-space()='LAST EDITED BY']")
	WebElement lastEditedByColHeader;

	@FindBy(xpath = "//td[@formgroupname='rebateStrategy']//input[@role='switch']")
	WebElement rebateToggle;
	
	@FindBy(xpath = "//td/mat-slide-toggle[@formcontrolname='pencd']//input[@role='switch']")
	WebElement pencdToggle;
	
	@FindBy(xpath="//span[normalize-space()='Accept']")
	WebElement btnAccept;
	
	// Initializing the Page Objects:
	public IBPBenefitPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}


	@Step("Verify Search Results in the page")
	public boolean verifySearchResults() throws InterruptedException {
		boolean flag = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectToBeInvisible(By.cssSelector("span.spinner"));
		
		try {
			if(WaitForObjectVisibility(hdrBenefitID)) {
				return true;
			}
			
		}
		catch (NoSuchElementException | TimeoutException SER) {
			if (ObjectExist(txtSearchResults)) {
				int recordCount = Integer.parseInt(txtSearchResults.getText().trim().split(" ")[1]);
				int count = 0;
				while(recordCount == 0) {
					OneframeLogger("Results :" + txtSearchResults.getText());
					clickSearchResults();
					recordCount = Integer.parseInt(txtSearchResults.getText().trim().split(" ")[1]);
					if(count == 5) {
						break;
					}
					count++;
				}
				OneframeLogger("Results :" + txtSearchResults.getText());
				flag = true;
			}
		}
		catch (StaleElementReferenceException SER) {
			flag = false;
		}
		return flag;
	}

	@Step("Click search results")
	public void clickSearchResults() {
		ClickWebObject(txtSearchResults);
		ClickWebObject(txtSearchResults);
	}

	@Step("Verify Create A Benefit Button Display")
	public boolean verifyCreateaBenefitButtonDisplay() {
		boolean blnRC = false;
		WaitForObjectToBeInvisible(By.cssSelector("span.spinner"));
		WaitForObject(btnCreateaBenefit);
		if (btnCreateaBenefit.isDisplayed()) {
			OneframeLogger("Create A Benefit Button is displayed");
			blnRC = true;
		} else {
			OneframeLogger("Create A Benefit Button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Create A Benefit Button")
	public void clickCreateaBenefitButton() {
		try {
			WaitForObjectToBeInvisible(By.cssSelector("span.spinner"));
			if (WaitForObjectVisibility(btnCreateaBenefit)) {
				ClickWebObject(btnCreateaBenefit);
				OneframeLogger("Create A Benefit Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Create A Benefit Button is not Clicked");
		}
	}

	@Step("Click on Assign to Yourself Button")
	public void clickAssignToYourselfButton() {
		try {
			if (ObjectExist(btnAssigntoYourself)) {
				ClickWebObject(btnAssigntoYourself);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Assign to Yourself button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Assign to Yourself button is not Clicked");
		}
	}

	@Step("Click on Edit Button")
	public void clickEditButton() {
		try {
			WaitForObjectVisibility(btnEdit);
			if (WaitForObjectVisibility(btnEdit)) {
				ClickWebObject(btnEdit);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Edit button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Edit button is not Clicked");
		}
	}

	@Step("Verify Submit button is displayed")
	public boolean verifySubmitbuttondisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(btnSubmit);
		try {
			if (btnSubmit.isDisplayed()) {
				highlightElement(btnSubmit);
				OneframeLogger("Submit button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Submit button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Submit Button")
	public void clickSubmitButton() {
		try {
			if (ObjectExist(btnSubmit)) {
				ClickWebObject(btnSubmit);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Submit button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Submit button is not Clicked");
		}
	}

	@Step("Verify whether Assign to Yourself button is displayed")
	public boolean verifyAssignYourselfbuttondisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(btnAssigntoYourself);
		try {
			if (btnAssigntoYourself.isDisplayed()) {
				highlightElement(btnAssigntoYourself);
				OneframeLogger("Assign to Yourself button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Assign to Yourself is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Reject button is displayed")
	public boolean verifyRejectbuttondisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(btnReject);
		try {
			if (btnReject.isDisplayed()) {
				highlightElement(btnReject);
				OneframeLogger("Reject button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Reject button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Client Approval Status is displayed")
	public boolean verifyclientApprovalStatusdisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(txtVersionStatusClientApproval);
		try {
			if (txtVersionStatusClientApproval.isDisplayed()) {
				highlightElement(txtVersionStatusClientApproval);
				OneframeLogger("Client Approval Status is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Client Approval Status is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Reject Button")
	public void clickRejectButton() {
		try {
			if (ObjectExist(btnReject)) {
				ClickWebObject(btnReject);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Reject button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Reject button is not Clicked");
		}
	}

	@Step("Verify Client Feedback Header is displayed")
	public boolean verifyclientFeedbackHeaderdisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrClientFeedback);
		try {
			if (hdrClientFeedback.isDisplayed()) {
				highlightElement(hdrClientFeedback);
				OneframeLogger("Client Feedback Header is displayed");
				// WebObjectHandler.SelectDropDownListByValue(arg0, arg1);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Client Feedback Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Client Feedback Widget is displayed")
	public boolean verifyclientFeedbackWidgetdisplay() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrClientWidget);
		try {
			if (hdrClientWidget.isDisplayed()) {
				highlightElement(hdrClientWidget);
				OneframeLogger("Client Feedback Widget is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Client Feedback Widget is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select value from Client Feedback Dropdown")
	public void selectClientFeedbackDropdown(String value) {
		if (WaitForObjectVisibility(btnSelect)) {
			ClickWebObject(btnSelect);
			WaitForObjectVisibility(drdClientFeedbackObject);
			SelectDropDownListByValue(drdClientFeedbackObject, value);
			OneframeLogger("The" + value + " Value has been Selected from dropdown");
		} else {
			OneframeLogger("The Value has not been Selected from dropdown");
		}
	}

	@Step("Enter the feedback in Client Review feedback Area")
	public void enterClientReviewFeedback(String feedback) {
		if (WaitForObjectVisibility(txtClientReviewFeedback)) {
			ClickWebObject(txtClientReviewFeedback);
			EnterText(txtClientReviewFeedback, feedback);
			OneframeLogger("The Client Feedback has been Entered");
		} else {
			OneframeLogger("The Client Feedback has not been Entered");
		}
	}

	@Step("Click on Add Button")
	public void clickAddButton() {
		try {
			if (ObjectExist(btnAdd)) {
				ClickWebObject(btnAdd);
				OneframeLogger("Add button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add button is not Clicked");
		}
	}

	@Step("Click on Client Reject Button")
	public void clickClientRejectButton() {
		try {
			if (ObjectExist(btnClientReject)) {
				ClickWebObject(btnClientReject);
				OneframeLogger("Reject button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Reject button is not Clicked");
		}
	}

	@Step("Verify Cancel Benefit Header is displayed")
	public void VerifyCanceBenefitHeaderDisplay() {
		try {
			if (ObjectExist(hdrCancelBenefitHeader)) {
				highlightElement(hdrCancelBenefitHeader);
				OneframeLogger("Cancel Benefit Header is Displayed");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cancel Benefit Header is not Displayed");
		}
	}

	@Step("Verfiy In Remediation for Rejected Benefit is displayed")
	public boolean verifyInRemediationStatusRejectedBenefit() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(txtVersionStatus))
			;
		ClickWebObject(txtVersionStatus);
		if (txtVersionStatus.getText().contains("IN_REMEDIATION")) {
			OneframeLogger("The Status is " + txtVersionStatus.getText());
			blnRC = true;
		} else {
			OneframeLogger("The InRemediation Status is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Submitted to PBM Status for Benefit is displayed")
	public boolean verifySubmittedPBMStatusBenefit() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(txtVersionStatus))
			;
		ClickWebObject(txtVersionStatus);
		if (txtVersionStatus.getText().contains("SUBMITTED_PBM")) {
			OneframeLogger("The Status is " + txtVersionStatus.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Submitted PBM Status is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Benefit Banner Message is displayed")
	public boolean verifybenefitBannerMessage() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(msgBenefitLockMessage))
			;
		ClickWebObject(msgBenefitLockMessage);
		if (msgBenefitLockMessage.getText().contains("This benefit requires remediation.")) {
			OneframeLogger("The Message is " + msgBenefitLockMessage.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Benefit Banner Message for Pending is displayed")
	public boolean verifybenefitBannerPendingMessage() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(msgBenefitLockMessage))
			;
		ClickWebObject(msgBenefitLockMessage);
		if (msgBenefitLockMessage.getText().contains("This benefit is pending review")) {
			OneframeLogger("The Message is " + msgBenefitLockMessage.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Benefit Banner Message for IN Remediation is displayed")
	public boolean verifybenefitBannerInRemediationMessage() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(txtNotificationMessage))
			;
		ClickWebObject(txtNotificationMessage);
		if (txtNotificationMessage.getText().contains(" has been assigned to you.")) {
			OneframeLogger("The Message is " + txtNotificationMessage.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Benefit Banner Message for Save the benefit is displayed")
	public boolean verifybenefitBannerBenefitSaveMessage() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(txtNotificationMessage))
			ClickWebObject(txtNotificationMessage);
		if (txtNotificationMessage.getText().contains(" was saved")) {
			OneframeLogger("The Message is " + txtNotificationMessage.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Benefit Banner Message for IN Remediation Client Approval is displayed")
	public boolean verifybenefitBannerInRemediationClientApprovalMessage() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(txtNotificationMessage))
			ClickWebObject(txtNotificationMessage);
		if (txtNotificationMessage.getText().contains(" submitted for Client Review.")) {
			OneframeLogger("The Message is " + txtNotificationMessage.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Benefit Banner Message for IN Remediation is displayed")
	public boolean verifybenefitBannerAssignedYourselfMessage() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(txtNotificationMessage))
			;
		ClickWebObject(txtNotificationMessage);
		if (txtNotificationMessage.getText().contains(" has been assigned to you.")) {
			OneframeLogger("The Message is " + txtNotificationMessage.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Benefit Banner Message for Submit for Client Approval is displayed")
	public boolean verifybenefitBannerClientApprovalMessage() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(txtNotificationMessage))
			;
		ClickWebObject(txtNotificationMessage);
		if (txtNotificationMessage.getText().contains(" submitted to Client Review")) {
			OneframeLogger("The Message is " + txtNotificationMessage.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verfiy Benefit Banner Message for Submit to PBM is displayed")
	public boolean verifybenefitBannerPBMMessage() {
		boolean blnRC = false;
		if (WaitForObjectVisibility(txtNotificationMessage))
			ClickWebObject(txtNotificationMessage);
		if (txtNotificationMessage.getText().contains(" submitted to adjudication system")) {
			OneframeLogger("The Message is " + txtNotificationMessage.getText());
			blnRC = true;
		} else {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Edit Button is displayed for Rejected Benefit")
	public boolean verifyEditButtondisplayforRejectedBenefit() {
		boolean blnRC = false;
		WaitForObjectVisibility(btnEdit);
		try {
			if (btnEdit.isDisplayed()) {
				highlightElement(btnEdit);
				OneframeLogger("Edit Button is displayed for Rejected Benefit");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Edit Button is not displayed for Rejected Benefit");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Cancel Button is displayed for Rejected Benefit")
	public boolean verifyCancelButtondisplayforRejectedBenefit() {
		boolean blnRC = false;
		WaitForObjectVisibility(btnCancel);
		try {
			if (btnCancel.isDisplayed()) {
				highlightElement(btnCancel);
				OneframeLogger("Cancel Button is displayed for Rejected Benefit");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Cancel Button is not displayed for Rejected Benefit");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Cancel Button in Client FeedBack")
	public void clickCancelButtoninClientFeedback() {
		try {
			if (ObjectExist(btnCancel)) {
				ClickWebObject(btnCancel);
				OneframeLogger("Cancel button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cancel button is not Clicked");
		}
	}

	@Step("Click on Cancel Button in In Remediation Status")
	public void clickCancelButtoninInRemediationStatus() {
		try {
			if (ObjectExist(btnCancel)) {
				ClickWebObject(btnCancel);
				OneframeLogger("Cancel button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Cancel button is not Clicked");
		}
	}

	@Step("Click on Yes Button")
	public void clickYesButtoninCancelBenefit() {
		try {
			if (ObjectExist(btnYesOption)) {
				ClickWebObject(btnYesOption);
				OneframeLogger("Yes button in Cancel Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Yes button in Cancel Benefit is not Clicked");
		}
	}

	@Step("Verfiy Notification Message for Rejected Benefit is displayed")
	public boolean verifyNotificationMsgRejectedBenefit() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtNotificationMessage))
				ClickWebObject(txtNotificationMessage);
			if (txtNotificationMessage.getText().contains(" is in remediation")) {
				OneframeLogger("The Message is " + txtNotificationMessage.getText());
				blnRC = true;
			} else {
				OneframeLogger("The Notification Message is not displayed");
				blnRC = false;
			}
		} catch (StaleElementReferenceException se) {
		}
		return blnRC;
	}

	@Step("Verfiy Notification Message for Submitted Benefit is displayed")
	public boolean verifyNotificationMsgSubmitforClientApprovalBenefit() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtNotificationMessage))
				;
			ClickWebObject(txtNotificationMessage);
			if (txtNotificationMessage.getText().contains(" submitted for Client Review")) {
				OneframeLogger("The Message is " + txtNotificationMessage.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}

		return blnRC;
	}

	@Step("Verfiy Notification Message for Assign Task To Yourself")
	public boolean verifyNotificationMsgAssignTaskToYourself() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtNotificationMessage))
				;
			Thread.sleep(1000);
			ClickWebObject(txtNotificationMessage);
			if (txtNotificationMessage.getText().contains(" has been assigned to you.")) {
				OneframeLogger("The Message is : " + txtNotificationMessage.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException | InterruptedException toException) {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}

		return blnRC;
	}

	@Step("Verfiy Notification Message for Benefit Got Cancelled")
	public boolean verifyNotificationMsgforBenefitGotCancelled() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtNotificationMessage))
				;
			ClickWebObject(txtNotificationMessage);
			if (txtNotificationMessage.getText().contains(" got cancelled")) {
				OneframeLogger("The Message is : " + txtNotificationMessage.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}

		return blnRC;
	}

	@Step("Verfiy Notification Message for Benefit Got Saved")
	public boolean verifyNotificationMsgforBenefitGotSaved() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtNotificationMessage))
				;
			ClickWebObject(txtNotificationMessage);
			if (txtNotificationMessage.getText().contains("was saved")) {
				OneframeLogger("The Message is : " + txtNotificationMessage.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Notification Message is not displayed");
			blnRC = false;
		}

		return blnRC;
	}

	@Step("Enter Legacy Benefit Plan ID Text")
	public void EnterLegacyPlanID(String planID) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(txtLegacyBenefitPlanID);
		try {
			if (ObjectExist(txtLegacyBenefitPlanID)) {
				ClickWebObject(txtLegacyBenefitPlanID);
				// txtSearchBenefit.sendKeys(Keys.CONTROL + "a");
				txtLegacyBenefitPlanID.sendKeys(Keys.CONTROL + "a");
				txtLegacyBenefitPlanID.sendKeys(Keys.DELETE);
				EnterText(txtLegacyBenefitPlanID, planID);
				txtLegacyBenefitPlanID.sendKeys(Keys.ENTER);
				highlightElement(txtLegacyBenefitPlanID);
				OneframeLogger("Legacy Benefit Plan ID is Entered");
			} else {
				OneframeLogger("Legacy Benefit Plan ID is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Enter Legacy Benefit Plan ID Text")
	public boolean EnterLegacyPlanIDRandom() {
		boolean bln = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(txtLegacyBenefitPlanID);
		try {
			if (ObjectExist(txtLegacyBenefitPlanID)) {
				String planId = RandomStringUtils.randomAlphanumeric(4);
				String planID = planId.toString();
				EnterText(txtLegacyBenefitPlanID, planID);
				txtLegacyBenefitPlanID.sendKeys(Keys.ENTER);
				OneframeLogger("Legacy Benefit Plan ID is Entered");
				bln = true;
			} else {
				OneframeLogger("Legacy Benefit Plan ID is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
		return bln;
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Enter Legacy Benefit Plan Version Text")
	public void EnterLegacyPlanVersion(String versionId) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(txtLegacyBenefitPlanVersion);
		try {
			if (ObjectExist(txtLegacyBenefitPlanVersion)) {
				// ClickWebObject(txtSearchBenefit);
				// txtSearchBenefit.sendKeys(Keys.CONTROL + "a");
				EnterText(txtLegacyBenefitPlanVersion, versionId);
				txtLegacyBenefitPlanVersion.sendKeys(Keys.ENTER);
				highlightElement(txtLegacyBenefitPlanVersion);
				OneframeLogger("Legacy Benefit Plan Version ID is Entered");
			} else {
				OneframeLogger("Legacy Benefit Plan Version ID is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Click on Save and Exit Button")
	public void clickSaveandExitButton() {
		try {
			if (ObjectExist(btnSaveandExit)) {
				ClickWebObject(btnSaveandExit);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Save and Exit button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Save and Exit button is not Clicked");
		}
	}

	@Step("Click on Close Button")
	public void clickCloseButton() {
		try {
			if (ObjectExist(btnClose)) {
				ClickWebObject(btnClose);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Close button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Close button is not Clicked");
		}
	}

	@Step("Verify whether Benefit Version Effective Date is updated")
	public boolean verifyVersionEffectiveDateValue(String effectiveDate) {
		boolean blnRC = false;
		String ActualEffectiveDate = benefitVersionEffectiveDateField.getAttribute("value");
		String ExpectedEffectiveDate = effectiveDate;
		if (ActualEffectiveDate.equalsIgnoreCase(ExpectedEffectiveDate)) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether Benefit Version End Date is updated")
	public boolean verifyVersionEndDateValue(String endDate) {
		boolean blnRC = false;
		String ActualEndDate = benefitVersionEndDateField.getAttribute("value");
		String ExpectedEndDate = endDate;
		if (ActualEndDate.equalsIgnoreCase(ExpectedEndDate)) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether Legacy Benefit PlanID is updated")
	public boolean verifyLegacyBenefitPlanID(String planID) {
		boolean blnRC = false;
		String ActualPlanID = txtLegacyBenefitPlanID.getAttribute("value");
		String ExpectedPlanID = planID;
		if (ActualPlanID.equalsIgnoreCase(ExpectedPlanID)) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether Legacy Benefit Plan VersionID is updated")
	public boolean verifyLegacyBenefitPlanVersionID(String versionId) {
		boolean blnRC = false;
		String ActualPlanVersionID = txtLegacyBenefitPlanVersion.getAttribute("value");
		String ExpectedPlanVersionID = versionId;
		if (ActualPlanVersionID.equalsIgnoreCase(ExpectedPlanVersionID)) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Benefit Build Error widget display")
	public boolean verifyBenefitBuildWidgetError() {
		boolean blnRC = false;
		WaitForObject(hdrBenefitBuildErrorWidget);
		if (hdrBenefitBuildErrorWidget.isDisplayed()) {
			OneframeLogger("Benefit Build Error widget is  displayed");
			blnRC = true;
		} else {
			OneframeLogger("Benefit Build Error widget is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Benefit Build Error Header display")
	public boolean verifyBenefitBuildErrorHeader() {
		boolean blnRC = false;
		WaitForObject(hdrBenefitErrorHeader);
		if (hdrBenefitErrorHeader.isDisplayed()) {
			OneframeLogger("" + hdrBenefitErrorHeader.getText());
			blnRC = true;
		} else {
			OneframeLogger("Benefit Build Error Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Details tab")
	public void clickDetailsTab() {
		try {
			if (ObjectExist(tabDetails)) {
				ClickWebObject(tabDetails);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Details Tab is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Details Tab is not Clicked");
		}
	}

	@Step("Click on Details Sub tab")
	public void clickDetailsSubTab() {
		try {
			if (ObjectExist(subtabDetails)) {
				ClickWebObject(subtabDetails);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Sub Details Tab is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Sub Details Tab is not Clicked");
		}
	}

	@Step("Click on General Sub tab")
	public void clickGeneralSubTab() {
		WaitForApplicationToLoadCompletely();
		try {
			if (WaitForObjectVisibility(subtabGeneral)) {
				ClickWebObject(subtabGeneral);
				WaitForApplicationToLoadCompletely();
				String isGeneralTabClicked = subtabGeneral.getAttribute("aria-selected");
				sa.assertEquals(isGeneralTabClicked, "true", "CLicked General Subtab");
				OneframeLogger("General Sub Tab is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("General Sub Tab is not Clicked");
		}
		sa.assertAll();
	}

	@Step("Enter Benefit Version Effective Date")
	public void EnterBenefitVersionEffectiveDate(String effectiveDate) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(benefitVersionEffectiveDateField);
		try {
			if (ObjectExist(benefitVersionEffectiveDateField)) {
				// ClickWebObject(txtSearchBenefit);
				// txtSearchBenefit.sendKeys(Keys.CONTROL + "a");
				benefitVersionEffectiveDateField.sendKeys(Keys.CONTROL + "a");
				benefitVersionEffectiveDateField.sendKeys(Keys.DELETE);
				benefitVersionEffectiveDateField.sendKeys(effectiveDate);
//				EnterText(txtLegacyBenefitPlanVersion, versionId);
//				txtLegacyBenefitPlanVersion.sendKeys(Keys.ENTER);
//				highlightElement(txtLegacyBenefitPlanVersion);
				OneframeLogger("Benefit Version Effective Date is Entered and the value is " + effectiveDate);
			} else {
				OneframeLogger("Benefit Version Effective Date is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Enter Benefit Version End Date")
	public void EnterBenefitVersionEndDate(String endDate) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(benefitVersionEndDateField);
		try {
			if (ObjectExist(benefitVersionEndDateField)) {
				benefitVersionEndDateField.sendKeys(Keys.CONTROL + "a");
				benefitVersionEndDateField.sendKeys(Keys.DELETE);
				benefitVersionEndDateField.sendKeys(endDate);
				OneframeLogger("Benefit Version End Date is Entered and the value is " + endDate);
			} else {
				OneframeLogger("Benefit Version End Date is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Enter Benefit Timely Filling Value")
	public void EnterTimelyFillng(String data) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(benefitTimelyFilling);
		try {
			if (ObjectExist(benefitTimelyFilling)) {
				benefitTimelyFilling.sendKeys(Keys.CONTROL + "a");
				benefitTimelyFilling.sendKeys(Keys.DELETE);
				benefitTimelyFilling.sendKeys(data);
				OneframeLogger("Benefit Timely Filling is Entered and the value is " + data);
			} else {
				OneframeLogger("Benefit Timely Filling Value is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Enter Benefit High Dollar Limit Retail Value")
	public void EnterHDLRetail(String data) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(benefitHighdollarlimitRetail);
		try {
			if (ObjectExist(benefitHighdollarlimitRetail)) {
				benefitHighdollarlimitRetail.sendKeys(Keys.CONTROL + "a");
				benefitHighdollarlimitRetail.sendKeys(Keys.DELETE);
				benefitHighdollarlimitRetail.sendKeys(data);
				OneframeLogger("Benefit High Dollar Limit Retail is Entered and the value is " + data);
			} else {
				OneframeLogger("Benefit High Dollar Limit Retail Value is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Enter Benefit High Dollar Limit Home Delivery Value")
	public void EnterHDLHomeDelivery(String data) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(benefitHighdollarlimitHomeDelivery);
		try {
			if (ObjectExist(benefitHighdollarlimitHomeDelivery)) {
				benefitHighdollarlimitHomeDelivery.sendKeys(Keys.CONTROL + "a");
				benefitHighdollarlimitHomeDelivery.sendKeys(Keys.DELETE);
				benefitHighdollarlimitHomeDelivery.sendKeys(data);
				OneframeLogger("Benefit High Dollar Limit Home Delivery is Entered and the value is " + data);
			} else {
				OneframeLogger("Benefit High Dollar Limit Home Delivery Value is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Enter Benefit Veterans Administration High Dollar Limit Value")
	public void EnterVAHDLValue(String data) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(benefitVeteransHighDollarLimit);
		try {
			if (ObjectExist(benefitVeteransHighDollarLimit)) {
				benefitVeteransHighDollarLimit.sendKeys(Keys.CONTROL + "a");
				benefitVeteransHighDollarLimit.sendKeys(Keys.DELETE);
				benefitVeteransHighDollarLimit.sendKeys(data);
				OneframeLogger("Benefit Veterans Administration High Dollar Limit is Entered and the value is " + data);
			} else {
				OneframeLogger("Benefit Veterans Administration High Dollar Limit Value is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, 'mat-select-panel mat-primary')]/mat-option/span[text()=' %s ']", values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
//		OneframeLogger("The Selected Dropdown value is "+dropdownvalue.getText());		
	}

	@Step("Select In Network Value from Paper Claims Processing dropdown")
	public boolean selectINNDropdown(String innValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnPaperClaimsInNetwork)) {
				ClickWebObject(btnPaperClaimsInNetwork);
				selectDropdownValues(innValue);
//				btnPaperClaimsInNetwork.sendKeys(Keys.TAB);			
				blnRC = true;
			}
		} catch (StaleElementReferenceException toException) {
			OneframeLogger("The INN Value has not been Selected from Paper Claims Processing dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Out Network Value from Paper Claims Processing dropdown")
	public boolean selectONNDropdown(String onnValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnPaperClaimsOutNetwork)) {
				ClickWebObject(btnPaperClaimsOutNetwork);
				selectDropdownValues(onnValue);
//				btnPaperClaimsInNetwork.sendKeys(Keys.TAB);			
				blnRC = true;
			}
		} catch (StaleElementReferenceException toException) {
			OneframeLogger("The ONN Value has not been Selected from Paper Claims Processing dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select a Value from Follow Me Logic Applies dropdown")
	public boolean selectFollowMeDropdown(String logicValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnFollowMeLogic)) {
				ClickWebObject(btnFollowMeLogic);
				selectDropdownValues(logicValue);
				btnFollowMeLogic.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Follow Me Logic Applies dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select a Value from Foreign Claim dropdown")
	public boolean selectForeignClaimDropdown(String claimValue) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(btnForeignClaim)) {
				ClickWebObject(btnForeignClaim);
				selectDropdownValues(claimValue);
				btnForeignClaim.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from Foreign Claim dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether Timely Filling Value is updated")
	public boolean verifyTimelyFillingValue(String Timevalue) {
		boolean blnRC = false;
		String Actualvalue = benefitTimelyFilling.getAttribute("value");
		String ExpectedValue = Timevalue;
		if (Actualvalue.equalsIgnoreCase(ExpectedValue)) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether HDR Value is updated")
	public boolean verifyHDRValue(String Retail, String HomeDelivery) {
		boolean blnRC = false;
		String ActualRetailvalue = benefitHighdollarlimitRetail.getAttribute("value");
		String ExpectedRetailValue = Retail;
		String ActualHomeDeliveryvalue = benefitHighdollarlimitHomeDelivery.getAttribute("value");
		String ExpectedHomeDeliveryValue = HomeDelivery;
		if (ActualRetailvalue.equalsIgnoreCase(ExpectedRetailValue)
				&& ActualHomeDeliveryvalue.equalsIgnoreCase(ExpectedHomeDeliveryValue)) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify whether VAHDR Value is updated")
	public boolean verifyVAHDRValue(String VAHDRvalue) {
		boolean blnRC = false;
		String Actualvalue = benefitVeteransHighDollarLimit.getAttribute("value");
		String ExpectedValue = VAHDRvalue;
		if (Actualvalue.equalsIgnoreCase(ExpectedValue)) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Rebate Strategy Toggle")
	public void clickRebateStrategyToggle() {
		try {
			
			if(ObjectExist(rebateToggle)) {
				String status = rebateToggle.getAttribute("aria-checked");
				
				if(status.equalsIgnoreCase("false")) {
					WaitForObject(tglRebateStrategy);
					ClickWebObject(tglRebateStrategy);
					WaitForApplicationToLoadCompletely();
					OneframeLogger("Rebate Strategy Toggle is ON");
				}
				else {
					OneframeLogger("Rebate Strategy Toggle is ON");
				}
			}
			
		} catch (TimeoutException e) {
			OneframeLogger("Rebate Strategy Toggle is Not ON");
		}
	}

	@Step("Enter Benefit Percent Value")
	public void EnterPercent(String data) {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(txtpercentvalue);
		try {
			if (ObjectExist(txtpercentvalue)) {
				txtpercentvalue.sendKeys(Keys.CONTROL + "a");
				txtpercentvalue.sendKeys(Keys.DELETE);
				txtpercentvalue.sendKeys(data);
				OneframeLogger("Benefit Percent value is Entered and the value is " + data);
			} else {
				OneframeLogger("Benefit Percent value is not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Click on PENCD Toggle")
	public void clickPENCDToggle() {
		try {
			
			if(ObjectExist(pencdToggle)) {
				String status = pencdToggle.getAttribute("aria-checked");
				
				if(status.equalsIgnoreCase("false")) {
					WaitForObject(tglPENCD);
					ClickWebObject(tglPENCD);
					WaitForApplicationToLoadCompletely();
					OneframeLogger("Pencd Toggle is ON");
				}
				else {
					OneframeLogger("Pencd Toggle is ON");
				}
			}
		} catch (TimeoutException e) {
			OneframeLogger("PENCD Toggle is Not ON");
		}
	}

	@Step("Verify whether Percent Value is updated")
	public boolean verifyPercentValue(String percent) {
		boolean blnRC = false;
		String Actualvalue = txtpercentvalue.getAttribute("value");
		String ExpectedValue = percent;
		if (Actualvalue.equalsIgnoreCase(ExpectedValue)) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Get Benefit ID, Client, LOB, State, previous version, retail and home delivery values")
	public ArrayList<String> getOldData() {
		ArrayList<String> expectedData = new ArrayList();

		if (WaitForObject(hdrBenefitID)) {
			expectedData.add(hdrBenefitID.getText());
			expectedData.add(hdrClientValue.getText());
			expectedData.add(hdrLOBValue.getText());
			if (hdrState.getText().equalsIgnoreCase("CA")) {
				expectedData.add("California");
			}
			expectedData.add(hdrVersion.getText());
			expectedData.add(benefitHighdollarlimitRetail.getAttribute("value"));
			expectedData.add(benefitHighdollarlimitHomeDelivery.getAttribute("value"));

		}
		return expectedData;
	}

	public boolean clickVersionDropDown() {
		boolean flg = false;
		WaitForApplicationToLoadCompletely();
		if (WaitForObject(dropDownIcon)) {
			ClickWebObject(dropDownIcon);
			OneframeLogger("Clicked on version dropdown");
			flg = true;
		} else {
			flg = false;
			OneframeLogger("Unable to click on version dropdown");
		}
		return flg;
	}

	@Step("Get Benefit ID, Client, LOB, State, previous version, retail and home delivery values")
	public ArrayList<ArrayList> getAllOldData(int numOfRows, String fileName) throws InterruptedException {
		ArrayList<ArrayList> expectedData = new ArrayList();
		IBPHomePage homepage = new IBPHomePage();

		OneframeLogger("Reading File: " + fileName + ".xlsx");
		ExcelFile xlFile1 = new ExcelFile("TestData", fileName + ".xlsx");

		for (int i = 1; i <= numOfRows; i++) {
			String strCell = xlFile1.OpenWorkBook().OpenWorkSheet("Sheet1").ReadCell(i, 1);
			ArrayList<String> subList = new ArrayList();
			oneframeDriver.navigate().refresh();
			homepage.verifyandclickSearchButton();
			homepage.EnterBenefit(strCell);
			WaitForApplicationToLoadCompletely();
			Thread.sleep(10000);
			clickGeneralSubTab();
			//ClickWebObject(hdrBenefitID);
			if (WaitForObjectVisibility(hdrBenefitID)) {
				hdrBenefitID.click();
				hdrBenefitID.click();
				hdrBenefitID.click();
				hdrBenefitID.click();
				oneframeDriver.navigate().refresh();
				//oneframeDriver.navigate().refresh();
				Thread.sleep(10000);
				subList.add(hdrBenefitID.getText());
				subList.add(hdrClientValue.getText());
				subList.add(hdrLOBValue.getText());
				if (hdrState.getText().equalsIgnoreCase("DE")) {
					subList.add("Delaware");
				} else {
					subList.add("Not California");
				}
				clickGeneralSubTab();
				clickGeneralSubTab();
				subList.add(hdrVersion.getText());
				subList.add(benefitHighdollarlimitRetail.getAttribute("value"));
				subList.add(benefitHighdollarlimitHomeDelivery.getAttribute("value"));

			}
			expectedData.add(subList);
		}

		for (ArrayList x : expectedData) {
			System.out.println(x);
		}

		return expectedData;
	}

	public ArrayList<ArrayList> addToList(String retailInput, ArrayList<ArrayList> expectedContent) {
		for (ArrayList x : expectedContent) {
			x.add(retailInput);
		}
		return expectedContent;
	}

	@Step("Validate notes added in bulk update page is visible in benefit screen")
	public boolean validateNotesAddedInBulkUpdate(int numOfRows, String notes, String fileName)
			throws InterruptedException {
		boolean flg = false;
		IBPHomePage homepage = new IBPHomePage();
		OneframeLogger("Reading File: " + fileName + ".xlsx");
		ExcelFile xlFile1 = new ExcelFile("TestData", fileName + ".xlsx");

		for (int i = 1; i <= numOfRows; i++) {
			String strCell = xlFile1.OpenWorkBook().OpenWorkSheet("Sheet1").ReadCell(i, 1);
			homepage.verifyandclickSearchButton();
			homepage.EnterBenefit(strCell);
			WaitForObjectVisibility(hdrBenefitID);
			ClickWebObject(hdrBenefitID);

			WaitForObjectVisibility(notesArea);
			if (WaitForObject(notesArea)) {
				ScrollToElement(notesArea);
				highlightElement(notesArea);
				String actualData = notesArea.getAttribute("value");
				if (actualData.contains(notes)) {
					OneframeLogger("Notes entered in bulkupdate is visible in benefit page");
					flg = true;
				} else {
					OneframeLogger("Notes entered in bulkupdate is not visible in benefit page");
					flg = false;
				}
			}
		}

		return flg;
	}

	public String getRandomString() {
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < 5) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();
		return saltStr;

	}

	public ArrayList<String> getPrevVersionNotes(int numOfRows, String fileName) {
		ArrayList<String> expectedData = new ArrayList();
		IBPHomePage homepage = new IBPHomePage();

		OneframeLogger("Reading File: " + fileName + ".xlsx");
		ExcelFile xlFile1 = new ExcelFile("TestData", fileName + ".xlsx");

		for (int i = 1; i <= numOfRows; i++) {
			String strCell = xlFile1.OpenWorkBook().OpenWorkSheet("Sheet1").ReadCell(i, 1);
			// ArrayList<String> subList = new ArrayList();
			oneframeDriver.navigate().refresh();
			homepage.verifyandclickSearchButton();
			homepage.EnterBenefit(strCell);
			// clickGeneralSubTab();
			WaitForObjectVisibility(notesArea);
			if (WaitForObject(notesArea)) {
				highlightElement(notesArea);
				expectedData.add(notesArea.getAttribute("value"));
			}
		}

		for (String x : expectedData) {
			System.out.println(x);
		}

		return expectedData;
	}

	public void clickPreviousVersion() {
		WaitForObjectToBeClickable(lastVersion);
		if (WaitForObject(lastVersion)) {
			ClickWebObject(lastVersion);
			OneframeLogger("Clicked on Last version: " + lastVersion.findElement(By.className("oval--old")).getText());
		}
	}

	@Step("Validate notes added in previous version of benefit")
	public boolean validatePrevVersionNotes(int numOfRows, ArrayList<String> actualData, String fileName) {
		ArrayList<String> expectedData = new ArrayList();
		IBPHomePage homepage = new IBPHomePage();
		boolean flg = false;

		OneframeLogger("Reading File: " + fileName + ".xlsx");
		ExcelFile xlFile1 = new ExcelFile("TestData", fileName + ".xlsx");

		for (int i = 1; i <= numOfRows; i++) {
			String strCell = xlFile1.OpenWorkBook().OpenWorkSheet("Sheet1").ReadCell(i, 1);
			// ArrayList<String> subList = new ArrayList();
			oneframeDriver.navigate().refresh();
			homepage.verifyandclickSearchButton();
			homepage.EnterBenefit(strCell);
			ClickWebObject(hdrBenefitID);
			if (WaitForObject(hdrBenefitID)) {
				clickVersionDropDown();
				clickPreviousVersion();
				ClickWebObject(hdrBenefitID);
				ClickWebObject(hdrBenefitID);
				ClickWebObject(hdrBenefitID);
				ClickWebObject(hdrBenefitID);
				ClickWebObject(hdrBenefitID);
				ClickWebObject(hdrBenefitID);
				
				expectedData.add(notesArea.getAttribute("value"));
			}
		}

		for (int i = 0; i < actualData.size(); i++) {
			if (expectedData.get(i).contentEquals(actualData.get(i))) {
				OneframeLogger("Previous version data matches");
				OneframeLogger("Expected Data: " + expectedData.get(i) + "\nActual Data: " + actualData.get(i));
				flg = true;
			} else {
				OneframeLogger("Previous version notes does not match");
				flg = false;
			}
		}

		return flg;
	}

	@Step("Clik on Duplicate Benefit Icon")
	public void clickOnDuplicateBenefitIcon() throws InterruptedException {
		Thread.sleep(3000);
		if(WaitForObject(duplicateBenefitIconColumn.get(0))) {
			duplicateBenefitIconColumn.get(0).click();
			OneframeLogger("Clicked on Duplicate benefit icon in benefit search results page");
		}
		else {
			OneframeLogger("Unable to click on Duplicate benefit icon in benefit search results page");
		}
	}

	@Step("Clik on Duplicate Benefit Button")
	public void clickOnDuplicateBenefitButton() {
		if(WaitForObject(btnDuplicateBenefit)) {
			btnDuplicateBenefit.click();
			OneframeLogger("Clicked on Duplicate benefit button");
		}
		else {
			OneframeLogger("Unable to click on Duplicate benefit button");
		}
	}

	@Step("Validate Filter By Header is displayed")
	public boolean verifyFilterByHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!benefitsFilterBySection.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitsFilterBySection);
			OneframeLogger("FilterBy Header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Lob Filter is displayed")
	public boolean verifyLobDropdownIsDisplayed() {
		boolean flg = false;
		
		if(! benefitsFilterByLOB.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitsFilterByLOB);
			OneframeLogger("Lob filter is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate State Filter is displayed")
	public boolean verifyStateDropdownIsDisplayed() {
		boolean flg = false;
		
		if(!benefitsFilterByState.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitsFilterByState);
			OneframeLogger("State Header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Effective Date Filter is displayed")
	public boolean verifyEffectiveDateDropdownIsDisplayed() {
		boolean flg = false;
		
		if(!benefitsFilterByEffectiveDate.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitsFilterByEffectiveDate);
			OneframeLogger("Effective Date filter is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Version Status Filter is displayed")
	public boolean verifyVersionStatusDropdownIsDisplayed() {
		boolean flg = false;
		
		if(!benefitsFilterByVerStatus.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitsFilterByVerStatus);
			OneframeLogger("Version Status filter is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Apply Filter button is displayed")
	public boolean verifyApplyFilterButtonIsDisplayed() {
		boolean flg = false;
		
		if(!benefitsApplyFilterButton.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitsApplyFilterButton);
			OneframeLogger("Apply Filter button is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Benefit Code column header is displayed")
	public boolean verifyBenefitCodeColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!benefitCodeColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitCodeColHeader);
			OneframeLogger("Benefit Code column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Benefit Plan ID column header is displayed")
	public boolean verifyBenefitPlanIDColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!benefitPlanIdColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitPlanIdColHeader);
			OneframeLogger("Benefit Plan ID column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Client column header is displayed")
	public boolean verifyClientColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!clientColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(clientColHeader);
			OneframeLogger("CLient column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate LOB column header is displayed")
	public boolean verifyLobColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!lobColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(lobColHeader);
			OneframeLogger("Lob column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate State column header is displayed")
	public boolean verifyStateColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!stateColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(stateColHeader);
			OneframeLogger("State column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Effective Date column header is displayed")
	public boolean verifyEffectiveDateColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!effectiveDateColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(effectiveDateColHeader);
			OneframeLogger("Effective Date column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Status column header is displayed")
	public boolean verifyStatusColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!statusColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(statusColHeader);
			OneframeLogger("Status column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Version Created On column header is displayed")
	public boolean verifyVersionCraetedOnColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!verCreatedOnColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(verCreatedOnColHeader);
			OneframeLogger("Version Created On column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Version column header is displayed")
	public boolean verifyVersionColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!versionColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(versionColHeader);
			OneframeLogger("Version column header is displayed");
			flg = true;
		}
		return flg;
	}
	
	@Step("Validate Last Edited By column header is displayed")
	public boolean verifyLastEditedByColHeaderIsDisplayed() {
		boolean flg = false;
		
		if(!lastEditedByColHeader.isDisplayed()) {
			return false;
		} else {
			highlightElement(lastEditedByColHeader);
			OneframeLogger("Last Edited By column header is displayed");
			flg = true;
		}
		return flg;
	}

	public void clickAcceptButton() {
		try {
			if (ObjectExist(btnAccept)) {
				ClickWebObject(btnAccept);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Accept button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Accept button is not Clicked");
		}
	}
}

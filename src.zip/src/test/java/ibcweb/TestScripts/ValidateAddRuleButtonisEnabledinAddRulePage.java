package ibcweb.TestScripts;



import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAddRuleButtonisEnabledinAddRulePage extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Date Validation For Creating a Rule")
	public void setUp() {
		InitializeLaunchPad("IBPW_16");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "RuleName", "Description", "Message", "StartDate",
				"EndDate", "ClientId", "LOBId", "StateId", "DType" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate Add Rule Button is Enabled in  Create Rule Page Page", dataProvider = "TestData")
	@Description("Validate Add Rule Button is Enabled in Add Rule Page")
	public void ValidateAddRuleButtonisEnabled(String TestCaseID, String TestStatus, String RuleName, String Description,
			String Message, String StartDate, String EndDate,  String ClientId, String LOBId, String StateId, String DType) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();
			addrulepage.verifyCreateaRuleHeader();
			addrulepage.EnterRuleName(RuleName);
			addrulepage.EnterDescription(Description);
			addrulepage.EnterMessage(Message);
			addrulepage.EnterStartDate(StartDate);
			addrulepage.EnterEndDate(EndDate);
			sa.assertTrue(addrulepage.selectClientIdDropdown(ClientId), "Client Dropdown has been selected");
			sa.assertTrue(addrulepage.selectLobIdDropdown(LOBId), "Lob Dropdown has been selected");
			sa.assertTrue(addrulepage.selectStateIdDropdown(StateId), "State Dropdown has been selected");
			addrulepage.clickAddButton();
			sa.assertTrue(addrulepage.selectLibraryDropdown(), "Library Dropdown has been selected");
			sa.assertTrue(addrulepage.selectPropertyDropdown(), "Property Dropdown has been selected");
			sa.assertTrue(addrulepage.selectOperatorDropdown(), "Operator Dropdown has been selected");
			sa.assertTrue(addrulepage.selectRHSDropdown(), "RHS Dropdown has been selected");		
			sa.assertTrue(addrulepage.selectDecisionTypeDropdown(DType), "Decision Type Dropdown has been selected");	
			sa.assertTrue(addrulepage.VerifyAddRuleButton(),"Verified the add rule button is Enabled");
			sa.assertAll();
			gTestResult = RESULT_PASS;
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Add Rule Button is Disabled ");
		}
		homepage.clickLogout();		
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

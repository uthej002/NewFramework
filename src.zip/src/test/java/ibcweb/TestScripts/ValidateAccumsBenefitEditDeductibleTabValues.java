package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumsBenefitEditDeductibleTabValues extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitPage benefitpage;

	@BeforeClass
	@Step("Initializing Test Script for Edit the Deductible Tab values in Accums Tab on the Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_700");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		benefitpage = new IBPBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "NewBenefitID", "INDINNRetail", "INDHomeDelivery", "INDOONRetail","FamINNRetail","FamINNHomeDelivery","FamOONRetail", "NumberofMembers", "INNOONAccumulate", "OOPDed", "Embedded", "PSLDed", "Rollover", "CrossNetwork" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate  Edit the Deductible Tab values in Accums Tab on the Benefit", dataProvider = "TestData")
	@Description("Validate Edit the Deductible Tab values in Accums Tab on the Benefit")
	public void ValidateCDHPFieldValuesinAccumsTab(String TestCaseID, String TestStatus, String NewBenefitID,String INDINNRetail,String INDHomeDelivery,String INDOONRetail,String FamINNRetail,String FamINNHomeDelivery,String FamOONRetail, String NumberofMembers, String INNOONAccumulate, String OOPDed, String Embedded, String PSLDed, String Rollover, String CrossNetwork )
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		OneframeAssert ha = new OneframeAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitID);
			//createbenefitpage.verifyFilterByTxt();
			//createbenefitpage.clickExistBenefit();
			ha.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			accumsbenefitpage.clickOnAccumsTab();
			createbenefitpage.ClickEditButtoninWFE();		
			sa.assertTrue(accumsbenefitpage.verifyAccumsContentDisplay(), "Verified Accums Content is Displayed");
			accumsbenefitpage.clickOnDeductibleTab();
			if(accumsbenefitpage.checkHomeDeliveryToggle()) {
				
				//accumsbenefitpage.clickHomeDeliveryToggle();
				sa.assertTrue(accumsbenefitpage.EditDifferentHomeDeliveryIndividualValues(INDINNRetail, INDHomeDelivery, INDOONRetail), "Verified the Individual Member values are edited when Different Home Delivery Toggle is enabled");
				sa.assertTrue(accumsbenefitpage.EditDifferentHomeDeliveryFamilyValues(FamINNRetail,FamINNHomeDelivery,FamOONRetail), "Verified the Family Member values are edited when Different Home Delivery Toggle is enabled");
				sa.assertTrue(accumsbenefitpage.selectNumberofMembersDropdown(NumberofMembers),"Verified the number of Members values are updated");
				sa.assertTrue(accumsbenefitpage.selectINNOONAccumsDropdown(INNOONAccumulate),"Verified the INN and ONN Accums values are updated");
				sa.assertTrue(accumsbenefitpage.selectOOPDedDropdown(OOPDed),"Verified the Deductible OOP values are updated");
				sa.assertTrue(accumsbenefitpage.selectEmbeddedDropdown(Embedded),"Verified the Embedded dropdown value is updated");
				sa.assertTrue(accumsbenefitpage.selectPSLDedDropdown(PSLDed),"Verified the Deductible PSL dropdown value is updated");
				sa.assertTrue(accumsbenefitpage.selectRolloverDropdown(Rollover),"Verified the Last Quarter Rollover dropdown value is updated");
				sa.assertTrue(accumsbenefitpage.selectCrossNetworkDropdown(CrossNetwork),"Verified the Cross Network dropdown value is updated");
				createbenefitpage.ClickWFECloseButton();
				createbenefitpage.ClickWFEExitAndSaveButton(); 
			}
			else {
			//accumsbenefitpage.clickDifferentHomeDeliveryToggle();
			sa.assertTrue(accumsbenefitpage.EditDifferentHomeDeliveryIndividualValues(INDINNRetail, INDHomeDelivery, INDOONRetail), "Verified The Individual Member values are edited when Different Home Delivery Toggle is enabled");
			sa.assertTrue(accumsbenefitpage.EditDifferentHomeDeliveryFamilyValues(FamINNRetail,FamINNHomeDelivery,FamOONRetail), "Verified The Family Member values are edited when Different Home Delivery Toggle is enabled");
			accumsbenefitpage.selectNumberofMembersDropdown(NumberofMembers);
			sa.assertTrue(accumsbenefitpage.selectNumberofMembersDropdown(NumberofMembers),"Verified the number of Members values are updated");
			sa.assertTrue(accumsbenefitpage.selectINNOONAccumsDropdown(INNOONAccumulate),"Verified the INN and ONN Accums values are updated");
			sa.assertTrue(accumsbenefitpage.selectOOPDedDropdown(OOPDed),"Verified the Deductible OOP values are updated");
			sa.assertTrue(accumsbenefitpage.selectEmbeddedDropdown(Embedded),"Verified the Embedded dropdown value is updated");
			sa.assertTrue(accumsbenefitpage.selectPSLDedDropdown(PSLDed),"Verified the Deductible PSL dropdown value is updated");
			sa.assertTrue(accumsbenefitpage.selectRolloverDropdown(Rollover),"Verified the Last Quarter Rollover dropdown value is updated");
			sa.assertTrue(accumsbenefitpage.selectCrossNetworkDropdown(CrossNetwork),"Verified the Cross Network dropdown value is updated");
			createbenefitpage.ClickWFECloseButton(); 
			createbenefitpage.ClickWFEExitAndSaveButton(); 
			}
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit the Deductible Tab values in Accums Tab on the Benefit Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Edit the Deductible Tab values in Accums Tab on the Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

	
	

}

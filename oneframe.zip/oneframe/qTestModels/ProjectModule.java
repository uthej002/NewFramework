// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import org.joda.time.DateTime;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProjectModule
{
    @JsonProperty("creatorId")
    private Long creatorId;
    @JsonProperty("createdDate")
    private DateTime createdDate;
    @JsonProperty("lastModifiedUserId")
    private Long lastModifiedUserId;
    @JsonProperty("lastModifiedDate")
    private DateTime lastModifiedDate;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("pid")
    private Long pid;
    @JsonProperty("clientId")
    private Long clientId;
    @JsonProperty("projectId")
    private Long projectId;
    @JsonProperty("project")
    private Project project;
    @JsonProperty("objOrder")
    private Long objOrder;
    @JsonProperty("parentModuleId")
    private Long parentModuleId;
    @JsonProperty("parentModule")
    private ProjectModule parentModule;
    @JsonProperty("name")
    private String name;
    @JsonProperty("description")
    private String description;
    @JsonProperty("moduleType")
    private byte[] moduleType;
    @JsonProperty("deleted")
    private Boolean deleted;
    @JsonProperty("shared")
    private Boolean shared;
    @JsonProperty("damage")
    private Long damage;
    @JsonProperty("frequency")
    private Long frequency;
    @JsonProperty("weight")
    private Long weight;
    @JsonProperty("tdsFlowId")
    private String tdsFlowId;
    @JsonProperty("objectType")
    private Long objectType;
    @JsonProperty("longId")
    private Long longId;
    @JsonProperty("artifactType")
    private Integer artifactType;
    @JsonProperty("parentArtifactId")
    private Long parentArtifactId;
    @JsonProperty("parentObjectType")
    private Long parentObjectType;
    @JsonProperty("statusId")
    private Long statusId;
    @JsonProperty("pidWithPrefix")
    private String pidWithPrefix;
    
    public ProjectModule() {
        this.creatorId = null;
        this.createdDate = null;
        this.lastModifiedUserId = null;
        this.lastModifiedDate = null;
        this.id = null;
        this.pid = null;
        this.clientId = null;
        this.projectId = null;
        this.project = null;
        this.objOrder = null;
        this.parentModuleId = null;
        this.parentModule = null;
        this.name = null;
        this.description = null;
        this.moduleType = null;
        this.deleted = false;
        this.shared = false;
        this.damage = null;
        this.frequency = null;
        this.weight = null;
        this.tdsFlowId = null;
        this.objectType = null;
        this.longId = null;
        this.artifactType = null;
        this.parentArtifactId = null;
        this.parentObjectType = null;
        this.statusId = null;
        this.pidWithPrefix = null;
    }
    
    public ProjectModule creatorId(final Long creatorId) {
        this.creatorId = creatorId;
        return this;
    }
    
    public Long getCreatorId() {
        return this.creatorId;
    }
    
    public void setCreatorId(final Long creatorId) {
        this.creatorId = creatorId;
    }
    
    public ProjectModule createdDate(final DateTime createdDate) {
        this.createdDate = createdDate;
        return this;
    }
    
    public DateTime getCreatedDate() {
        return this.createdDate;
    }
    
    public void setCreatedDate(final DateTime createdDate) {
        this.createdDate = createdDate;
    }
    
    public ProjectModule lastModifiedUserId(final Long lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
        return this;
    }
    
    public Long getLastModifiedUserId() {
        return this.lastModifiedUserId;
    }
    
    public void setLastModifiedUserId(final Long lastModifiedUserId) {
        this.lastModifiedUserId = lastModifiedUserId;
    }
    
    public ProjectModule lastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
        return this;
    }
    
    public DateTime getLastModifiedDate() {
        return this.lastModifiedDate;
    }
    
    public void setLastModifiedDate(final DateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
    
    public ProjectModule id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public ProjectModule pid(final Long pid) {
        this.pid = pid;
        return this;
    }
    
    public Long getPid() {
        return this.pid;
    }
    
    public void setPid(final Long pid) {
        this.pid = pid;
    }
    
    public ProjectModule clientId(final Long clientId) {
        this.clientId = clientId;
        return this;
    }
    
    public Long getClientId() {
        return this.clientId;
    }
    
    public void setClientId(final Long clientId) {
        this.clientId = clientId;
    }
    
    public ProjectModule projectId(final Long projectId) {
        this.projectId = projectId;
        return this;
    }
    
    public Long getProjectId() {
        return this.projectId;
    }
    
    public void setProjectId(final Long projectId) {
        this.projectId = projectId;
    }
    
    public ProjectModule project(final Project project) {
        this.project = project;
        return this;
    }
    
    public Project getProject() {
        return this.project;
    }
    
    public void setProject(final Project project) {
        this.project = project;
    }
    
    public ProjectModule objOrder(final Long objOrder) {
        this.objOrder = objOrder;
        return this;
    }
    
    public Long getObjOrder() {
        return this.objOrder;
    }
    
    public void setObjOrder(final Long objOrder) {
        this.objOrder = objOrder;
    }
    
    public ProjectModule parentModuleId(final Long parentModuleId) {
        this.parentModuleId = parentModuleId;
        return this;
    }
    
    public Long getParentModuleId() {
        return this.parentModuleId;
    }
    
    public void setParentModuleId(final Long parentModuleId) {
        this.parentModuleId = parentModuleId;
    }
    
    public ProjectModule parentModule(final ProjectModule parentModule) {
        this.parentModule = parentModule;
        return this;
    }
    
    public ProjectModule getParentModule() {
        return this.parentModule;
    }
    
    public void setParentModule(final ProjectModule parentModule) {
        this.parentModule = parentModule;
    }
    
    public ProjectModule name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public ProjectModule description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public ProjectModule moduleType(final byte[] moduleType) {
        this.moduleType = moduleType;
        return this;
    }
    
    public byte[] getModuleType() {
        return this.moduleType;
    }
    
    public void setModuleType(final byte[] moduleType) {
        this.moduleType = moduleType;
    }
    
    public ProjectModule deleted(final Boolean deleted) {
        this.deleted = deleted;
        return this;
    }
    
    public Boolean getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(final Boolean deleted) {
        this.deleted = deleted;
    }
    
    public ProjectModule shared(final Boolean shared) {
        this.shared = shared;
        return this;
    }
    
    public Boolean getShared() {
        return this.shared;
    }
    
    public void setShared(final Boolean shared) {
        this.shared = shared;
    }
    
    public ProjectModule damage(final Long damage) {
        this.damage = damage;
        return this;
    }
    
    public Long getDamage() {
        return this.damage;
    }
    
    public void setDamage(final Long damage) {
        this.damage = damage;
    }
    
    public ProjectModule frequency(final Long frequency) {
        this.frequency = frequency;
        return this;
    }
    
    public Long getFrequency() {
        return this.frequency;
    }
    
    public void setFrequency(final Long frequency) {
        this.frequency = frequency;
    }
    
    public ProjectModule weight(final Long weight) {
        this.weight = weight;
        return this;
    }
    
    public Long getWeight() {
        return this.weight;
    }
    
    public void setWeight(final Long weight) {
        this.weight = weight;
    }
    
    public ProjectModule tdsFlowId(final String tdsFlowId) {
        this.tdsFlowId = tdsFlowId;
        return this;
    }
    
    public String getTdsFlowId() {
        return this.tdsFlowId;
    }
    
    public void setTdsFlowId(final String tdsFlowId) {
        this.tdsFlowId = tdsFlowId;
    }
    
    public ProjectModule objectType(final Long objectType) {
        this.objectType = objectType;
        return this;
    }
    
    public Long getObjectType() {
        return this.objectType;
    }
    
    public void setObjectType(final Long objectType) {
        this.objectType = objectType;
    }
    
    public ProjectModule longId(final Long longId) {
        this.longId = longId;
        return this;
    }
    
    public Long getLongId() {
        return this.longId;
    }
    
    public void setLongId(final Long longId) {
        this.longId = longId;
    }
    
    public ProjectModule artifactType(final Integer artifactType) {
        this.artifactType = artifactType;
        return this;
    }
    
    public Integer getArtifactType() {
        return this.artifactType;
    }
    
    public void setArtifactType(final Integer artifactType) {
        this.artifactType = artifactType;
    }
    
    public ProjectModule parentArtifactId(final Long parentArtifactId) {
        this.parentArtifactId = parentArtifactId;
        return this;
    }
    
    public Long getParentArtifactId() {
        return this.parentArtifactId;
    }
    
    public void setParentArtifactId(final Long parentArtifactId) {
        this.parentArtifactId = parentArtifactId;
    }
    
    public ProjectModule parentObjectType(final Long parentObjectType) {
        this.parentObjectType = parentObjectType;
        return this;
    }
    
    public Long getParentObjectType() {
        return this.parentObjectType;
    }
    
    public void setParentObjectType(final Long parentObjectType) {
        this.parentObjectType = parentObjectType;
    }
    
    public ProjectModule statusId(final Long statusId) {
        this.statusId = statusId;
        return this;
    }
    
    public Long getStatusId() {
        return this.statusId;
    }
    
    public void setStatusId(final Long statusId) {
        this.statusId = statusId;
    }
    
    public ProjectModule pidWithPrefix(final String pidWithPrefix) {
        this.pidWithPrefix = pidWithPrefix;
        return this;
    }
    
    public String getPidWithPrefix() {
        return this.pidWithPrefix;
    }
    
    public void setPidWithPrefix(final String pidWithPrefix) {
        this.pidWithPrefix = pidWithPrefix;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ProjectModule projectModule = (ProjectModule)o;
        return Objects.equals(this.creatorId, projectModule.creatorId) && Objects.equals(this.createdDate, projectModule.createdDate) && Objects.equals(this.lastModifiedUserId, projectModule.lastModifiedUserId) && Objects.equals(this.lastModifiedDate, projectModule.lastModifiedDate) && Objects.equals(this.id, projectModule.id) && Objects.equals(this.pid, projectModule.pid) && Objects.equals(this.clientId, projectModule.clientId) && Objects.equals(this.projectId, projectModule.projectId) && Objects.equals(this.project, projectModule.project) && Objects.equals(this.objOrder, projectModule.objOrder) && Objects.equals(this.parentModuleId, projectModule.parentModuleId) && Objects.equals(this.parentModule, projectModule.parentModule) && Objects.equals(this.name, projectModule.name) && Objects.equals(this.description, projectModule.description) && Objects.equals(this.moduleType, projectModule.moduleType) && Objects.equals(this.deleted, projectModule.deleted) && Objects.equals(this.shared, projectModule.shared) && Objects.equals(this.damage, projectModule.damage) && Objects.equals(this.frequency, projectModule.frequency) && Objects.equals(this.weight, projectModule.weight) && Objects.equals(this.tdsFlowId, projectModule.tdsFlowId) && Objects.equals(this.objectType, projectModule.objectType) && Objects.equals(this.longId, projectModule.longId) && Objects.equals(this.artifactType, projectModule.artifactType) && Objects.equals(this.parentArtifactId, projectModule.parentArtifactId) && Objects.equals(this.parentObjectType, projectModule.parentObjectType) && Objects.equals(this.statusId, projectModule.statusId) && Objects.equals(this.pidWithPrefix, projectModule.pidWithPrefix);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.creatorId, this.createdDate, this.lastModifiedUserId, this.lastModifiedDate, this.id, this.pid, this.clientId, this.projectId, this.project, this.objOrder, this.parentModuleId, this.parentModule, this.name, this.description, this.moduleType, this.deleted, this.shared, this.damage, this.frequency, this.weight, this.tdsFlowId, this.objectType, this.longId, this.artifactType, this.parentArtifactId, this.parentObjectType, this.statusId, this.pidWithPrefix);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class ProjectModule {\n");
        sb.append("    creatorId: ").append(this.toIndentedString(this.creatorId)).append("\n");
        sb.append("    createdDate: ").append(this.toIndentedString(this.createdDate)).append("\n");
        sb.append("    lastModifiedUserId: ").append(this.toIndentedString(this.lastModifiedUserId)).append("\n");
        sb.append("    lastModifiedDate: ").append(this.toIndentedString(this.lastModifiedDate)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    pid: ").append(this.toIndentedString(this.pid)).append("\n");
        sb.append("    clientId: ").append(this.toIndentedString(this.clientId)).append("\n");
        sb.append("    projectId: ").append(this.toIndentedString(this.projectId)).append("\n");
        sb.append("    project: ").append(this.toIndentedString(this.project)).append("\n");
        sb.append("    objOrder: ").append(this.toIndentedString(this.objOrder)).append("\n");
        sb.append("    parentModuleId: ").append(this.toIndentedString(this.parentModuleId)).append("\n");
        sb.append("    parentModule: ").append(this.toIndentedString(this.parentModule)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("    moduleType: ").append(this.toIndentedString(this.moduleType)).append("\n");
        sb.append("    deleted: ").append(this.toIndentedString(this.deleted)).append("\n");
        sb.append("    shared: ").append(this.toIndentedString(this.shared)).append("\n");
        sb.append("    damage: ").append(this.toIndentedString(this.damage)).append("\n");
        sb.append("    frequency: ").append(this.toIndentedString(this.frequency)).append("\n");
        sb.append("    weight: ").append(this.toIndentedString(this.weight)).append("\n");
        sb.append("    tdsFlowId: ").append(this.toIndentedString(this.tdsFlowId)).append("\n");
        sb.append("    objectType: ").append(this.toIndentedString(this.objectType)).append("\n");
        sb.append("    longId: ").append(this.toIndentedString(this.longId)).append("\n");
        sb.append("    artifactType: ").append(this.toIndentedString(this.artifactType)).append("\n");
        sb.append("    parentArtifactId: ").append(this.toIndentedString(this.parentArtifactId)).append("\n");
        sb.append("    parentObjectType: ").append(this.toIndentedString(this.parentObjectType)).append("\n");
        sb.append("    statusId: ").append(this.toIndentedString(this.statusId)).append("\n");
        sb.append("    pidWithPrefix: ").append(this.toIndentedString(this.pidWithPrefix)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

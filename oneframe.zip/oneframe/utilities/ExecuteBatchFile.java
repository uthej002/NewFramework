// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ExecuteBatchFile
{
    public static void main(final String[] args) throws IOException {
        final String command = "cmd /C powershell C:\\Repositories\\irx_arrt\\src\\test\\resources\\BatchFiles\\AWS_Batch.ps1";
        final Process powerShellProcess = Runtime.getRuntime().exec(command);
        powerShellProcess.getOutputStream().close();
        System.out.println("Standard Output:");
        final BufferedReader stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
        String line;
        while ((line = stdout.readLine()) != null) {
            System.out.println(line);
        }
        stdout.close();
        final BufferedReader stderr = new BufferedReader(new InputStreamReader(powerShellProcess.getErrorStream()));
        while ((line = stderr.readLine()) != null) {
            System.out.println(line);
        }
        stderr.close();
        System.out.println("Done");
    }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCostOfCareEditAndCancelButtonFunctionality extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validating Cost of Care Edit and Cancel button Functionality")
	public void setUp() {
		InitializeLaunchPad("IBPW_772");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","ProgramName" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Cost of Care Edit and Cancel button Functionality", dataProvider = "TestData")
	@Description("Validate Cost of Care Edit and Cancel button Functionality")
	public void ValidateCostOfCareEditAndCancelFunctionality(String TestCaseID, String TestStatus,String ProgramName)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");

			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "Verified 'Programs' header");
			librariesprogramspage.clickCostofCareofPrograms();
			librariesprogramspage.clickProgramsHeader();
			sa.assertTrue(librariesprogramspage.verifyAndClickProgramName(ProgramName),
					"Verified and clicked Program name");
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			sa.assertTrue(librariesprogramspage.verifyProgramNameIsEnabledOrNot(),
					"Verified 'Program Name' field is Enabled");
			sa.assertTrue(controls.verifyCancelButton(), "Verified 'Cancel button' is displayed");
			sa.assertTrue(controls.verifySaveChangesButton(), "Verified 'Save Changes button' is displayed");
			controls.clickCancelButton();
			sa.assertTrue(controls.verifyLeaveWithOutSavingHeader(),
					"Verified 'Leave With out Saving header' is displayed");
			sa.assertTrue(controls.verifyTextYouhaveMadeChanges(),
					"Verified text 'You have made changes' is displayed");
			sa.assertTrue(controls.verifyCancelButtonInLeavePage(),
					"Verified 'Cancel button in Leave Without Saving Page' is displayed");
			sa.assertTrue(controls.verifyLeaveButtonInLeavePage(),
					"Verified 'Leave button in Leave Without Saving Page' is displayed");
			controls.clickCancelButtonInLeavePage();
			sa.assertTrue(librariesprogramspage.verifyProgramNameIsEnabledOrNot(),
					"Verified 'Program Name' field is Enabled");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Cost of Care Edit and Cancel button Functionality is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Cost of Care Edit and Cancel button Functionality");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

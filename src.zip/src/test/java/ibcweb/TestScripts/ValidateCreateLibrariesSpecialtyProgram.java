package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLibrariesSpecialtyPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCreateLibrariesSpecialtyProgram extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPLibrariesMandatesPage librariesmandatespage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesSpecialtyPage specialty;

	@BeforeClass
	@Step("Initializing Test Script for Validating Libraries Specialty Program is created")
	public void setUp() {
		InitializeLaunchPad("IBPW_708");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
	    librariesmandatespage =  new IBPLibrariesMandatesPage();
	    controls = new IBPLibrariesControlsPage();
	    specialty = new IBPLibrariesSpecialtyPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType", "MarketSegment",
				"ProductType", "Other", "Priority"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Libraries Specialty Program is created", dataProvider = "TestData")
	@Description("Validate Libraries Specialty Program is created")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String AutoApply, String BusinessEntity,
			String BusinessUnit, String CDHP, String Formulary, String FundingType, String MarketSegment,
			String ProductType, String Other, String Priority)throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickOnSpeciality();
			//librariesprogramspage.clickAddProgramofPrograms();
			sa.assertTrue(librariesprogramspage.clickAddaSpecialtyProgram(), "Click on Add a speicalty button");
			sa.assertTrue(librariesprogramspage.verifyAddNewProgramHeader(), "The Add New Program Section Page is displayed");
			String programName = librariesprogramspage.enterAndGetProgramName("TestAuto");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId), "The ClientID dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectLobdropdown(LOBId), "The LOB dropdown has been selected");
			sa.assertTrue(librariesprogramspage.selectStatedropdown(StateId), "The State dropdown has been selected");
			
			String autoApply = createbenefitpage.selectBenefitAutoApplyDropdown(AutoApply);
			sa.assertTrue(librariesmandatespage.selectBusinessEntityDropdown(BusinessEntity),	"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(librariesmandatespage.selectBusinessUnitDropdown(BusinessUnit),	"Verified and Selected 'Business Unit' dropdown");
			sa.assertTrue(librariesmandatespage.selectCDHPTypeDropdown(CDHP), "Verified and Selected 'CDHP Type' dropdown");
			sa.assertTrue(librariesmandatespage.selectFormularyDropdown(Formulary),
					"Verified and Selected 'Formulary' dropdown");
			sa.assertTrue(librariesmandatespage.selectFundingTypeDropdown(FundingType),
					"Verified and Selected 'Funding Type' dropdown");
			sa.assertTrue(librariesmandatespage.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' dropdown");
			sa.assertTrue(librariesmandatespage.selectProductTypeDropdown(ProductType),
					"Verified and Selected 'Product Type' dropdown");
			sa.assertTrue(librariesmandatespage.enterPriority(Priority), "Verified and Entered Priority Value");
			sa.assertTrue(librariesmandatespage.enterMandateDescription("Federal"), "Verified and Entered Description");
			
			sa.assertTrue(specialty.verifyDrugListHeaderIsDisplayed(), "Verified Drug List header is displayed");
			sa.assertTrue(specialty.verifyAddDrugListButtonIsDisplayed(), "Verified Add Drug List button is displayed");
			sa.assertTrue(specialty.verifyDrugListTableHeaders(), "Verified Drug List table headers are displayed");
			
			librariesprogramspage.clickAddProgram();
			librariesprogramspage.verifySpecialtyCreatedMessage();
			
			//librariesprogramspage.clickOnSpeciality();
			//sa.assertTrue(librariesmandatespage.VerifyMandateNameIsCreated(programName),
					//"Verified the Specialty Name is created and present in the Specialty List");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Benefit Libraries Add Program Auto Apply Dropdown Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Benefit Libraries Add Program Auto Apply Dropdown");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}



}

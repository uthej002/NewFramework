package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

public class IBPLibrariesFormulariesPosDur extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//span[text()=' POS DUR ']")
	WebElement txtPosDurTab;

	@FindBy(xpath = "//*[@formcontrolname='clientIds']")
	WebElement drdClientFilters;

	@FindBy(xpath = "//*[@formcontrolname='lobIds']")
	WebElement drdLOBFilters;

	@FindBy(xpath = "//*[@formcontrolname='stateIds']")
	WebElement drdStateFilters;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-clients mat-column-clients ng-star-inserted\"]")
	List<WebElement> lstClientValue;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-lobs mat-column-lobs ng-star-inserted\"]")
	List<WebElement> lstLOBValue;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-states mat-column-states ng-star-inserted\"]")
	List<WebElement> lstStateValue;

	@FindBy(xpath = "//*[text()='Clear filter']")
	WebElement btnClearFilter;

	@FindBy(xpath = "//*[text()=' Create a POS DUR ']")
	WebElement btnCreateAPosDur;

	@FindBy(xpath = "//*[text()='Create a POS DUR']")
	WebElement hdrCreateAPosDur;

	@FindBy(xpath = "//*[@class=\"mat-icon notranslate left-arrow mat-icon-no-color\"]")
	WebElement btnBack;

	@FindBy(xpath = "//*[@class=\"mat-cell cdk-cell cdk-column-posDurName mat-column-posDurName ng-star-inserted\"]")
	List<WebElement> lstPosDurname;

	@FindBy(xpath = "//*[@formcontrolname='name']")
	WebElement txtPosDurNameField;

	@FindBy(xpath = "//*[@formcontrolname='standardStepTherapyModelApplies']")
	WebElement txtStandardStepTherapyModelAppliesField;

	@FindBy(xpath = "//*[@formcontrolname='standardSafetyEditsModelApplies']")
	WebElement txtStandardSafetyEditsModelAppliesField;

	@FindBy(xpath = "//*[@formcontrolname='quantityEditModelApplies']")
	WebElement txtQuantityEditModelAppliesField;

	@FindBy(xpath = "//*[@formcontrolname='standardPriorAuthModelApplies']")
	WebElement txtStandardPriorAuthModelAppliesField;

	@FindBy(xpath = "//*[@formcontrolname='doseComboApplies']")
	WebElement txtDoseComboAppliesField;

	@FindBy(xpath = "//*[@formcontrolname='doesOptimizationApplies']")
	WebElement txtDoesOptimizationAppliesField;

	@FindBy(xpath = "//input[@placeholder=\"List item here\"]")
	List<WebElement> lstPosDurField;

	@FindBy(xpath = "//mat-select[@formcontrolname='clients']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdClient;

	@FindBy(xpath = "//mat-select[@formcontrolname='lobs']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdLob;

	@FindBy(xpath = "//mat-select[@formcontrolname='states']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdState;

	@FindBy(xpath = "//h3[text()='Dynamic Layer']")
	WebElement hdrDynamicLayer;

	@FindBy(xpath = " //*[text()=' Add POS DUR ']")
	WebElement btnAddPosDur;

	@FindBy(xpath = "//*[text()='Client,lob,state and dynamicLayer exists for the selected period please change the values. ']")
	WebElement txtErrMessage;

	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-posDurName mat-column-posDurName ng-star-inserted\"]")
	List<WebElement> lstPosDurName;

	@FindBy(xpath = "//*[@class=\"mat-paginator-icon\"]")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//span[contains(.,'POS DUR created successfully!')]")
	WebElement txtPosDurCreated;

	public IBPLibrariesFormulariesPosDur() {
		// Initializing the Page Objects
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify Pos Dur Tab is displayed")
	public void verifyPosDurTab() {
		boolean bln = false;
		WaitForObjectVisibility(txtPosDurTab);
		if (txtPosDurTab.isDisplayed()) {
			bln = true;
		}
		sa.assertTrue(bln, "Verified Pos Dur Tab is displayed");
	}

	@Step("Click on Pos Dur Tab")
	public void clickPosDurTab() {
		WaitForObjectVisibility(txtPosDurTab);
		txtPosDurTab.click();
		OneframeLogger("Clicked on Pos Dur tab");
	}

	@Step("Select and Get client Filter dropdownvalue ")
	public String selectAndGetClientDropdownValue(String client) {
		try {
			if (WaitForObjectVisibility(drdClientFilters)) {
				drdClientFilters.click();
				String clientVal = selectDropdownValues(client);
				OneframeLogger("The Selected client Dropdown value is : " + clientVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Client dropdown ");

		}
		return drdClientFilters.getText();
	}

	@Step("Select and Get Lob Filter dropdown value")
	public String selectAndGetLobFilterDropdownValue(String lob) {
		try {
			if (WaitForObjectVisibility(drdLOBFilters)) {
				drdLOBFilters.click();
				String lobVal = selectDropdownValues(lob);
				OneframeLogger("The Selected lob Dropdown value is : " + lobVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Lob dropdown ");

		}
		return drdLOBFilters.getText();
	}

	@Step("Select and Get State Filter dropdown value")
	public String selectAndGetStateFilterDropdownValue(String State) {
		try {
			if (WaitForObjectVisibility(drdStateFilters)) {
				drdStateFilters.click();
				String stateVal = selectDropdownValues(State);
				OneframeLogger("The Selected State Dropdown value is : " + stateVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select State dropdown ");
		}
		return drdStateFilters.getText();
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[normalize-space()='%s']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		return dropdownvalue.getText();
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-container\"]"));
		ClickWebObject(overlayElement);
	}

	@Step("Verify the Client filtered value is Same as Expected")
	public void verifyClientFilteredList(String client) {
		WaitForObjectVisibility(lstClientValue.get(0));
		highlightElement(lstClientValue.get(0));
		sa.assertEquals(lstClientValue.get(0).getText(), client, "Verified Client value is same as expected");
	}

	@Step("Verify the lob filtered value is Same as Expected")
	public void verifyLobFilteredList(String lob) {
		WaitForObjectVisibility(lstLOBValue.get(0));
		highlightElement(lstLOBValue.get(0));
		sa.assertEquals(lstLOBValue.get(0).getText(), lob, "Verified lob value is same as expected");
	}

	@Step("Verify the State filtered value is Same as Expected")
	public void verifyStateFilteredList(String State) {
		WaitForObjectVisibility(lstStateValue.get(0));
		highlightElement(lstStateValue.get(0));
		sa.assertEquals(lstStateValue.get(0).getText(), State, "Verified State value is same as expected");
	}

	@Step("Click on clear button filter")
	public void clickClearFilterButton() {
		WaitForObjectVisibility(btnClearFilter);
		btnClearFilter.click();
		OneframeLogger("Clicked on clear filter button");
	}

	@Step("Click on Create a Pos Dur")
	public void clickOnCreateAPosDur() {
		WaitForObjectVisibility(btnCreateAPosDur);
		btnCreateAPosDur.click();
		OneframeLogger("Clicked on Create a Pos Dur button");
	}

	@Step("Verify Pos Dur url")
	public void verifyPosDurUrl() {
		sa.assertEquals(hdrCreateAPosDur.getText(), "Create a POS DUR", "Validated header is same as expected");
		String currentUrl = oneframeDriver.getCurrentUrl();
		ha.assertTrue(currentUrl.contains("admin/library/formularies/pos-dur/new"),
				"Validated New Pos Dur url is as expected");
		btnBack.click();
		String currentURl = oneframeDriver.getCurrentUrl();
		ha.assertTrue(currentURl.contains("/admin/library/formularies/pos-dur"),
				"Validated Pos Dur url is as expected");
	}

	@Step("Verify Pos Dur Header")
	public void verifyPosDurHeader() {
		WaitForObjectVisibility(hdrCreateAPosDur);
		ClickWebObject(hdrCreateAPosDur);
		sa.assertEquals(hdrCreateAPosDur.getText(), "Create a POS DUR", "Validated header is same as expected");

	}

	@Step("Click on first record of Pos Dur page")
	public void clickFirstRecordOfPosDur() {
		WaitForObjectVisibility(lstPosDurname.get(0));
		lstPosDurname.get(0).click();
	}

	@Step("Verify {posDur} labels is displayed")
	public void verifyPosDurDetailslabelsAreDisplayed(String posDur) {
		WebElement expectedHeader = oneframeDriver.findElement(By.xpath(String.format("//*[text()=\"%s\"]", posDur)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to see Pos Dur labels");
		}
		sa.assertEquals(expectedHeader.getText(), posDur, "Validated Label is : " + posDur);
	}

	@Step("Select Standard Step Therapy Dropdown")
	public boolean selectStandardStepTherapyDropdown(String standardStepTherapy) {
		boolean blnRC = false;
		try {
			if (WaitForObject(txtStandardStepTherapyModelAppliesField)) {
				ClickWebObject(txtStandardStepTherapyModelAppliesField);
				selectDropdownValue(standardStepTherapy);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Standard Step Therapy dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()='%s']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
		// WebElement
		// sec=oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-backdrop
		// cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing\"]"));
		// ClickWebObject(sec);
	}

	@Step("Select the values from dropdowns")
	public void selDropdownValue(String values) throws InterruptedException {
		Thread.sleep(2000);
		String element = String.format(
				"//*[contains(@class, 'mat-option mat-focus-indicator provided ng-star-inserted')]//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));

		WaitForObjectVisibility(dropdownvalue);
		Thread.sleep(2000);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
		// WebElement
		// sec=oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-backdrop
		// cdk-overlay-transparent-backdrop cdk-overlay-backdrop-showing\"]"));
		// ClickWebObject(sec);
	}

	@Step("Select Standard Safety Edits Dropdown")
	public boolean selectStandardSafetyEditsDropdown(String standardSafetyEdits) {
		boolean blnRC = false;
		try {
			if (WaitForObject(txtStandardSafetyEditsModelAppliesField)) {
				ClickWebObject(txtStandardSafetyEditsModelAppliesField);
				selectDropdownValue(standardSafetyEdits);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Standard Safety Edits dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Quantity Edits Dropdown")
	public boolean selectQuantityEditsDropdown(String quantityEdits) {
		boolean blnRC = false;
		try {
			if (WaitForObject(txtQuantityEditModelAppliesField)) {
				ClickWebObject(txtQuantityEditModelAppliesField);
				selectDropdownValue(quantityEdits);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Quantity Edits dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Standard Prior Auth Dropdown")
	public boolean selectStandardPriorAuthDropdown(String standardPriorAuth) {
		boolean blnRC = false;
		try {
			if (WaitForObject(txtStandardPriorAuthModelAppliesField)) {
				ClickWebObject(txtStandardPriorAuthModelAppliesField);
				selectDropdownValue(standardPriorAuth);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Standard Prior Auth dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Dose Combo Applies Dropdown")
	public boolean selectDoseComboAppliesDropdown(String doseComboApplies) {
		boolean blnRC = false;
		try {
			if (WaitForObject(txtDoseComboAppliesField)) {
				ClickWebObject(txtDoseComboAppliesField);
				selectDropdownValue(doseComboApplies);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Dose Combo Applies dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Dose Optimization Applies Dropdown")
	public boolean selectDoseOptimizationAppliesDropdown(String doseOptimizationApplies) {
		boolean blnRC = false;
		try {
			if (WaitForObject(txtDoesOptimizationAppliesField)) {
				ClickWebObject(txtDoesOptimizationAppliesField);
				selectDropdownValue(doseOptimizationApplies);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Dose Optimization Applies dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select DGPI Dropdown")
	public boolean selectDGPIDropdown(String dgpi) throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(lstPosDurField.get(0))) {
				ClickWebObject(lstPosDurField.get(0));
				EnterText(lstPosDurField.get(0), "DG");
				selDropdownValue(dgpi);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select dgpi dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Dur Package Dropdown")
	public boolean selectDurPackageDropdown(String durPackage) throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(lstPosDurField.get(1))) {
				ClickWebObject(lstPosDurField.get(1));
				EnterText(lstPosDurField.get(1), "P");
				selDropdownValue(durPackage);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Dur Package dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Step Therapy Dropdown")
	public boolean selectStepTherapyDropdown(String stepTherapy) throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(lstPosDurField.get(2))) {
				ClickWebObject(lstPosDurField.get(2));
				EnterText(lstPosDurField.get(2), "ST");
				selDropdownValue(stepTherapy);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Step Therapy dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Enter POS Dur Names")
	public String enterPosDurName(String PosDur) {

		if (WaitForObjectVisibility(txtPosDurNameField)) {
			ClickWebObject(txtPosDurNameField);
			String posDurName = PosDur + "PosDur";
			int randomNumber = getRandomNumber();
			String posName = posDurName + randomNumber;
			txtPosDurNameField.sendKeys(posName);
			OneframeLogger("The Mandate Name is : " + txtPosDurNameField.getAttribute("value"));

		}
		return txtPosDurNameField.getAttribute("value");
	}

	@Step("Enter POS Dur Name Duplicate")
	public boolean enterPosDurNameDuplicate(String PosDur) {
		boolean bln = false;
		if (WaitForObjectVisibility(txtPosDurNameField)) {
			ClickWebObject(txtPosDurNameField);
			txtPosDurNameField.sendKeys(PosDur);
			OneframeLogger("The Mandate Name is : " + txtPosDurNameField.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Select Value Client from dropdown")
	public boolean selectClientropdown(String client) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdClient)) {
				ClickWebObject(drdClient);
				selectDropdownValues(client);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from client dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Value LOB from dropdown")
	public boolean selLobdropdown(String lob) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdLob)) {
				ClickWebObject(drdLob);
				selectDropdownValue(lob);

				Robot rt = new Robot();
				rt.keyPress(KeyEvent.VK_TAB);

				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from lob dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Value State from dropdown")
	public boolean selectStatedropdown(String state) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdState)) {
				ClickWebObject(drdState);
				selectDropdownValues(state);
				clickOverlayElement();
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Value has not been Selected from state dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on dynamic Layer")
	public void clickDynamicLayer() {
		WaitForObjectVisibility(hdrDynamicLayer);
		ClickWebObject(hdrDynamicLayer);
		ClickWebObject(hdrDynamicLayer);
		ClickWebObject(hdrDynamicLayer);
	}

	@Step("Click on Add Pos Dur Button")
	public void clickAddPosDurButton() {
		WaitForObjectVisibility(btnAddPosDur);
		btnAddPosDur.click();
		OneframeLogger("Clicked on Add Pos Dur Button");
	}

	@Step("Verify Error text message if we provide duplicate values")
	public void verifyErrorTextMessageDuplicate() {
		WaitForObjectVisibility(txtErrMessage);
		ScrollToElement(txtErrMessage);
		highlightElement(txtErrMessage);
		sa.assertEquals(txtErrMessage.getText(),
				"Client,lob,state and dynamicLayer exists for the selected period please change the values.",
				"Verified Error Text message is same as expected");
	}

	@Step("Verify Pos Dur Created")
	public boolean verifyPosDurCreated() {
		boolean bln = false;
		WaitForObjectVisibility(txtPosDurCreated);
		if (txtPosDurCreated.isDisplayed()) {
			highlightElement(txtPosDurCreated);
			bln = true;
		}
		return bln;
	}

	@Step("Verify Pos Dur Name")
	public boolean verifyPosDurName(String programName) {
		boolean bln = false;
		WaitForApplicationToLoadCompletely();
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstPosDurName.size(); i++) {
					WaitForObjectVisibility(lstPosDurName.get(i));
					if (lstPosDurName.get(i).getText().contains(programName)) {
						highlightElement(lstPosDurName.get(i));
						// ClickWebObject(lstPosDurName.get(i));
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to get Pos Dur Name");
			bln = false;
		}
		return bln;
	}
}

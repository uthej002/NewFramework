package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ScrollToElement;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

public class IBPLibrariesBaseFormularies extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//*[@formcontrolname='clientId']")
	WebElement drdClientFilters;

	@FindBy(xpath = "//*[@formcontrolname='lobId']")
	WebElement drdLOBFilters;

	@FindBy(xpath = "//*[@formcontrolname='stateId']")
	WebElement drdStateFilters;

	@FindBy(xpath = "//*[@formcontrolname='formularyType']")
	WebElement drdFormularyType;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-client mat-column-client ng-star-inserted\"]")
	List<WebElement> lstClientValue;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-lob mat-column-lob ng-star-inserted\"]")
	List<WebElement> lstLOBValue;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-state mat-column-state ng-star-inserted\"]")
	List<WebElement> lstStateValue;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-formularyType mat-column-formularyType ng-star-inserted\"]")
	List<WebElement> lstFormularyType;

	@FindBy(xpath = "//*[text()=' Clear filter ']")
	WebElement btnClearFilter;

	@FindBy(xpath = "//*[text()=' Create a Base Formulary ']")
	WebElement btnCreateABaseFormulary;

	@FindBy(xpath = "//*[@placeholder=\"Select\"]")
	List<WebElement> txtBaseFormulariesField;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyDescription\"]")
	WebElement txtFormularyNameField;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyIdentifier\"]")
	WebElement txtFormularyIDField;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyType\"]")
	WebElement txtFormularyTypeField;

	@FindBy(xpath = "//*[@formcontrolname=\"clients\"]")
	WebElement txtClientField;

	@FindBy(xpath = "//*[@formcontrolname=\"lobs\"]")
	WebElement txtLOBField;

	@FindBy(xpath = "//*[@formcontrolname=\"states\"]")
	WebElement txtStateField;

	@FindBy(xpath = "//*[@formcontrolname=\"effectiveDate\"]")
	WebElement txtEffectiveField;

	@FindBy(xpath = "//*[@formcontrolname=\"stopSaleDate\"]")
	WebElement txtStopSaleDateField;

	@FindBy(xpath = "//*[@formcontrolname=\"termDate\"]")
	WebElement txtTermDateField;

	@FindBy(xpath = "//*[@formcontrolname=\"formularyManagedBy\"]")
	WebElement txtManagedByField;

	@FindBy(xpath = "//*[@formcontrolname=\"link\"]")
	WebElement txtFormularyLinkField;

	@FindBy(xpath = "//*[@formcontrolname=\"implementationDate\"]")
	WebElement txtImplementationDateField;

	public IBPLibrariesBaseFormularies() {
		// Initializing the Page Objects
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Select and Get client Filter dropdownvalue ")
	public String selectAndGetClientDropdownValue(String client) {
		try {
			if (WaitForObject(drdClientFilters)) {
				drdClientFilters.click();
				String clientVal = selectDropdownValues(client);
				OneframeLogger("The Selected client Dropdown value is : " + clientVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Client dropdown ");

		}
		return drdClientFilters.getText();
	}

	@Step("Select and Get Lob Filter dropdown value")
	public String selectAndGetLobFilterDropdownValue(String lob) {
		try {
			if (WaitForObject(drdLOBFilters)) {
				drdLOBFilters.click();
				String lobVal = selectDropdownValues(lob);
				OneframeLogger("The Selected lob Dropdown value is : " + lobVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Lob dropdown ");

		}
		return drdLOBFilters.getText();
	}

	@Step("Select and Get State Filter dropdown value")
	public String selectAndGetStateFilterDropdownValue(String State) {
		try {
			if (WaitForObject(drdStateFilters)) {
				drdStateFilters.click();
				String stateVal = selectDropdownValues(State);
				OneframeLogger("The Selected State Dropdown value is : " + stateVal);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select State dropdown ");
		}
		return drdStateFilters.getText();
	}

	@Step("Select and Get formulary type Filter dropdown value")
	public String selectAndGetFormularyTypeFilterDropdownValue(String formulary) {
		try {
			if (WaitForObjectVisibility(drdFormularyType)) {
				drdFormularyType.click();
				String formularyVal = selectDropdownValue(formulary);
				OneframeLogger("The Selected Formulary Type Dropdown value is : " + formularyVal);
				// clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Formulary Type dropdown ");
		}
		return drdFormularyType.getText();
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[normalize-space()='%s']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		return dropdownvalue.getText();
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-container\"]"));
		ClickWebObject(overlayElement);
	}

	@Step("Verify the Client filtered value is Same as Expected")
	public void verifyClientFilteredList(String client) {
		WaitForObjectVisibility(lstClientValue.get(0));
		highlightElement(lstClientValue.get(0));
		sa.assertEquals(lstClientValue.get(0).getText(), client, "Verified Client value is same as expected");
	}

	@Step("Verify the lob filtered value is Same as Expected")
	public void verifyLobFilteredList(String lob) {
		WaitForObjectVisibility(lstLOBValue.get(0));
		highlightElement(lstLOBValue.get(0));
		sa.assertEquals(lstLOBValue.get(0).getText(), lob, "Verified lob value is same as expected");
	}

	@Step("Verify the State filtered value is Same as Expected")
	public void verifyStateFilteredList(String State) {
		WaitForObjectVisibility(lstStateValue.get(0));
		highlightElement(lstStateValue.get(0));
		sa.assertEquals(lstStateValue.get(0).getText(), State, "Verified Client value is same as expected");
	}

	@Step("Verify the Formulary Type filtered value is Same as Expected")
	public void verifyFormularytypeFilteredList(String formularyType) {
		WaitForObjectVisibility(lstFormularyType.get(0));
		highlightElement(lstFormularyType.get(0));
		sa.assertEquals(lstFormularyType.get(0).getText(), formularyType,
				"Verified Formulary type value is same as expected");

	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
		return value;
	}

	@Step("Click on clear button filter")
	public void clickClearFilterButton() {
		WaitForObjectVisibility(btnClearFilter);
		btnClearFilter.click();
		OneframeLogger("Clicked on clear filter button");
	}

	@Step("Click on Create A Base Formulary button")
	public void clickCreateABaseFormularyButton() {
		WaitForObjectVisibility(btnCreateABaseFormulary);
		btnCreateABaseFormulary.click();
		OneframeLogger("Clicked on Create A Base Formulary button");
	}

	@Step("Verify {baseFormulary} labels is displayed")
	public void verifyBaseFormularyDetailslabelsAreDisplayed(String baseFormulary) {
		WebElement expectedHeader = oneframeDriver
				.findElement(By.xpath(String.format("//*[text() and normalize-space()='%s']", baseFormulary)));

		ScrollToElement(expectedHeader);
		if (expectedHeader.isDisplayed()) {
			highlightElement(expectedHeader);
		} else {
			OneframeLogger("Unable to see base Formulary labels");
		}
		sa.assertEquals(expectedHeader.getText(), baseFormulary, "Validated Label is : " + baseFormulary);
	}
	
	

	@Step("Verify {baseFormulary} field are displayed")
	public void verifyBaseFormularyFieldsisDisplayed(String baseFormulary) {
		switch (baseFormulary) {
		case "Formulary Name":
			if (txtFormularyNameField.isDisplayed()) {
				highlightElement(txtFormularyNameField);
				sa.assertTrue(true, "Verified Formulary Name Field is displayed");
			}
			break;

		case "Formulary ID":
			if (txtFormularyIDField.isDisplayed()) {
				highlightElement(txtFormularyIDField);
				sa.assertTrue(true, "Verified Formulary Id Field is displayed");
			}
			break;
		case "Formulary Type":
			if (txtFormularyTypeField.isDisplayed()) {
				highlightElement(txtFormularyTypeField);
				sa.assertTrue(true, "Verified Formulary Type Field is displayed");
			}
			break;
		case "Client":
			if (txtClientField.isDisplayed()) {
				highlightElement(txtClientField);
				sa.assertTrue(true, "Verified Client Field is displayed");
			}
			break;
		case "LOB":
			if (txtLOBField.isDisplayed()) {
				highlightElement(txtLOBField);
				sa.assertTrue(true, "Verified LOB Field is displayed");
			}
			break;
		case "State":
			if (txtStateField.isDisplayed()) {
				highlightElement(txtStateField);
				sa.assertTrue(true, "Verified State Field is displayed");
			}
			break;
		case "Effective Date":
			if (txtEffectiveField.isDisplayed()) {
				highlightElement(txtEffectiveField);
				sa.assertTrue(true, "Verified Effective Date Field is displayed");
			}
			break;
		case "Stop Sale Date":
			if (txtStopSaleDateField.isDisplayed()) {
				highlightElement(txtStopSaleDateField);
				sa.assertTrue(true, "Verified Stop Sale Date Field is displayed");
			}
			break;
		case "Term Date":
			if (txtTermDateField.isDisplayed()) {
				highlightElement(txtTermDateField);
				sa.assertTrue(true, "Verified Term Date Field is displayed");
			}
			break;
		case "Managed By":
			if (txtManagedByField.isDisplayed()) {
				highlightElement(txtManagedByField);
				sa.assertTrue(true, "Verified Managed By Field is displayed");
			}
			break;
		case "Formulary Link":
			if (txtFormularyLinkField.isDisplayed()) {
				highlightElement(txtFormularyLinkField);
				sa.assertTrue(true, "Verified Formulary Link Field is displayed");
			}
			break;
		case "Implementation Date":
			if (txtImplementationDateField.isDisplayed()) {
				highlightElement(txtImplementationDateField);
				sa.assertTrue(true, "Verified Implementation Date Field is displayed");
			}
			break;
		default:
			OneframeLogger(baseFormulary + " base formularies field is not displayed");

		}
	}

}

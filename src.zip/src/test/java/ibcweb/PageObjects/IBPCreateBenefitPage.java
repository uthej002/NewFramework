package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.EmptyFileException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.ExcelFile;
import io.qameta.allure.Step;

public class IBPCreateBenefitPage extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//*[@placeholder='Select']/div/div/span")
	List<WebElement> btnDropDowns;

	@FindBy(xpath = "//h3[text()='Create benefit']")
	WebElement hdrCreateBenefit;

	@FindBy(xpath = "//h3[text()='Benefit header']")
	WebElement hdrBenefitHeader;

	@FindBy(xpath = "//input[@formcontrolname='effectiveDate']")
	WebElement txtEffectiveDate;

	// input[@aria-haspopup='dialog']

	@FindBy(xpath = "//*[@formcontrolname=\"benefitPlanId\"]")
	WebElement txtEnterBenefitId;

	@FindBy(xpath = "//div[contains(@class,'mat-select-panel-wrap ')]//div/mat-option/span")
	List<WebElement> btnCBClientId;

	@FindBy(xpath = "//div[contains(@class,'mat-select-panel-wrap ')]//div/mat-option/span")
	List<WebElement> btnCBLOBId;

	@FindBy(xpath = "//mat-option[@role='option']/span")
	List<WebElement> btnCBStateId;

	@FindBy(xpath = "//mat-option[@role='option']")
	List<WebElement> btnCBMandates;

	@FindBy(xpath = "//div[contains(text(),\"Mandates\")]")
	WebElement btnMandateTab;

	@FindBy(xpath = "//div[@class=\"header\"]//following::div[@role='tab'][2]")
	WebElement btnStateTab;

	@FindBy(xpath = "//div[@class=\"mat-list-item-content mat-list-item-content-reverse\"]")
	List<WebElement> federalMandateAutoApplied;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text() =' Create ']")
	WebElement btnCBCreate;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text() = 'Cancel']")
	WebElement btnCBCancel;

	@FindBy(xpath = "//button[@data-automation-id='createCancel']/span")
	WebElement btnCancel1;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()= ' Create a Benefit ']")
	WebElement btnCreateaBenefit;

	@FindBy(xpath = "//span[@class='mat-button-wrapper' and text()= ' Bulk Edit ']")
	WebElement btnBulkEdit;

	@FindBy(xpath = "//div[@class='benefit-header']/h1")
	WebElement hdrCreatedBenefitHeader;

	@FindBy(xpath = "//*[contains(text(),\"Auto Apply\")]//following::span[1]")
	WebElement txtAutoApplyInBenefitPage;

	@FindBy(xpath = "//div[@class='main-header']/div/div[@class='element']/span[@data-automation-id='headerVersionValue']")
	WebElement hdrVerStatus;

	@FindBy(css = "span.oval--current")
	WebElement hdrVersionValue;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and text()=' Verify ']")
	WebElement btnVerifyForCreatedBenefit;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and text()=' Close ']")
	WebElement btnWFEClose;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and text()=' Save ']")
	WebElement btnSave;

	@FindBy(xpath = "//span[contains(text(),'was saved')]")
	WebElement txtSaveMessage;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and text()=' Submit for Client Approval ']")
	WebElement btnSubmitForClientApproval;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and normalize-space()='Edit']")
	WebElement btnEdit;

	@FindBy(xpath = "//div[@class=\"question-section-1\" and text()= ' Leave without Saving? ']")
	WebElement hdrLeavewithoutSaving;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and text() =' Exit without Saving ']")
	WebElement btnExitWithoutSaving;

	@FindBy(xpath = "//button/span[@class='mat-button-wrapper' and text() =' Save & Exit ']")
	WebElement btnExitAndSave;

	@FindBy(xpath = "//span[contains(text(),\"was saved\")]")
	WebElement txtWasSaved;

//	@FindBy(xpath = "//mat-select[@placeholder=\"Select\"]")
//	List<WebElement> drdAutoApply;

	@FindBy(xpath = "//mat-select[@data-automation-id='createMandates']")
	WebElement drdMandate;
	
	@FindBy(xpath = "//mat-select[@data-automation-id='createMandates']")
	List<WebElement> drdAutoApply;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> firstDropdownOption;

	@FindBy(xpath = "//mat-icon[@svgicon=\"add\"]")
	WebElement btnAddMandate;

	@FindBy(xpath = "//*[@class=\"header__title\"]")
	WebElement hdrAddAMandate;

	@FindBy(xpath = "//*[contains(text(),\" MANDATE NAME \")]//following::tr//td[3]")
	List<WebElement> lstAddAMandate;

	@FindBy(xpath = "//*[contains(text(),\"Add to benefit\")]")
	WebElement btnAddToBenefit;

	@FindBy(xpath = "//h3[contains(text(),\"Mandates Setup\")]")
	WebElement hdrMandatesSetup;

	@FindBy(xpath = "//span[text()=' Request Benefit ID ']")
	WebElement btnRequestBenefitID;

	@FindBy(xpath = "//mat-label[text()='Auto Apply']/../../..//div/div[2]")
	WebElement selAutoApply;

	@FindBy(xpath = "//*[@class='mat-row cdk-row ng-star-inserted']")
	List<WebElement> selectBenefit;

	@FindBy(xpath = "//*[text()=' Filter by ']")
	WebElement txtFilterBy;

	@FindBy(xpath = "//span[text()=' Opt-out ']")
	WebElement btnOptout;

	@FindBy(xpath = "//span[text()= 'Opt-out']")
	WebElement btnPopupOptout;

	@FindBy(xpath = "//span[text()=' Opt-in ']")
	WebElement btnOptIn;

	@FindBy(xpath = "//h3[text()= ' AutoApplyNoOne (out) ']")
	WebElement hdrAutoApplyOut;

	@FindBy(xpath = "//*[text()=' BENEFIT CODE']")
	WebElement txtBenefitCode;
	
	@FindBy(xpath = "//h3[text()='Duplicate a Benefit']")
	WebElement hdrDuplicateBenefit;
	
	@FindBy(xpath = "//mat-label[text()='Business Unit']/..//mat-select[@data-automation-id='createMandates']")
	WebElement drdBusinessUnit;
     
	
	@FindBy(xpath = "//div[text()=' Formulary ']/parent::div")
	WebElement formularytab;

	@FindBy(xpath = "//div[text()='POS DUR Packages']/parent::div")
	WebElement posDurPackagetab;
	
	@FindBy(xpath = "//*[@class='mat-icon notranslate material-icons mat-icon-no-color']")
	WebElement eyebtn;
	
	@FindBy(xpath = "//h3[text()='Details']")
	WebElement headerDetails;
	
	@FindBy(xpath = "(//span[text()='Yes'])[2]")
	WebElement autoApplyDropDownValue;
	
	@FindBy(xpath = "//button[@class='mat-focus-indicator header__icon mat-icon-button mat-button-base']")
	WebElement crossBtn;
	
	@FindBy(xpath = "//h3[text()='Dynamic Layer']")
	WebElement dynamicLayerHeader;
	
	@FindBy(xpath = "//span[text()=' Save ']")
	WebElement savebtn;
	
	@FindBy(xpath = "//mat-select[@id='mat-select-73']/div")
	WebElement standardStepTerapyDropdown;
	
	@FindBy(xpath = "//mat-form-field[12]/div/div/div[3]")
	WebElement standardsafetyEditsDropdown;

	@FindBy(xpath = "(//*[@placeholder='Select']/div/div/span)[9]//following::div/div/span/span")
	List<WebElement> durPagebtnDropDowns;
	
	@FindBy(xpath = "//div[contains(@class,'mat-select-panel-wrap ')]//div/mat-option/span")
	List<WebElement> btnstandardSafetyeditoptions;
	
	@FindBy(xpath = "//div[@class=\"col\"]")
	List<WebElement> textValuesInPosDur;
	
	@FindBy(xpath = "//mat-select[@placeholder='Select']")
	List<WebElement> dropDownsforDisabledInPosDur;
	
	@FindBy(xpath = "//input[@formcontrolname='benefitPlanId']")
	WebElement inputPlanId;
	
	// Initializing the Page Objects:
	public IBPCreateBenefitPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify Create Benefit header is Displayed")
	public boolean verifyCreateBenefit() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrCreateBenefit);
		try {
			if (WaitForObject(hdrCreateBenefit)) {
				ClickWebObject(hdrCreateBenefit);
				OneframeLogger(" Create Benefit Header is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger(" Create Benefit Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Benefit header is Displayed")
	public boolean verifyBenefitHeader() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectToBeInvisible(By.cssSelector("span.spinner"));
		WaitForObjectVisibility(hdrBenefitHeader);
		try {
			if (WaitForObject(hdrBenefitHeader)) {
				ClickWebObject(hdrBenefitHeader);
				OneframeLogger(" Benefit Header is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger(" Benefit Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Benefit header")
	public void clickBenefitHeader() {
		ClickWebObject(hdrBenefitHeader);
		ClickWebObject(hdrBenefitHeader);
		OneframeLogger("Clicked on Benefit header");
	}

	@Step("Verify Created Benefit header is Displayed")
	public boolean verifyCreatedBenefitHeader() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(hdrCreatedBenefitHeader);
		try {
			if (WaitForObject(hdrCreatedBenefitHeader)) {
				ClickWebObject(hdrCreatedBenefitHeader);
				OneframeLogger("The Benefit Header is " + hdrCreatedBenefitHeader.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Benefit Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Created Benefit header is Displayed")
	public boolean verifyBenefitCreatedHeader(String benefitId) throws InterruptedException {
		Thread.sleep(10000);
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(hdrCreatedBenefitHeader);
		try {
			if (hdrCreatedBenefitHeader.getText().equalsIgnoreCase(benefitId)) {
				ClickWebObject(hdrCreatedBenefitHeader);
				OneframeLogger("The Benefit Header is " + hdrCreatedBenefitHeader.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Benefit Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Auto Apply Benefit Page is 'Yes'")
	public boolean verifyAutoApplyInBenefitPage(String autoApply) {
		boolean bln = false;
		WaitForObject(txtAutoApplyInBenefitPage);
		ClickWebObject(txtAutoApplyInBenefitPage);
		if (txtAutoApplyInBenefitPage.getText().equalsIgnoreCase(autoApply)) {
			highlightElement(txtAutoApplyInBenefitPage);
			bln = true;
		}
		return bln;
	}

	@Step("Verify Version Status is Displayed")
	public boolean verifyVerStatus() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrVerStatus);
		try {
			if (WaitForObject(hdrVerStatus)) {
				highlightElement(hdrVerStatus);
				
				if(hdrVerStatus.getText()!="") {
					ClickWebObject(hdrVerStatus);
					OneframeLogger("The Version Status is " + hdrVerStatus.getText());

					blnRC = true;
				}
				else {
					blnRC = false;
				}
				
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Version Status is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Version Value is Displayed")
	public boolean verifyVersionValue() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrVersionValue);
		try {
			if (WaitForObject(hdrVersionValue)) {
				ClickWebObject(hdrVersionValue);
				OneframeLogger("The Version Value is " + hdrVersionValue.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Version Value is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Version Value")
	public boolean verifyVersionVal(String versionVal) throws InterruptedException {
		boolean blnRC = false;
		double previousVersion = Double.parseDouble(versionVal);
		WaitForObjectVisibility(hdrVersionValue);
		try {
			if (WaitForObject(hdrVersionValue)) {
				double currentVersion = Double.parseDouble(hdrVersionValue.getText().trim());
				if (currentVersion > previousVersion) {
					OneframeLogger("Curent Version is greater than previous version");
					OneframeLogger("Current Version is : " +currentVersion);
					OneframeLogger("Previous Version is : " +previousVersion);
					blnRC = true;
				}
				else {
					blnRC = false;
					OneframeLogger("Curent Version is not greater than previous version");
					OneframeLogger("Current Version is : " +currentVersion);
					OneframeLogger("Previous Version is : " +previousVersion);
				}

			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Version Value is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Ist Dropdown is Display")
	public void verifyCB1stDropdownDisplay() {
		try {
			WaitForObject(btnDropDowns.get(0));
			if (btnDropDowns.get(0).isDisplayed()) {
				OneframeLogger("Client Id Dropdown is displayed");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Client Id Dropdown is not displayed");
		}
	}

	@Step("Click on 1stDropdown ")
	public void clickCBClientIdDropdown() {
		try {
			if (ObjectExist(btnDropDowns.get(0))) {
				ClickWebObject(btnDropDowns.get(0));
				WaitForApplicationToLoadCompletely();
				OneframeLogger(" Client Id Dropdown is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Client Id Dropdown is not clicked");
		}
	}

	@Step("Click on 2ndDropdown ")
	public void clickCBLOBIdDropdown() {
		try {
			if (ObjectExist(btnDropDowns.get(1))) {
				ClickWebObject(btnDropDowns.get(1));
				WaitForApplicationToLoadCompletely();
				OneframeLogger(" LOB Dropdown is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("LOB Dropdown is not clicked");
		}
	}

	@Step("Click on 4th Dropdown ")
	public void clickCBMandatesDropdown() {
		try {
			if (ObjectExist(btnDropDowns.get(3))) {
				ClickWebObject(btnDropDowns.get(3));
				WaitForApplicationToLoadCompletely();
				OneframeLogger(" Mandates Dropdown is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Mandates Dropdown is not clicked");
		}
	}

	@Step("Click on 3rd Dropdown ")
	public void clickCBStateIdDropdown() {
		try {
			if (ObjectExist(btnDropDowns.get(2))) {
				ClickWebObject(btnDropDowns.get(2));
				WaitForApplicationToLoadCompletely();
				OneframeLogger(" State Id Dropdown is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("State Id Dropdown is not clicked");
		}
	}

	// mat-select[@data-automation-id='benefitsFilterLob']/div/div/span
	@Step("Select Client id Value in Ist drop down")
	public void selectClientId(String ClientId) {
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(0))) {
				ClickWebObject(btnDropDowns.get(0));
				for (int i = 0; i < btnCBClientId.size(); i++) {
					if (btnCBClientId.get(i).getText().equalsIgnoreCase(ClientId)) {
						WebElement clientId = btnCBClientId.get(i);
						WaitForObjectVisibility(clientId);
						ClickWebObject(clientId);
						OneframeLogger("Selected value from Dropdown is :" + clientId.getText());
//					SelectDropDownListByValue(clientId, ClientId);
					}
				}
			}
		} catch (StaleElementReferenceException toException) {
			OneframeLogger("The Given Value has not been Selected from Client ID dropdown");
		}
	}

	@Step("Select Client dropdown Value")
	public boolean selectClientDropdown(String ClientId) throws AWTException {
		boolean bln = false;
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(0))) {
				ClickWebObject(btnDropDowns.get(0));
				WebElement clientId = btnCBClientId.get(4);
				WaitForObjectVisibility(clientId);
				SelectDropDownListByValue(clientId, ClientId);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				bln = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from Client ID dropdown");
		}
		return bln;
	}

	@Step("Select Lob id Value in 2nd drop down")
	public void selectLOBId(String LOBId) throws AWTException {
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(1))) {
				ClickWebObject(btnDropDowns.get(1));
				for (int i = 0; i < btnCBLOBId.size(); i++) {
					if (btnCBLOBId.get(i).getText().equalsIgnoreCase(LOBId)) {
						WebElement lobId = btnCBLOBId.get(i);
						WaitForObjectVisibility(lobId);
						ClickWebObject(lobId);
						OneframeLogger("Selected value from Dropdown is :" + lobId.getText());
					}
				}
			}
		} catch (StaleElementReferenceException toException) {
			OneframeLogger("The Given Value has not been Selected from LOB dropdown");
		}
	}
	

	@Step("Select Lob drop down")
	public boolean selectLOBDropdown(String LOBId) throws AWTException {
		boolean bln = false;
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(1))) {
				ClickWebObject(btnDropDowns.get(1));
				WaitForObjectVisibility(btnCBLOBId.get(1));
				SelectDropDownListByValue(btnCBLOBId.get(1), LOBId);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				bln = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from LOB dropdown");
		}
		return bln;
	}

	@Step("Select State id Value in 3rd drop down")
	public void selectStateId(String StateId) throws AWTException {
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(2))) {
				ClickWebObject(btnDropDowns.get(2));
				for (int i = 0; i < btnCBStateId.size(); i++) {
					if (btnCBStateId.get(i).getText().equalsIgnoreCase(StateId)) {
						WebElement stateId = btnCBStateId.get(i);
						ClickWebObject(stateId);
						OneframeLogger("Selected value from Dropdown is :" + stateId.getText());
					}
				}
			}
		} catch (StaleElementReferenceException toException) {
			OneframeLogger("The Given Value has not been Selected from State Id dropdown");
		}
	}

	/*
	 * @Step("Select State drop down") public boolean selectStateDropdown(String
	 * StateId) { boolean bln = false; try { if
	 * (WaitForObjectVisibility(btnDropDowns.get(2))) {
	 * ClickWebObject(btnDropDowns.get(2)); WebElement drdValue = null;
	 * for(WebElement ele: btnCBStateId) {
	 * if(ele.getText().equalsIgnoreCase(StateId)) { drdValue = ele; break; } }
	 * WaitForObjectVisibility(drdValue); SelectDropDownListByValue(drdValue,
	 * StateId); bln = true; } } catch (NoSuchElementException toException) {
	 * OneframeLogger("The Given Value has not been Selected from State Id dropdown"
	 * ); } return bln; }
	 */

	@Step("Select State drop down")
	public boolean selectStateDropdown(String StateId) throws AWTException {
		boolean bln = false;
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(2))) {
				ClickWebObject(btnDropDowns.get(2));
				WaitForObjectVisibility(btnCBStateId.get(5));
				SelectDropDownListByValue(btnCBStateId.get(5), StateId);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				bln = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from State Id dropdown");
		}
		return bln;
	}

	
	@Step("Select Mandates Value in 4th drop down")
	public void selectMandates(String Mandates) {
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(3))) {
				ClickWebObject(btnDropDowns.get(3));
				WaitForObjectVisibility(btnCBMandates.get(0));
				SelectDropDownListByValue(btnCBMandates.get(0), Mandates);
//				OneframeLogger("Selected value from Dropdown is :" +btnCBMandates.get(0).getText() );
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from Mandates dropdown");
		}
	}
	
	@Step("Select Mandates Dropdown For Dynamic Layer")
	public boolean selectMandatesDropdownForDynamicLayer() {
		boolean bln = false;
		try {
			WaitForApplicationToLoadCompletely();
			if (WaitForObjectVisibility(drdMandate)) {
				ClickWebObject(drdMandate);
				String value = firstDropdownOption.get(0).getText();
				ClickWebObject(firstDropdownOption.get(0));
				OneframeLogger("Mandate dropdown selected:" + value);
				// clickOverlayElement();
				bln = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from Mandates dropdown");
		}
		return bln;
	}
	/*	
	@Step("Select Mandates Dropdown For Dynamic Layer")
	public boolean selectMandatesDropdownForDynamicLayer() {
		boolean bln = false;
		try {
			WaitForApplicationToLoadCompletely();
			if (WaitForObjectVisibility(drdAutoApply.get(9))) {
				ClickWebObject(drdAutoApply.get(9));
				String value = firstDropdownOption.get(0).getText();
				ClickWebObject(firstDropdownOption.get(0));
				OneframeLogger("Mandate dropdown selected:" + value);
				// clickOverlayElement();
				bln = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from Mandates dropdown");
		}
		return bln;
	}
*/
	@Step("Click Create Button")
	public boolean ClickCBCreateButton() throws InterruptedException {
		boolean blnRC = false;
		try {
			WaitForObjectVisibility(btnCBCreate);
			if (WaitForObjectVisibility(hdrBenefitHeader)) {
				ClickWebObject(hdrBenefitHeader);
				ClickWebObject(hdrBenefitHeader);
				ClickWebObject(hdrBenefitHeader);
				WaitForObjectToBeClickable(btnCBCreate);
				ClickWebObject(btnCBCreate);
//				ClickWebObject(btnCBCreate);
				OneframeLogger("Create button is clicked");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Create button is not clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Cancel Button")
	public void ClickCBCancelButton() {
		WaitForApplicationToLoadCompletely();
		if (ObjectExist(btnCBCancel)) {
			ClickWebObject(btnCBCancel);
			OneframeLogger("Cancel button is Clicked");
		}
	}

	@Step("Verify the Verify Button for the Created Benefitis displayed")
	public boolean CheckVerifyButtonisDisplayed() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		if (WaitForObject(btnVerifyForCreatedBenefit)) {
			OneframeLogger("Verify Button is Displayed");
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Verify the Verify Button for the Created Benefitis disabled")
	public boolean CheckVerifyButtonStatus() throws InterruptedException {
		boolean blnRC = false;
		ScrollWebPageByPixel(-100);
		WaitForObjectVisibility(btnVerifyForCreatedBenefit);
		highlightElement(btnVerifyForCreatedBenefit);
		if (btnVerifyForCreatedBenefit.isEnabled()) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Verify Button for the Created Benefit")
	public Boolean ClickVerifyButtonforCreatedBenefit() throws InterruptedException {
		boolean blnRC = false;
		try {
			if (ObjectExist(btnVerifyForCreatedBenefit)) {
				ClickWebObject(btnVerifyForCreatedBenefit);
				OneframeLogger("Verify Button  is Clicked");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Verify Button is not Clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify the Close Button is displayed")
	public boolean CheckCloseButtonisDisplayed() throws InterruptedException {
		boolean blnRC = false;
		try {
			if (WaitForObject(btnWFEClose)) {
				OneframeLogger("Close Button is Displayed");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Close Button is Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step(" Click the Close Button")
	public boolean ClickWFECloseButton() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(btnWFEClose)) {
				ClickWebObject(btnWFEClose);
				OneframeLogger("Close Button  is Clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Close Button is not Clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step(" Click the Close Button")
	public boolean ClickCloseButton() {
		boolean flg = false;
		
		try {
			WaitForApplicationToLoadCompletely();
			if (ObjectExist(btnWFEClose)) {
				ClickWebObject(btnWFEClose);
				OneframeLogger("Close Button  is Clicked");
				flg = true;
			}
		} catch (Exception e) {
			OneframeLogger("Close Button  is not Clicked");
			OneframeLogger(e.toString());
		}
		
		return flg;
	}

	@Step("Verify the Save Button is displayed")
	public boolean CheckSaveButtonisDisplayed() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (WaitForObject(btnSave)) {
				OneframeLogger("Save Button is Displayed");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Save Button is not Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify the Verify Button for the Created Benefitis disabled")
	public boolean CheckSaveButtonStatus() throws InterruptedException {
		boolean blnRC = false;
		ScrollWebPageByPixel(-100);
		WaitForObjectVisibility(btnSave);
		highlightElement(btnSave);
		if (btnSave.isEnabled()) {
			blnRC = true;
		} else {
			blnRC = false;
		}
		return blnRC;
	}

	@Step(" Click the Save Button")
	public void ClickSaveButton() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		if (ObjectExist(btnSave)) {
			ClickWebObject(btnSave);
			OneframeLogger("Save Button  is Clicked");
			WaitForApplicationToLoadCompletely();
			Thread.sleep(5000);
		} else {
			OneframeLogger("Save Button is not Clicked");
		}
	}

	@Step("Verify Saved message when benefit is saved")
	public boolean verifySavedMessage() {
		boolean bln = false;
		if (ObjectExist(txtSaveMessage)) {
			txtSaveMessage.isDisplayed();
			bln = true;
		}
		return bln;
	}

	@Step(" Click the Cancel Button")
	public void ClickCancel1Button() {
		WaitForApplicationToLoadCompletely();
		if (ObjectExist(btnCancel1)) {
			ClickWebObject(btnCancel1);

			OneframeLogger("Cancel Button  is Clicked");
		} else {
			OneframeLogger("Cancel Button is not Clicked");
		}
	}

	@Step("Verify the Submit For CLient Approval Button is displayed")
	public boolean VerifySubmiforCLientApprovalButtonisDisplayed() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (WaitForObject(btnSubmitForClientApproval)) {
				OneframeLogger("Save Button is Displayed");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Submit For Client Approval Button is not Clicked");
			blnRC = false;
		}

		return blnRC;
	}

	@Step("Click the Submit For Client Approval Button")
	public boolean ClickSubmiforCLientApprovalButton() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(btnSubmitForClientApproval);
		try {
			if (ObjectExist(btnSubmitForClientApproval)) {
				ClickWebObject(btnSubmitForClientApproval);
//				ClickWebObject(btnSubmitForClientApproval);
				OneframeLogger("Submit For Client Approval Button is Clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Submit For Client Approval Button is not Clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step(" Click the Edit Button")
	public boolean ClickEditButtoninWFE() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			Thread.sleep(5000);
			if (ObjectExist(btnEdit)) {
				ClickWebObject(btnEdit);
				WaitForApplicationToLoadCompletely();
				Thread.sleep(10000);
				OneframeLogger("Edit Button  is Clicked");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Edit Button is not Clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Enter Effective date")
	public void EnterCBEffectiveDate(String EffectiveDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtEffectiveDate)) {
				ClickWebObject(txtEffectiveDate);
				EnterText(txtEffectiveDate, EffectiveDate);
				OneframeLogger("Effective Date has been Entered : " + txtEffectiveDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Effective Date has been Entered");
		}
	}

	public String verifyEffectiveDate() {
		LocalDate effDate = LocalDate.now();
		String EffectiveDate = effDate.toString();
		return EffectiveDate;
	}

	@Step("Enter Current Date as Effective date")
	public void EnterCurrentEffectiveDate() throws ParseException, AWTException {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtEffectiveDate)) {
				ClickWebObject(txtEffectiveDate);
				String EffectiveDate = verifyEffectiveDate();
				DateFormat userDateFormat = new SimpleDateFormat("yyyy-mm-dd");
				DateFormat dateFormatNeeded = new SimpleDateFormat("mm/dd/yyyy");
				Date date = userDateFormat.parse(EffectiveDate);
				String convertedDate = dateFormatNeeded.format(date);

				EnterText(txtEffectiveDate, convertedDate);
				OneframeLogger(
						"Current Date as Effective Date has been Entered : " + txtEffectiveDate.getAttribute("value"));
				
			}
		} catch (TimeoutException e) {
			OneframeLogger("Current Effective Date has been Entered");
		}
	}

	@Step("Enter New Benefit Id")
	public String EnterCBNewBenefitId() throws InterruptedException {
		String NewBenefitId = null;
		try {
			if (ObjectExist(txtEnterBenefitId)) {
				ClickWebObject(txtEnterBenefitId);
//				EnterText(txtEnterBenefitId, NewBenefitId);
				String type = "AUTOSMK";
				int randomNumber = getRandomNumber();
				NewBenefitId = type + randomNumber;
				txtEnterBenefitId.sendKeys(NewBenefitId);
				txtEnterBenefitId.sendKeys(Keys.CONTROL + "a");
				txtEnterBenefitId.sendKeys(Keys.DELETE);
//				txtEnterBenefitId.clear();
				txtEnterBenefitId.sendKeys(NewBenefitId);
				txtEnterBenefitId.sendKeys(Keys.CONTROL + "a");
				txtEnterBenefitId.sendKeys(Keys.DELETE);

				txtEnterBenefitId.sendKeys(NewBenefitId);
				txtEnterBenefitId.sendKeys(Keys.CONTROL + "a");
				txtEnterBenefitId.sendKeys(Keys.DELETE);
				txtEnterBenefitId.sendKeys(NewBenefitId);
				OneframeLogger("New Benefit Id has been Entered");
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("New Benefit Id has not been Entered");
		}
		return NewBenefitId;
	}

	@Step("Enter New Benefit Id")
	public String EnterNewBenefitId() throws InterruptedException {
		String NewBenefitId = null;
		try {
			ObjectExist(txtEnterBenefitId);
			ClickWebObject(txtEnterBenefitId);
			String type = "BEN";
			int randomNumber = getRandomNumber();
			NewBenefitId = type + randomNumber;
			txtEnterBenefitId.sendKeys(NewBenefitId);
			clickBenefitHeader();
			OneframeLogger("New Benefit Id has been Entered");

		} catch (NoSuchElementException toException) {
			OneframeLogger("New Benefit Id has not been Entered");
		}
		return NewBenefitId;
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Verify Close popup Header displayed")
	public boolean VerifyCLosePopUpHeaderDisplayed() throws InterruptedException {
		boolean blnRC = false;
		try {
			WaitForApplicationToLoadCompletely();
			if (WaitForObject(hdrLeavewithoutSaving)) {
				OneframeLogger("LeavewithoutSaving Header is Displayed");
			}
			blnRC = true;
		} catch (NoSuchElementException toException) {
			OneframeLogger("LeavewithoutSaving Header is Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Exit Without Saving Button is displayed")
	public boolean VerifyExitWithoutSavingButtonDisplayed() throws InterruptedException {
		boolean blnRC = false;
		try {
			WaitForApplicationToLoadCompletely();
			if (WaitForObject(btnExitWithoutSaving)) {
				highlightElement(btnExitWithoutSaving);
				OneframeLogger("ExitwithoutSaving Button is Displayed");
			}
			blnRC = true;
		} catch (NoSuchElementException toException) {
			OneframeLogger("ExitwithoutSaving Button is Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step(" Click the Exit Without Saving Button")
	public boolean ClickWFEExitwithoutSavingButton() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(btnExitWithoutSaving)) {
				ClickWebObject(btnExitWithoutSaving);
				OneframeLogger("ExitWithoutSaving Button  is Clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("ExitWithoutSaving is not Clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Exit and Save Button is displayed")
	public boolean VerifyExitAndSaveButtonDisplayed() throws InterruptedException {
		boolean blnRC = false;
		try {
			WaitForApplicationToLoadCompletely();
			if (WaitForObject(btnExitAndSave)) {
				highlightElement(btnExitAndSave);
				OneframeLogger("Exit&Save Button is Displayed");
			}
			blnRC = true;
		} catch (NoSuchElementException toException) {
			OneframeLogger("Exit&Save Button is Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step(" Click the Exit & Save Button")
	public boolean ClickWFEExitAndSaveButton() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(btnExitAndSave)) {
				ClickWebObject(btnExitAndSave);
				OneframeLogger("Exit&Save Button  is Clicked");
				Thread.sleep(5000);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Exit&Save is not Clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify text Benefit was saved")
	public boolean verifyTextBenefitWasSaved() {
		boolean flag = false;
		if (ObjectExist(txtWasSaved)) {
			highlightElement(txtWasSaved);
			txtWasSaved.isDisplayed();
			flag = true;
		}
		return flag;
	}

	@Step("Verify Auto Apply Dropdown is displayed")
	public boolean verifyAutoApplyDropdown() {
		ScrollWebPageByPixel(100);
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply.get(0))) {
				highlightElement(drdAutoApply.get(0));
				blnRC = true;
			}
		} catch (TimeoutException e) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value = dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
		return value;
	}

	@Step("Select Benefit Auto Apply Dropdown as Yes")
	public String selectBenefitAutoApplyDropdown(String autoApply) {
		ScrollWebPageByPixel(100);
		String dropDown = null;
		WaitForObjectVisibility(selAutoApply);
		try {
			if (WaitForObject(selAutoApply)) {
				ClickWebObject(drdAutoApply.get(0));
				dropDown = selectDropdownValues(autoApply);
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select Benefit Autoapply dropdown ");
		}
		return dropDown;
	}

	@Step("Select Business Entity Dropdown")
	public boolean selectBusinessEntityDropdown(String BusinessEntity) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdAutoApply.get(1))) {
				ClickWebObject(drdAutoApply.get(1));
				selectDropdownValue(BusinessEntity);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Entity dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(overlayElement);
	}

	@Step("Click on Mandates Setup header")
	public void clickMandatesSetupHeader() {
		ClickWebObject(hdrMandatesSetup);
		ClickWebObject(hdrMandatesSetup);
		OneframeLogger("Clicked on Mandates Setup header");
	}

	@Step("Select Business Unit Dropdown")
	public boolean selectBusinessUnitDropdown(String BusinessUnit) throws AWTException {
		boolean blnRC = false;
		try {
			if (ObjectExist(drdAutoApply.get(2))) {
				ClickWebObject(drdAutoApply.get(2));
				selectDropdownValue(BusinessUnit);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Business Unit dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select CDHP Type Dropdown")
	public boolean selectCDHPTypeDropdown(String CDHP) throws AWTException {
		boolean blnRC = false;
		try {
			if (ObjectExist(drdAutoApply.get(3))) {
				ClickWebObject(drdAutoApply.get(3));
				selectDropdownValue(CDHP);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select CDHP type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Formulary Dropdown")
	public boolean selectFormularyDropdown(String formulary) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply.get(4))) {
				ClickWebObject(drdAutoApply.get(4));
				selectDropdownValue(formulary);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Formulary dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Funding Type Dropdown")
	public boolean selectFundingTypeDropdown(String FundingType) throws AWTException {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply.get(5))) {
				ClickWebObject(drdAutoApply.get(5));
				selectDropdownValue(FundingType);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select Funding Type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Market Segment Dropdown")
	public boolean selectMarketSegmentDropdown(String MarketSegment) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply.get(6))) {
				ClickWebObject(drdAutoApply.get(6));
				selectDropdownValue(MarketSegment);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException | AWTException e) {
			OneframeLogger("Unable to select Market Segment dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Product Type Dropdown")
	public boolean selectProductTypeDropdown(String ProductType) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply.get(7))) {
				ClickWebObject(drdAutoApply.get(7));
				selectDropdownValue(ProductType);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException | AWTException e) {
			OneframeLogger("Unable to select Product type dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select Other Dropdown")
	public boolean selectOtherDropdown(String Other) {
		boolean blnRC = false;
		try {
			if (WaitForObject(drdAutoApply.get(8))) {
				ClickWebObject(drdAutoApply.get(8));
				selectDropdownValue(Other);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				blnRC = true;
			}
		} catch (TimeoutException | AWTException e) {
			OneframeLogger("Unable to select Others dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Mandate Tab in Benefit Page")
	public void clickMandatesTab() {
		WaitForObject(btnMandateTab);
		ClickWebObject(btnMandateTab);
		OneframeLogger("Clicked on Mandates Tab in Benefit Page");
	}

	@Step("Click on State Tab in Benefit Page")
	public void clickStateTab() {
		WaitForObject(btnStateTab);
		ClickWebObject(btnStateTab);
		OneframeLogger("Clicked on State Tab in Benefit Page");
	}

	@Step("Verify  Mandate Tab is Displayed When Auto Apply is 'Yes'")
	public boolean verifyMandateIsDisplayedWhenAutoApplyIsYes() {
		boolean bln = false;
		for (int i = 0; i < federalMandateAutoApplied.size(); i++) {
			if (WaitForObject(federalMandateAutoApplied.get(i))) {
				highlightElement(federalMandateAutoApplied.get(i));
				federalMandateAutoApplied.get(i).isDisplayed();
				bln = true;
			}
		}
		return bln;
	}

	@Step("Get Mandate Name is Displayed from  Mandate Tab When Auto Apply is 'Yes'")
	public List<String> getMandateNameIsDisplayedWhenAutoApplyIsYes() {
		List<String> ls = new ArrayList<String>();
		for (int i = 0; i < federalMandateAutoApplied.size(); i++) {
			if (WaitForObject(federalMandateAutoApplied.get(i))) {
				highlightElement(federalMandateAutoApplied.get(i));
				federalMandateAutoApplied.get(i).isDisplayed();
				ls.add(federalMandateAutoApplied.get(i).getText());
				OneframeLogger("Federal Mandate present by default when AutoApply is given as 'Yes' : " + ls);
			}
		}
		return ls;
	}

	@Step("Verify  Mandate Tab is Not Displayed When Auto Apply is 'No'")
	public boolean verifyMandateIsNotDisplayedWhenAutoApplyIsNo() {
		if (FindObjectByLocatorNoWait(
				By.xpath("//div[@class=\"mat-list-item-content mat-list-item-content-reverse\"]")) != null) {
			return true;
		} else {
			return false;
		}
	}

	@Step("Click on Add Mandate in Mandates tab")
	public void clickAddMandateButton() {
		WaitForObject(btnAddMandate);
		ClickWebObject(btnAddMandate);
		OneframeLogger("Clicked on Add Mandate in Mandates Tab");
	}

	@Step("Verify Add A Mandate header is Displayed")
	public boolean verifyAddAMandateHeader() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrAddAMandate);
		try {
			if (hdrAddAMandate.getText().equalsIgnoreCase("Add a Mandate")) {
				clickAddAMandateHeader();
				OneframeLogger("Add a Mandate Header is displayed");
				blnRC = true;
			}

		} catch (NoSuchElementException toException) {
			OneframeLogger(" Add a Mandate Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click header Add a Mandate")
	public void clickAddAMandateHeader() {
		ClickWebObject(hdrAddAMandate);
		ClickWebObject(hdrAddAMandate);
		ClickWebObject(hdrAddAMandate);
	}

	@Step("Click and Get first Mandate in Add A Mandate")
	public String clickAndGetFirstMandate() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < 2; i++) {
			try {
				WaitForObject(lstAddAMandate.get(0));
				ClickWebObject(lstAddAMandate.get(0));
				OneframeLogger("Clicked on Add Mandate in Mandates Tab");
			} catch (StaleElementReferenceException exc) {
				OneframeLogger("Unable to click Mandate");
			}
		}
		return lstAddAMandate.get(0).getText();
	}

	@Step("Click a Mandate from Add A Mandate list")
	public String clickAMandateFromList(List<String> mandateName) {
		String mandate = null;
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		outer: for (int i = 0; i < lstAddAMandate.size(); i++) {
			try {
				if (!lstAddAMandate.get(i).getText().equalsIgnoreCase(mandateName.get(i))) {
					WaitForObject(lstAddAMandate.get(i));
					ClickWebObject(lstAddAMandate.get(i));
					OneframeLogger("Clicked on Add Mandate in Mandates Tab");
					mandate = lstAddAMandate.get(i).getText();
					OneframeLogger("Federal Mandate added from Add A Mandate list is : " + mandate);
					break outer;
				}
			} catch (StaleElementReferenceException exc) {
				OneframeLogger("Unable to click Mandate");
			}
		}
		return mandate;

	}

	@Step("Click on Add to Benefit in Add A Mandate")
	public void clickAddToMandateButton() {
		WaitForObject(btnAddToBenefit);
		ClickWebObject(btnAddToBenefit);
		OneframeLogger("Clicked on Add to Benefit in Add A Mandate");
	}

	@Step("Verify Mandate is added in Mandates Tab")
	public boolean verifyMandateIsAddedInMandatesTab(String mandate) {
		boolean bln = false;
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < federalMandateAutoApplied.size(); i++) {
			if (federalMandateAutoApplied.get(i).getText().equalsIgnoreCase(mandate)) {
				highlightElement(federalMandateAutoApplied.get(i));
				bln = true;
			} else {
				continue;
			}
		}
		return bln;
	}

	@Step("Click Request Benefit ID button and Fetch New Benefit ID")
	public String clickRequestBenefitIDButtonGetBenefitID() {
		String NewBenefitId = null;
		try {
			if (WaitForObject(btnRequestBenefitID)) {
				ClickWebObject(btnRequestBenefitID);
				OneframeLogger("Clicked on Request Benefit ID button");
				WaitForObjectVisibility(txtEnterBenefitId);
				clickBenefitHeader();
				clickBenefitHeader();
				//ClickWebObject(btnRequestBenefitID);
				OneframeLogger("Clicked on Request Benefit ID button");
				NewBenefitId = txtEnterBenefitId.getAttribute("value");
				OneframeLogger("The Newly Created Benefif ID is:" + NewBenefitId);
				clickBenefitHeader();
				clickBenefitHeader();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Request Benefit ID button is not Clicked");
		}
		return NewBenefitId;
	}

	@Step("Click on existed Benefit")
	public void clickExistBenefit() throws InterruptedException {
		// Thread.sleep(4000);
		ClickWebObject(txtBenefitCode);
		ClickWebObject(txtBenefitCode);
		WaitForObject(selectBenefit.get(0));
		ClickWebObject(selectBenefit.get(0));
		OneframeLogger("Clicked on existing Benefit");
	}

	@Step("Verify Filter By Text")
	public void verifyFilterByTxt() {
		WaitForObject(txtFilterBy);
		ClickWebObject(txtFilterBy);
	}

	@Step("Select Mandates Dropdown For Opt-In")
	public boolean selectMandatesDropdownForptIn() {
		boolean bln = false;
		try {
			if (WaitForObjectVisibility(drdAutoApply.get(9))) {
				ClickWebObject(drdAutoApply.get(9));
				String value = firstDropdownOption.get(1).getText();
				ClickWebObject(firstDropdownOption.get(1));
				OneframeLogger("Mandate dropdown selected:" + value);
				// clickOverlayElement();
				bln = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from Mandates dropdown");
		}
		return bln;
	}

	@Step("Click on Optout button")
	public void clickOptoutBtn() {
		WaitForObject(btnOptout);
		ClickWebObject(btnOptout);
		OneframeLogger("Clicked on Optout Button");
	}

	@Step("Click on Optout button in popup")
	public void clickPopupOptoutBtn() {
		WaitForObject(btnPopupOptout);
		ClickWebObject(btnPopupOptout);
		OneframeLogger("Clicked on Popup Optout Button");
	}

	@Step("Verify Header AutoApplyNoOne (Out) is displayed")
	public boolean VerifyAutoApplyOutHdr() throws InterruptedException {
		boolean blnRC = false;
		try {
			// WaitForApplicationToLoadCompletely();
			if (WaitForObject(hdrAutoApplyOut)) {
				highlightElement(hdrAutoApplyOut);
				OneframeLogger("AutoApplyNoOne (Out) Header is Displayed");
			}
			blnRC = true;
		} catch (NoSuchElementException toException) {
			OneframeLogger("AutoApplyNoOne (Out) Header is not Displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Benefit header in Benefit Details page")
	public void clickBenefitHeaderInDetailsPage() {
		WaitForApplicationToLoadCompletely();
		WaitForObject(hdrCreatedBenefitHeader);
		hdrCreatedBenefitHeader.click();
		hdrCreatedBenefitHeader.click();
		hdrCreatedBenefitHeader.click();
		hdrCreatedBenefitHeader.click();
	}

	@Step("Click version status")
	public void clickVersionStatus() {
		WaitForObjectVisibility(hdrVerStatus);
		hdrVerStatus.click();
		hdrVerStatus.click();
		hdrVerStatus.click();
		hdrVerStatus.click();
		hdrVerStatus.click();
	}

	@Step("Verify Version Status is Displayed")
	public boolean verifyVersionStatusOfBen(String versionStatus) throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrVerStatus);
		try {
			if (hdrVerStatus.getText().equalsIgnoreCase(versionStatus)) {
				ClickWebObject(hdrVerStatus);
				OneframeLogger("The Version Status is " + hdrVerStatus.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Version Status is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	public void saveBenefitsToExcelSheet(String benefit, String clientId) {
		int numberOfRows = 0;
		ExcelFile xlFile = new ExcelFile("TestData", "InputForBulkUpdat.xlsx");
		try {
			numberOfRows = 0;
			xlFile.OpenWorkBook().OpenWorkSheet("Sheet1")
				.WriteToCell(numberOfRows + 1, 1, benefit)
				.WriteToCell(numberOfRows + 1, 2, clientId);
			xlFile.CloseExcelFile();
		}
		catch (EmptyFileException e) {
			OneframeLogger("Input file is empty, adding first row");
			xlFile.OpenWorkBook().OpenWorkSheet("Sheet1")
				.WriteToCell(1, 1, benefit)
				.WriteToCell(1, 2, clientId);
			xlFile.CloseExcelFile();
		}
		
		
		
	}

	public boolean verifyDuplicateBenefitHeader() {
		boolean flg = false;
		
		WaitForObjectVisibility(hdrDuplicateBenefit);
		
		if(hdrDuplicateBenefit.getText().equalsIgnoreCase("duplicate a benefit")) {
			flg = true;
			highlightElement(hdrDuplicateBenefit);
			OneframeLogger("Duplicate a Benefit header is displayed");
		}
		else {
			flg = false;
			OneframeLogger("Duplicate a Benefit header is not displayed");
		}
		
		return flg;
	}

	@Step("Get Benefit Version")
	public String getVersion() {
		String curVersion = null;
		
		try {
			if(WaitForObjectVisibility(hdrVersionValue)) {
				curVersion = hdrVersionValue.getText().trim();
				OneframeLogger("Current Version Value is: " +curVersion);
			}
		} catch (Exception e) {
			OneframeLogger("Unable to get current version value : " +e);
		}
		
		return curVersion;
	}

	public void removeAndEnterBenefit(String benefitID) {
		
		try {
			txtEnterBenefitId.click();
			txtEnterBenefitId.sendKeys(Keys.CONTROL + "a");
			txtEnterBenefitId.sendKeys(Keys.DELETE);
			
			OneframeLogger("Cleared Benefit ID");
			EnterText(txtEnterBenefitId, benefitID);
			OneframeLogger("Entered benefit ID");
		} catch (Exception e) {
			OneframeErrorLogger("Error while entering beneift id");
			OneframeErrorLogger(e.toString());
		}
		
	}

	@Step("Verify Version Value")
	public boolean verifyVersionValue(String versionVal) throws InterruptedException {
		boolean blnRC = false;
		double previousVersion = Double.parseDouble(versionVal);
		WaitForObjectVisibility(hdrVersionValue);
		try {
			if (WaitForObject(hdrVersionValue)) {
				double currentVersion = Double.parseDouble(hdrVersionValue.getText().trim());
				if (currentVersion == previousVersion) {
					OneframeLogger("Actual Version is : " +currentVersion);
					OneframeLogger("Expected Version is : " +previousVersion);
					blnRC = true;
				}
				else {
					blnRC = false;
					OneframeLogger("Version values did not match");
					
				}

			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Version Value is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

			
	@Step("Click on Formulary tab ")
public boolean clickOnFormularytab() throws InterruptedException {
	boolean blnRC = false;
	JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
	js.executeScript("arguments[0].scrollIntoView();",formularytab);


	WaitForObjectVisibility(formularytab);
	try {
	if	(ObjectExist(formularytab)) {
			ClickWebObject(formularytab);
			WaitForApplicationToLoadCompletely();
			OneframeLogger("formulary tab  is Clicked");
			blnRC = true;
		} 
	}catch (TimeoutException e) {
			OneframeLogger("formulary tab is not Clicked");
			blnRC = false;
	}
			return blnRC;
	}
	
	@Step("Click on PosDurPackage tab")
public boolean clickOnPosDurPackagestab() throws InterruptedException {
	boolean blnRC = false;

	WaitForObjectVisibility(posDurPackagetab);
	try {
	if	(ObjectExist(posDurPackagetab)) {
			ClickWebObject(posDurPackagetab);
			WaitForApplicationToLoadCompletely();
			OneframeLogger("posDurPackage tab  is Clicked");
			blnRC = true;
		} 
	}catch (TimeoutException e) {
			OneframeLogger("PosDurPackage tab is not Clicked");
			blnRC = false;
	}
			return blnRC;
	}
	@Step("Click on eye button")
	public boolean clickOneyetab() throws InterruptedException {
		boolean blnRC = false;

		WaitForObjectVisibility(eyebtn);
		try {
		if	(ObjectExist(eyebtn)) {
				ClickWebObject(eyebtn);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("eyebtn is Clicked");
				blnRC = true;
			} 
		}catch (TimeoutException e) {
				OneframeLogger("eyebtn is not Clicked");
				blnRC = false;
		}
				return blnRC;
		}

	
	@Step("Verify Details text is Displayed")
	public boolean verifyDetailsHeader() throws InterruptedException {
		boolean blnRC = false;
		WaitForObjectVisibility(headerDetails);
		try {
			if (WaitForObject(headerDetails)) {
				ClickWebObject(headerDetails);
				OneframeLogger(" Details Header is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger(" Details Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Verify the Dynamic text is displayed")
	public boolean verifyDynamicHeader() throws InterruptedException {
		boolean blnRC = false;
	//	ScrollWebPageByPixel(-100);
	if	(WaitForObjectVisibility(dynamicLayerHeader)) {
		highlightElement(dynamicLayerHeader);
		blnRC =true;
			
	}
	
	else{
		
		blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Verify  Auto Apply dropdown is disabled")
	public void verifyAutoApplyDropdownIsDisabled() throws InterruptedException {
	
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(0));
		highlightElement(dropDownsforDisabledInPosDur.get(0));
		String attributetext=dropDownsforDisabledInPosDur.get(0).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(0));
		if (dropDownsforDisabledInPosDur.get(0).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(0));;
			
		} 
		sa.assertEquals(attributetext, "true", "Verified Auto Apply dropdown is disabled");
		sa.assertAll();
	}
	
	
	@Step("Verify  Bussiness Entity dropdown is disabled")
	public void verifyBussinessEntityDropdownIsDisabled() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(1));
		highlightElement(dropDownsforDisabledInPosDur.get(1));
		String attributetext=dropDownsforDisabledInPosDur.get(1).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(1));
		if (dropDownsforDisabledInPosDur.get(1).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(1));;
			
		}
		sa.assertEquals(attributetext, "true", "Verified Bussiness Entity  has disabled");
		sa.assertAll();
	}
	
	@Step("Verify  Bussiness Unit dropdown is disabled")
	public void verifyBussinessUnitDropdownIsDisabled() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(2));
		highlightElement(dropDownsforDisabledInPosDur.get(2));
		String attributetext=dropDownsforDisabledInPosDur.get(2).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(2));
		if (dropDownsforDisabledInPosDur.get(2).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(2));;
			
		}
		sa.assertEquals(attributetext, "true", "Verified Bussiness Unit  value has disabled");
		sa.assertAll();
	}
	
	@Step("Verify  CDHP Type dropdown is disabled")
	public void verifyCDHPTypeDropdownIsDisabled() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(3));
		highlightElement(dropDownsforDisabledInPosDur.get(3));
		String attributetext=dropDownsforDisabledInPosDur.get(3).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(3));
		if (dropDownsforDisabledInPosDur.get(3).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(3));;
			
		}
		sa.assertEquals(attributetext, "true", "Verified CDHP Type  value has disabled");
		sa.assertAll();
	}
	
	@Step("Verify  Formularydropdown is disabled")
	public void verifyFormularyDropdownIsDisabled() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(4));
		highlightElement(dropDownsforDisabledInPosDur.get(4));
		String attributetext=dropDownsforDisabledInPosDur.get(4).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(4));
		if (dropDownsforDisabledInPosDur.get(4).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(4));;
			
		}
		sa.assertEquals(attributetext, "true", "Verified Formulary dropdown has disabled");
		sa.assertAll();
	}
	
	@Step("Verify  Funding Type dropdown is disabled")
	public void verifyFundingTypeDropdownIsDisabled() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(5));
		highlightElement(dropDownsforDisabledInPosDur.get(5));
		String attributetext=dropDownsforDisabledInPosDur.get(5).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(5));
		if (dropDownsforDisabledInPosDur.get(5).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(5));;
			
		}
		sa.assertEquals(attributetext, "true", "Verified Funding Type  has disabled");
		sa.assertAll();
	}
	
	@Step("Verify  Market Segment dropdown is disabled")
	public void verifyMarketSegmentDropdownIsDisabled() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(6));
		highlightElement(dropDownsforDisabledInPosDur.get(6));
		String attributetext=dropDownsforDisabledInPosDur.get(6).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(6));
		if (dropDownsforDisabledInPosDur.get(6).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(6));;
			
		}
		sa.assertEquals(attributetext, "true", "Verified Market Segment  value has disabled");
		sa.assertAll();
	}
	
	@Step("Verify  Product Type dropdown is disabled")
	public void verifyProductTypeDropdownIsDisabled() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(7));
		highlightElement(dropDownsforDisabledInPosDur.get(7));
		String attributetext=dropDownsforDisabledInPosDur.get(7).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(7));
		if (dropDownsforDisabledInPosDur.get(7).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(7));;
			
		}
		sa.assertEquals(attributetext, "true", "Verified Product Type dropdown has disabled");
		sa.assertAll();
	}
	
	@Step("Verify  Others Dropdown is disabled")
	public void verifyOthersDropdownIsDisabled() throws InterruptedException {
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(8));
		highlightElement(dropDownsforDisabledInPosDur.get(8));
		String attributetext=dropDownsforDisabledInPosDur.get(8).getAttribute("aria-disabled");
		WaitForObjectVisibility(dropDownsforDisabledInPosDur.get(8));
		if (dropDownsforDisabledInPosDur.get(7).getAttribute("aria-disabled").equalsIgnoreCase("true")) {
			highlightElement(dropDownsforDisabledInPosDur.get(8));;
			
		}
		sa.assertEquals(attributetext, "true", "Verified Others Dropdown has disabled");
		sa.assertAll();
	}
	
	
	@Step("Verify Auto Apply dropdown same as given")
	public  void verifyAutoapplydropDownvalue(String AutoApply ) throws InterruptedException {
	
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(autoApplyDropDownValue);
		if (autoApplyDropDownValue.getText().equalsIgnoreCase(AutoApply)) {
			 highlightElement(autoApplyDropDownValue);	
			OneframeLogger("Auto Apply dropdown value is "+ autoApplyDropDownValue.getText());
		}
		
	        sa.assertEquals(autoApplyDropDownValue.getText(), AutoApply, "Verified Auto Apply  value is same as expected");
	        sa.assertAll();
	    }
		

	

	@Step("Verify Bussiness Entity same as given")
	public void verifyBussinessEntitydropDownvalue(String BusinessEntity) throws InterruptedException {
		
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(btnDropDowns.get(1));
		
			if (btnDropDowns.get(1).getText().equalsIgnoreCase(BusinessEntity)) {
				 highlightElement(btnDropDowns.get(1));	
				OneframeLogger("Bussiness  dropdown value is "+ btnDropDowns.get(1).getText());
				
			}

			 sa.assertEquals(btnDropDowns.get(1).getText(), BusinessEntity, "Verified BusinessEntity value is same as expected");
			 sa.assertAll();
			
		}
		
	@Step("Verify Bussiness unit dropdown same as given")
	public void verifyBussinesUnitdropDownvalue(String BusinessUnit) throws InterruptedException {
		
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(btnDropDowns.get(2));

			if (btnDropDowns.get(2).getText().equalsIgnoreCase(BusinessUnit)) {
				 highlightElement(btnDropDowns.get(2));
				OneframeLogger("Bussiness Unit  dropdown value is "+ btnDropDowns.get(2).getText());
				
			}
			 sa.assertEquals(btnDropDowns.get(2).getText(), BusinessUnit, "Verified Bussiness Unit value is same as expected");
			 sa.assertAll();
		} 
			
			
		
	@Step("Verify CDHP dropdown same as given")
	public void verifyCDHPTypevalue(String CDHP) throws InterruptedException {
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(btnDropDowns.get(3));
		
			if (btnDropDowns.get(3).getText().equalsIgnoreCase(CDHP)) {
				 highlightElement(btnDropDowns.get(3));
				OneframeLogger("CDHP  dropdown value is "+ btnDropDowns.get(3).getText());
				
			}
			 sa.assertEquals(btnDropDowns.get(3).getText(), CDHP, "Verified CDHP type value is same as expected");
			 sa.assertAll();
        	}
	
	@Step("Verify formulary dropdown same as given")
	public void verifyFormularydropDownvalue(String Formulary) throws InterruptedException {
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(btnDropDowns.get(4));
			if (btnDropDowns.get(4).getText().equalsIgnoreCase(Formulary)) {
				 highlightElement(btnDropDowns.get(4));
				OneframeLogger("formulary  dropdown value is "+ btnDropDowns.get(4).getText());
				
			}

			 sa.assertEquals(btnDropDowns.get(4).getText(), Formulary, "Verified formulary value is same as expected");
			 sa.assertAll();
			
	        }
	
	
	@Step("Verify Funding Type  dropdown same as given")
	public void verifyFundingTypedropDownvalue(String FundingType) throws InterruptedException {
		
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(btnDropDowns.get(5));
		
			if (btnDropDowns.get(5).getText().equalsIgnoreCase(FundingType)) {
				 highlightElement(btnDropDowns.get(5));
				OneframeLogger("Funding Type dropdown value is "+ btnDropDowns.get(5).getText());
				
			}
			 sa.assertEquals(btnDropDowns.get(5).getText(), FundingType, "Verified funding type is same as expected");
			 sa.assertAll();
			
		}
	
	@Step("Verify Market Segment dropdown same as given")
	public void verifyMarketSegmentdropDownvalue(String MarketSegment) throws InterruptedException {

		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(btnDropDowns.get(6));
		
			if (btnDropDowns.get(6).getText().equalsIgnoreCase(MarketSegment)) {
				 highlightElement(btnDropDowns.get(6));
				OneframeLogger("Market Segment dropdown value is "+ btnDropDowns.get(6).getText());
				
		} 		
			 sa.assertEquals(btnDropDowns.get(6).getText(), MarketSegment, "Verified MarketSegment type is same as expected");
			 sa.assertAll();
	
	}
	@Step("Verify Product Type dropdown same as given")
	public void verifyProductTypedropDownvalue(String ProductType) throws InterruptedException {
		
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(btnDropDowns.get(7));
		
			if (btnDropDowns.get(7).getText().equalsIgnoreCase(ProductType)) {
				 highlightElement(btnDropDowns.get(7));
				OneframeLogger("Product Type dropdown value is "+ btnDropDowns.get(7).getText());
				
			}
			sa.assertEquals(btnDropDowns.get(7).getText(), ProductType, "Verified ProductType type is same as expected");
			sa.assertAll();
		} 
			
			
	
	
	@Step(" click on cross button ")
	public boolean ClickOnCrossButton() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(crossBtn)) {
				ClickWebObject(crossBtn);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("cross Button  is Clicked");
				
			}
	}catch (NoSuchElementException toException) {
				OneframeLogger("cross Button is not Clicked");
				blnRC = false;
			}
	     return blnRC;
					} 
	
	
	
	@Step(" click on save button ")
	public boolean ClickOnSaveButton() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(savebtn)) {
				ClickWebObject(savebtn);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("save Button  is Clicked");
				Thread.sleep(9000);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("save Button is not Clicked");
			blnRC = false;
		}
		return blnRC;
	
	
	}
	@Step("Select value in standard step therapy  Dropdown")
	public boolean selectStandardStepTherapyModelDropdown(String steptherapyvalue)  {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].scrollIntoView();",durPagebtnDropDowns.get(0));
		WaitForObject(durPagebtnDropDowns.get(0)); 
			ClickWebObject(durPagebtnDropDowns.get(0));
			int count =btnstandardSafetyeditoptions.size();
			OneframeLogger("DropDown Options count is"+count);
			for(int i=0;i<=count-1;i++) {
	        	if(btnstandardSafetyeditoptions.get(i).getText().contains(steptherapyvalue)) {
	        		btnstandardSafetyeditoptions.get(i).click();
	        		OneframeLogger("selected value in standardsaftyedits dropdown is "+steptherapyvalue);
	        		blnRC = true;
	        		break;
	        		
	        	}
	         }
			return blnRC;
	         }
	
	
	
	
	@Step("Select value in standard safety Edits Model  Dropdown")
	public boolean selectStandardSaftyEditsModelDropdown(String saftyeditsvalue) {
	boolean blnRC = false;
	WaitForApplicationToLoadCompletely();
	WaitForObject(durPagebtnDropDowns.get(1)); 
		ClickWebObject(durPagebtnDropDowns.get(1));
		int optionscount =btnstandardSafetyeditoptions.size();
		OneframeLogger("Dropdown options count is "+optionscount);
		for(int i=0;i<=optionscount-1;i++) {
        	if(btnstandardSafetyeditoptions.get(i).getText().contains(saftyeditsvalue)) {
        		btnstandardSafetyeditoptions.get(i).click();
        		OneframeLogger("selected value in standardsaftyedits dropdown is "+saftyeditsvalue);
        		blnRC = true;
        		break;
        		
        	}
         }
		return blnRC;
         }
	
	
	@Step("Verify the Standard Step Therapy Value Same As Edited values after clicking save button")
	public void verifyStandardStepTherapyValueSameAsEdited(String steptherapyvalue) throws InterruptedException {
		
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(textValuesInPosDur.get(0));
		 highlightElement(textValuesInPosDur.get(0));
		 
		 String s=textValuesInPosDur.get(0).getText();
		 OneframeLogger(s);
			if (textValuesInPosDur.get(0).getText().equalsIgnoreCase(steptherapyvalue)) {
				OneframeLogger("Standard Step Therapy Value Same As Edited value is "+ textValuesInPosDur.get(0).getText());
				
			}
			sa.assertEquals(textValuesInPosDur.get(0).getText(), steptherapyvalue, "Verified steptherapyvalue  is same as expected");
			sa.assertAll();
		} 		
			
	
	
	
	@Step("Verify the Standard Safety Edits Module Value Same As Edited values after clicking save button")
	public void verifyStandardSafetyEditModulesValueSameAsEdited(String saftyeditsvalue) throws InterruptedException {
		WaitForApplicationToLoadCompletely();	
		WaitForObjectVisibility(textValuesInPosDur.get(1));
		 highlightElement(textValuesInPosDur.get(1));
			if (textValuesInPosDur.get(1).getText().equalsIgnoreCase(saftyeditsvalue)) {
				OneframeLogger("Standard Safety Edits Module Value Same As Edited value is "+ textValuesInPosDur.get(1).getText());
				
			}

			sa.assertEquals(textValuesInPosDur.get(1).getText(), saftyeditsvalue, "Verified saftyeditsvalue  is same as expected");
			sa.assertAll();
			
		}
		
	
	public void enterPlanID(String planId) {
		if(WaitForObjectVisibility(inputPlanId)) {
			inputPlanId.sendKeys(planId);
			inputPlanId.sendKeys(Keys.TAB);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}

	
	

			
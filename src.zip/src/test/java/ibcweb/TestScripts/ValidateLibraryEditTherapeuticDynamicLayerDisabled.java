package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibraryEditTherapeuticDynamicLayerDisabled extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesProgramsPage librariesprogramspage;	
	IBPLibrariesMandatesPage mandate;

	@BeforeClass
	@Step("Initializing Test Script for Verify if the BOB and dynamic layer categories are in disabled mode while editing a therapeutic program.")
	public void setUp() {
		InitializeLaunchPad("IBPW_717");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		mandate =  new IBPLibrariesMandatesPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Verify if the BOB and dynamic layer categories are in disabled mode while editing a therapeutic program.", dataProvider = "TestData")
	@Description("Validate Verify if the BOB and dynamic layer categories are in disabled mode while editing a therapeutic program.")
	public void ValidateLibrariesEditTherapeuticProgram(String TestCaseID, String TestStatus)throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickLibraries();
			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "The Programs Section Page is displayed");
			librariesprogramspage.clickProgramsheader();		
     		librariesprogramspage.selectLibrariesProgramsRecord();
			
			sa.assertTrue(librariesprogramspage.verifyProgramDetailsHeader(),
					"Verified 'Programs Detail header' is displayed");
			librariesprogramspage.verifyAndClickEditButton();
			sa.assertTrue(librariesprogramspage.verifyDynamicLayersDisbaled(),
					"Verified BOB and Dynamic layers are in disabled mode in Program Details Page");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if the BOB and dynamic layer categories are in disabled mode while editing a therapeutic program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Edit a Therapeutic Program");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}




}

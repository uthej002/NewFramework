package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitCostSharesPage;
import ibcweb.PageObjects.IBPBenefitDetailsPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsCostOfCare;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLibrariesSpecialtyPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateUIElementsBenefitsGeneralTab extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPBenefitDetailsPage detailsPage;
	IBPLibrariesProgramsCostOfCare costOfCareTab;

	@BeforeClass
	@Step("Initializing Test Script for Validating UI elements in Benefit -> general tab")
	public void setUp() {
		InitializeLaunchPad("IBPW_244");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		detailsPage = new IBPBenefitDetailsPage();
		costOfCareTab = new IBPLibrariesProgramsCostOfCare();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate the UI elements in Benefit -> general tab", dataProvider = "TestData")
	@Description("Validate the UI elements in Benefit -> general tab")
	public void ValidateLibrariesAddProgramAutoApply(String TestCaseID, String TestStatus, String Benefit)throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(detailsPage.clickGeneralTab(), "Clicked on General Tab");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Timely Filling"), "Verified Timely Filling heading is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("High Dollar Limit"), "Verified High Dollar Limit heading is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Veterans Administration High Dollar Limit"), "Verified Veterans Administration High Dollar Limit heading is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Paper Claims Processing"), "Verified Paper Claims Processing heading is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Follow Me Logic Applies"), "Verified Follow Me Logic Applies heading is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Foreign Claims"), "Verified Foreign Claims heading is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("Rebate Strategy"), "Verified Rebate Strategy heading is displayed");
			sa.assertTrue(costOfCareTab.validateTextIsDisplayed("URGENT"), "Verified URGENT heading is displayed");
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated if the General/Network/CostShares/Accum tabs are enabled after selecting General/Network/CostShares/Accum overrides as Yes in the form while creating a Cost of Care Program Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to create a Cost of Care Program");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

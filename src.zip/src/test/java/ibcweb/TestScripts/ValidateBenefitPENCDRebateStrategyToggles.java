package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitPENCDRebateStrategyToggles extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating Benefit Rebate Strategy and PENCD Toggle values")
	public void setUp() {
		InitializeLaunchPad("IBPW_662");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "NewBenefitId", "TimelyFilling","HDRRetail", "HDRHomeDelivery",
				"VAHDR", "ClaimsProcessingINN","ClaimsProcessingONN", "LogicValue","ForeignClaims","Percent"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Benefit Rebate Strategy and PENCD Toggle values", dataProvider = "TestData")
	@Description("Validate Benefit Rebate Strategy and PENCD Toggle values")
	public void ValidateGeneralTab(String TestCaseID, String TestStatus, String NewBenefitId,
			String TimelyFilling, String HDRRetail,String HDRHomeDelivery,String VAHDR, String ClaimsProcessingINN,String ClaimsProcessingONN, String LogicValue,String ForeignClaims,String Percent)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();	 
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitId);
			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Benefit header is displayed");
			sa.assertTrue(createbenefitpage.verifyVerStatus(), "Verified Version Status  is displayed");
			sa.assertTrue(createbenefitpage.verifyVersionValue(), "Verified Version Value is displayed");
			createbenefitpage.ClickEditButtoninWFE();			
		    sa.assertTrue(createbenefitpage.CheckVerifyButtonisDisplayed(), "Verified the Verify Button is displayed");
			sa.assertTrue(createbenefitpage.CheckCloseButtonisDisplayed(), "Verified Close Button is displayed");
			sa.assertTrue(createbenefitpage.CheckSaveButtonisDisplayed(), "Verified Save Button is displayed");
			benefitpage.clickDetailsTab();
			benefitpage.clickDetailsSubTab();	
			benefitpage.clickGeneralSubTab();
//			benefitpage.EnterTimelyFillng(TimelyFilling);
//			benefitpage.EnterHDLRetail(HDRRetail);
//			benefitpage.EnterHDLHomeDelivery(HDRHomeDelivery);
//			benefitpage.EnterVAHDLValue(VAHDR);
//			sa.assertTrue(benefitpage.selectINNDropdown(ClaimsProcessingINN), "The INN dropdown for Claims processing has been selected");
//			sa.assertTrue(benefitpage.selectONNDropdown(ClaimsProcessingONN), "The ONN dropdown for Claims processing has been selected");
//			sa.assertTrue(benefitpage.selectFollowMeDropdown(LogicValue), "The Follow me Logic Applies dropdown has been selected");
//			sa.assertTrue(benefitpage.selectForeignClaimDropdown(ForeignClaims), "The Foreign Claims dropdown has been selected");
			benefitpage.clickRebateStrategyToggle();
			benefitpage.EnterPercent(Percent);
			benefitpage.clickPENCDToggle();	
			benefitpage.clickCloseButton();
			benefitpage.clickSaveandExitButton();
			sa.assertTrue(benefitpage.verifyPercentValue(Percent), "The Actual Percent value is matched with Expected Value");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Benefit Rebate Strategy and PENCD Toggle values are entered Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to enter Validate Benefit Rebate Strategy and PENCD Toggle values");
		}
		
//		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}



}

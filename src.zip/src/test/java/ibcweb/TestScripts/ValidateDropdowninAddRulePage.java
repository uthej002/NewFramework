package ibcweb.TestScripts;



import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateDropdowninAddRulePage extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;
	IBPRuleIDPage ruleidpage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Dropdown")
	public void setUp() {
		InitializeLaunchPad("IBPW_08");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();
		ruleidpage = new IBPRuleIDPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId", "DType" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate Dropdown", dataProvider = "TestData")
	@Description("Validate Dropdown")
	public void ValidateDropdown(String TestCaseID, String TestStatus, String ClientId, String LOBId, String StateId, String DType)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();
			sa.assertTrue(addrulepage.verifyCreateaRuleHeader(),"Verified Create a Rule Header is displayed");
			sa.assertTrue(addrulepage.selectClientIdDropdown(ClientId),"Verified Client value has been selected");
			sa.assertTrue(addrulepage.selectLobIdDropdown(LOBId),"Verified LOB value has been selected");
			sa.assertTrue(addrulepage.selectStateIdDropdown(StateId),"Verified State value has been selected");
			sa.assertTrue(addrulepage.selectDecisionTypeDropdown(DType),"Verified Decision value has been selected");	
			sa.assertTrue(addrulepage.verifyAddRuleButtonisDisabled(), "Verified Add Rule Button is Disabled");
		    gTestResult = RESULT_PASS;
			OneframeLogger("Validation for dropdowns in add rule page  is successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate for dropdowns in add rule page");
		}
	sa.assertAll();

	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

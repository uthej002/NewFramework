// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class ProjectResource
{
    private List<Link> links;
    private Long id;
    private String name;
    private String description;
    private Long status_id;
    @JsonProperty("start_date")
    private String startDate;
    @JsonProperty("end_date")
    private String endDate;
    private Boolean sample;
    @JsonProperty("defect_tracking_systems")
    private List<DefectTrackingSystem> defectTrackingSystems;
    @JsonProperty("x_explorer_access_level")
    private Integer xExplorerAccessLevel;
    @JsonProperty("date_format")
    private String dateFormat;
    @JsonProperty("automation")
    private Boolean automation;
    @JsonProperty("template_id")
    private Long templateId;
    @JsonProperty("uuid")
    private String uuid;
    
    public ProjectResource() {
        this.links = new ArrayList<Link>();
        this.id = null;
        this.name = null;
        this.description = null;
        this.status_id = null;
        this.startDate = null;
        this.endDate = null;
        this.sample = false;
        this.defectTrackingSystems = new ArrayList<DefectTrackingSystem>();
        this.xExplorerAccessLevel = null;
        this.dateFormat = null;
        this.automation = false;
        this.templateId = null;
        this.uuid = null;
    }
    
    public ProjectResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public ProjectResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public ProjectResource id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public ProjectResource name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public ProjectResource description(final String description) {
        this.description = description;
        return this;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public ProjectResource statusId(final Long statusId) {
        this.status_id = statusId;
        return this;
    }
    
    public Long getstatus_id() {
        return this.status_id;
    }
    
    public void setstatus_id(final Long statusId) {
        this.status_id = statusId;
    }
    
    public ProjectResource startDate(final String startDate) {
        this.startDate = startDate;
        return this;
    }
    
    public String getStartDate() {
        return this.startDate;
    }
    
    public void setStartDate(final String startDate) {
        this.startDate = startDate;
    }
    
    public ProjectResource sample(final Boolean sample) {
        this.sample = sample;
        return this;
    }
    
    public Boolean getSample() {
        return this.sample;
    }
    
    public void setSample(final Boolean sample) {
        this.sample = sample;
    }
    
    public ProjectResource defectTrackingSystems(final List<DefectTrackingSystem> defectTrackingSystems) {
        this.defectTrackingSystems = defectTrackingSystems;
        return this;
    }
    
    public ProjectResource addDefectTrackingSystemsItem(final DefectTrackingSystem defectTrackingSystemsItem) {
        this.defectTrackingSystems.add(defectTrackingSystemsItem);
        return this;
    }
    
    public List<DefectTrackingSystem> getDefectTrackingSystems() {
        return this.defectTrackingSystems;
    }
    
    public void setDefectTrackingSystems(final List<DefectTrackingSystem> defectTrackingSystems) {
        this.defectTrackingSystems = defectTrackingSystems;
    }
    
    public ProjectResource xExplorerAccessLevel(final Integer xExplorerAccessLevel) {
        this.xExplorerAccessLevel = xExplorerAccessLevel;
        return this;
    }
    
    public Integer getXExplorerAccessLevel() {
        return this.xExplorerAccessLevel;
    }
    
    public void setXExplorerAccessLevel(final Integer xExplorerAccessLevel) {
        this.xExplorerAccessLevel = xExplorerAccessLevel;
    }
    
    public ProjectResource dateFormat(final String dateFormat) {
        this.dateFormat = dateFormat;
        return this;
    }
    
    public String getDateFormat() {
        return this.dateFormat;
    }
    
    public void setDateFormat(final String dateFormat) {
        this.dateFormat = dateFormat;
    }
    
    public Boolean getAutomation() {
        return this.automation;
    }
    
    public ProjectResource templateId(final Long templateId) {
        this.templateId = templateId;
        return this;
    }
    
    public Long getTemplateId() {
        return this.templateId;
    }
    
    public void setTemplateId(final Long templateId) {
        this.templateId = templateId;
    }
    
    public ProjectResource uuid(final String uuid) {
        this.uuid = uuid;
        return this;
    }
    
    public String getUuid() {
        return this.uuid;
    }
    
    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ProjectResource projectResource = (ProjectResource)o;
        return Objects.equals(this.links, projectResource.links) && Objects.equals(this.id, projectResource.id) && Objects.equals(this.name, projectResource.name) && Objects.equals(this.description, projectResource.description) && Objects.equals(this.status_id, projectResource.status_id) && Objects.equals(this.startDate, projectResource.startDate) && Objects.equals(this.sample, projectResource.sample) && Objects.equals(this.defectTrackingSystems, projectResource.defectTrackingSystems) && Objects.equals(this.xExplorerAccessLevel, projectResource.xExplorerAccessLevel) && Objects.equals(this.dateFormat, projectResource.dateFormat) && Objects.equals(this.automation, projectResource.automation) && Objects.equals(this.templateId, projectResource.templateId) && Objects.equals(this.uuid, projectResource.uuid);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links, this.id, this.name, this.description, this.status_id, this.startDate, this.sample, this.defectTrackingSystems, this.xExplorerAccessLevel, this.dateFormat, this.automation, this.templateId, this.uuid);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class ProjectResource {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    description: ").append(this.toIndentedString(this.description)).append("\n");
        sb.append("    statusId: ").append(this.toIndentedString(this.status_id)).append("\n");
        sb.append("    startDate: ").append(this.toIndentedString(this.startDate)).append("\n");
        sb.append("    sample: ").append(this.toIndentedString(this.sample)).append("\n");
        sb.append("    defectTrackingSystems: ").append(this.toIndentedString(this.defectTrackingSystems)).append("\n");
        sb.append("    xExplorerAccessLevel: ").append(this.toIndentedString(this.xExplorerAccessLevel)).append("\n");
        sb.append("    dateFormat: ").append(this.toIndentedString(this.dateFormat)).append("\n");
        sb.append("    automation: ").append(this.toIndentedString(this.automation)).append("\n");
        sb.append("    templateId: ").append(this.toIndentedString(this.templateId)).append("\n");
        sb.append("    uuid: ").append(this.toIndentedString(this.uuid)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

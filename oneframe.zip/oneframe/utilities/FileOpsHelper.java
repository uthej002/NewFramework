// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import java.nio.file.StandardCopyOption;
import java.nio.file.CopyOption;
import anthem.irx.oneframe.core.OneframeReporter;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.file.Path;
import java.text.DateFormat;
import java.nio.file.LinkOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import anthem.irx.oneframe.core.OneframeConstants;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Paths;
import java.io.IOException;
import anthem.irx.oneframe.core.OneframeContainer;
import java.io.File;

public class FileOpsHelper
{
    public static File createFile(final String FolderPath, final String FileName) {
        Boolean status = false;
        final File newFile = new File(FolderPath + "\\" + FileName);
        try {
            status = newFile.createNewFile();
        }
        catch (IOException ioe) {
            OneframeContainer.OneframeLogger("Error occured while creating the file" + ioe);
        }
        if (status) {
            OneframeContainer.OneframeLogger("File [" + newFile.getPath() + "] created");
        }
        else {
            OneframeContainer.OneframeLogger("File [" + newFile.getPath() + "] already exists");
        }
        return newFile;
    }
    
    public static void deleteFile(final String FolderPath, final String FileName) throws IOException {
        deleteFile(FolderPath + "/" + FileName);
    }
    
    public static void deleteFile(final String FilePathAndName) throws IOException {
        Boolean status = false;
        final File newFile = new File(FilePathAndName);
        status = newFile.delete();
        if (status) {
            OneframeContainer.OneframeLogger("[ONEFRAME] File [" + newFile.getPath() + "] deleted");
        }
        else {
            OneframeContainer.OneframeLogger("[ONEFRAME] File [" + newFile.getPath() + "] Unable to delete");
        }
    }
    
    public static void writeToFile(final String FileName, final String Content) {
        try {
            Files.write(Paths.get(FileName, new String[0]), Content.getBytes(), new OpenOption[0]);
        }
        catch (IOException e) {
            OneframeContainer.OneframeLogger(e.getMessage());
        }
    }
    
    public static boolean checkFolderExist(final String FolderPath) {
        final File file = new File(FolderPath);
        if (!file.isDirectory()) {
            OneframeContainer.OneframeLogger("Path is not directory");
        }
        return file.exists();
    }
    
    public static boolean checkFileExist(final String FilePathAndName) {
        final File file = new File(FilePathAndName);
        return file.exists();
    }
    
    public static boolean createDirectory(final String FolderPath) {
        Boolean status = false;
        final File newFolder = new File(FolderPath);
        try {
            status = newFolder.mkdir();
        }
        catch (SecurityException se) {
            OneframeContainer.OneframeLogger("Error occured while creating the folder" + se);
        }
        if (status) {
            OneframeContainer.OneframeLogger("Folder [" + newFolder.getPath() + "] created");
        }
        else {
            OneframeContainer.OneframeLogger("Folder [" + newFolder.getPath() + "] already exists");
        }
        return status;
    }
    
    public static String createTodaysLogFolder(final String ReportType) {
        final String ReportDir = OneframeConstants.TESTOUTPUT_FOLDER + ReportType + "/";
        createDirectory(ReportDir);
        String todaysLogDir = "FAILED TO CREATE DIRECTORY";
        final Date currentDate = new Date();
        try {
            final DateFormat dateFormatter = new SimpleDateFormat("MM-dd-yyyy");
            final String date = dateFormatter.format(currentDate);
            todaysLogDir = ReportDir + date;
            final Path todaysDirectoryPath = Paths.get(todaysLogDir, new String[0]);
            if (Files.exists(todaysDirectoryPath, new LinkOption[0])) {
                OneframeContainer.OneframeLogger("[ONEFRAME]Log folder already exist...");
            }
            else {
                createDirectory(todaysLogDir);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return todaysLogDir;
    }
    
    public static void createBatchFile(final String FileName) {
        final String BatchFileFolder = OneframeConstants.BATCHFILE_FOLDER;
        BufferedWriter writer = null;
        try {
            final File batchFile = new File(BatchFileFolder + "\\" + FileName);
            writer = new BufferedWriter(new FileWriter(batchFile));
            writer.write("cd %ProgramFiles(x86)%\\SOME_FOLDER \r\nstart xyz.bat \r\nexit");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                writer.close();
            }
            catch (Exception ex) {}
        }
    }
    
    public static void executeBatchFile(final String BatchFileName) {
        final String batchFile = OneframeConstants.BATCHFILE_FOLDER + "\\" + BatchFileName;
        final Runtime objRunTime = Runtime.getRuntime();
        try {
            final Process objProcess = objRunTime.exec("powershell /c start \"\" \"" + batchFile);
            OneframeContainer.OneframeLogger("Executed Batch File : " + batchFile);
            objProcess.getOutputStream().close();
        }
        catch (IOException ex) {
            OneframeContainer.OneframeLogger(ex.getMessage());
        }
    }
    
    public static void backupTestNGReports() throws IOException {
        createTodaysLogFolder("TestNG_Reports");
        final Path destinationPath = Paths.get("src/test/resources/copiedWithNio.txt", new String[0]);
        final Path originalPath = OneframeReporter.getSourcePathTestNGemailableReport().toPath();
        Files.copy(originalPath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
    }
}

package anthem.irx.oneframe.core;

import anthem.irx.oneframe.selenium.DriverType;

public class OneframeConstants {
  public static final String TEST_BED_CONFIGURATION = "TestBed.properties";
  
  public static final String SCRIPT_EXECUTION_CONFIGURATION = "ScriptExecution.properties";
  
  public static final String APPLICATION_CONFIGURATION = "Applications.properties";
  
  public static final String MOBILE_CONFIGURATION = "MobileConfig.properties";
  
  public static final String ONEFRAME_CONFIGURATION = "Oneframe.properties";
  
  public static final String QTEST_CONFIGURATION = "qTest.properties";
  
  public static final String CREDENTIAL_CONFIGURATION = "Credential.properties";
  
  public static final String PROJECT_FOLDER = System.getProperty("user.dir");
  
  public static final String RESOURCES_FOLDER = PROJECT_FOLDER + "/src/test/resources/";
  
  public static final String BATCHFILE_FOLDER = RESOURCES_FOLDER + "BatchFiles/";
  
  public static final String CONFIG_FOLDER = RESOURCES_FOLDER + "Configurations/";
  
  public static final String TESTDATA_FOLDER = RESOURCES_FOLDER + "TestData/";
  
  public static final String TESTSUITES_FOLDER = RESOURCES_FOLDER + "TestSuites/";
  
  public static final String RUNTIME_FOLDER = RESOURCES_FOLDER + "RunTime";
  
  public static final String TESTOUTPUT_FOLDER = PROJECT_FOLDER + "/test-output/";
  
  public static final String VIDEOLOG_FOLDER = TESTOUTPUT_FOLDER + "/VideoTestLogs/";
  
  public static final String RESOURCES_CONFIG = "/src/test/resources/Configurations/";
  
  public static final String TEST_BED_CONFIG_FILE = CONFIG_FOLDER + "TestBed.properties";
  
  public static final String APPLICATION_CONFIG_FILE = CONFIG_FOLDER + "Applications.properties";
  
  public static final String MOBILE_CONFIG_FILE = CONFIG_FOLDER + "MobileConfig.properties";
  
  public static final String ONEFRAME_CONFIG_FILE = CONFIG_FOLDER + "Oneframe.properties";
  
  public static final String QTEST_CONFIG_FILE = CONFIG_FOLDER + "qTest.properties";
  
  public static final String SCRIPTEXE_CONFIG_FILE = CONFIG_FOLDER + "ScriptExecution.properties";
  
  public static final String CREDENTIAL_CONFIG_FILE = CONFIG_FOLDER + "Credential.properties";
  
  public static final String RESULT_PASS = "PASS";
  
  public static final String RESULT_FAIL = "FAIL";
  
  public static final String RESULT_ERROR = "SCRIPT-ERROR";
  
  public static final String STATUS_SKIPPED = "TEST SKIPPED";
  
  public static final String TEST_CASE_ID = "TestCaseID";
  
  public static final String DB_URL = ".dburl";
  
  public static final String DB_DRIVER = ".dbdriver";
  
  public static final String DB_HOST = ".host";
  
  public static final String DB_PORT = ".port";
  
  public static final String DB_DBNAME = ".dbname";
  
  public static final String DB_USERNAME = ".username";
  
  public static final String DB_PASSWORD = ".password";
  
  public static final String DB_PARAMETERS = ".parameters";
  
  public static final String DBMS_REDSHIFT = "redshift";
  
  public static final String DBMS_MONGODB = "mongodb";
  
  public static final String DBMS_MSSQL = "mssql";
  
  public static final String DBMS_ORACLE = "oracle";
  
  public static final String DBMS_POSTGRESQL = "postgresql";
  
  public static final String DBMS_MYSQL = "mysql";
  
  public static final String AWS_DISPLAYNAME = ".aws.DisplayName";
  
  public static final String AWS_ROLE = ".aws.Role";
  
  public static final String AWS_ACCOUNT = ".aws.account";
  
  public static final String AWS_USERNAME = ".aws.username";
  
  public static final String AWS_PASSWORD = ".aws.password";
  
  public static final String AWS_URL = ".aws.url";
  
  public static final String BROWSER_NAME_PARAMETER = "Browser";
  
  public static final String SELENIUM_SERVER_PARAMETER = "SeleniumServer";
  
  public static final String DISABLE_SCREENSHOT_PARAMETER = "DisableScreenshot";
  
  public static final String PROJECT_ID_PARAMETER = "ProjectId";
  
  public static final DriverType DEFAULT_BROWSER = DriverType.CHROME;
  
  public static final String DEFAULT_SELENIUM_SERVER = "http://localhost:4444";
  
  public static final String SELENIUM_SERVER_URI = "/wd/hub";
  
  public static final String SELENIUM_SERVER_ADMIN_URI = "/grid/admin";
  
  public static final String CHROME = "chrome";
  
  public static final String CHROME_MOB_EMULATOR = "chrome_mobile_emulator";
  
  public static final String CHROME_HEADLESS = "chrome_headless";
  
  public static final String FIREFOX = "firefox";
  
  public static final String EDGE = "edge";
  
  public static final String INTERNET_EXPLORER = "internet_explorer";
  
  public static final String SAFARI = "safari";
  
  public static final String AATYP_WEB = "web";
  
  public static final String AATYP_API = "api";
  
  public static final String AATYP_MOB = "mobile";
  
  public static final String AATYP_DB = "database";
  
  public static final String AATYP_FILE = "file";
  
  public static final String AATYP_WINDOWS = "windows";
  
  public static final String AATYP_JAVA = "java";
  
  public static final String AATYP_MAINFRAME = "mainframe";
  
  public static final String TESTNG_REPORTS = "TestNG_Reports";
  
  public static final String EXTENT_REPORTS = "Extent_Reports";
  
  public static final String RUN_FLAG = "Yes";
  
  public static final String PRICE_MEDICATION_SEARCH = "priceMedicationSearch";
  
  public static final String IEP_CONFIGURATION = "IEPConfig.properties";
  
  public static final String IEP_CONFIG_FILE = PROJECT_FOLDER + "/src/test/resources/Configurations/" + "IEPConfig.properties";
}
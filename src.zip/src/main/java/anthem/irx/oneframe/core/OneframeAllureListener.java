package anthem.irx.oneframe.core;

import anthem.irx.oneframe.selenium.WebObjectHandler;
import com.aventstack.extentreports.Status;
import io.qameta.allure.listener.StepLifecycleListener;
import io.qameta.allure.listener.TestLifecycleListener;
import io.qameta.allure.model.StepResult;
import io.qameta.allure.model.TestResult;

public class OneframeAllureListener implements StepLifecycleListener, TestLifecycleListener {
  public static boolean TestStarted = false;
  
  public void afterStepStart(StepResult result) {}
  
  public void afterStepStop(StepResult result) {
    try {
      OneframeContainer.OneframeLogger(result.getName() + " -> " + result.getStatus().toString());
      if (result.getStatus().equals(Status.PASS))
        if (TestStarted) {
          OneframeContainer.ofReporter.LogPassTestStep(result.getName());
        } else {
          OneframeContainer.ofReporter.LogInfoTestStep(result.getName());
        } 
      //remobed result.getStatus().equals(Status.BROKEN) ||, from below line
      if (result.getStatus().equals(Status.FAIL)) {
        String base64Screenshot = WebObjectHandler.takeScreenshotOnDemand();
        if (OneframeContainer.glblScreenshotString.equalsIgnoreCase(base64Screenshot)) {
          OneframeContainer.ofReporter.LogFailTestStep(result.getName());
        } else {
          OneframeContainer.ofReporter.LogFailTestStep(result.getName(), base64Screenshot);
        } 
      } 
    } catch (Exception e) {
      OneframeContainer.OneframeLogger("\t[ONEFRAME] Exception occured within allure listener ");
      e.printStackTrace();
    } 
  }
  
  public void afterTestStart(TestResult result) {
    TestStarted = true;
  }
  
  public void afterTestStop(TestResult result) {
    try {
      OneframeContainer.OneframeLogger("End of Test -> " + result.getName() + " -> " + result.getStatus().toString());
      TestStarted = false;
      if (result.getStatus().equals(Status.PASS))
        OneframeContainer.ofReporter.CompleteTest(Status.PASS, "End of test - [" + result.getName() + "] Overall Test Status [" + result.getStatus().toString() + "]"); 
      //remobed result.getStatus().equals(Status.BROKEN) ||, from below line
      if (result.getStatus().equals(Status.FAIL))
        OneframeContainer.ofReporter.CompleteTest(Status.FAIL, "End of test - [" + result.getName() + "] Overall Test Status [" + result.getStatus().toString() + "]"); 
    } catch (Exception E) {
      OneframeContainer.OneframeLogger("\t[ONEFRAME] Exception occured within allure listener ");
      E.printStackTrace();
    } 
  }
}

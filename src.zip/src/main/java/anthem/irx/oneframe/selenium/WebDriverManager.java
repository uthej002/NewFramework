package anthem.irx.oneframe.selenium;

import anthem.irx.oneframe.core.OneframeContainer;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;

public abstract class WebDriverManager {
  protected WebDriver driver;
  
  protected abstract void createWebDriver();
  
  public void quitWebDriver() {
    if (null != this.driver) {
      this.driver.quit();
      this.driver = null;
      OneframeContainer.OneframeLogger("[ONEFRAME]WebDriverManager> Driver is closed");
    } 
  }
  
  public WebDriver getWebDriver() {
    if (null == this.driver) {
      createWebDriver();
      OneframeContainer.OneframeLogger("[ONEFRAME]WebDriverManager> Create Web Driver");
    } 
    this.driver.manage().window().maximize();
    this.driver.manage().timeouts().pageLoadTimeout(OneframeContainer.PageLoadTimeOut, TimeUnit.SECONDS);
    this.driver.manage().deleteAllCookies();
    OneframeContainer.OneframeLogger("[ONEFRAME]WebDriverManager> Driver is initialized");
    return this.driver;
  }
}

// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class DefectTrackingSystem
{
    @JsonProperty("defect_mappings")
    private List<DefectMapping> defectMappings;
    @JsonProperty("connection_name")
    private String connectionName;
    @JsonProperty("url")
    private String url;
    @JsonProperty("system_name")
    private String systemName;
    @JsonProperty("active")
    private Boolean active;
    @JsonProperty("id")
    private Long id;
    
    public DefectTrackingSystem() {
        this.defectMappings = new ArrayList<DefectMapping>();
        this.connectionName = null;
        this.url = null;
        this.systemName = null;
        this.active = false;
        this.id = null;
    }
    
    public DefectTrackingSystem defectMappings(final List<DefectMapping> defectMappings) {
        this.defectMappings = defectMappings;
        return this;
    }
    
    public DefectTrackingSystem addDefectMappingsItem(final DefectMapping defectMappingsItem) {
        this.defectMappings.add(defectMappingsItem);
        return this;
    }
    
    public List<DefectMapping> getDefectMappings() {
        return this.defectMappings;
    }
    
    public void setDefectMappings(final List<DefectMapping> defectMappings) {
        this.defectMappings = defectMappings;
    }
    
    public DefectTrackingSystem connectionName(final String connectionName) {
        this.connectionName = connectionName;
        return this;
    }
    
    public String getConnectionName() {
        return this.connectionName;
    }
    
    public void setConnectionName(final String connectionName) {
        this.connectionName = connectionName;
    }
    
    public DefectTrackingSystem url(final String url) {
        this.url = url;
        return this;
    }
    
    public String getUrl() {
        return this.url;
    }
    
    public void setUrl(final String url) {
        this.url = url;
    }
    
    public DefectTrackingSystem systemName(final String systemName) {
        this.systemName = systemName;
        return this;
    }
    
    public String getSystemName() {
        return this.systemName;
    }
    
    public void setSystemName(final String systemName) {
        this.systemName = systemName;
    }
    
    public DefectTrackingSystem active(final Boolean active) {
        this.active = active;
        return this;
    }
    
    public Boolean getActive() {
        return this.active;
    }
    
    public void setActive(final Boolean active) {
        this.active = active;
    }
    
    public DefectTrackingSystem id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final DefectTrackingSystem defectTrackingSystem = (DefectTrackingSystem)o;
        return Objects.equals(this.defectMappings, defectTrackingSystem.defectMappings) && Objects.equals(this.connectionName, defectTrackingSystem.connectionName) && Objects.equals(this.url, defectTrackingSystem.url) && Objects.equals(this.systemName, defectTrackingSystem.systemName) && Objects.equals(this.active, defectTrackingSystem.active) && Objects.equals(this.id, defectTrackingSystem.id);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.defectMappings, this.connectionName, this.url, this.systemName, this.active, this.id);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class DefectTrackingSystem {\n");
        sb.append("    defectMappings: ").append(this.toIndentedString(this.defectMappings)).append("\n");
        sb.append("    connectionName: ").append(this.toIndentedString(this.connectionName)).append("\n");
        sb.append("    url: ").append(this.toIndentedString(this.url)).append("\n");
        sb.append("    systemName: ").append(this.toIndentedString(this.systemName)).append("\n");
        sb.append("    active: ").append(this.toIndentedString(this.active)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

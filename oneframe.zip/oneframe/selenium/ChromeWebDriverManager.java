// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.selenium;

import org.openqa.selenium.WebDriver;
import java.util.Map;
import org.openqa.selenium.chrome.ChromeDriver;
import anthem.irx.oneframe.core.OneframeContainer;
import java.util.Arrays;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.PageLoadStrategy;
import java.util.HashMap;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ChromeWebDriverManager extends WebDriverManager
{
    DesiredCapabilities caps;
    ChromeOptions options;
    DriverType chromeDriverType;
    
    public ChromeWebDriverManager(final DriverType chromeDriverType) {
        this.caps = new DesiredCapabilities();
        this.options = new ChromeOptions();
        this.chromeDriverType = chromeDriverType;
    }
    
    public void createWebDriver() {
        final HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("profile.default_content_setting_values.notifications", 2);
        map.put("profile.default_content_settings.popups", 0);
        map.put("download.default_directory", System.getProperty("user.dir") + "\\src\\test\\resources\\RunTime");
        map.put("download.prompt_for_download", "false");
        map.put("download.directory_upgrade", "true");
        this.options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        this.options.setCapability("ensureCleanSession", true);
        this.options.setCapability("unexpectedAlertBehaviour", (Object)UnexpectedAlertBehaviour.DISMISS);
        this.options.setCapability("unhandledPromptBehavior", (Object)UnexpectedAlertBehaviour.DISMISS);
        this.options.setExperimentalOption("prefs", (Object)map);
        this.options.setExperimentalOption("excludeSwitches", (Object)Arrays.asList("disable-popup-blocking"));
        this.options.addArguments(new String[] { "ignore-certificate-errors" });
        this.options.addArguments(new String[] { "start-maximized" });
        OneframeContainer.OneframeLogger(System.getProperty("user.dir"));
        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/src/main/resources/DriverBinaries/chromedriver_win32/chromedriver.exe");
        switch (this.chromeDriverType) {
            case CHROME: {}
            case CHROME_MOB_EMULATOR: {
                final Map<String, String> mobileEmulation = new HashMap<String, String>();
                mobileEmulation.put("deviceName", "iPad Pro");
                this.options.setExperimentalOption("mobileEmulation", (Object)mobileEmulation);
                break;
            }
        }
        this.driver = (WebDriver)new ChromeDriver(this.options);
    }
}

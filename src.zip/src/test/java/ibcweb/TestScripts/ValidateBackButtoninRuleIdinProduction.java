package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderProduction;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBackButtoninRuleIdinProduction  extends OneframeContainer{
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderProduction rulebuilderproduction;
	IBPRuleIDPage ruleid;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for validating Back Button in Rule Id In Production Area")
	public void setUp() {
		InitializeLaunchPad("IBPW_33");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderproduction = new IBPRuleBuilderProduction();
		ruleid = new IBPRuleIDPage();
		addrulepage = new IBPAddRulePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","LibraryName","RuleName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "validate Back Button In Rule Id In Production", dataProvider = "TestData")
	@Description("validate Back Button in  Rule Id in Production")
	public void ValidateBackButtoninRuleIdinProductionArea(String TestCaseID, String TestStatus, String LibraryName,String RuleName) throws AWTException, InterruptedException, IOException {
		
	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickProductionLink();
            //sa.assertTrue(rulebuilderproduction.verifyRuleEngineHeaderdisplay(), "Verified Benefit Validation Rules Engine");
			sa.assertTrue(rulebuilderproduction.verifyProductionHeaderdisplay(), "Verified PRODUCTION is displayed");
			rulebuilderproduction.clickRuleName(LibraryName, RuleName);
			ruleid.clickBackbutton();
			//sa.assertTrue(rulebuilderproduction.verifyRuleEngineHeaderdisplay(), "Verified Benefit Validation Rules Engine");
		    sa.assertTrue(rulebuilderproduction.verifyProductionHeaderdisplay(), "Verified PRODUCTION is displayed");
		    gTestResult = RESULT_PASS;
			OneframeLogger("Validate Back Button in Rule Id Validation In Production is successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate Back Button in Rule Id Validation In Production is Unsuccessful");
		}
		sa.assertAll();
	}


	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}


}

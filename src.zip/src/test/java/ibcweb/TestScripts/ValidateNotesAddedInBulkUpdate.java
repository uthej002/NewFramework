package ibcweb.TestScripts;

import static anthem.irx.oneframe.core.OneframeContainer.OneframeLogger;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.CSVFile;
import anthem.irx.oneframe.utilities.ExcelFile;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBulkUpdateBulkUpdatedPage;
import ibcweb.PageObjects.IBPBulkUpdatePage;
import ibcweb.PageObjects.IBPBulkUpdateReviewPage;
import ibcweb.PageObjects.IBPBulkUpdateWorkInProgressPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;


public class ValidateNotesAddedInBulkUpdate extends OneframeContainer {
	
		IBPWelcomePage welcomePage;
		IBPLoginPage   loginpage;
		IBPHomePage homepage;
		IBPBenefitPage benefitPage;
		IBPBulkUpdatePage bulkUpdatePage;
		IBPBulkUpdateWorkInProgressPage workInProgressPage;
		IBPBulkUpdateBulkUpdatedPage bulkUpdatedPage;
		IBPBulkUpdateReviewPage reviewPage;
		// move to page object
		Robot robot;

	@BeforeClass
	@Step("Initializing Test Script for validating Butterscotch App Login")
	public void setUp() {
		InitializeLaunchPad("IBPW_859");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitPage = new IBPBenefitPage();
		bulkUpdatePage = new IBPBulkUpdatePage();
		workInProgressPage = new IBPBulkUpdateWorkInProgressPage();
		reviewPage = new IBPBulkUpdateReviewPage();
		bulkUpdatedPage = new IBPBulkUpdateBulkUpdatedPage();
	}

	@DataProvider(name = "LoginTestData")
	public Object[][] getLoginTestDataTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Module", "Action", "EffectiveArea", 
								"RetailInput", "HomeDeliveryInput", "DataSheetWithBenefits"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Notes added in Bulk Update Review Screen", dataProvider = "LoginTestData")
	@Description("Validate Notes added in Bulk Update Review Screen")
	public void ValidateNotesAddedInReviewScreen(String TestCaseID, String TestStatus, String Module, String Action, String EffectiveArea, 
			String RetailInput, String HomeDeliveryInput, String DataSheetWithBenefits) throws AWTException, InterruptedException, IOException {
	
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		int numberOfRows = bulkUpdatePage.getRowCount(DataSheetWithBenefits);
		if (loginpage.MemberLogin()) {
			
			//Creating a New Project
			homepage.clickMenuButton();
			bulkUpdatePage.clickBulkProcess();
			bulkUpdatePage.clickBulkUpdate();
			
			bulkUpdatePage.clickOnCreateAProjectButton();
			sa.assertTrue(bulkUpdatePage.verifyCreateProjectHilightedInProgressBar(), "'Create Project' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatePage.verifyCreateAProjectHeader(), "'Create a Project' heading is displayed");
			sa.assertTrue(!bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is disabled");
			sa.assertTrue(bulkUpdatePage.verifyAndEnterProjectID("TestA"), "Verified and entered project id");
			sa.assertTrue(bulkUpdatePage.verifyAndEnterProjectDescription("Test Auto Project Desc"), "Verified and entered project description");
			sa.assertTrue(workInProgressPage.selectModuleDropdown(Module) , "Selected Module as General Defaults");
			bulkUpdatePage.clickOnFileUploadButton();
			bulkUpdatePage.uploadFile(DataSheetWithBenefits);
			sa.assertTrue(bulkUpdatePage.verifySuccessfulUploadMessage(numberOfRows+" of "+numberOfRows+" benefits found"), "File upload");
			sa.assertTrue(bulkUpdatePage.verifyCreateProjectButton(), "'Create Project' button is enabled");
			bulkUpdatePage.clickOnCreateProjectButton();
			bulkUpdatedPage.clickOnYesButton();			
			sa.assertTrue(bulkUpdatePage.verifyProjectIsCreated(bulkUpdatePage.getProjectID()), "Project ID is found in the grid");
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "IN_PROGRESS"), "Project Status is In Progress");
			
			// Validations in Work in progress screen
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyWorkInProgressHilightedInProgressBar(), "'Work In Progress' is hilighted in Progress Bar");
			sa.assertTrue(workInProgressPage.verifyModuleHeader() , "Heading Module is displayed");
			sa.assertTrue(workInProgressPage.verifyActionHeader() , "Heading Action is displayed");
			//sa.assertTrue(workInProgressPage.selectModuleDropdown(Module) , "Selected Module as General Defaults");
			sa.assertTrue(workInProgressPage.selectActionDropdown(Action) , "Selected Action as Update");
			sa.assertTrue(workInProgressPage.verifyEffectiveAreaHeader() , "Heading Effective Area is displayed");
			sa.assertTrue(!workInProgressPage.verifyReviewProjectButtonEnabled() , "Review Project button is disabled");
			sa.assertTrue(workInProgressPage.selectEffectiveAreaDropdown(EffectiveArea) , "Selected Effective Area as High Dollar");
			sa.assertTrue(workInProgressPage.verifyAndEnterRetailInput(RetailInput) , "Retial input box is displayed and entered value as 5$");

			sa.assertTrue(workInProgressPage.verifyAndEnterHomeDeliveryInput(HomeDeliveryInput) , "Home Delivery input box is displayed and entered value as 7$");

			sa.assertTrue(workInProgressPage.verifyReviewProjectButtonEnabled() , "Review Project button is enabled");
			workInProgressPage.clickProjectReviewButton();
			
			//Validations in Review screen
			sa.assertTrue(bulkUpdatePage.verifyReviewHilightedInProgressBar(), "'Review' is hilighted in Progress Bar");
			sa.assertTrue(reviewPage.verifyUpdateGeneralDefaultsHeading() , "UPDATE GENERAL DEFAULTS heading is displayed");
			sa.assertTrue(workInProgressPage.verifyHighDollarHeading() , "High Dollar heading is displayed");
			sa.assertTrue(reviewPage.verifyRetailValue(RetailInput), "Retail value is displayed");
			sa.assertTrue(reviewPage.verifyHomeDeliveryValue(HomeDeliveryInput), "Home Delivery value is displayed");
			reviewPage.clickBulkUpdateButton();
			
			reviewPage.verifyTextAreaSize();
			String notesText = benefitPage.getRandomString();
			reviewPage.enterNotes(notesText);
			reviewPage.verifyTextAreaSize();
			
			reviewPage.clickYesButton();
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "PROCESSING"), "Project Status is PROCESSING");
			
			//Validations in Processing screen
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyProcessingHilightedInProgressBar(), "'Processing' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatedPage.verifyBulkUpdatInProgressTextMessage(bulkUpdatePage.getProjectID()), "Benefit status is 'Bulk Update in Progress'");
			bulkUpdatedPage.clickOnBackButton();
			
			//Validations in Bulk Updated Screen
			bulkUpdatePage.verifybenefitStatus(bulkUpdatePage.getProjectID());
		//	sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "BULKUPDATED"), "Project Status is BULK UPDATED");
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyBulkUpdatedHilightedInProgressBar(), "'Bulk Updated' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatedPage.verifyExportUpdatesLink() , "Export Updates link is displayed");
			sa.assertTrue(bulkUpdatedPage.verifyUnlockBenefitsButton() , "Unlock Benefits button is displayed");
			sa.assertTrue(bulkUpdatedPage.verifySubmitToAdjudication() , "Submit to Adjudication button is displayed");
			bulkUpdatedPage.clickUnlockBenefitsButton();
			bulkUpdatedPage.clickOnYesButton();
			sa.assertTrue(bulkUpdatedPage.verifyUnlockInProgressTextMessage(bulkUpdatePage.getProjectID()) , "Unlock in Progress message is displayed");
			bulkUpdatedPage.clickOnBackButton();
			sa.assertTrue(bulkUpdatePage.verifyStatus(bulkUpdatePage.getProjectID(), "COMPLETED"), "Project Status is COMPLETED");
			bulkUpdatePage.clickOnProject(bulkUpdatePage.getProjectID());
			sa.assertTrue(bulkUpdatePage.verifyCompleteHilightedInProgressBar(), "'Complete' is hilighted in Progress Bar");
			sa.assertTrue(bulkUpdatedPage.verifyCompletedTextMessage(bulkUpdatePage.getProjectID()), "Benefit status is 'Completed' in Complete screen");

			sa.assertTrue(benefitPage.validateNotesAddedInBulkUpdate(numberOfRows, notesText, DataSheetWithBenefits), "Notes entered in bulk update is visible in benefits page");
			
			sa.assertAll();
			gTestResult = RESULT_PASS;
			
			OneframeLogger("Validate Butterscotch App Login Succseefully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate Butterscotch App Login");
		}
		
		homepage.clickLogout();		
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}
	
	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

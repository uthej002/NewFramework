package ibcweb.PageObjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPLoginPage extends OneframeContainer {

	IBPHomePage homepage;
	IBPWelcomePage welcomePage;

	//	@FindBy(xpath = "//b[text()='Please Login']")
	//	WebElement txtLoginLogo;

	@FindBy(xpath="//div[@class='ping-header']")
	WebElement txtLoginLogo;

	//div[@class='ping-header']

	//	@FindBy(xpath = "//input[@name='USER']")
	//	WebElement txtUsername;

	@FindBy(xpath = "//input[@id='username']")
	WebElement txtUsername;

	@FindBy(xpath = "//input[@id='password']")
	WebElement txtPassword;

	//	@FindBy(xpath = "//input[@name='PASSWORD']")
	//	WebElement txtPassword;

	//	@FindBy(xpath = "//input[@value='Login']")
	//	WebElement btnLogin;

	@FindBy(xpath = "//a[@title='Submit']")
	WebElement btnLogin;

	// Initializing the Page Objects:
	public IBPLoginPage() {
		PageFactory.initElements(oneframeDriver, this);
		homepage = new IBPHomePage();
		welcomePage = new IBPWelcomePage();
	}

	// Actions
	public static String dataReader(String key) throws IOException {
		String configFile = System.getProperty("user.dir") + "/src/test/resources/Configurations/Credential.properties";
		String value = null;
		FileInputStream fis = null;
		Properties prop = null;
		try {
			fis = new FileInputStream(configFile);
			prop = new Properties();
			prop.load(fis);
			value = prop.getProperty(key);

		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			fis.close();
		}
		return value;
	}

	@Step("Verify Login page is displayed")
	public boolean verifyLoginLogo() {
		if (WebObjectHandler.WaitForObject(txtLoginLogo)) {
			return true;
		} else {
			return false;
		}
	}

	//		@Step("Login with user and password")
	//		public boolean MemberLogin() throws InterruptedException, IOException {
	//			boolean blnRC = false;
	//			if (verifyLoginLogo()) {
	//				OneframeLogger("IBP Member Portal Login page displayed");
	//				EnterLoginID();
	//				EnterPassword();
	//				ClickOnSubmit();
	//				if (homepage.verifyButterscotchHeader()) {
	//					//homepage.verifyButterscotchHeader();
	//					WebObjectHandler.makeScreenshotOnDemand();
	//					blnRC = true;
	//				} else {
	//					blnRC = false;
	//				}
	//			}
	//			return blnRC;
	//		}

	//@Step("Login with user and password")
	public boolean MemberLogin() throws InterruptedException, IOException {
		boolean blnRC = false;

		welcomePage.verifyButterscotchLogo();
		welcomePage.verifyLoginButtonDisplay();
		welcomePage.ClickLoginButton();
		Thread.sleep(3000);

		OFWebDriver.navigate().refresh();
		OFWebDriver.navigate().refresh();
		int iterationCount = OneframeContainer.gTestIteration;

		if(iterationCount == 1) {
			OneframeAssert ofa = new OneframeAssert();
			OneframeLogger("IBP Member Portal Login page displayed");
			EnterLoginID();
			EnterPassword();
			ClickOnSubmit();
			if (homepage.verifyWelcomeMesaage()) {
				OneframeLogger("Butterscotch Home Page is Displayed");
				WebObjectHandler.makeScreenshotOnDemand();
				blnRC = true;
			} else {
				blnRC = false;
			}
			ofa.assertTrue(blnRC, "Login to Butterscotch Application");
		}
		else {
			//welcomePage.verifyLoginButtonDisplay();
			//welcomePage.ClickLoginButton();
			if (homepage.verifyWelcomeMesaage()) {
				OneframeLogger("Butterscotch Home Page is Displayed");
				WebObjectHandler.makeScreenshotOnDemand();
				blnRC = true;
			} else {
				blnRC = false;
			}
		}


		/*
		 * if (verifyLoginLogo()) { OneframeAssert ofa = new OneframeAssert();
		 * OneframeLogger("IBP Member Portal Login page displayed"); EnterLoginID();
		 * EnterPassword(); ClickOnSubmit(); if (homepage.verifyWelcomeMesaage()) {
		 * OneframeLogger("Butterscotch Home Page is Displayed");
		 * WebObjectHandler.makeScreenshotOnDemand(); blnRC = true; } else { blnRC =
		 * false; } ofa.assertTrue(blnRC, "Login to Butterscotch Application"); } else {
		 * if (homepage.verifyWelcomeMesaage()) {
		 * OneframeLogger("Butterscotch Home Page is Displayed");
		 * WebObjectHandler.makeScreenshotOnDemand(); blnRC = true; } else { blnRC =
		 * false; } }
		 * 
		 */

		return blnRC;
	}

	@Step("Enter Member user ID")
	public void EnterLoginID() throws IOException {
		String strLoginID = getUserIDfromCredentialProperties();
		//String strLoginID = dataReader("ingeniorx.US.username");
		OneframeLogger("The Username is    " + strLoginID);
		WebObjectHandler.EnterText(txtUsername, strLoginID);
	}

	@Step("Enter Member Password")
	public void EnterPassword() throws IOException {
		String strPass = getPwdfromCredentialProperties();
		//String strPass = dataReader("ingeniorx.US.password");
		//OneframeLogger("The Password is    " + strPass);
		WebObjectHandler.EnterPasswordText(txtPassword, strPass);

	}

	@Step("Click on Submit Button")
	public void ClickOnSubmit() {
		WebObjectHandler.ClickWebObject(btnLogin);
	}

}

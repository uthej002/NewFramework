package com.ibc.base;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.apache.commons.io.FileUtils;

import com.ibc.config.ConfigFileReader;
import com.ibc.util.LoggerUtil;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class PageBase {
    protected WebDriver driver;
    protected ConfigFileReader configFileReader;
    protected FluentWait wait;
    protected SoftAssert sa;
    protected Assert ha;
    
    public PageBase(){
    	
    	 driver = DriverBase.getInstance().getDriver();
    	 sa = new SoftAssert();
        configFileReader = ConfigFileReader.getInstance();
        wait = new FluentWait(driver)
            .withTimeout(Duration.ofSeconds(configFileReader.getTimeout()))
            .pollingEvery(Duration.ofSeconds(1))
            .ignoring(NoSuchElementException.class);
        PageFactory.initElements(driver, this);
    }

    public void clearCookies() {
        driver.manage().deleteAllCookies();
    }

    public void clearCache() {
        driver.manage().deleteAllCookies();
        driver.navigate().refresh();
    }

    public void clearLocalStorage() {
        JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
        javascriptExecutor.executeScript("localStorage.clear()");
    }
    
    public void navigateToUrl(String url){
    	LoggerUtil.log("Launch url: " +url);
        driver.get(url);
    }

    public String getTitle(){
    	LoggerUtil.log("Get title: " +driver.getTitle());
        return driver.getTitle();
    }
    
    public void sendKeys(WebElement element, String keys) {
    	waitForElementToBeVisible(element);
    	LoggerUtil.log("Clear the input field: " +element);
        element.clear();
        LoggerUtil.log("Enter text '"+keys+"' into the field");
        element.sendKeys(keys);
    }
    
    public void pressEnterOnElement(WebElement element, Keys key) {
    	LoggerUtil.log("Press '"+key.toString()+"' on element: " +element);
        element.sendKeys(key);
    }

    public void waitForElementToBeVisible(WebElement element) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.visibilityOf(element));
    }
    
    public void clickElement(WebElement element) {
    	LoggerUtil.log("Click on element: " +element);
    	element.click();
    }
    
    public void refreshBrowser() {
    	LoggerUtil.log("Refresh Browser");
    	driver.navigate().refresh();
    }

    public void switchToFrame(WebElement frameElement) {
        driver.switchTo().frame(frameElement);
    }
    
    public void switchToDefaultContent() {
        driver.switchTo().defaultContent();
    }

    public void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
    }
    
    public void clickUsingJavaScript(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    public void waitForPageLoad() {
        ExpectedCondition<Boolean> pageLoadCondition = driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
        wait.pollingEvery(Duration.ofSeconds(1)).until(pageLoadCondition);
    }

    public String getCurrentURL(){
        return driver.getCurrentUrl();
    }

    public void acceptAlert() {
        driver.switchTo().alert().accept();
    }

    public void dismissAlert() {
        driver.switchTo().alert().dismiss();
    }

    public String getTextFromAlert(){
        return driver.switchTo().alert().getText();
    }

    public void switchToNewWindow(String windowTitle){
        Set<String> handles = driver.getWindowHandles();
        for(String handle : handles){
            driver.switchTo().window(handle);
            if(driver.getTitle().equalsIgnoreCase(windowTitle)) break;
        }
    }

    public void hoverOverElement(WebElement element){
        Actions actions = new Actions(driver);
        actions.moveToElement(element).build().perform();
    }

    public void dragAndDrop(WebElement from, WebElement to){
        Actions actions = new Actions(driver);
        actions.dragAndDrop(from,to).build().perform();
    }
    public void uploadFile(WebElement uploadElement, String filePath){
        uploadElement.sendKeys(filePath);
    }

    public void selectFromDropdown(WebElement dropdown, String visibleText){
        Select select = new Select(dropdown);
        select.selectByVisibleText(visibleText);
    }

    public void selectFromDropdown(WebElement dropdown, int index){
        Select select = new Select(dropdown);
        select.selectByIndex(index);
    }

    public String getSelectedOptionFromDropdown(WebElement dropdown){
        Select select = new Select(dropdown);
        return select.getFirstSelectedOption().getText();
    }

    public List<String> getAllOptionsFromDropdown(WebElement dropdown){
        Select select = new Select(dropdown);
        List<WebElement> allOptions = select.getOptions();
        List<String> optionTexts = new ArrayList<>();
        for (WebElement option : allOptions) {
            optionTexts.add(option.getText());
        }
        return optionTexts;
    }

    public void takeScreenshot(String fileName) {
        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
        File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
        String filePath = "src/test/resources/screenshots/" + fileName + ".png";
        File destinationFile = new File(filePath);
        try {
            FileUtils.copyFile(sourceFile, destinationFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleWindowsAuthenticationDialog(String userName, String password) {
        try {
            Robot robot = new Robot();
            robot.setAutoDelay(2000);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            Thread.sleep(3000);
            StringSelection stringSelection = new StringSelection(userName);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(stringSelection, stringSelection);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            stringSelection = new StringSelection(password);
            clipboard.setContents(stringSelection, stringSelection);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (AWTException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    public void waitForElementToBeClickable(WebElement element) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitForElementToBeSelected(WebElement element) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.elementToBeSelected(element));
    }

    public void waitForPageTitleToBe(String title) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.titleIs(title));
    }

    public void waitForPageTitleContains(String title) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.titleContains(title));
    }

    public void waitForElementToDisappear(By locator) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    public void waitForNumberOfElementsToBe(By locator, int number) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.numberOfElementsToBe(locator, number));
    }

    public void waitForNumberOfElementsToBeMoreThan(By locator, int number) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.numberOfElementsToBeMoreThan(locator, number));
    }
    
    public void waitForNumberOfElementsToBeLessThan(By locator, int number) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.numberOfElementsToBeLessThan(locator, number));
    }
    public void waitForAlertToBePresent() {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.alertIsPresent());
    }
    public void waitForElementToHaveAttributeValue(WebElement element, String attribute, String value) {
        wait.pollingEvery(Duration.ofSeconds(1)).until(ExpectedConditions.attributeToBe(element, attribute, value));
    }
}



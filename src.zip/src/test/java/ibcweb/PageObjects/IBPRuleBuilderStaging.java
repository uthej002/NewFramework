package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.bson.Document;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import APIUtilities.MongoDBConnection;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPRuleBuilderStaging extends OneframeContainer {

	static MongoDBConnection mongodb;
	public static MongoDatabase database;
	IBPRuleIDPage ruleid;

	@FindBy(xpath = "//h2[text()='Benefit Validation Rules Engine']")
	WebElement hdrBenefitRuleEngine;

	@FindBy(xpath = "//h3[text()='STAGING']")
	WebElement hdrStaging;

	@FindBy(xpath = "//h3[text()='PRODUCTION']")
	WebElement hdrProduction;

//	@FindBy(xpath = "//div[@class='bg-none-ibp ng-star-inserted']//button")
//	WebElement btnAddRule;
	
	@FindBy(xpath="//span[text()=' Add Rule ']")
	WebElement btnAddRule;

	@FindBy(xpath = "//mat-expansion-panel-header[contains(.,' Block of Business ')]")
	WebElement lnkBlockofBusiness;

	@FindBy(xpath = "//mat-expansion-panel-header[contains(.,'Base Formulary')]")
	WebElement lnkBaseFormulary;

	@FindBy(xpath = "//mat-expansion-panel-header[contains(.,'Net Formulary')]")
	WebElement lnkNetFormulary;

    @FindBy(xpath="//tbody/tr/td[contains(@class, 'mat-cell cdk-cell cdk-column-id mat-column-id ')]/a")
    List<WebElement> lstRuleIDS;

//	@FindBy(xpath = "//div[@id='cdk-accordion-child-1']/div/table/tbody/tr/td/a")
//	WebElement lstRuleIDS;

	@FindBy(xpath = "//div[contains(@id, 'cdk-accordion-child-')]/div//table/tbody/tr")
	List<WebElement> hdrLibraries;

	@FindBy(xpath = "//div[contains(@id, 'cdk-accordion-child-')]/div//table/tbody/tr/td[6]/a")
	WebElement lnkVersionIds;

	@FindBy(xpath = "//div[@class='mat-title title']")
	WebElement txtRuleIDTitle;

	@FindBy(xpath = "//button[@aria-label='Previous page']")
	List<WebElement> btnPreviousPage;

	@FindBy(xpath = "//button[@aria-label='Next page']")
	List<WebElement> btnNextPage;

	@FindBy(xpath = "//div[@class='mat-paginator-range-label']")
	List<WebElement> txtrecordscount;

	@FindBy(xpath = "//thead[@role='rowgroup']")
	List<WebElement> hdrRule;
	
	@FindBy(xpath = "//mat-expansion-panel-header[@aria-expanded='true']/following-sibling::div//div[@class='mat-paginator-range-label']")
	WebElement txtPageNumber;
	
	@FindBy(xpath = "//*[@class='mat-paginator-icon']")
	List<WebElement> lstPageTraverseChevronButton;
	
	@FindBy(xpath = "//h3[contains(@class, 'production-subtitle')]")
	WebElement productionTitle;

	// Initializing the Page Objects:
	public IBPRuleBuilderStaging() {
		PageFactory.initElements(oneframeDriver, this);
		ruleid = new IBPRuleIDPage();
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify RuleEngine Header is displayed")
	public boolean verifyRuleEngineHeaderdisplay() throws InterruptedException {
		WebObjectHandler.WaitForObjectVisibility(hdrBenefitRuleEngine);
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (hdrBenefitRuleEngine.isDisplayed()) {
				highlightElement(hdrBenefitRuleEngine);
				OneframeLogger("Benefit Rule Engine Header is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Benefit Rule Engine Header is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Staging Header is displayed")
	public boolean verifyStagingHeaderdisplay() {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if (WaitForObjectVisibility(hdrStaging)) {
				ClickWebObject(hdrStaging);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify PostAddRuleBody Button is displayed")
	public boolean verifyaddrulebuttondisplay() throws InterruptedException {
		Thread.sleep(5000);
		boolean blnRC = false;

		try {
			if (btnAddRule.isDisplayed()) {
				highlightElement(btnAddRule);
				OneframeLogger("PostAddRuleBody Button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("PostAddRuleBody Button is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on PostAddRuleBody Button")
	public void clickAddRuleButton() {
		try {
			if (ObjectExist(btnAddRule)) {
				ClickWebObject(btnAddRule);
				OneframeLogger("Add Rule Button clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Rule button not clicked");
		}
	}

	@Step("Click Block of Business Button")
	public void clickBlockofbusinessLink() {
		try {
			if (ObjectExist(lnkBlockofBusiness)) {
				ClickWebObject(lnkBlockofBusiness);
				OneframeLogger("Block of Business link clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Block Of Business link not displayed");
		}
	}

	@Step("Close the Butterscotch App")
	public void closeApp() {
		oneframeDriver.close();
		OneframeLogger("Butterscotch App is closed");
	}

	@Step("Click on BaseFormulary")
	public void clickBaseFormualry() {
		try {
			if (ObjectExist(lnkBaseFormulary)) {
				ClickWebObject(lnkBaseFormulary);
				OneframeLogger("Base Formulary link is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Base Formulary link is not clicked");
		}
	}
	
	@Step("Click on NetFormulary")
	public void clickNetFormualry() {
		try {
			if (ObjectExist(lnkNetFormulary)) {
				ClickWebObject(lnkNetFormulary);
				OneframeLogger("Net Formulary link is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Net Formulary link is not clicked");
		}
	}

	@Step("Click on First Rule ID")
	public void clickFirstRuleID() throws InterruptedException {
		Thread.sleep(2000);
		try {
			if (WaitForObjectVisibility(lstRuleIDS.get(0))) {
				ClickWebObject(lstRuleIDS.get(0));
				OneframeLogger("First Rule ID link is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("First Rule ID link is not clicked");
		}
	}

//	@Step("Verify Pagination Buttons are disabled when the records are less than 10")
//	public boolean verifyPaginationwhenlessthan10records() throws Throwable {
//		Thread.sleep(5000);
//		ScrollWebPageByPixel(100);
//		ClickWebObject(hdrLibraries.get(1));
//		WaitForApplicationToLoadCompletely();
//		WaitForObjectVisibility(txtrecordscount.get(1));
//		highlightElement(txtrecordscount.get(1));
//		OneframeLogger("The Records Count is " + txtrecordscount.get(1).getText());
//		highlightElement(btnPreviousPage.get(1));
//		highlightElement(btnNextPage.get(1));
//		return btnPreviousPage.get(1).isEnabled() && btnNextPage.get(1).isEnabled();
//	}

	@Step("Verify Block of Business Data is displayed")
	public boolean verifyBlockofBusinessDatadisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(hdrLibraries.get(0));
		try {
			if (hdrLibraries.get(0).isDisplayed()) {
				highlightElement(hdrLibraries.get(0));
				OneframeLogger("Block of Business Data is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Block of Business is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Base Formulary Data is displayed")
	public boolean verifyBaseFormualryDatadisplay() throws InterruptedException {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		ClickWebObject(hdrBenefitRuleEngine);
		ClickWebObject(hdrBenefitRuleEngine);
		ClickWebObject(hdrBenefitRuleEngine);
		ClickWebObject(hdrBenefitRuleEngine);
	//	WaitForObjectVisibility(hdrLibraries.get(1));
		try {
			if (hdrLibraries.get(1).isDisplayed()) {
				highlightElement(hdrLibraries.get(1));
				
				OneframeLogger("Base Formulary data is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Base Formulary data is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Rule Version ID")
	public void clickRuleVersionID() {

		try {
			if (ObjectExist(lnkVersionIds)) {
				ClickWebObject(lnkVersionIds);
				OneframeLogger("First Rule Version ID link is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("First Rule Version ID link is not clicked");
		}
	}

	@Step("Verify RuleID Title is Displayed")
	public boolean verifyRuleIDTitleDisplay() {
		//WaitForObjectVisibility(txtRuleIDTitle);
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {

			if (WaitForObject(txtRuleIDTitle)) {
				highlightElement(txtRuleIDTitle);
				OneframeLogger("RuleID is   " + txtRuleIDTitle.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("RuleID Title is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

//	@Step("Verify Pagination Buttons are Enabled when the records are more than 10")
//	public boolean verifyPaginationwhenmorethan10records() throws Throwable {
//		ScrollWebPageByPixel(100);		
//		ClickWebObject(hdrLibraries.get(0));
//		WaitForApplicationToLoadCompletely();
//		WaitForObjectVisibility(txtrecordscount.get(0));
//		highlightElement(txtrecordscount.get(0));
//		OneframeLogger("The Records Count is " + txtrecordscount.get(0).getText());
//		Thread.sleep(3000);
//		highlightElement(btnPreviousPage.get(0));
//		highlightElement(btnNextPage.get(0));
//		return btnPreviousPage.get(0).isEnabled() && btnNextPage.get(0).isEnabled();
//	}

	@Step("Click on Next Button")
	public void clickNextButton() {
		try {
			if (ObjectExist(btnNextPage.get(0))) {
				ClickWebObject(btnNextPage.get(0));
				OneframeLogger("Next Button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Next Button is not clicked");
		}
	}

	@Step("Click on Previous Button")
	public boolean clickPreviousButton() throws InterruptedException {
		Thread.sleep(2000);
		boolean blnRC = false;
		try {
			if (ObjectExist(btnPreviousPage.get(0))) {
				ClickWebObject(btnPreviousPage.get(0));
				OneframeLogger("Previous Page is clicked");
				blnRC = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Previous Page is not clicked");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on required RuleName in any Library")
	public void clickRuleName(String libraryname, String ruleID) throws InterruptedException {
		try {
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			String element = String.format("//mat-expansion-panel-header[contains(.,' %s ')]", libraryname);
			WebElement LibraryName = oneframeDriver.findElement(By.xpath(element));
			String elementthree = String.format(
					"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/table/thead[@role='rowgroup']",
					libraryname);
			WebElement ruleHeader = oneframeDriver.findElement(By.xpath(elementthree));
			if (ObjectExist(LibraryName)) {
				ClickWebObject(LibraryName);
				OneframeLogger("Library Name is clicked " + LibraryName.getText());
				ClickWebObject(ruleHeader);
				OneframeLogger("Library Name headers are clicked ");
				String elementTwo = String.format(
						"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/div/mat-paginator/div/div/di"
								+ "v/div[@class='mat-paginator-range-label']",
						libraryname);
				WebElement RecordsCount = oneframeDriver.findElement(By.xpath(elementTwo));
				String records = RecordsCount.getText();
				OneframeLogger("The Total No of Records are " + records);

				String[] recordCnt = records.split("–");
				String[] totalRecordCnt = recordCnt[1].split("of");
				int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				int recordsPerPage = Integer.parseInt(totalRecordCnt[0].trim());
				boolean ruleIdClicked = false;
				while (recordsPerPage <= totalRecords) {
					String elementOne = String.format(
							"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/table/tbody/tr/td/a",
							libraryname);
					List<WebElement> listofRules = oneframeDriver.findElements(By.xpath(elementOne));
					for (int i = 0; i < listofRules.size(); i++) {
						if (listofRules.get(i).getText().equals(ruleID)) {
							WaitForObjectToBeClickable(listofRules.get(i));
							OneframeLogger("The Selected Rule Name is  " + listofRules.get(i).getText());
							listofRules.get(i).click();
							OneframeLogger("The Selected Rule Name is Clicked ");
							ruleIdClicked = true;
							ruleid.verifyRuleIDTitleDisplay();
						}
					}
					if (!ruleIdClicked) {
						ScrollWebPageByPixel(200);
						WaitForObjectVisibility(btnNextPage.get(0));
						btnNextPage.get(0).click();
						OneframeLogger("Next Page is clicked");
						ClickWebObject(ruleHeader);
						elementTwo = String.format(
								"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/div/mat-paginator/div/div/di"
										+ "v/div[@class='mat-paginator-range-label']",
								libraryname);
						RecordsCount = oneframeDriver.findElement(By.xpath(elementTwo));
						records = RecordsCount.getText();
						OneframeLogger("The Total No of Records are " + records);
						recordCnt = records.split("–");
						totalRecordCnt = recordCnt[1].split("of");	
						totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
						recordsPerPage = Integer.parseInt(totalRecordCnt[0].trim());
					}
				}
			}
		} catch (StaleElementReferenceException sef) {
		}
	}
	
	@Step("Verify Pagination Buttons are Enabled when the records are more than 10")
	public boolean verifyPaginationwhenmorethan10records(String libraryname) throws InterruptedException {
		boolean blnRC = false;
		try {
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			String element = String.format("//mat-expansion-panel-header[contains(.,' %s ')]", libraryname);
			WebElement LibraryName = oneframeDriver.findElement(By.xpath(element));
			String elementthree = String.format(
					"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/table/thead[@role='rowgroup']",
					libraryname);
			WebElement ruleHeader = oneframeDriver.findElement(By.xpath(elementthree));
			if (WaitForObjectVisibility(LibraryName)) {
				ClickWebObject(LibraryName);
				OneframeLogger("Library Name is clicked " + LibraryName.getText());
				WaitForObjectVisibility(ruleHeader);
				ClickWebObject(ruleHeader);
				OneframeLogger("Library Name headers are clicked ");
				String elementTwo = String.format(
						"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/div/mat-paginator/div/div/di"
								+ "v/div[@class='mat-paginator-range-label']",
						libraryname);
				WebElement RecordsCount = oneframeDriver.findElement(By.xpath(elementTwo));
				String records = RecordsCount.getText();
				OneframeLogger("The Total No of Records are " + records);
				String[] recordCnt = records.split("–");
				String[] totalRecordCnt = recordCnt[1].split("of");
				int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				if (totalRecords >10) {
					ScrollToElement(RecordsCount);
					String elementFour = String.format(
							"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div/div/div/mat-paginator/div/div/div/div//following-sibling::button[@aria-label='Previous page']",
							libraryname);
					WebElement previousPage = oneframeDriver.findElement(By.xpath(elementFour));
					String elementFive = String.format(
							"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div/div/div/mat-paginator/div/div/div/div//following-sibling::button[@aria-label='Next page']",
							libraryname);
					WebElement nextPage = oneframeDriver.findElement(By.xpath(elementFive));
					WaitForObjectVisibility(nextPage);
					WaitForObjectVisibility(previousPage);
					if (nextPage.isEnabled()) {
						WaitForObjectVisibility(previousPage);
						WaitForObjectVisibility(nextPage);
						ClickWebObject(nextPage);
						ClickWebObject(previousPage);
						blnRC = true;
					}
				} else {
					OneframeLogger("Previous and Next buttons are not clicked");
				}
			}
		} catch (InvalidSelectorException sef) {
		}
		return blnRC;
	}
	
	@Step("Verify Pagination Buttons are disabled when the records are less than 10")
	public boolean verifyPaginationwhenlessthan10records(String libraryname) throws InterruptedException {
		
		boolean blnRC = false;
		try {
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			String element = String.format("//mat-expansion-panel-header[contains(.,' %s ')]", libraryname);
			WebElement LibraryName = oneframeDriver.findElement(By.xpath(element));
			String elementthree = String.format(
					"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/table/thead[@role='rowgroup']",
					libraryname);
			WebElement ruleHeader = oneframeDriver.findElement(By.xpath(elementthree));
			if (WaitForObjectVisibility(LibraryName)) {
				ClickWebObject(LibraryName);
				OneframeLogger("Library Name is clicked " + LibraryName.getText());
				WaitForObjectVisibility(ruleHeader);
				ClickWebObject(ruleHeader);
				OneframeLogger("Library Name headers are clicked ");
				String elementTwo = String.format(
						"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div[@role='region']/div/div/mat-paginator/div/div/di"
								+ "v/div[@class='mat-paginator-range-label']",
						libraryname);
				WebElement RecordsCount = oneframeDriver.findElement(By.xpath(elementTwo));
				String records = RecordsCount.getText();
				OneframeLogger("The Total No of Records are " + records);
				String[] recordCnt = records.split("–");
				String[] totalRecordCnt = recordCnt[1].split("of");
				int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				if (totalRecords <= 10) {
					ScrollToElement(RecordsCount);
					String elementFour = String.format(
							"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div/div/div/mat-paginator/div/div/div/div//following-sibling::button[@aria-label='Previous page']",
							libraryname);		
				WebElement previousPage =oneframeDriver.findElement(By.xpath(elementFour));
				String elementFive = String.format(
						"//mat-expansion-panel-header[contains(.,' %s ')]//following-sibling::div/div/div/mat-paginator/div/div/div/div//following-sibling::button[@aria-label='Next page']",
						libraryname);	
				WebElement nextPage =oneframeDriver.findElement(By.xpath(elementFive));
				WaitForObjectVisibility(nextPage);
					WaitForObjectVisibility(previousPage);
					if (!previousPage.isEnabled() && !nextPage.isEnabled()) { //!previousPage.isEnabled() && 
						blnRC = true;
					}
				} else {
					OneframeLogger("Previous and Next buttons are not clicked");
				}
			}
		} catch (InvalidSelectorException sef) {
		}
		return blnRC;
	}
	
	@Step("Click Library")
	public void clickLibrary(String libraryName) {
		try {
			String element = String.format("//mat-expansion-panel-header[contains(.,' %s ')]", libraryName);
			WaitForApplicationToLoadCompletely();
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			WebElement LibraryName = oneframeDriver.findElement(By.xpath(element));
			ClickWebObject(LibraryName);
			OneframeLogger("Library Name is clicked " + LibraryName.getText());
		}
		catch (NoSuchElementException e) {
			OneframeLogger("Unable to click on library: " +libraryName);
		}
	}
	
	@Step("Click Rule ID")
	public String clickRule(String libraryName, String ruleID) {
		String versionId = null;
		try {
			String xpath = "//*[contains(text(), '"+libraryName+"')]/../../following-sibling::div//td/a[normalize-space()='"+ruleID+"']";
			Thread.sleep(3000);
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			ClickWebObject(hdrBenefitRuleEngine);
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split(" ");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());
			
			// Dividing totalRecords by 10 because there are only 10 records per page
			int numberOfPages = Math.round(totalRecords/10) + 1;
			
			if(numberOfPages != 0) {
				for(int i=0; i<numberOfPages; i++) {
					try {
						WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
						if(WaitForObjectVisibility(ele)) {
							OneframeLogger("Cliked Rule ID : " +ele.getText());
							versionId = ruleid.getLatestVersionID(libraryName, ruleID);
							ClickWebObject(ele);
							break;
						}
					}
					catch (NoSuchElementException e) {
						 ClickWebObject(lstPageTraverseChevronButton.get(1));
						 ClickWebObject(txtPageNumber); 
						 ClickWebObject(txtPageNumber);
						 WaitForApplicationToLoadCompletely();
					}
					
				}
			}
			
		} catch (TimeoutException | InterruptedException e) {
			OneframeLogger("Latest Rule ID not clicked");
		}
		return versionId;
	}

	public boolean verifyProductionHeaderdisplay() {
		
		try {
			if(WaitForObjectVisibility(productionTitle)) {
				OneframeLogger("Title '" +productionTitle.getText()+ "' is displayed");
				return true;
			}
		} catch (Exception e) {
			OneframeLogger("Title '" +productionTitle.getText()+ "' is displayed");
			OneframeLogger(e.toString());
		}
		
		return false;
	}
}

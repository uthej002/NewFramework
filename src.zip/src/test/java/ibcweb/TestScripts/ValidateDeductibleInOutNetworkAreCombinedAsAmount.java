package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateDeductibleInOutNetworkAreCombinedAsAmount extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating deductible In Out Network are combined as Amount in Accums of benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_702");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "NewBenefitId" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate deductible tab deductible In Out Network are combined as Amount in Accums of benefit", dataProvider = "TestData")
	@Description("Validate deductible tab deductible In Out Network are combined as Amount in Accums of benefit")
	public void ValidatethedeductibletabinAccumofbenefit(String TestCaseID, String TestStatus, String NewBenefitId)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(NewBenefitId);
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");
			createbenefitpage.ClickEditButtoninWFE();
			accumsbenefitpage.clickOnAccumsTab();
			accumsbenefitpage.clickAccumsText();
			accumsbenefitpage.disableAllToggles();
			accumsbenefitpage.clickAccumsText();
			accumsbenefitpage.enablerequireToggle("deductible");
			accumsbenefitpage.clickAccumsText();
			sa.assertTrue(accumsbenefitpage.verifyDeductibleButtonDisplay(), "Verified Deductible Button is displayed");
			accumsbenefitpage.clickDeductibleinAccumsTab();
			accumsbenefitpage.enableInOutNetworkToggle();
			sa.assertTrue(accumsbenefitpage.verifyInOutOfNetworkLabel(),
					"Verified In/Out of Network label is displayed");
			String individualFieldValue = accumsbenefitpage.editAndGetIndividualFieldValueOfInOutNetwork();
			String FamilyFieldValue = accumsbenefitpage.editAndGetFamilyFieldValueOfInOutNetwork();
			createbenefitpage.ClickCloseButton();
			createbenefitpage.ClickWFEExitAndSaveButton();
			sa.assertTrue(createbenefitpage.verifyTextBenefitWasSaved(), "Verified 'Benefit was saved'");
			sa.assertTrue(accumsbenefitpage.verifyEditedIndividualFieldValueIsSame(individualFieldValue),
					"Verified the edited Individual Field value is same");
			sa.assertTrue(accumsbenefitpage.verifyEditedFamilyFieldValueIsSame(FamilyFieldValue),
					"Verified the edited Family Field value is same");

			gTestResult = RESULT_PASS;
			OneframeLogger(
					"Validated deductible tab deductible In Out Network are combined as Amount in Accums of benefit successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger(
					"Unable to Validate deductible tab deductible In Out Network are combined as Amount in Accums of benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

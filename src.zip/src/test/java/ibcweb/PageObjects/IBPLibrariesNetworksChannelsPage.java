package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPLibrariesNetworksChannelsPage extends OneframeContainer {

	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//div[contains(text(),'Libraries')]")
	WebElement txtLibraries;

	@FindBy(xpath = "//a[@routerlink='/admin/library/network-channels']")
	WebElement btnView;

	@FindBy(xpath = "//div[text()='Networks & Channels']")
	WebElement hdrNetworksChannels;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-networkType mat-column-networkType ng-star-inserted\"]")
	List<WebElement> lstNetworkType;

	@FindBy(xpath = "//span[text()=' Network ']")
	WebElement tabNetwork;

	@FindBy(xpath = "//button[@routerlink='./network-packages']")
	WebElement tabNetworkPackages;

	@FindBy(xpath = "//span[text()=' Add Network ']")
	WebElement btnAddNetwork;

	@FindBy(xpath = "//span[text()=' Add a Network ']")
	WebElement btnAddaNetwork;

	@FindBy(xpath = "//span[text()=' Create a Network Package ']")
	WebElement btnCreateaNetworkPackage;

	@FindBy(xpath = "//h3[text()='Add a Network']")
	WebElement hdrAddaNetworkheader;

	@FindBy(xpath = "//h3[text()='Create a Network Package']")
	WebElement hdrCreateaNetworkPackage;

	@FindBy(xpath = "//h3[text()='Included Networks']")
	WebElement hdrIncludedNetworks;

	@FindBy(xpath = "//div[@class='header__title']")
	WebElement hdrAddNetwork;

	@FindBy(xpath = "//input[@formcontrolname='networkName']")
	WebElement txtNetworkName;

	@FindBy(xpath = "//input[@formcontrolname='packageName']")
	WebElement txtNetworkPackageName;

	@FindBy(xpath = "//input[@formcontrolname='description']")
	WebElement txtDescription;

	@FindBy(xpath = "//input[@formcontrolname='networkCode']")
	WebElement txtNetworkCode;

	@FindBy(xpath = "//input[@formcontrolname='adjudicationCode']")
	WebElement txtAdjudicationCode;

	@FindBy(xpath = "//input[@formcontrolname='ranking']")
	WebElement txtDisplayPriority;

	@FindBy(xpath = "//mat-select[@formcontrolname='networkType']")
	WebElement drdNetworkType;

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']/div/div/mat-option[@role='option']/span")
	List<WebElement> dropdownNetworkType;

	@FindBy(xpath = "//*[@formcontrolname='stopSaleDate']")
	WebElement txtStopSaleDate;

	@FindBy(xpath = "//*[@formcontrolname='terminationDate']")
	WebElement txtTermDate;

	@FindBy(xpath = "//*[@formcontrolname='clients']/..")
	WebElement newNetworkClientDropdown;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> clientDropdown;

	@FindBy(xpath = "//*[@formcontrolname='lobs']")
	WebElement newNetworkLOBDropdown;

	@FindBy(xpath = "//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span")
	List<WebElement> LOBDropdown;

	@FindBy(xpath = "//*[@formcontrolname='states']")
	WebElement newNetworkStateDropdown;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> StateDropdown;

	@FindBy(xpath = "//div[@class='channel__title' and text()=' Retail ']")
	WebElement txtRetail;

	@FindBy(xpath = "//label[@for='mat-checkbox-1-input']")
	WebElement cbkRetailIncludeCheckbox;

	@FindBy(xpath = "//button[@type='submit']/span[text()=' Create ']")
	WebElement btnCreate;

	@FindBy(xpath = "//span[text()=' Add Network Package ']")
	WebElement btnAddNetworkPackage;

	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;

	@FindBy(xpath = "//*[@class='mat-paginator-icon']")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//td[contains(@class,'mat-cell cdk-cell cdk-column-networkName mat-column-networkName ')]")
	List<WebElement> lstNetworkName;

	@FindBy(xpath = "//td[contains(@class,'mat-cell cdk-cell cdk-column-name mat-column-name ')]")
	List<WebElement> lstNetworkPackageName;

	@FindBy(xpath = "//div[@class='cdk-overlay-container']")
	WebElement cdkOverlay;

	@FindBy(xpath = "//div[@class='bs-row row-cols-3']/mat-form-field[contains(@class, 'mat-form-field col ng-tns-c94-7 ')]")
	WebElement cdkOverlayone;

	@FindBy(xpath = "//mat-select[@formcontrolname='lobs']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdLob;

	@FindBy(xpath = "//mat-icon[@svgicon='filter']")
	WebElement btnFilter;

	@FindBy(xpath = "//div[@class='filter__text']")
	WebElement txtFilterBy;

	@FindBy(xpath = "//span[text()='Apply filter']")
	WebElement btnApplyFilter;

	@FindBy(xpath = "//tbody[@role='rowgroup']//tr[@role='row']")
	List<WebElement> lstNetworkItems;

	@FindBy(xpath = "//h3[text()='Network Details']")
	WebElement hdrNetworkDetails;

	@FindBy(xpath = "//h3[text()='Network Package Details']")
	WebElement hdrNetworkPackageDetails;

	@FindBy(xpath = "//div[@formgroupname='network']/div")
	List<WebElement> lstNetworkDetails;

	@FindBy(xpath = "//mat-icon[@svgicon='down-arrow']")
	WebElement lnkBackbutton;

	@FindBy(xpath = "//mat-icon[@svgicon='edit']")
	WebElement lnkEditButton;

	@FindBy(xpath = "//span[text()='Save Changes']")
	WebElement btnSaveChages;

	@FindBy(xpath = "//*[@formcontrolname=\"clientIds\"]")
	WebElement drdClient;

	@FindBy(xpath = "//*[@formcontrolname=\"lobIds\"]")
	WebElement drdLOB;

	@FindBy(xpath = "//*[@formcontrolname=\"stateIds\"]")
	WebElement drdState;

	@FindBy(xpath = "//*[@formcontrolname=\"networkIds\"]")
	WebElement drdNetwork;

	@FindBy(xpath = "//td[@class=\"mat-cell cdk-cell cdk-column-networks mat-column-networks ng-star-inserted\"]")
	List<WebElement> lstNetwork;

	public IBPLibrariesNetworksChannelsPage() {
		// Initializing the Page Objects
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify and click Libraries Section on Menu bar")
	public boolean verifyAndClickLibrariesSection() {
		boolean flag = false;
		if (ObjectExist(txtLibraries)) {
			txtLibraries.isDisplayed();
			ClickWebObject(txtLibraries);
			OneframeLogger("Libraries section clicked");
			flag = true;
		}
		return flag;
	}

	@Step("Click View button of Networks and Channels")
	public void clickViewButtonOfNetworksandChannels() {
		if (ObjectExist(btnView)) {
			ClickWebObject(btnView);
			OneframeLogger("Networks and Channel view button is clicked");
		}
	}

	@Step("Verify Networks header is displayed")
	public boolean verifyNetworksHeader() {
		boolean flag = false;
		if (ObjectExist(hdrNetworksChannels)) {
			if (hdrNetworksChannels.getText().equalsIgnoreCase("Networks & Channels")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Click on network & Channels header")
	public void clickNetworkChannelsHeader() {
		hdrNetworksChannels.click();
		hdrNetworksChannels.click();
	}

	@Step("Click Network tab")
	public void clickNetworkTab() {
		tabNetwork.click();
		OneframeLogger("Clicked Network tab");
	}

	@Step("Click Network Packages")
	public void clickNetworkPackagesTab() {
		tabNetworkPackages.click();
		OneframeLogger("Clicked Network Packages tab");
	}

	@Step("Click on Add a Network button")
	public void clickAddaNetworkButton() {
		btnAddaNetwork.click();
		OneframeLogger("Clicked on Add a Network button");
	}

	@Step("Click on Add Network button")
	public void clickAddNetworkButton() {
		btnAddNetwork.click();
		OneframeLogger("Clicked on Add Network button");
	}

	@Step("Click on Create a Network Package button")
	public void clickCreateaNetworkPackageButton() {
		btnCreateaNetworkPackage.click();
		OneframeLogger("Clicked on Create a Network Package button");
	}

	@Step("Verify Add a Network header is displayed")
	public boolean verifyAddaNetworkHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAddaNetworkheader)) {
			if (hdrAddaNetworkheader.getText().equalsIgnoreCase("Add a Network")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Create a Network Package header is displayed")
	public boolean verifyCreateaNetworkPackageHeader() {
		boolean flag = false;
		if (ObjectExist(hdrCreateaNetworkPackage)) {
			if (hdrCreateaNetworkPackage.getText().equalsIgnoreCase("Create a Network Package")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Included Networks header is displayed")
	public boolean verifyIncludedNetworksHeader() {
		boolean flag = false;
		if (ObjectExist(hdrIncludedNetworks)) {
			if (hdrIncludedNetworks.getText().equalsIgnoreCase("Included Networks")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Add Network header is displayed")
	public boolean verifyAddNetworkHeader() {
		ClickWebObject(hdrAddNetwork);
		ClickWebObject(hdrAddNetwork);
		boolean flag = false;
		if (ObjectExist(hdrAddNetwork)) {

			if (hdrAddNetwork.getText().equalsIgnoreCase("Add Network")) {
				flag = true;
			}
		}
		return flag;
	}

	String itemName = "NULL";

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Get Random Numeric value")
	public String getRandomNumericValue(int length) {
		String value = "";
		String letters = "123456789";
		for (int i = 0; i < length; i++) {
			value += letters.charAt((int) Math.floor(Math.random() * letters.length()));
		}
		return value;
	}

	@Step("Get Random Alphabetical String")
	public String getRandomAlphabeticalString(int length) {
		String value = " ";
		String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		for (int i = 1; i < length; i++) {
			value += letters.charAt((int) Math.floor(Math.random() * letters.length()));
		}
		return "TESTAUTO" + value;
	}

	@Step("Enter a Random Value in Network Name")
	public String EnterNetworkName() {
		String randomString = getRandomAlphabeticalString(5);
		// newNetFormularyNetFormularyNameTextField.clear();
		txtNetworkName.click();
		txtNetworkName.sendKeys(randomString);
		OneframeLogger("Enter Random value In Network Name Field : " + randomString);
		return randomString;
	}

	@Step("Enter a Random Value in Network Package Name")
	public String EnterNetworkPackageName() {
		String randomString = getRandomAlphabeticalString(5);
		txtNetworkPackageName.click();
		txtNetworkPackageName.sendKeys(randomString);
		OneframeLogger("Enter Random value In Network Package Name Field : " + randomString);
		return randomString;
	}

	@Step("Enter a Random Value in Description")
	public String EnterNetworkPackageDescription() {
		String randomString = getRandomAlphabeticalString(5);
		txtDescription.click();
		txtDescription.sendKeys(randomString);
		OneframeLogger("Entered Random value In Network Package Description Field : " + randomString);
		return randomString;
	}

	@Step("Enter a Random Value in Network Code")
	public boolean EnterNetworkCode() {
		boolean flag = false;
		txtNetworkCode.click();
		String type = "TestCode";
		int randomNumber = getRandomNumber();
		itemName = type + randomNumber;
		txtNetworkCode.sendKeys(itemName);
		if (ObjectExist(txtNetworkCode)) {
			txtNetworkCode.click();
			OneframeLogger("Network Code:" + txtNetworkCode.getAttribute("value"));
			flag = true;
		}
		return flag;
	}

	@Step("Enter a Random Value in Adjudication Code")
	public boolean EnterAdjudicationCode() {
		boolean flag = false;
		txtAdjudicationCode.click();
		String type = "AdjCode";
		int randomNumber = getRandomNumber();
		itemName = type + randomNumber;
		txtAdjudicationCode.sendKeys(itemName);
		if (ObjectExist(txtAdjudicationCode)) {
			txtAdjudicationCode.click();
			OneframeLogger("Adjudication Code:" + txtAdjudicationCode.getAttribute("value"));
			flag = true;
		}
		return flag;
	}

	@Step("Enter Random value to Display Priority")
	public boolean EnterDisplayPriority() {
		boolean bln = false;
		if (ObjectExist(txtDisplayPriority)) {
			String randomNumericValue = getRandomNumericValue(2);
			txtDisplayPriority.sendKeys(randomNumericValue);
			OneframeLogger("Display Priority : " + randomNumericValue);
			bln = true;
		}
		return bln;
	}

	@Step("Select Network Type")
	public String selectNetworkType() throws Throwable {
		if (ObjectExist(drdNetworkType)) {
			drdNetworkType.click();
			dropdownNetworkType.get(0).click();
			Robot rt = new Robot();
			rt.keyPress(KeyEvent.VK_TAB);
			OneframeLogger("Selected first value from Network Type dropdown : " + drdNetworkType.getText());
		}
		return drdNetworkType.getText();
	}

	@Step("Enter StopSale date")
	public void EnterStopSaleDate(String StopSaleDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtStopSaleDate)) {
				ClickWebObject(txtStopSaleDate);
				EnterText(txtStopSaleDate, StopSaleDate);
				OneframeLogger("StopSale Date has been Entered: " + txtStopSaleDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("StopSale Date has been Entered");
		}
	}

	@Step("Enter Term date")
	public void EnterTermDate(String TermDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtTermDate)) {
				ClickWebObject(txtTermDate);
				EnterText(txtTermDate, TermDate);
				OneframeLogger("Term Date has been Entered : " + txtTermDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Term Date has been Entered");
		}
	}

	@Step("Select Client Dropdown")
	public void selectClientDropdown() throws AWTException {
		newNetworkClientDropdown.click();
		clientDropdown.get(0).click();
		//ClickWebObject(cdkOverlay);
		Robot rt = new Robot();
		rt.keyPress(KeyEvent.VK_ESCAPE);
		OneframeLogger("Selected first client dropdown ");
	}

	@Step("Select LOB Dropdown")
	public void selectLOBDropdown() throws Throwable {
		drdLob.click();
		WaitForObjectVisibility(LOBDropdown.get(6));
		LOBDropdown.get(6).click();
		Robot rt = new Robot();
		rt.keyPress(KeyEvent.VK_TAB);
//		rt.keyRelease(KeyEvent.VK_TAB);
		OneframeLogger("Selected first LOB dropdown ");
	}

	@Step("Select State Dropdown")
	public void selectStateDropdown() {
		newNetworkStateDropdown.click();
		StateDropdown.get(0).click();
		ClickWebObject(cdkOverlay);
		OneframeLogger("Selected first State dropdown ");
	}

	@Step("Select Include Checkbox from Retail Network")
	public boolean selectRetailIncludeCheckbox() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtRetail)) {
				ClickWebObject(cbkRetailIncludeCheckbox);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click Create Network button")
	public void clickCreateNetworkButton() {
		btnCreate.click();
		OneframeLogger("Clicked Create Network Button");
	}

	@Step("Click Add Network Package button")
	public void clickNetworkPackageButton() {
		ClickWebObject(btnAddNetworkPackage);
		OneframeLogger("Clicked on Add Network Package Button");
	}

	@Step("Verify Network is created")
	public boolean VerifyNetworkIsCreated(String networkName) throws InterruptedException {
		Thread.sleep(2000);
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstNetworkName.size(); i++) {
					if (lstNetworkName.get(i).getText().equalsIgnoreCase(networkName)) {
						highlightElement(lstNetworkName.get(i));
						OneframeLogger("Network is created : " + lstNetworkName.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
					// clickMandatesHeader();
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException exc) {

		}
		return bln;
	}

	@Step("Verify Network Package is created")
	public boolean VerifyNetworkPackageIsCreated(String networkName) throws InterruptedException {
		Thread.sleep(3000);
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstNetworkPackageName.size(); i++) {
					if (lstNetworkPackageName.get(i).getText().equalsIgnoreCase(networkName)) {
						highlightElement(lstNetworkPackageName.get(i));
						OneframeLogger("Network is created : " + lstNetworkPackageName.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
//					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException exc) {
		}
		return bln;
	}

	@Step("Click on Filter button")
	public void clickFilterButton() {
		WaitForObjectVisibility(btnFilter);
		btnFilter.click();
		OneframeLogger("Clicked on Filter button");
	}

	@Step("Click on Apply Filter button")
	public void clickApplyFilterButton() {
		btnApplyFilter.click();
		OneframeLogger("Clicked on Apply Filter button");
	}

	@Step("Verify Filter By text is displayed")
	public boolean verifyFilterText() {
		boolean flag = false;
		if (ObjectExist(txtFilterBy)) {
			txtFilterBy.isDisplayed();
			ClickWebObject(txtFilterBy);
			OneframeLogger("Filter By Text is displayed");
			flag = true;
		}
		return flag;
	}

	@Step("Verify whether selected Network Type has displayed")
	public void verifySelectedNetworkTypeDisplayed(String NetworkType) {
		ClickWebObject(hdrNetworksChannels);
		ClickWebObject(hdrNetworksChannels);
		if (lstNetworkType.get(0).getText().equalsIgnoreCase(NetworkType)) {
			highlightElement(lstNetworkType.get(0));
			sa.assertEquals(lstNetworkType.get(0).getText(), NetworkType,
					"Verified Filtered Network type value is same as expected");
		}

	}

	@Step("Click on First Network Item")
	public void clickNetworkItem() {
		ClickWebObject(hdrNetworksChannels);
		ClickWebObject(hdrNetworksChannels);
		ClickWebObject(hdrNetworksChannels);
		try {
			if (WaitForObjectVisibility(lstNetworkItems.get(0))) {
				ClickWebObject(lstNetworkItems.get(0));
				OneframeLogger("Clicked on the First Network Type Item");
			}
		} catch (NoSuchElementException NSE) {
		}
	}

	@Step("Click on any Network Package Item")
	public void clickNetworkPackageItem() {
		ClickWebObject(hdrNetworksChannels);
		ClickWebObject(hdrNetworksChannels);
		ClickWebObject(hdrNetworksChannels);
		try {
			if (WaitForObjectVisibility(lstNetworkPackageName.get(lstNetworkPackageName.size() - 1))) {
				ClickWebObject(lstNetworkPackageName.get(lstNetworkPackageName.size() - 1));
				OneframeLogger("Clicked on the Network Package Item");
			}
		} catch (NoSuchElementException NSE) {
		}
	}

	@Step("Verify Network Details header is displayed")
	public boolean verifyNetworkDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrNetworkDetails)) {
			ClickWebObject(hdrNetworkDetails);
			if (hdrNetworkDetails.getText().equalsIgnoreCase("Network Details")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Network Package Details header is displayed")
	public boolean verifyNetworkPakageDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrNetworkPackageDetails)) {
			ClickWebObject(hdrNetworkPackageDetails);
			if (hdrNetworkPackageDetails.getText().equalsIgnoreCase("Network Package Details")) {
				flag = true;
			}
		}
		return flag;
	}

	@Step("Verify Network Item has displayed in the Networks Details Page")
	public boolean verifyNetworkIteminNetworkDetails() {
		boolean blnRC = false;
		ClickWebObject(hdrNetworkDetails);
		ClickWebObject(hdrNetworkDetails);
		try {
			if (WaitForObjectVisibility(lstNetworkDetails.get(0))) {
				ClickWebObject(lstNetworkDetails.get(0));
				ClickWebObject(lstNetworkDetails.get(1));
				ClickWebObject(lstNetworkDetails.get(2));
				ScrollWebPageByPixel(200);
				ClickWebObject(lstNetworkDetails.get(3));
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		ClickWebObject(lnkBackbutton);
		return blnRC;
	}

	@Step("Click Edit button in Network Details page")
	public void clickEditButton() {
//		ClickWebObject(hdrNetworkDetails);
		lnkEditButton.click();
		OneframeLogger("Clicked on Edit button in Network Details page");
	}

	@Step("Edit the Network details")
	public boolean EditNetworkDetails() {
		boolean blnRC = false;
		try {
			ClickWebObject(hdrNetworkDetails);
			WaitForObjectVisibility(txtNetworkName);
			txtNetworkName.sendKeys(Keys.CONTROL + "a");
			txtNetworkName.sendKeys(Keys.DELETE);
			EnterNetworkName();
			OneframeLogger("Edited the Network Name");
			WaitForObjectVisibility(txtNetworkCode);
			txtNetworkCode.sendKeys(Keys.CONTROL + "a");
			txtNetworkCode.sendKeys(Keys.DELETE);
			EnterNetworkCode();
			OneframeLogger("Edited the Network Code");
			WaitForObjectVisibility(txtAdjudicationCode);
			txtAdjudicationCode.sendKeys(Keys.CONTROL + "a");
			txtAdjudicationCode.sendKeys(Keys.DELETE);
			EnterAdjudicationCode();
			OneframeLogger("Edited the Adjudication Code");
			WaitForObjectVisibility(txtDisplayPriority);
			txtDisplayPriority.sendKeys(Keys.CONTROL + "a");
			txtDisplayPriority.sendKeys(Keys.DELETE);
			EnterDisplayPriority();
			OneframeLogger("Edited the Display Priority");
			WaitForObjectVisibility(btnSaveChages);
			ClickWebObject(btnSaveChages);
			OneframeLogger("Clicked on Save Changes button and the changes are saved");
			ClickWebObject(lnkBackbutton);
			blnRC = true;
		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Edit the Network Package details")
	public boolean EditandVerifyNetworkPackageDetails() {
		boolean blnRC = false;
		try {
			ClickWebObject(hdrNetworkPackageDetails);
			WaitForObjectVisibility(txtNetworkPackageName);
			String currentValue = txtNetworkPackageName.getText();
			txtNetworkPackageName.sendKeys(Keys.CONTROL + "a");
			txtNetworkPackageName.sendKeys(Keys.DELETE);
			String packageName = EnterNetworkPackageName();
			OneframeLogger("Edited the Network Package Name");
			WaitForObjectVisibility(btnSaveChages);
			ClickWebObject(btnSaveChages);
			OneframeLogger("Clicked on Save Changes button and the changes are saved");
			if (!currentValue.equals(packageName)) {
				blnRC = true;
			}
			ClickWebObject(lnkBackbutton);
		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Add Network into the library and verify whether it has been added or not")
	public boolean addNetworktoLibrary() throws Throwable {
		Thread.sleep(5000);
		boolean blnRC = false;
		try {
			ClickWebObject(hdrAddNetwork);
			List<WebElement> addNetwork = oneframeDriver
					.findElements(By.xpath("//tbody[@role='rowgroup']//tr[@role='row']"));
			if (WaitForObjectVisibility(addNetwork.get(0))) {
				ClickWebObject(addNetwork.get(0));
				Thread.sleep(3000);
				OneframeLogger("The Network has been selected for the Network Package Library");
				List<WebElement> addNetworkbutton = oneframeDriver
						.findElements(By.xpath("//span[text()=' Add Network ']"));
				WaitForObjectVisibility(addNetworkbutton.get(1));
				ClickWebObject(addNetworkbutton.get(1));
				OneframeLogger("The Network has been added to the Network Package Library");
				ClickWebObject(hdrIncludedNetworks);
				ClickWebObject(hdrIncludedNetworks);
				ClickWebObject(hdrIncludedNetworks);
				WebElement addNetworkCheckbox = oneframeDriver
						.findElement(By.xpath("//mat-checkbox[@data-automation-id='standard']"));
				Thread.sleep(2000);
				ScrollWebPageByPixel(200);
				if (WaitForObjectVisibility(addNetworkCheckbox)) {
					ClickWebObject(addNetworkCheckbox);
					OneframeLogger("Clicked on add Network checkbox to the Library");
					blnRC = true;
				}
			}
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select any Network Package Item")
	public boolean selectNetworkPackage() throws InterruptedException {
		Thread.sleep(7000);
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstNetworkPackageName.size(); i++) {
					if (lstNetworkPackageName.get(i).getText().contains("TESTAUTO")) {
						ClickWebObject(lstNetworkPackageName.get(i));
//						OneframeLogger("Network is created : " + lstNetworkPackageName.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
//					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException exc) {
		}
		return bln;
	}

	@Step("Select any Network Item")
	public boolean selectNetworkItem() throws InterruptedException {
		Thread.sleep(7000);
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstNetworkItems.size(); i++) {
					if (lstNetworkItems.get(i).getText().contains("TESTAUTO")) {
						ClickWebObject(lstNetworkItems.get(i));
//						OneframeLogger("Network is created : " + lstNetworkPackageName.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException exc) {

		}
		return bln;
	}

	@Step("Select Network value in filter dropdown")
	public String selectNetworkValueFilter(String network) {

		try {
			if (WaitForObjectVisibility(drdNetwork)) {
				drdNetwork.click();
				selectDropdownValues(network);
				OneframeLogger("The Selected Network Dropdown value is : " + network);
				clickOverlayElement();
			}
		} catch (TimeoutException e) {
			OneframeLogger("Unable to select Network dropdown ");
		}
		return drdNetwork.getText();

	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class=\"cdk-overlay-container\"]"));
		ClickWebObject(overlayElement);
	}

	@Step("Select the values from dropdowns")
	public String selectDropdownValues(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span[normalize-space()='%s']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		return dropdownvalue.getText();
	}

	@Step("Verify the Network filtered value is Same as Expected")
	public void verifyNetworkFilteredList(String Network) {
		WaitForObjectVisibility(lstNetwork.get(0));
		highlightElement(lstNetwork.get(0));
		sa.assertEquals(lstNetwork.get(0).getText(), Network, "Verified Network value is same as expected");
	}

}

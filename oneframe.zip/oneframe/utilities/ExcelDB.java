// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import java.util.Iterator;
import com.codoid.products.fillo.Recordset;
import java.util.List;
import org.testng.Assert;
import java.util.ArrayList;
import com.codoid.products.exception.FilloException;
import anthem.irx.oneframe.core.OneframeContainer;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import anthem.irx.oneframe.core.OneframeConstants;

public class ExcelDB extends OneframeConstants
{
    private static Fillo fillo;
    private static Connection connection;
    
    public static Connection getExcelDBConnectionObject(final String TDSFile) throws FilloException {
        OneframeContainer.OneframeLogger("[ONEFRAME]Excel DB | Fillo establishing connection Excel TDS File [ " + TDSFile + " ] ");
        ExcelDB.fillo = new Fillo();
        return ExcelDB.connection = ExcelDB.fillo.getConnection(TDSFile);
    }
    
    public static String[] getScriptConfigsFromTDS(final String TDSFile, final String sheetName, final String ScenarioID) throws FilloException {
        OneframeContainer.OneframeLogger("[ONEFRAME]Reading script configurations from TDS File [ " + TDSFile + " ] Sheet : " + sheetName + " for scenario ID - " + ScenarioID);
        List<String> ScriptConfigs = new ArrayList<String>();
        ExcelDB.connection = getExcelDBConnectionObject(TDSFile);
        final String strSelectQuerry = "select * from " + sheetName + " where TestScenarioID = '" + ScenarioID + "'";
        final Recordset rs = ExcelDB.connection.executeQuery(strSelectQuerry);
        final int count = rs.getCount();
        OneframeContainer.OneframeLogger("[ONEFRAME]" + strSelectQuerry);
        OneframeContainer.OneframeLogger("[ONEFRAME]Test Cases/Data Count : " + count);
        Assert.assertEquals(count, 1);
        ScriptConfigs = (List<String>)rs.getFieldNames();
        OneframeContainer.OneframeLogger("[ONEFRAME]TDS Columns : " + ScriptConfigs);
        final String[] data = new String[ScriptConfigs.size()];
        OneframeContainer.OneframeLogger(data.length);
        int j = 0;
        rs.moveFirst();
        for (final String testColumn : ScriptConfigs) {
            data[j] = rs.getField(testColumn);
            ++j;
        }
        rs.close();
        ExcelDB.connection.close();
        return data;
    }
    
    public static void CloseExcelDBConnection() {
        try {
            ExcelDB.connection.close();
        }
        catch (Exception gExcpn) {
            OneframeContainer.OneframeErrorLogger(gExcpn.getMessage());
        }
    }
    
    public static String[][] getDatafromExcel(final String TDSFile, final String sheetName, final String TestCaseID, final List<String> testData) throws FilloException {
        int count = 0;
        ExcelDB.connection = getExcelDBConnectionObject(TDSFile);
        OneframeContainer.OneframeLogger("[ONEFRAME]" + TDSFile);
        final String strSelectQuerry = "select * from " + sheetName + " where " + "TestCaseID" + " LIKE '" + TestCaseID + "_%' AND RunFlag = '" + "Yes" + "'";
        OneframeContainer.OneframeLogger("[ONEFRAME]" + strSelectQuerry);
        final Recordset rs = ExcelDB.connection.executeQuery(strSelectQuerry);
        count = rs.getCount();
        OneframeContainer.OneframeLogger("[ONEFRAME]Record Count " + count);
        final String[][] data = new String[count][testData.size()];
        int i = 0;
        while (rs.next()) {
            int j = 0;
            for (final String testColumn : testData) {
                data[i][j] = rs.getField(testColumn);
                OneframeContainer.OneframeLogger("[ONEFRAME]" + data[i][j]);
                ++j;
            }
            ++i;
        }
        rs.close();
        ExcelDB.connection.close();
        return data;
    }
    
    public static boolean UpdateTestResultToExcel(final String TDSFile, final String TDSSheet, final String TestCaseID, final String TestCaseStatus) {
        try {
            ExcelDB.connection = getExcelDBConnectionObject(TDSFile);
        }
        catch (FilloException E) {
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
        }
        final String strUpdateQuery = "Update " + TDSSheet + " Set TestStatus = '" + TestCaseStatus + "' where TestCaseID = '" + TestCaseID + "'";
        OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQuery);
        try {
            ExcelDB.connection.executeUpdate(strUpdateQuery);
        }
        catch (FilloException E2) {
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E2.getMessage());
        }
        return true;
    }
    
    public static boolean UpdateActualResultsToExcel(final String TDSFile, final String TDSSheet, final String TestCaseID, final String[] TDSColumnHeaders, final String[] TDSColumnActualResults) {
        try {
            ExcelDB.connection = getExcelDBConnectionObject(TDSFile);
        }
        catch (FilloException E) {
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
        }
        for (int i = 0; i < TDSColumnHeaders.length; ++i) {
            final String strUpdateQuery = "Update " + TDSSheet + " Set " + TDSColumnHeaders[i] + " = '" + TDSColumnActualResults[i] + "' where TestCaseID = '" + TestCaseID + "'";
            OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQuery);
            try {
                ExcelDB.connection.executeUpdate(strUpdateQuery);
            }
            catch (FilloException E2) {
                OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E2.getMessage());
            }
        }
        return true;
    }
    
    public static boolean UpdateTestDataToExcel(final String TDSFile, final String TDSSheet, final String TestCaseID, final String TestCaseStatus) {
        try {
            ExcelDB.connection = getExcelDBConnectionObject(TDSFile);
        }
        catch (FilloException E) {
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
        }
        final String strUpdateQuery = "Update " + TDSSheet + " Set TestStatus = '" + TestCaseStatus + "' where TestCaseID = '" + TestCaseID + "'";
        OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQuery);
        try {
            ExcelDB.connection.executeUpdate(strUpdateQuery);
        }
        catch (FilloException E2) {
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E2.getMessage());
        }
        return true;
    }
    
    public static boolean UpdateMobileTestResultToExcel(final String TDSFile, final String TDSSheet, final String TestCaseID, final String TestCaseStatus, final String ReportiumURL) {
        try {
            ExcelDB.connection = getExcelDBConnectionObject(TDSFile);
        }
        catch (FilloException E) {
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E.getMessage());
        }
        final String strUpdateQuery = "Update " + TDSSheet + " Set TestStatus = '" + TestCaseStatus + "' where TestCaseID = '" + TestCaseID + "'";
        OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQuery);
        final String strUpdateQueryReport = "Update " + TDSSheet + " Set ReportiumURL = '" + ReportiumURL + "' where TestCaseID = '" + TestCaseID + "'";
        OneframeContainer.OneframeLogger("[ONEFRAME]" + strUpdateQueryReport);
        try {
            ExcelDB.connection.executeUpdate(strUpdateQuery);
            ExcelDB.connection.executeUpdate(strUpdateQueryReport);
        }
        catch (FilloException E2) {
            OneframeContainer.OneframeLogger("[ONEFRAME]Excel Exception:" + E2.getMessage());
        }
        return true;
    }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitFormularyPage;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPBenefitProgramsPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBenefitLibrariesProgramsCostOfCareEdit extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPBenefitFormularyPage librariesFormularyPage;
	IBPBenefitProgramsPage BenefitProgramsPage;

	@BeforeClass
	@Step("Initializing Test Script for Validate Edit Program details, General, Network Tabs of Cost of care")
	public void setUp() {
		InitializeLaunchPad("IBPW_485");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		librariesFormularyPage = new IBPBenefitFormularyPage();
		BenefitProgramsPage = new IBPBenefitProgramsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "EffectiveDate", "TermDate", "NonSellableDate"};

		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit Program details, General, Network Tabs of Cost of care", dataProvider = "TestData")
	@Description("Validate Edit Program details, General, Network Tabs of Cost of care")
	public void ValidateLibrariesEditCostofCare(String TestCaseID, String TestStatus, String EffectiveDate,
			 String TermDate, String NonSellableDate )throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");

			librariesprogramspage.clickViewButtonofPrograms();
			sa.assertTrue(librariesprogramspage.verifyProgramsHeader(), "Verified 'Programs' header");
			librariesprogramspage.clickCostofCareofPrograms();
			librariesprogramspage.clickProgramsHeader();
			BenefitProgramsPage.clickonExistingCostofCareProgram();
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			librariesprogramspage.verifyCategoryDropdownIsDisabled();
			librariesprogramspage.verifySubCategoryDropdownIsDisabled();
			librariesprogramspage.editProgramName();		
			librariesFormularyPage.EditEffectiveDate(EffectiveDate);
			librariesprogramspage.EditTermDate(TermDate);
			librariesprogramspage.EditNonSellableDate(NonSellableDate);
			librariesprogramspage.SelectGeneralOverrideDropdown();
			librariesprogramspage.verifyNetworkOverrideDropdown();
			librariesprogramspage.SelectCostShareOverrideDropdown();
			librariesprogramspage.SelectAccumsOverrideDropdown();
			librariesprogramspage.editPriorityField();
			librariesprogramspage.editProgramDescription();
			librariesprogramspage.editDetailsinProgramDetails();
			librariesprogramspage.clickCostofcareCancelButton();
			librariesprogramspage.clickLeaveButton();
			librariesprogramspage.clickOnGeneralTab();
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			librariesprogramspage.enterRetailhighDollar();
			librariesprogramspage.enterMailhighDollar();
			librariesprogramspage.selectChannelNameDropdown();
			librariesprogramspage.enterQuantityLimit();
			librariesprogramspage.selectQuantityLimitatonDropdown();
			librariesprogramspage.enterDaysSupply();
			librariesprogramspage.enterInitialFillDaysSupply();
			librariesprogramspage.enterLookBackDays();
			librariesprogramspage.enterMaxFillDaysSupply();
			librariesprogramspage.enterLowerAge();
			librariesprogramspage.enterUpperAge();
			librariesprogramspage.selectUnderAgeDropdown();
			librariesprogramspage.selectOverAgeDropdown();
			librariesprogramspage.selectBetweenAgeDropdown();
			librariesprogramspage.clickCostofcareCancelButton();
			librariesprogramspage.clickLeaveButton();
			librariesprogramspage.verifyNetworkTabIsEnabledAndClicked();
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			librariesprogramspage.clickAllNetworksCheckbox();
			librariesprogramspage.verifyandEnterRetailValues();
			librariesprogramspage.selectRetailDropdown();
			librariesprogramspage.clickAllNetworksCheckboxHome();
			librariesprogramspage.verifyandEnterHomeValues();
			librariesprogramspage.selectHomeDropdown();
			librariesprogramspage.clickAllNetworksCheckbox();
			librariesprogramspage.clickAllNetworksCheckboxHome();
			librariesprogramspage.clickCostofcareCancelButton();
			librariesprogramspage.clickLeaveButton();
			sa.assertTrue(librariesprogramspage.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			librariesprogramspage.clickonSpecificNetworkTgl();
			librariesprogramspage.clickonAddSpecificNetworkbtn();
			librariesprogramspage.click1stSpecificNetworklst();
			librariesprogramspage.clickAddSpecificNetworkButton();
			librariesprogramspage.clickRemoveNetwork();
			librariesprogramspage.clickonRemoveButton();
			librariesprogramspage.clickonSpecificNetworkTgl();
			librariesprogramspage.clickCostofcareCancelButton();
			librariesprogramspage.clickLeaveButton();
			librariesFormularyPage.clickDownArrowButton();
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit Program details, General, Network Tabs of Cost of care Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Edit Program details, General, Network Tabs of Cost of care");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeContainer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileReader {
  private Properties properties;
  
  private String ConfigurationFile;
  
  private BufferedReader reader;
  
  private BufferedWriter writer;
  
  public ConfigFileReader(String ConfigurationFile) {
    this.ConfigurationFile = ConfigurationFile;
    try {
      this.reader = new BufferedReader(new FileReader(ConfigurationFile));
      OneframeContainer.OneframeLogger("[ONEFRAME]Reading..." + ConfigurationFile);
      this.properties = new Properties();
      try {
        this.properties.load(this.reader);
        this.reader.close();
      } catch (IOException e) {
        e.printStackTrace();
      } 
    } catch (FileNotFoundException e) {
      e.printStackTrace();
      throw new RuntimeException("File not found at " + ConfigurationFile);
    } 
  }
  
  public boolean checkPropertyExists(String PropertyKey) {
    String propertyValue = this.properties.getProperty(PropertyKey);
    if (propertyValue != null)
      return true; 
    OneframeContainer.OneframeLogger("[ONEFRAME] Property key [" + PropertyKey + "] - NOT FOUND");
    return false;
  }
  
  public String getProperty(String PropertyKey) {
    String propertyValue = this.properties.getProperty(PropertyKey);
    if (!PropertyKey.contains("password"))
      OneframeContainer.OneframeLogger("[ONEFRAME]" + PropertyKey + "=" + propertyValue); 
    if (propertyValue != null)
      return propertyValue; 
    throw new RuntimeException("Property : " + PropertyKey + " not specified in the Configuration file.");
  }
  
  public void setProperty(String PropertyKey, String PropertyValue) {
    try {
      this.writer = new BufferedWriter(new FileWriter(this.ConfigurationFile));
    } catch (FileNotFoundException e) {
      e.printStackTrace();
      throw new RuntimeException("File not found at " + this.ConfigurationFile);
    } catch (IOException e) {
      e.printStackTrace();
    } 
    try {
      this.properties.setProperty(PropertyKey, PropertyValue);
      this.properties.store(this.writer, (String)null);
      OneframeContainer.OneframeLogger("[ONEFRAME]" + PropertyKey + "=" + PropertyValue);
      this.writer.close();
    } catch (Exception ofe) {
      OneframeContainer.OneframeLogger("[ONEFRAME]Unable to set property for key - " + PropertyKey);
    } 
  }
}

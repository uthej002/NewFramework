package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumsTabonBenefitHowdoesINNandOONAccumulateValues extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating how inn and out accumulate dropdown values in Accums Tab on Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_120");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "Benefit" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}
	

	@Test(description = "Validate how inn and out accumulate dropdown values in Accums Tab on Benefit", dataProvider = "TestData")
	@Description("Validate how inn and out accumulate dropdown values in Accums Tab on Benefit")
	public void ValidateINNOONAccumulateValuesinAccumsTab(String TestCaseID, String TestStatus, String Benefit)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {	
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");
			createbenefitpage.ClickEditButtoninWFE();
			accumsbenefitpage.clickOnAccumsTab();
			sa.assertTrue(accumsbenefitpage.verifyAccumsContentDisplay(), "Verified Accums Content is Displayed");
			accumsbenefitpage.disableAllToggles();
			accumsbenefitpage.enablerequireToggle("deductible");
			sa.assertTrue(accumsbenefitpage.verifyINNOONLabel(), "Verified How does INN and OUT accumulate Label is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyINNOONDropdown(), "Verified How does INN and OUT accumulate dropdown is Displayed");
			accumsbenefitpage.clickOnHowdoesINNandOONDropdown();
			sa.assertTrue(accumsbenefitpage.verifyINNandOONAccumulateValuesDisplay(), "Verified How does INN and OUT accumulate dropdown values are Displayed");		
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated enable and disable toggles in Accums Tab on Benefit successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate enable and disable toggles in Accums Tab on Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

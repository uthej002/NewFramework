// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.pojo;

import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MSTeamMessageCard
{
    @JsonProperty("@type")
    public String type;
    @JsonProperty("@context")
    public String context;
    public String themeColor;
    public String summary;
    public ArrayList<MessageSection> sections;
}

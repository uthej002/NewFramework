package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAddMultipleLibrariesforRule extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Add Multiple Libraries in a rule")
	public void setUp() {
		InitializeLaunchPad("IBPW_13");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Add Multiple Libraries in a rule", dataProvider = "TestData")
	@Description("Validate Add Multiple Libraries in a rule")
	public void ValidateCreateaRuleinBRE(String TestCaseID, String TestStatus, String ClientId, String LOBId, String StateId) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();
			sa.assertTrue(addrulepage.verifyCreateaRuleHeader(),"Verified Create a Rule Header is displayed");
			sa.assertTrue(addrulepage.selectClientIdDropdown(ClientId),"Verified Client value has been selected");
			sa.assertTrue(addrulepage.selectLobIdDropdown(LOBId),"Verified LOB value has been selected");
			sa.assertTrue(addrulepage.selectStateIdDropdown(StateId),"Verified State value has been selected");
			addrulepage.clickAddButton();
			sa.assertTrue(addrulepage.verifyANDOperator(),"Verified AND Opeator has been displayed by default");
			sa.assertTrue(addrulepage.selectLibraryDropdown(),"Verified Library value has been selected");
			sa.assertTrue(addrulepage.selectPropertyDropdown(),"Verified Property value has been selected");
			sa.assertTrue(addrulepage.selectOperatorDropdown(),"Verified Operator value has been selected");
			sa.assertTrue(addrulepage.selectRHSDropdown(),"Verified RHS value has been selected");
			addrulepage.clickAddButton();
			sa.assertTrue(addrulepage.verifyBothOperatorsdisplay(),"Verified AND,OR Operators are displayed");
			sa.assertAll();	
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Add Multiple Libraries in a rule successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Add Multiple Libraries in a rule"); 
		}
		
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}


}

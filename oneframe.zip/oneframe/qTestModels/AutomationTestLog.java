// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import org.joda.time.DateTime;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class AutomationTestLog
{
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("test_case_version_id")
    private Long testCaseVersionId;
    @JsonProperty("exe_start_date")
    private DateTime exeStartDate;
    @JsonProperty("exe_end_date")
    private DateTime exeEndDate;
    @JsonProperty("note")
    private String note;
    @JsonProperty("attachments")
    private List<AttachmentResource> attachments;
    @JsonProperty("name")
    private String name;
    @JsonProperty("planned_exe_time")
    private Long plannedExeTime;
    @JsonProperty("actual_exe_time")
    private Long actualExeTime;
    @JsonProperty("build_number")
    private String buildNumber;
    @JsonProperty("build_url")
    private String buildUrl;
    @JsonProperty("properties")
    private List<PropertyResource> properties;
    @JsonProperty("status")
    private String status;
    @JsonProperty("test_step_logs")
    private List<AutomationStepLog> testStepLogs;
    
    public AutomationTestLog() {
        this.links = new ArrayList<Link>();
        this.id = null;
        this.testCaseVersionId = null;
        this.exeStartDate = null;
        this.exeEndDate = null;
        this.note = null;
        this.attachments = new ArrayList<AttachmentResource>();
        this.name = null;
        this.plannedExeTime = null;
        this.actualExeTime = null;
        this.buildNumber = null;
        this.buildUrl = null;
        this.properties = new ArrayList<PropertyResource>();
        this.status = null;
        this.testStepLogs = new ArrayList<AutomationStepLog>();
    }
    
    public AutomationTestLog links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public AutomationTestLog addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public AutomationTestLog id(final Long id) {
        this.id = id;
        return this;
    }
    
    public Long getId() {
        return this.id;
    }
    
    public void setId(final Long id) {
        this.id = id;
    }
    
    public AutomationTestLog testCaseVersionId(final Long testCaseVersionId) {
        this.testCaseVersionId = testCaseVersionId;
        return this;
    }
    
    public Long getTestCaseVersionId() {
        return this.testCaseVersionId;
    }
    
    public void setTestCaseVersionId(final Long testCaseVersionId) {
        this.testCaseVersionId = testCaseVersionId;
    }
    
    public AutomationTestLog exeStartDate(final DateTime exeStartDate) {
        this.exeStartDate = exeStartDate;
        return this;
    }
    
    public DateTime getExeStartDate() {
        return this.exeStartDate;
    }
    
    public void setExeStartDate(final DateTime exeStartDate) {
        this.exeStartDate = exeStartDate;
    }
    
    public AutomationTestLog exeEndDate(final DateTime exeEndDate) {
        this.exeEndDate = exeEndDate;
        return this;
    }
    
    public DateTime getExeEndDate() {
        return this.exeEndDate;
    }
    
    public void setExeEndDate(final DateTime exeEndDate) {
        this.exeEndDate = exeEndDate;
    }
    
    public AutomationTestLog note(final String note) {
        this.note = note;
        return this;
    }
    
    public String getNote() {
        return this.note;
    }
    
    public void setNote(final String note) {
        this.note = note;
    }
    
    public AutomationTestLog attachments(final List<AttachmentResource> attachments) {
        this.attachments = attachments;
        return this;
    }
    
    public AutomationTestLog addAttachmentsItem(final AttachmentResource attachmentsItem) {
        this.attachments.add(attachmentsItem);
        return this;
    }
    
    public List<AttachmentResource> getAttachments() {
        return this.attachments;
    }
    
    public void setAttachments(final List<AttachmentResource> attachments) {
        this.attachments = attachments;
    }
    
    public AutomationTestLog name(final String name) {
        this.name = name;
        return this;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public AutomationTestLog plannedExeTime(final Long plannedExeTime) {
        this.plannedExeTime = plannedExeTime;
        return this;
    }
    
    public Long getPlannedExeTime() {
        return this.plannedExeTime;
    }
    
    public void setPlannedExeTime(final Long plannedExeTime) {
        this.plannedExeTime = plannedExeTime;
    }
    
    public AutomationTestLog actualExeTime(final Long actualExeTime) {
        this.actualExeTime = actualExeTime;
        return this;
    }
    
    public Long getActualExeTime() {
        return this.actualExeTime;
    }
    
    public void setActualExeTime(final Long actualExeTime) {
        this.actualExeTime = actualExeTime;
    }
    
    public AutomationTestLog buildNumber(final String buildNumber) {
        this.buildNumber = buildNumber;
        return this;
    }
    
    public String getBuildNumber() {
        return this.buildNumber;
    }
    
    public void setBuildNumber(final String buildNumber) {
        this.buildNumber = buildNumber;
    }
    
    public AutomationTestLog buildUrl(final String buildUrl) {
        this.buildUrl = buildUrl;
        return this;
    }
    
    public String getBuildUrl() {
        return this.buildUrl;
    }
    
    public void setBuildUrl(final String buildUrl) {
        this.buildUrl = buildUrl;
    }
    
    public AutomationTestLog properties(final List<PropertyResource> properties) {
        this.properties = properties;
        return this;
    }
    
    public AutomationTestLog addPropertiesItem(final PropertyResource propertiesItem) {
        this.properties.add(propertiesItem);
        return this;
    }
    
    public List<PropertyResource> getProperties() {
        return this.properties;
    }
    
    public void setProperties(final List<PropertyResource> properties) {
        this.properties = properties;
    }
    
    public AutomationTestLog status(final String status) {
        this.status = status;
        return this;
    }
    
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(final String status) {
        this.status = status;
    }
    
    public AutomationTestLog testStepLogs(final List<AutomationStepLog> testStepLogs) {
        this.testStepLogs = testStepLogs;
        return this;
    }
    
    public AutomationTestLog addTestStepLogsItem(final AutomationStepLog testStepLogsItem) {
        this.testStepLogs.add(testStepLogsItem);
        return this;
    }
    
    public List<AutomationStepLog> getTestStepLogs() {
        return this.testStepLogs;
    }
    
    public void setTestStepLogs(final List<AutomationStepLog> testStepLogs) {
        this.testStepLogs = testStepLogs;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final AutomationTestLog automationTestLog = (AutomationTestLog)o;
        return Objects.equals(this.links, automationTestLog.links) && Objects.equals(this.id, automationTestLog.id) && Objects.equals(this.testCaseVersionId, automationTestLog.testCaseVersionId) && Objects.equals(this.exeStartDate, automationTestLog.exeStartDate) && Objects.equals(this.exeEndDate, automationTestLog.exeEndDate) && Objects.equals(this.note, automationTestLog.note) && Objects.equals(this.attachments, automationTestLog.attachments) && Objects.equals(this.name, automationTestLog.name) && Objects.equals(this.plannedExeTime, automationTestLog.plannedExeTime) && Objects.equals(this.actualExeTime, automationTestLog.actualExeTime) && Objects.equals(this.buildNumber, automationTestLog.buildNumber) && Objects.equals(this.buildUrl, automationTestLog.buildUrl) && Objects.equals(this.properties, automationTestLog.properties) && Objects.equals(this.status, automationTestLog.status) && Objects.equals(this.testStepLogs, automationTestLog.testStepLogs);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links, this.id, this.testCaseVersionId, this.exeStartDate, this.exeEndDate, this.note, this.attachments, this.name, this.plannedExeTime, this.actualExeTime, this.buildNumber, this.buildUrl, this.properties, this.status, this.testStepLogs);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class AutomationTestLog {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        sb.append("    testCaseVersionId: ").append(this.toIndentedString(this.testCaseVersionId)).append("\n");
        sb.append("    exeStartDate: ").append(this.toIndentedString(this.exeStartDate)).append("\n");
        sb.append("    exeEndDate: ").append(this.toIndentedString(this.exeEndDate)).append("\n");
        sb.append("    note: ").append(this.toIndentedString(this.note)).append("\n");
        sb.append("    attachments: ").append(this.toIndentedString(this.attachments)).append("\n");
        sb.append("    name: ").append(this.toIndentedString(this.name)).append("\n");
        sb.append("    plannedExeTime: ").append(this.toIndentedString(this.plannedExeTime)).append("\n");
        sb.append("    actualExeTime: ").append(this.toIndentedString(this.actualExeTime)).append("\n");
        sb.append("    buildNumber: ").append(this.toIndentedString(this.buildNumber)).append("\n");
        sb.append("    buildUrl: ").append(this.toIndentedString(this.buildUrl)).append("\n");
        sb.append("    properties: ").append(this.toIndentedString(this.properties)).append("\n");
        sb.append("    status: ").append(this.toIndentedString(this.status)).append("\n");
        sb.append("    testStepLogs: ").append(this.toIndentedString(this.testStepLogs)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

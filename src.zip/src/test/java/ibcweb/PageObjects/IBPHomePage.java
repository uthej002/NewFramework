package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IBPHomePage extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//h1[text()='Welcome to Butterscotch']")
	WebElement txtButterscotchlogo;

	@FindBy(xpath = "//mat-icon[@svgicon='home']")
	WebElement txtHome;

	@FindBy(xpath = "//button[@id='openSide']")
	WebElement btnMenu;

	@FindBy(xpath = "//div[@class='search-container__filter']/button")
	WebElement btnSearch;

	@FindBy(xpath = "//input[@placeholder='Search benefit']")
	WebElement txtSearchBenefit;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Rules Builder ']")
	WebElement btnRuleBuilder;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Staging ']")
	WebElement btnStaging;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Production ']")
	WebElement btnProduction;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Libraries ']")
	WebElement btnLibraries;

	@FindBy(xpath = "//button[contains(@class,' mat-button mat-button-base ')]//span[text()=' Therapeutic ']")
	WebElement btnTherapeutic;

	@FindBy(xpath = "//div[@class='welcome-message']")
	WebElement txtWelcomeMessage;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Accounts ']")
	WebElement btnAccounts;

	@FindBy(xpath = "//div[@class='mat-list-item-content' and text()=' Logout ']")
	WebElement btnLogout;

	@FindBy(xpath = "//h1[contains(.,'My Tasks')]")
	WebElement hdrMyTask;

	@FindBy(xpath = "//span[contains(.,'In Progress')]")
	WebElement hdrInProgressSection;

	@FindBy(xpath = "//span[contains(.,'In Remediation')]")
	WebElement hdrInRemediationSection;

	@FindBy(xpath = "//span[contains(.,'In Client Review')]")
	WebElement hdrInClientReviewSection;

	@FindBy(xpath = "//h1[contains(.,'Remediation Required ')]")
	WebElement hdrRemediationRequiredSection;

	@FindBy(xpath = "//h1[contains(.,'Client Review Pending ')]")
	WebElement hdrClientReviewPending;

	@FindBy(xpath = "//b[contains(.,'View All')]")
	List<WebElement> lnkViewAll;

	@FindBy(xpath = "//div[@class='mat-title title'and text()='In Progress']")
	WebElement hdrInprogressHeader;

	@FindBy(xpath = "//div[@class='mat-title title'and text()='In Remediation']")
	WebElement hdrInRemediationHeader;

	@FindBy(xpath = "//div[@class='mat-title title'and text()='In Client Review']")
	WebElement hdrInClientReviewHeader;

	@FindBy(xpath = "//div[@class='mat-paginator-range-label']")
	WebElement txtHprecordscount;

	@FindBy(xpath = "//button[@aria-label='Previous page']")
	WebElement btnHpPreviousPage;

	@FindBy(xpath = "//button[@aria-label='Next page']")
	WebElement btnHpNextPage;

	@FindBy(xpath = "//td[@role='gridcell' and text()=' AG93438 ']")
	List<WebElement> AssigneeEachLineItem;

	@FindBy(xpath = "//div[@class='container__listing']")
	WebElement InprogressDataTable;

	@FindBy(xpath = "//div[@class='container__listing']")
	WebElement InRemediationDataTable;

	@FindBy(xpath = "//div[@class='container__listing']")
	WebElement InClientReviewDataTable;
	
	@FindBy(xpath = "(//span[normalize-space()='In Remediation']/../following-sibling::div//button)[1]")
	WebElement InRemediationViewAllLink;

	// Initializing the Page Objects:
	public IBPHomePage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	public boolean verifyButterscotchURL() {
		String currentURl = oneframeDriver.getCurrentUrl();
		OneframeLogger("URL is " + currentURl);
		ha.assertTrue(currentURl.contains("https://sit.ibp.ingenio-rx.com/admin/dashboard"),
				"Butterscotch Url is matching");
		return true;
	}

	@Step("Verify Accounts Section is not displayed")
	public boolean verifyNoAccountsSection() {
		if (FindObjectByLocatorNoWait(
				By.xpath("//div[@class='mat-list-item-content' and text()=' Accounts ']")) != null) {
			return true;
		} else {
			return false;
		}
	}

	@Step("Verify 'Butterscotch' header in Page")
	public boolean verifyButterscotchHeader() throws InterruptedException {
		boolean flag = false;
		WaitForApplicationToLoadCompletely();

		if (WaitForObject(txtButterscotchlogo)) {
			ClickWebObject(txtButterscotchlogo);
			OneframeLogger("Butterscotch Header is displayed");
			flag = true;
		}
		return flag;
	}

	public boolean verifyWelcomeMesaage() throws InterruptedException {
		boolean flag = false;
		WaitForApplicationToLoadCompletely();
		if (WaitForObjectVisibility(txtWelcomeMessage)) {
			ClickWebObject(txtWelcomeMessage);
			OneframeLogger("Welcome Message is displayed");
			flag = true;
		}
		return flag;
	}

	@Step("Verify Menu button is displayed and click on Menu Button")
	public void clickMenuButton() {
		WaitForObject(btnMenu);
		if (btnMenu.isDisplayed()) {
			OneframeLogger("Menu button is displayed");
			ClickWebObject(btnMenu);
			OneframeLogger("Menu Button is clicked");
		}
	}

	@Step("Verify Menu Buttom is displayed")
	public boolean verifyMenuButton() {
		boolean bln = false;
		WaitForObject(btnMenu);
		highlightElement(btnMenu);
		if (btnMenu.isDisplayed()) {
			bln = true;
			OneframeLogger("Menu button is displayed");
		}
		return bln;
	}

	@Step("Verify Search Button is displayed and click on Search Button")
	public void verifyandclickSearchButton() {
		WaitForObject(btnSearch);
		if (btnSearch.isDisplayed()) {
			OneframeLogger("Search button is displayed");
			ClickWebObject(btnSearch);
			OneframeLogger("Search Button is clicked");
		}
	}

	@Step("Verify Search Button is displayed")
	public boolean verifySearchButton() {
		boolean bln = false;
		WaitForObject(btnSearch);
		highlightElement(btnSearch);
		if (btnSearch.isDisplayed()) {
			bln = true;
			OneframeLogger("Search button is displayed");
		}
		return bln;
	}

	@Step("Verify Search Benefit Text Box")
	public boolean verifySearchBenefitTextBox() throws InterruptedException {
		boolean flag = false;
		WaitForApplicationToLoadCompletely();
		if (WaitForObject(txtSearchBenefit)) {
			ClickWebObject(txtSearchBenefit);
			OneframeLogger("Search Benefit Text Box is displayed");
			flag = true;
		}
		return flag;
	}

	@Step("Verify Rule Builder button is displayed and click on Rule Builder Button")
	public boolean clickRuleBuilder() throws InterruptedException {
		boolean flag = false;
		if (WaitForObject(btnRuleBuilder)) {
			ClickWebObject(btnRuleBuilder);
			OneframeLogger("Rule Builder is displayed and clicked");
			flag = true;
		}
		return flag;
	}

	@Step("Verify Staging Button is displayed")
	public boolean verifyStagingbuttondisplay() {
		boolean blnRC = false;
		WebObjectHandler.WaitForObjectVisibility(btnStaging);
		try {
			if (btnStaging.isDisplayed()) {
				highlightElement(btnStaging);
				OneframeLogger("Staging Button Title is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Staging Title is not displayed");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Staging link")
	public void clickStagingLink() {
		try {
			if (ObjectExist(btnStaging)) {
				ClickWebObject(btnStaging);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Staging link clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Staging link not displayed");
		}
	}

	@Step("Verify Staging Link is not displayed")
	public boolean verifyNoStagingLink() {
		if (FindObjectByLocatorNoWait(
				By.xpath("//div[@class='mat-list-item-content' and text()=' Staging ']")) != null) {
			return true;
		} else {
			return false;
		}
	}

	@Step("Verify Production Button is displayed")
	public boolean verifyProductionbuttondisplay() {
		boolean blnRC = false;
		WebObjectHandler.WaitForObjectVisibility(btnProduction);
		try {
			if (btnProduction.isDisplayed()) {
				highlightElement(btnProduction);
				OneframeLogger("Production Button button is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Production button is not displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Click on Production link")
	public void clickProductionLink() {
		try {
			if (ObjectExist(btnProduction)) {
				ClickWebObject(btnProduction);
				WaitForApplicationToLoadCompletely();
				OneframeLogger("Production link clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Production link not displayed");
		}
	}

	@Step("Close the Butterscotch App")
	public void closeApp() {
		oneframeDriver.close();
		OneframeLogger("Butterscotch App is closed");
	}

	@Step("Enter Benefit Text")
	public void EnterBenefit(String Benefit) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtSearchBenefit)) {
				// ClickWebObject(txtSearchBenefit);
				// txtSearchBenefit.sendKeys(Keys.CONTROL + "a");
				EnterText(txtSearchBenefit, Benefit);
				txtSearchBenefit.sendKeys(Keys.ENTER);
				OneframeLogger("Benefit ID Is Entered");
				WaitForObjectToBeInvisible(By.cssSelector("span.spinner"));
			} else {
				OneframeLogger("Benefit ID Is Not Entered");
			}
		} catch (StaleElementReferenceException SEP) {
		}
	}

	@Step("Click on Accounts")
	public void clickAccounts() {
		try {
			if (ObjectExist(btnAccounts)) {
				ClickWebObject(btnAccounts);
				OneframeLogger("Accounts button is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Acoounts button is not Clicked");
		}
	}

	@Step("Click on Logout")
	public void clickLogout() {
		/*
		 * try { if (FindObjectByLocatorNoWait(By.xpath("//button[@id='openSide']")) !=
		 * null) // if (WaitForObject(btnMenu)) { ClickWebObject(btnMenu);
		 * ClickWebObject(txtHome); ScrollToElement(btnLogout); //
		 * ScrollToBottomOfthePage(); ClickWebObject(btnLogout);
		 * OneframeLogger("Logout from the Application"); } else if
		 * (txtHome.isDisplayed()) { ScrollToElement(btnLogout);
		 * ClickWebObject(btnLogout); OneframeLogger("Logout from the Application"); } }
		 * catch (TimeoutException e) { OneframeLogger("Logout button is not Clicked");
		 * }
		 */
	}

	@Step("Verify pagination is implemented in InProgress Section ")
	public boolean verifyPaginationisimplementedinInProgressSession() throws InterruptedException {
		ScrollWebPageByPixel(100);
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(txtHprecordscount);
		highlightElement(txtHprecordscount);
		Thread.sleep(1000);
		OneframeLogger("The Records Count is " + txtHprecordscount.getText());
		highlightElement(btnHpPreviousPage);
		highlightElement(btnHpNextPage);
		return btnHpNextPage.isEnabled();
	}

	@Step("Verify My Task Header is displayed")
	public boolean verifyMyTaskHeader() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrMyTask);
		try {
			if (hdrMyTask.isDisplayed()) {
				highlightElement(hdrMyTask);
				OneframeLogger("My Task Header :" + hdrMyTask.getText());
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("MyTask Header is not displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify In Progress Section in My task widget")
	public boolean verifyInProgressSectioninMytask() {
		boolean blnRC = false;
		
		WaitForObjectVisibility(hdrInProgressSection);
		try {
			Thread.sleep(3000);
			if (hdrInProgressSection.isDisplayed()) {
				highlightElement(hdrInProgressSection);
				OneframeLogger("In Progess Section is displayed in MyTask widget");
				blnRC = true;
			}
		} catch (NoSuchElementException | InterruptedException toException) {
			OneframeLogger("InProgress Section is not displayed in MyTask Widget");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify In Progress Header is Displayed")
	public boolean verifyInProgressHeaderisDisplayed() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrInprogressHeader);
		try {
			if (hdrInprogressHeader.isDisplayed()) {
				highlightElement(hdrInprogressHeader);
				// neframeLogger("In Progess Header is displayed ");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("InProgress Header is not displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify In Progress data is Displayed")
	public boolean verifyInprogressdataTable() {
		boolean blnRC = false;
		WaitForObjectVisibility(InprogressDataTable);
		try {
			if (InprogressDataTable.isDisplayed()) {
				highlightElement(InprogressDataTable);
				// neframeLogger("In Progess Header is displayed ");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("InProgress Header is not displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify In InRemediation data is Displayed")
	public boolean verifyInRemediationDataTable() {
		boolean blnRC = false;
		WaitForObjectVisibility(InRemediationDataTable);
		try {
			if (InRemediationDataTable.isDisplayed()) {
				highlightElement(InRemediationDataTable);
				// neframeLogger("In Progess Header is displayed ");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("InProgress Header is not displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify In In Client Review data is Displayed")
	public boolean verifyInClientReviewDataTable() {
		boolean blnRC = false;
		WaitForObjectVisibility(InClientReviewDataTable);
		try {
			if (InClientReviewDataTable.isDisplayed()) {
				highlightElement(InClientReviewDataTable);
				// neframeLogger("In Progess Header is displayed ");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("InProgress Header is not displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify In Remediation Section in my Task Widget")
	public boolean verifyInRemediationSectioninMyTask() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrInRemediationSection);
		try {
			if (hdrInRemediationSection.isDisplayed()) {
				highlightElement(hdrInRemediationSection);
				OneframeLogger("In Remediation Section is displayed in My Task Widget");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify In Remediation Header is displayed")
	public boolean verifyInRemediationHeaderisDisplayed() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrInRemediationHeader);
		try {
			if (hdrInRemediationHeader.isDisplayed()) {
				highlightElement(hdrInRemediationHeader);
				// neframeLogger("In Progess Header is displayed ");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("InProgress Header is not displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify In Client Review Section in My Task Widget")
	public boolean verifyInClientReviewSectioninMyTask() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrInClientReviewSection);
		try {
			Thread.sleep(3000);
			if (hdrInClientReviewSection.isDisplayed()) {
				highlightElement(hdrInClientReviewSection);
				OneframeLogger("In Client Review Section is displayed in My Task Widget");
				blnRC = true;
			}
		} catch (NoSuchElementException | InterruptedException toException) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify In Client Review  Header is displayed")
	public boolean verifyInClientReviewHeaderisDisplayed() {
		boolean blnRC = false;
		WaitForObjectVisibility(hdrInClientReviewHeader);
		try {
			if (hdrInClientReviewHeader.isDisplayed()) {
				highlightElement(hdrInClientReviewHeader);
				// neframeLogger("In Progess Header is displayed ");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("InProgress Header is not displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify View All Link in In Progress Section in My task")
	public boolean verifyViewAllLinkinInProgressSection() {
		boolean blnRC = false;
		WaitForObjectVisibility(lnkViewAll.get(1));
		try {
			if (lnkViewAll.get(1).isDisplayed()) {
				highlightElement(lnkViewAll.get(1));
				OneframeLogger("View All Link is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("View All Link is Not Displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Click All Link in In Progress Section in My task")
	public boolean ClickViewAllLinkinInProgressSection() {
		boolean blnRC = false;
		ClickWebObject(txtWelcomeMessage);
		ClickWebObject(txtWelcomeMessage);
		ClickWebObject(txtWelcomeMessage);
		WaitForObjectVisibility(lnkViewAll.get(1));
		try {
			if (lnkViewAll.get(1).isDisplayed()) {
				highlightElement(lnkViewAll.get(1));
				ClickWebObject(lnkViewAll.get(1));
				OneframeLogger("View All Link is clicked in In progress Section in My Task Widget");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("View All Link is Not Clicked In In Progess Section in My Task Widget");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify View All Link in In Remediation Section in My Task Widget")
	public boolean verifyViewAllLinkinInRemediationSection() {
		boolean blnRC = false;
		WaitForObjectVisibility(InRemediationViewAllLink);
		try {
			if (InRemediationViewAllLink.isDisplayed()) {
				highlightElement(InRemediationViewAllLink);
				OneframeLogger("View All Link is displayed");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("View All Link is Not Displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Click All Link in In Remediation Section in My task")
	public boolean ClickViewAllLinkinInRemediationSection() {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		WaitForObjectVisibility(InRemediationViewAllLink);
		try {
			if (InRemediationViewAllLink.isDisplayed()) {
				highlightElement(InRemediationViewAllLink);
				ClickWebObject(InRemediationViewAllLink);
				OneframeLogger("View All Link is clicked in In Remediation Section in MY Task Widget");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("View All Link is not Clicked in In Remedition Section in My Task Widget");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify View All Link in In Client Review Section in My Task Widget")
	public boolean verifyViewAllLinkinInClientReviewSection() {
		boolean blnRC = false;
		ClickWebObject(txtWelcomeMessage);
		ClickWebObject(txtWelcomeMessage);
		ClickWebObject(txtWelcomeMessage);
		WaitForObjectVisibility(lnkViewAll.get(3));
		try {
			if (lnkViewAll.get(3).isDisplayed()) {
				highlightElement(lnkViewAll.get(3));
				OneframeLogger("View All Link is displayed in In Client Review Section");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("View All Link is Not Displayed");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Click All Link in In Client Review Section in My task")
	public boolean ClickViewAllLinkinInClientReviewSection() {
		boolean blnRC = false;
		ClickWebObject(txtWelcomeMessage);
		ClickWebObject(txtWelcomeMessage);
		ClickWebObject(txtWelcomeMessage);
		WaitForObjectVisibility(lnkViewAll.get(3));
		try {
			if (lnkViewAll.get(3).isDisplayed()) {
				highlightElement(lnkViewAll.get(3));
				ClickWebObject(lnkViewAll.get(3));
				OneframeLogger("View All Link is clicked in In Client Review Section in MY Task Widget");
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("View All Link is not Clicked in In Client Review Section in My Task Widget");
			blnRC = false;
		}
		return blnRC;

	}

	@Step("Verify Assignee is displayed")
	public boolean verifyAssigneeisDisplayed() {
		boolean blnRC = false;
		WaitForObjectVisibility(AssigneeEachLineItem.get(0));
		for (int i = 0; i < AssigneeEachLineItem.size(); i++) {
			highlightElement(AssigneeEachLineItem.get(0));
			if (!AssigneeEachLineItem.get(0).isDisplayed()) {
				blnRC = false;
				break;
			}
			blnRC = true;
		}
		return blnRC;
	}

	@Step("Click on Libraries")
	public void clickLibraries() {
		try {
			if (WaitForObject(btnLibraries)) {
				ClickWebObject(btnLibraries);
				OneframeLogger("Clicked on Libraries");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Libraries is not Clicked");
		}
	}

	@Step("Click Welcome Message")
	public void clickWelcomeMessage() {
		WaitForApplicationToLoadCompletely();
		txtWelcomeMessage.click();
		txtWelcomeMessage.click();
		txtWelcomeMessage.click();
		txtWelcomeMessage.click();
		txtWelcomeMessage.click();
		txtWelcomeMessage.click();
	}
	

}

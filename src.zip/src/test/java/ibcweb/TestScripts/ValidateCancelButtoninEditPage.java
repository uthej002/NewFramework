package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateCancelButtoninEditPage extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;
	IBPAddRulePage addrulepage;

	@BeforeClass
	@Step("Initializing Test Script for validating Cancel Button in Edit Functionality Page ")
	public void setUp() {
		InitializeLaunchPad("IBPW_44");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
		addrulepage = new IBPAddRulePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "RuleName","LibraryName" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "IBPW_44 Validate Cancel Button Edit Functinality RuleID Page", dataProvider = "TestData")
	@Description("Validate Cancel Button Edit Functinality RuleID Page")
	public void ValidateCancelButtoninEditFunctionalityPage(String TestCaseID, String TestStatus, String ruleName,String Library)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickLibrary(Library);
			//ruleid.getLatestVersionID(LibraryName, RuleName);
            String versionId = rulebuilderstaging.clickRule(Library, ruleName);
			ruleid.clickLatestVersionofRuleID(versionId);
			ruleid.verifyEditbuttondisplay();
			ruleid.clickEditButton();
			ruleid.clickEditCancelButton();
			sa.assertTrue(ruleid.verifyEditbuttondisplay(), "Verified Edit Button is displayed");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Cancel Button in Edit Functinality for RuleID is successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger(" Cancel Button in Edit Functinality for RuleID is unsuccessful");
		}
		
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

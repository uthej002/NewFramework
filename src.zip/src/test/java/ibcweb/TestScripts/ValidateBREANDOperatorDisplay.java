package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAddRulePage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateBREANDOperatorDisplay extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPAddRulePage addrulepage;
	IBPRuleIDPage ruleidpage;

	@BeforeClass
	@Step("Initializing Test Script for Validate AND Operator is displayed by default in Add Rule page")
	public void setUp() {
		InitializeLaunchPad("IBPW_9");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		addrulepage = new IBPAddRulePage();
		ruleidpage = new IBPRuleIDPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "StateId", "DType" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate AND Operator is displayed by default in Add Rule page", dataProvider = "TestData")
	@Description("Validate AND Operator is displayed by default in Add Rule page")
	public void ValidateANDOperator(String TestCaseID, String TestStatus, String ClientId, String LOBId, String StateId, String DType)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
			homepage.clickStagingLink();
			rulebuilderstaging.clickAddRuleButton();
			sa.assertTrue(addrulepage.verifyCreateaRuleHeader(),"Verified Create a Rule Header is displayed");
			sa.assertTrue(addrulepage.selectClientIdDropdown(ClientId),"Verified Client value has been selected");
			sa.assertTrue(addrulepage.selectLobIdDropdown(LOBId),"Verified LOB value has been selected");
			sa.assertTrue(addrulepage.selectStateIdDropdown(StateId),"Verified State value has been selected");
			addrulepage.clickAddButton();
			sa.assertTrue(addrulepage.verifyANDOperator(),"Verified AND Opeator has been displayed by default");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate AND Operator is displayed by default in Add Rule page is successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate AND Operator is displayed by default in Add Rule page");
		}
	

	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

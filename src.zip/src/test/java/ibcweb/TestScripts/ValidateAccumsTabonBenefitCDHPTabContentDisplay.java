package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateAccumsTabonBenefitCDHPTabContentDisplay extends OneframeContainer{
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating CDHP Field Level Values in Accums Tab on Benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_107");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "Benefit" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate CDHP Field Level Values in Accums Tab on Benefit", dataProvider = "TestData")
	@Description("Validate CDHP Field Level Values in Accums Tab on Benefit")
	public void ValidateCDHPFieldValuesinAccumsTab(String TestCaseID, String TestStatus, String Benefit)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");
			createbenefitpage.ClickEditButtoninWFE();
			accumsbenefitpage.clickOnAccumsTab();
			sa.assertTrue(accumsbenefitpage.verifyAccumsContentDisplay(), "Verified Accums Content is Displayed");
			accumsbenefitpage.disableAllToggles();
			accumsbenefitpage.enablerequireToggle("cdhp");
			sa.assertTrue(accumsbenefitpage.verifyCDHPLabel(), "Verified CDHP Label is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyFundedByLabel(), "Verified Funded By Label is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyFundedByDropdown(), "Verified Funded By Dropdown is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyPayerIDLabel(), "Verified Payer ID Label is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyPayerIDDropdown(), "Verified Payer ID Dropdown is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyHRABenefitLabel(), "Verified HRA Benefit Label is displayed");
			sa.assertTrue(accumsbenefitpage.verifyHRABenefitCheckbox(), "Verified HRA Benefit Checkbox is displayed");
			sa.assertTrue(accumsbenefitpage.verifyUpfrontDeductibleAppliesLabel(), "Verified Upfront Deductible Applies label is displayed");
			sa.assertTrue(accumsbenefitpage.verifyUpfrontDeductibleAppliesDropdown(), "Verified Upfront Deductible Applies Dropdown is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyHRALabel(), "Verified Apply HRA is displayed");
			sa.assertTrue(accumsbenefitpage.verifyHRAUpfrontDeductibleDropdown(), "Verified Apply HRA Upfront Deductible Dropdown is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyDeductibleHRADropdown(), "Verified Deductible HRA Dropdown is Displayed");
			sa.assertTrue(accumsbenefitpage.verifyCrossUFDEDLabel(), "Verified Cross UFDED and Deductible Label is displayed");
			sa.assertTrue(accumsbenefitpage.verifyCrossUFDEDDropdown(), "Verified Cross UFDED and Deductible Dropdown is displayed");
			sa.assertTrue(accumsbenefitpage.verifySplitHRALabel(), "Verified Split HRA Label is displayed");
			sa.assertTrue(accumsbenefitpage.verifySplitHRADropdown(), "Verified Split HRA Dropdown is displayed");
			sa.assertTrue(accumsbenefitpage.verifySplitHRATextField(), "Verified Split HRA Text Field is displayed");
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated CDHP Field Level Values in Accums Tab on Benefit Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate CDHP Field Level Values in Accums Tab on Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}


}

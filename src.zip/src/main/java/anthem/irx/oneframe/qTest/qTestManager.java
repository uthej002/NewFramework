package anthem.irx.oneframe.qTest;

import anthem.irx.oneframe.core.OneframeContainer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.qas.api.ClientConfiguration;
import org.qas.qtest.api.internal.model.FieldValue;
import org.qas.qtest.api.services.attachment.AttachmentService;
import org.qas.qtest.api.services.attachment.AttachmentServiceClient;
import org.qas.qtest.api.services.design.TestDesignService;
import org.qas.qtest.api.services.design.TestDesignServiceClient;
import org.qas.qtest.api.services.design.model.TestCase;
import org.qas.qtest.api.services.execution.TestExecutionService;
import org.qas.qtest.api.services.execution.TestExecutionServiceClient;
import org.qas.qtest.api.services.plan.TestPlanService;
import org.qas.qtest.api.services.plan.TestPlanServiceClient;
import org.qas.qtest.api.services.project.ProjectService;
import org.qas.qtest.api.services.project.ProjectServiceClient;
import org.qas.qtest.api.services.project.model.ListProjectRequest;
import org.qas.qtest.api.services.project.model.Project;
import org.qas.qtest.api.services.search.SearchService;
import org.qas.qtest.api.services.search.SearchServiceClient;
import org.qas.qtest.api.services.search.model.SearchArtifactRequest;
import org.qas.qtest.api.services.search.model.SearchResult;

public class qTestManager {
  QTestConnection qTestCon;
  
  String qTestEndPoint;
  
  ProjectService qTestProjectService;
  
  TestPlanService qTestTestPlanService;
  
  TestDesignService qTestTestDesignService;
  
  TestExecutionService qTestTestExecutionService;
  
  AttachmentService qTestAttachmentService;
  
  SearchService qTestSearchService;
  
  public qTestManager() {
    if (!OneframeContainer.loadedOneframeProperties && !OneframeContainer.loadedOneframeProperties) {
      OneframeContainer.OneframeLogger("Test is not executed via onframe launchpad");
      OneframeContainer ofctemp = new OneframeContainer();
      OneframeContainer.readOneframeConfiguration();
    } 
    if (OneframeContainer.ofcqTestEnabled == true) {
      this.qTestCon = new QTestConnection();
      this.qTestProjectService = (ProjectService)new ProjectServiceClient(this.qTestCon.QTestCredential);
      this.qTestProjectService.setEndpoint(OneframeContainer.ofcQTestHost);
      this.qTestTestPlanService = (TestPlanService)new TestPlanServiceClient(this.qTestCon.QTestCredential);
      this.qTestTestPlanService.setEndpoint(OneframeContainer.ofcQTestHost);
      this.qTestTestDesignService = (TestDesignService)new TestDesignServiceClient(this.qTestCon.QTestCredential);
      this.qTestTestDesignService.setEndpoint(OneframeContainer.ofcQTestHost);
      this.qTestTestExecutionService = (TestExecutionService)new TestExecutionServiceClient(this.qTestCon.QTestCredential);
      this.qTestTestExecutionService.setEndpoint(OneframeContainer.ofcQTestHost);
      this.qTestAttachmentService = (AttachmentService)new AttachmentServiceClient(this.qTestCon.QTestCredential);
      this.qTestAttachmentService.setEndpoint(OneframeContainer.ofcQTestHost);
      this.qTestSearchService = (SearchService)new SearchServiceClient(this.qTestCon.QTestCredential, new ClientConfiguration());
      this.qTestSearchService.setEndpoint(OneframeContainer.ofcQTestHost);
    } 
  }
  
  public long getQtestProjectID(String qTestProjectName) {
    boolean projFound = false;
    long projId = -1L;
    ListProjectRequest ProjectListRequest = new ListProjectRequest();
    List<Project> qTestProjects = this.qTestProjectService.listProject(ProjectListRequest);
    for (int i = 0; i < qTestProjects.size(); i++) {
      if (((Project)qTestProjects.get(i)).getName().equalsIgnoreCase(qTestProjectName)) {
        projFound = true;
        projId = ((Project)qTestProjects.get(i)).getId().longValue();
        break;
      } 
    } 
    if (projId == -1L)
      OneframeContainer.OneframeErrorLogger("Project [" + qTestProjectName + "] not found in qTest"); 
    return projId;
  }
  
  public HashMap<String, Object> getQTestCaseDetails(long ProjectID, String strAutomationContent) {
    HashMap<String, Object> testCaseDetailsMap = new HashMap<>();
    List<String> searchResultFields = Arrays.asList(new String[] { "id", "pid", "name", "description", "properties" });
    SearchArtifactRequest searchRequest = new SearchArtifactRequest();
    searchRequest.setProjectId(Long.valueOf(ProjectID));
    searchRequest.setFields(searchResultFields);
    searchRequest.setQuery("'Automation' = 'Yes' and 'Automation Content' = '" + strAutomationContent + "'");
    SearchResult<TestCase> TestCaseResults = this.qTestSearchService.searchTestCase(searchRequest);
    int testCaseCt = (int)TestCaseResults.getTotal();
    if (testCaseCt < 1) {
      OneframeContainer.OneframeErrorLogger("Test case with automation content - [" + strAutomationContent + "] not found in qTest,fix qTest test cases");
      System.exit(1);
    } else {
      OneframeContainer.OneframeLogger("Test case with automation content - [" + strAutomationContent + "] found in qTest,fix qTest test cases");
    } 
    List<TestCase> testcaseDetails = TestCaseResults.getItems();
    testCaseDetailsMap.put("TC_ID", ((TestCase)testcaseDetails.get(0)).getId());
    testCaseDetailsMap.put("TC_PID", ((TestCase)testcaseDetails.get(0)).getPid());
    testCaseDetailsMap.put("TC_name", ((TestCase)testcaseDetails.get(0)).getName());
    testCaseDetailsMap.put("TC_description", ((TestCase)testcaseDetails.get(0)).getDescription());
    List<FieldValue> testCaseFieldValues = ((TestCase)testcaseDetails.get(0)).getFieldValues();
    for (int i = 0; i < testCaseFieldValues.size(); i++) {
      FieldValue tcProperties = testCaseFieldValues.get(i);
      if (tcProperties.getProperty("field_name").toString().equalsIgnoreCase("Automation Content"))
        testCaseDetailsMap.put("TC_automation_content", tcProperties.getValue()); 
    } 
    return testCaseDetailsMap;
  }
  
  public long getQTestRunID(long ProjectID, long TC_id) {
    long testRunID = 0L;
    return testRunID;
  }
}
package anthem.irx.oneframe.utilities;

import anthem.irx.oneframe.core.OneframeContainer;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinUser;
import java.util.ArrayList;

public class NativeOperations {
  public static String getActiveWindowTitle() {
    WinDef.HWND activeWindow = User32.INSTANCE.GetForegroundWindow();
    int titleLength = User32.INSTANCE.GetWindowTextLength(activeWindow) + 1;
    char[] title = new char[titleLength];
    User32.INSTANCE.GetWindowText(activeWindow, title, titleLength);
    return Native.toString(title);
  }
  
  public static boolean minimizeActiveWindow() {
    WinDef.HWND activeWindow = User32.INSTANCE.GetForegroundWindow();
    return User32.INSTANCE.CloseWindow(activeWindow);
  }
  
  public static void closeActiveWindow() {
    WinDef.HWND activeWindow = User32.INSTANCE.GetForegroundWindow();
    closeWindow(activeWindow);
  }
  
  public static boolean findWindow(String WindowTitle) {
    WinDef.HWND hwnd = User32.INSTANCE.FindWindow(null, WindowTitle);
    if (hwnd != null)
      return true; 
    return false;
  }
  
  public static ArrayList<String> getCurrrentWindows() {
    final ArrayList<String> windowTitles = new ArrayList<>();
    final User32 user32 = User32.INSTANCE;
    user32.EnumWindows(new WinUser.WNDENUMPROC() {
          int count = 0;
          
          public boolean callback(WinDef.HWND hWnd, Pointer arg1) {
            char[] windowText = new char[512];
            user32.GetWindowText(hWnd, windowText, 512);
            String wText = Native.toString(windowText);
            WinDef.RECT rectangle = new WinDef.RECT();
            user32.GetWindowRect(hWnd, rectangle);
            if (wText.isEmpty() || !User32.INSTANCE.IsWindowVisible(hWnd) || rectangle.left <= -32000)
              return true; 
            windowTitles.add(wText);
            return true;
          }
        }, null);
    return windowTitles;
  }
  
  public static void printCurrentWindows() {
    ArrayList<String> windowTitles = getCurrrentWindows();
    for (String title : windowTitles)
      OneframeContainer.OneframeLogger(title); 
  }
  
  public static void maximizeWindow(String WindowTitle) {
    WinDef.HWND hwnd = User32.INSTANCE.FindWindow(null, WindowTitle);
    User32.INSTANCE.ShowWindow(hwnd, 3);
    User32.INSTANCE.SetForegroundWindow(hwnd);
  }
  
  public static void setFocusOnWindow(String WindowTitle) {
    WinDef.HWND hwnd = User32.INSTANCE.FindWindow(null, WindowTitle);
    User32.INSTANCE.ShowWindow(hwnd, 10);
    User32.INSTANCE.SetForegroundWindow(hwnd);
  }
  
  public static void closeWindow(String WindowTitle) {
    WinDef.HWND hwnd = User32.INSTANCE.FindWindow(null, WindowTitle);
    closeWindow(hwnd);
  }
  
  public static void quitWindow(String WindowTitle) {
    WinDef.HWND hwnd = User32.INSTANCE.FindWindow(null, WindowTitle);
    quitWindow(hwnd);
  }
  
  private static void closeWindow(WinDef.HWND ofhwnd) {
    User32.INSTANCE.PostMessage(ofhwnd, 16, null, null);
  }
  
  private static void quitWindow(WinDef.HWND ofhwnd) {
    User32.INSTANCE.PostMessage(ofhwnd, 18, null, null);
  }
}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateNetFormulariesFilterFunctionality extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;
	IBPLibrariesBaseFormularies baseFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validate Filter Functionality of Net Formularies")
	public void setUp() {
		InitializeLaunchPad("IBPW_398");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();
		baseFormulary = new IBPLibrariesBaseFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "LOBId", "Tiers", "StateId", "TierStructure",
				"Tags" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Filter Functionality of Net Formularies", dataProvider = "TestData")
	@Description("Validate Filter Functionality of Net Formularies")
	public void ValidateNetFormularyFilter(String TestCaseID, String TestStatus, String ClientId, String LOBId,
			String Tiers, String StateId, String TierStructure, String Tags)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			netFormulary.clickFormularyViewButton();
			sa.assertTrue(netFormulary.verifyFormularyHeader(), "Verified 'Formularies' header is displayed");
			netFormulary.clickNetFormularyTab();
			netFormulary.clickFormulariesHeader();

			controls.clickFilterButton();
			netFormulary.clickFormulariesHeader();

			String TiersId = netFormulary.selectAndGetTiersFilterDropdownValue(Tiers);
			String clientId = netFormulary.selectAndGetClientDropdownValue(ClientId);
			String lobId = netFormulary.selectAndGetLobFilterDropdownValue(LOBId);
			String StateIdVal = netFormulary.selectAndGetStateFilterDropdownValue(StateId);
			String TierStructureId = netFormulary.selectAndGetTiersStructureFilterDropdownValue(TierStructure);
			String TagsId = netFormulary.selectAndGetTagsFilterDropdownValue(Tags);

			controls.clickApplyFilterButton();
			netFormulary.clickFormulariesHeader();

			netFormulary.verifyTiersFilteredList(TiersId);
			baseFormulary.verifyClientFilteredList(clientId);
			baseFormulary.verifyLobFilteredList(lobId);
			baseFormulary.verifyStateFilteredList(StateIdVal);
			netFormulary.verifyTierStructureFilteredList(TierStructureId);
			netFormulary.verifyTagsFilteredList(TagsId);
			
			netFormulary.clickFormulariesHeader();
			baseFormulary.clickClearFilterButton();
			netFormulary.clickFormulariesHeader();

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Filter Functionality of Net Formularies is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Filter Functionality of Net Formularies");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibrariesCreateStateMandate extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;

	@BeforeClass
	@Step("Initializing Test Script for Validating Libraries State Mandate is created")
	public void setUp() {
		InitializeLaunchPad("IBPW_671");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType", "MarketSegment",
				"ProductType", "Other", "GeneralOverride", "NetworkOverride", "CostShareOverride", "AccumOverride" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Libraries State Mandate is created", dataProvider = "TestData")
	@Description("Validate Libraries State Mandate is created")
	public void ValidateStateMandateDynamicLayer(String TestCaseID, String TestStatus, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String AutoApply, String BusinessEntity,
			String BusinessUnit, String CDHP, String Formulary, String FundingType, String MarketSegment,
			String ProductType, String Other, String GeneralOverride, String NetworkOverride, String CostShareOverride,
			String AccumOverride) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			mandate.clickViewButtonofMandates();
			sa.assertTrue(mandate.verifyMandatesHeader(), "Verified 'Mandates header' is displayed");
			mandate.clickStateMandateTab();
			mandate.clickAddStateMandate();
			sa.assertTrue(mandate.verifyAddNewMandateHeader(), "Verified 'Add New Mandate' header is displayed");
			String mandateName = mandate.enterAndGetMandateName("State");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(librariesprogramspage.selectClientropdown(ClientId),
					"Verified and selected ClientID dropdown");
			sa.assertTrue(librariesprogramspage.selectLobdropdown(LOBId), "Verified and selected 'LOB dropdown' ");
			sa.assertTrue(librariesprogramspage.selectStatedropdown(StateId), "Verified and selected 'State dropdown'");
			sa.assertTrue(mandate.verifyFederalAutoApplyDropdown(), "Verified 'Auto Apply' dropdown is displayed");
			sa.assertTrue(mandate.selectFederalAutoApplyDropdown(AutoApply),
					"Verified and Selected 'Auto Apply' dropdown");
			sa.assertTrue(mandate.selectBusinessEntityDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(mandate.selectBusinessUnitDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' dropdown");
			sa.assertTrue(mandate.selectCDHPTypeDropdown(CDHP), "Verified and Selected 'CDHP Type' dropdown");
			sa.assertTrue(mandate.selectFormularyDropdown(Formulary), "Verified and Selected 'Formulary' dropdown");
			sa.assertTrue(mandate.selectFundingTypeDropdown(FundingType),
					"Verified and Selected 'Funding Type' dropdown");
			sa.assertTrue(mandate.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' dropdown");
			sa.assertTrue(mandate.selectProductTypeDropdown(ProductType),
					"Verified and Selected 'Product Type' dropdown");
			sa.assertTrue(mandate.selectOtherDropdown(Other), "Verified and Selected 'Others' dropdown");
			sa.assertTrue(mandate.selectGeneralOverrideDropdown(GeneralOverride),
					"Verified and Selected 'General OverRide' dropdown");
			sa.assertTrue(mandate.selectNetworkOverrideDropdown(NetworkOverride),
					"Verified and Selected 'Network OverRide' dropdown");
			sa.assertTrue(mandate.selectCostShareOverrideDropdown(CostShareOverride),
					"Verified and Selected 'CostShare OverRide' dropdown");
			sa.assertTrue(mandate.selectAccumsOverrideDropdown(AccumOverride),
					"Verified and Selected 'Accums OverRide' dropdown");
			sa.assertTrue(mandate.enterMandateDescription("State"), "Verified and Entered 'Mandate Description'");
			mandate.clickAddMandate();
			mandate.clickMandatesHeader();
			mandate.clickStateMandateTab();
			sa.assertTrue(mandate.VerifyMandateNameIsCreated(mandateName),
					"Verified the 'State Mandate Name' is created and present in the Mandate List");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Libraries State Mandate is created Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Libraries Create State Mandate");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

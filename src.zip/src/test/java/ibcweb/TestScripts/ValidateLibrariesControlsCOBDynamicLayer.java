package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibrariesControlsCOBDynamicLayer extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;

	@BeforeClass
	@Step("Initializing Test Script for Validating Libraries Controls COB Dynamic Layer Auto apply field is displayed")
	public void setUp() {
		InitializeLaunchPad("IBPW_X12");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit", "ClientId", "EffectiveDate", "LOBId",
				"StateId" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Libraries Controls COB Dynamic Layer Auto apply field is displayed", dataProvider = "TestData")
	@Description("Validate Libraries Controls COB Dynamic Layer Auto apply field is displayed")
	public void ValidateVersionEffectiveDate(String TestCaseID, String TestStatus, String Benefit, String ClientId,
			String EffectiveDate, String LOBId, String StateId) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on Libraries Section");
			controls.clickViewButtonofControls();
			sa.assertTrue(controls.verifyControlsHeader(), "Verified controls header");
			controls.clickCOBTab();
			controls.clickCreateCOBPackage();
			sa.assertTrue(controls.verifyCreateACOBPackageHeader(), "Verified Create a COB Package button");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(controls.selectClientropdown(ClientId), "Verified ClientID dropdown");
			sa.assertTrue(controls.selectLobdropdown(LOBId), "Verified LOB dropdown ");
			sa.assertTrue(librariesprogramspage.selectStatedropdown(StateId), "Verified State dropdown");
			sa.assertTrue(controls.verifyAutoApplyDropdown(), "Verified Auto Apply dropdown is displayed");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Libraries Controls COB Dynamic Layer Auto apply field is displayed Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Libraries Controls COB Dynamic Layer Auto apply field");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

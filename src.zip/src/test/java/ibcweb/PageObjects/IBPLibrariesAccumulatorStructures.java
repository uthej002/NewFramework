package ibcweb.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

public class IBPLibrariesAccumulatorStructures extends OneframeContainer {
	
	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();
	
	@FindBy(xpath = "//div[contains(text(),'Libraries')]")
	WebElement txtLibraries;

	@FindBy(xpath = "//a[@routerlink='/admin/library/accumulators/accumulator-structure']")
	WebElement btnView;
		
	@FindBy(xpath="//h2[text()='Accumulators structures']")
	WebElement hdrAccumulatorStructures;
	
	@FindBy(xpath="//span[text()=' Accumulator structure ']")
	WebElement tabAccumulatorStructures;
	
	@FindBy(xpath="//span[text()=' Vendor management ']")
	WebElement tabVendorManagement;
	
	@FindBy(xpath="//mat-icon[@svgicon='add-button']")
	WebElement btnAddAccumulatorStructures;
	
	@FindBy(xpath="//h3[text()='Add New Accum Structure']")
	WebElement hdrAddNewAccumulatorStructures;
	
	@FindBy(xpath="//input[@formcontrolname='name']")
	WebElement txtAccumName;
	
	@FindBy(xpath="//input[@formcontrolname='vendorPayerId']")
	WebElement txtVendorPayerID;
		
	@FindBy(xpath = "//input[@formcontrolname='terminationDate']")
	WebElement txtTermDate;
	
	
	@FindBy(xpath = "//*[@formcontrolname='clients']/..")
	WebElement newNetworkClientDropdown;

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> clientDropdown;

	@FindBy(xpath = "//*[@formcontrolname='lobs']")
	WebElement newNetworkLOBDropdown;

	@FindBy(xpath = "//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option/mat-pseudo-checkbox/following::span")
	List<WebElement> LOBDropdown;

	@FindBy(xpath = "//*[@formcontrolname='states']")
	WebElement newNetworkStateDropdown;
	
	@FindBy(xpath = "//span[@class='mat-option-text']")	
	List<WebElement> StateDropdown;
	
	@FindBy(xpath = "//div[@class='cdk-overlay-container']")
	WebElement cdkOverlay;
	
	@FindBy(xpath="//mat-select[@formcontrolname='lobs']//div[contains(@class, 'mat-select-arrow-wrapper ')]")
	WebElement drdLob;
	
	@FindBy(xpath="//span[text()=' Add Accum ']")
	WebElement btnAddAccum;
	
	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;
	
	@FindBy(xpath = "//*[@class='mat-paginator-icon']")
	List<WebElement> lstPageTraverseChevronButton;
	
	@FindBy(xpath="//td[@class='mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted']")
	List<WebElement> lstAccumName;
	
	@FindBy(xpath="//tbody[@role='rowgroup']//tr[@role='row']")
	List<WebElement> lstAccumItems;
	
	@FindBy(xpath="//tbody[@role='rowgroup']//tr[@role='row']")
	List<WebElement> lstVendorItems;
	
	@FindBy(xpath="//div[text()='Accum Details']")
	WebElement hdrAccumDetails;
	
	@FindBy(xpath="//h3[text()=' Vendor Management Code Details ']")
	WebElement hdrVendorDetails;
	
	@FindBy(xpath="//mat-icon[@svgicon='edit']")
	WebElement lnkEditButton;
	
	@FindBy(xpath="//span[text()='Save changes ']")
	WebElement btnSaveChages;
	
	@FindBy(xpath="//span[text()='Save Changes']")
	WebElement btnVendorSaveChages;
	
	@FindBy(xpath="//mat-icon[@svgicon='down-arrow']")
	WebElement lnkBackbutton;
	
	@FindBy(xpath="//h4[text()='Apply Defaults']")
	WebElement hdrApplyDefaults;
	
	@FindBy(xpath="//mat-slide-toggle[@formcontrolname='deductible']")
	WebElement tglApplyDeductible;
	
	@FindBy(xpath="//mat-slide-toggle[@formcontrolname='mop']")
	WebElement tglApplyMOP;
	
	@FindBy(xpath="//mat-slide-toggle[@formcontrolname='psl']")
	WebElement tglApplyPSL;
	
	@FindBy(xpath="//mat-slide-toggle[@formcontrolname='cdhp']")
	WebElement tglApplyCDHP;
	
	@FindBy(xpath="//mat-select[@data-automation-id='fundedBy']")
	WebElement drdFundedBy;
	
	@FindBy(xpath="//mat-option[@role='option']/span")
	List<WebElement> dropdownValues;
	
	@FindBy(xpath="//mat-select[@data-automation-id='payerId']")
	WebElement drdPayerID;
	
	@FindBy(xpath="//div[text()='CDHP']")
	WebElement tabCDHP;
	
	@FindBy(xpath="//div[text()='Deductible']")
	WebElement tabDeductible;
	
	@FindBy(xpath = "//tbody['rowgroup']/tr/td[1]")
	List<WebElement> lstAccumStructure;
	
	@FindBy(xpath = "//div[@class='mat-slide-toggle-thumb']")
	List<WebElement> tglAccumDeductibletoggles;
	
	@FindBy(xpath = "//*[@data-automation-id='individualInNetwork']")
	WebElement txtINNetwork;
	
	@FindBy(xpath = "//*[@data-automation-id='individualOutOfNetwork']")
	WebElement txtOutoFNetwork;
	
	@FindBy(xpath = "//*[@data-automation-id='familyInNetwork']")
	WebElement txtFamilyINNetwork;
	
	@FindBy(xpath = "//*[@data-automation-id='familyOutOfNetwork']")
	WebElement txtFamilyOutoFNetwork;
	
	@FindBy(xpath = "//*[@formcontrolname='numberMembersMeetAccum']")
	WebElement drpDwnnumberMeetAccum;
	
	@FindBy(xpath = "//*[@data-automation-id='applyIntegratedMedicalInNetwork']")
	WebElement drpDwnapplyIntegratedINN;
	
	@FindBy(xpath = "//*[@data-automation-id='applyIntegratedMedicalOutOfNetwork']")
	WebElement drpDwnapplyIntegratedOON;
	
	@FindBy(xpath = "//*[@formcontrolname='howDoesINNAndOONAccumulate']")
	WebElement drpDwnHowINNOONAccumulate;
	
	@FindBy(xpath = "//*[@formcontrolname='dedAppliesOop']")
	WebElement drpDwnDedAppliesOOP;
	
	@FindBy(xpath = "//*[@formcontrolname='embedded']")
	WebElement drpDwnEmbedded;
	
	@FindBy(xpath = "//*[@formcontrolname='deductibleWithPSL']")
	WebElement drpDwnDedwithPSL;
	
	@FindBy(xpath = "//*[@formcontrolname='lastQuarterRollover']")
	WebElement drpDwnlastQuarterRollover;
	
	@FindBy(xpath = "//*[@formcontrolname='crossNetwork']")
	WebElement drpDwnCrossNetwork;
	
	@FindBy(xpath = "//*[text()='Cancel ']")
	WebElement btnAccumStructureCancel;
	
	@FindBy(xpath = "//*[@formcontrolname='fundedBy']")
	WebElement drpDwnFundedBy;
	
	@FindBy(xpath = "//*[@formcontrolname='payerId']")
	WebElement drpDwnPayerId;
	
	@FindBy(xpath = "//*[@data-automation-id='enabled']")
	WebElement chkboxEnabled;
	
	@FindBy(xpath = "//*[@formcontrolname='applyPharmacy']")
	WebElement drpDwnApplyPharmacy;
	
	@FindBy(xpath = "//*[@formcontrolname='applyUpfrontDeductible']")
	WebElement drpDwnApplyUpfrontDeductible;
	
	@FindBy(xpath = "//*[@formcontrolname='upfrontDeductible']")
	WebElement drpDwnUpfrontDeductible;
	
	@FindBy(xpath = "//*[@formcontrolname='deductible']")
	WebElement drpDwnDeductible;
	
	@FindBy(xpath = "//*[@formcontrolname='applyHraOop']")
	WebElement drpDwnApplyHraOop;
	
	@FindBy(xpath = "//*[@formcontrolname='applyHraDaw']")
	WebElement drpDwnApplyHraDaw;
	
	@FindBy(xpath = "//*[@formcontrolname='crossUfdedDeductibleProcess']")
	WebElement drpDwncrossUfdedDeductibleProcess;
	
	@FindBy(xpath = "//*[@data-automation-id='splitHraEnabled']")
	WebElement drpDwnSplitHraEnabled;
	
	@FindBy(xpath = "//*[@data-automation-id='splitHraValue']")
	WebElement inputSplitHraValue;
	
	
		
	public IBPLibrariesAccumulatorStructures() {
		// Initializing the Page Objects
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}
	
	@Step("Verify and click Libraries Section on Menu bar")
	public boolean verifyAndClickLibrariesSection() {
		boolean flag = false;
		if (ObjectExist(txtLibraries)) {
			txtLibraries.isDisplayed();
			ClickWebObject(txtLibraries);
			OneframeLogger("Libraries section clicked");
			flag = true;
		}
		return flag;
	}
	
	@Step("Click View button of Accumulator Structures")
	public void clickViewButtonOfAccumulatorStructures() {
		if (ObjectExist(btnView)) {
			ClickWebObject(btnView);
			OneframeLogger("Accumulator Structures view button is clicked");
		}
	}
	
	@Step("Verify Accumulator Structures header is displayed")
	public boolean verifyAccumulatorStructuresHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAccumulatorStructures)) {
			if (hdrAccumulatorStructures.getText().equalsIgnoreCase("Accumulators structures")) {
				flag = true;
			}
		}
		return flag;
	}
	
	@Step("Click Accumulator Structure Tab")
	public void clickAccumulatorStructuresTab() {
		if (ObjectExist(tabAccumulatorStructures)) {
			ClickWebObject(tabAccumulatorStructures);
			OneframeLogger("Accumulator Structures Tab is clicked");
		}
	}
	
	@Step("Click Vendor Management Tab")
	public void clickVendorManagementTab() {
		if (ObjectExist(tabVendorManagement)) {
			ClickWebObject(tabVendorManagement);
			OneframeLogger("Vendor Management Tab is clicked");
		}
	}
	
	@Step("Click Add Accumulator Structure Button")
	public void clickAccumulatorStructuresButton() {
		if (ObjectExist(btnAddAccumulatorStructures)) {
			ClickWebObject(btnAddAccumulatorStructures);
			OneframeLogger("Add Accumulator Structures Button is clicked");
		}
	}
	
	@Step("Verify Add Accumulator Structure header is displayed")
	public boolean verifyAddAccumulatorStructureHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAddNewAccumulatorStructures)) {
			if (hdrAddNewAccumulatorStructures.getText().equalsIgnoreCase("Add New Accum Structure")){
				flag = true;
			}
		}
		return flag;
	}
	
	@Step("Get Random Alphabetical String")
	public String getRandomAlphabeticalString(int length) {
		String value = " ";
		String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		for (int i = 1; i < length; i++) {
			value += letters.charAt((int) Math.floor(Math.random() * letters.length()));
		}
		return "TESTAUTO" + value;
	}
	@Step("Enter a Random Value in Accum Name")
	public String EnterAccumStructureName() {
		String randomString = getRandomAlphabeticalString(5);
		// newNetFormularyNetFormularyNameTextField.clear();
		WaitForObjectVisibility(txtAccumName);
		txtAccumName.click();
		txtAccumName.sendKeys(randomString);
		OneframeLogger("Enter Random value In Accum Name Field : " + randomString);
		return randomString;
	}
	
	@Step("Enter a Random Value in Vendor Payer ID")
	public String EnterVendorPayerID() {
		String randomString = getRandomAlphabeticalString(5);
		// newNetFormularyNetFormularyNameTextField.clear();
		WaitForObjectVisibility(txtVendorPayerID);
		txtVendorPayerID.click();
		txtVendorPayerID.sendKeys(randomString);
		OneframeLogger("Enter Random value In Vendor Payer ID Field : " + randomString);
		return randomString;
	}
	
	@Step("Enter Term date")
	public void EnterTermDate(String TermDate) {
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(txtTermDate)) {
				ClickWebObject(txtTermDate);
				EnterText(txtTermDate, TermDate);
				OneframeLogger("Term Date has been Entered : " + txtTermDate.getAttribute("value"));
			}
		} catch (TimeoutException e) {
			OneframeLogger("Term Date has been Entered");
		}
	}
	
	@Step("Select Client Dropdown")
	public void selectClientDropdown() throws Throwable {
		newNetworkClientDropdown.click();
		clientDropdown.get(0).click();
//		ClickWebObject(cdkOverlay);
		Robot rt = new Robot();
		rt.keyPress(KeyEvent.VK_TAB);
		OneframeLogger("Selected first client dropdown ");
	}

	@Step("Select LOB Dropdown")
	public void selectLOBDropdown() throws Throwable {
		WaitForObjectVisibility(drdLob);
		drdLob.click();
		WaitForObjectVisibility(LOBDropdown.get(0));
		LOBDropdown.get(0).click();
		Robot rt = new Robot();
		rt.keyPress(KeyEvent.VK_TAB);
//		rt.keyRelease(KeyEvent.VK_TAB);
		OneframeLogger("Selected first LOB dropdown ");
	}

	@Step("Select State Dropdown")
	public void selectStateDropdown() {
		newNetworkStateDropdown.click();
		StateDropdown.get(0).click();
		ClickWebObject(cdkOverlay);
		OneframeLogger("Selected first State dropdown ");
	}
	
	@Step("Click Add Accum button")
	public void clickAddAccumButton() {
		btnAddAccum.click();
		btnAddAccum.click();
		OneframeLogger("Clicked Add Accum Button");
	}
	
	@Step("Verify Accum is created")
	public boolean VerifyAccumIsCreated(String accumName) throws InterruptedException {
		Thread.sleep(9000);
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPerPage <= totalRecords) {
				for (int i = 0; i < lstAccumName.size(); i++) {
					if (lstAccumName.get(i).getText().equalsIgnoreCase(accumName)) {
						highlightElement(lstAccumName.get(i));
						OneframeLogger("Accum is created : " + lstAccumName.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
					// clickMandatesHeader();
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException exc) {
		}
		return bln;
	}
	
	@Step("Click on First Accum Item")
	public void clickAccumItem() {
		ClickWebObject(hdrAccumulatorStructures);
		ClickWebObject(hdrAccumulatorStructures);
		ClickWebObject(hdrAccumulatorStructures);
		try {
			if(WaitForObjectVisibility(lstAccumItems.get(0))) {
				ClickWebObject(lstAccumItems.get(0));
				OneframeLogger("Clicked on the First Accum Structure Item");
			}
		}catch(NoSuchElementException NSE) {			
		}
	}
	
	@Step("Click on Last Vendor Item")
	public void clickVendorItem() {
		ClickWebObject(hdrAccumulatorStructures);
		ClickWebObject(hdrAccumulatorStructures);
		ClickWebObject(hdrAccumulatorStructures);
		try {
			if(WaitForObjectVisibility(lstVendorItems.get(lstVendorItems.size()-1))) {
				ClickWebObject(lstVendorItems.get(lstVendorItems.size()-1));
				OneframeLogger("Clicked on the Last Vendor Management Item");
			}
		}catch(NoSuchElementException NSE) {			
		}
	}
	
	@Step("Verify Accum Details header is displayed")
	public boolean verifyAccumDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAccumDetails)) {
			ClickWebObject(hdrAccumDetails);
			if (hdrAccumDetails.getText().equalsIgnoreCase("Accum Details")) {
				flag = true;
			}
		}
		return flag;
	}
	
	@Step("Verify Vendor Details header is displayed")
	public boolean verifyVendorDetailsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrVendorDetails)) {
			ClickWebObject(hdrVendorDetails);
			if (hdrVendorDetails.getText().equalsIgnoreCase("Vendor Management Code Details")) {
				flag = true;
			}
		}
		return flag;
	}
	
	@Step("Click Edit button in Details page")
	public void clickEditButton() {
//		ClickWebObject(hdrAccumDetails);
		lnkEditButton.click();
		OneframeLogger("Clicked on Edit button in Network Details page");
	}
	
	@Step("Edit the Accum details")
	public boolean EditAccumDetails() {
		boolean blnRC = false;
		try {
		ClickWebObject(hdrAccumDetails);
		WaitForObjectVisibility(txtAccumName);
		txtAccumName.sendKeys(Keys.CONTROL + "a");
		txtAccumName.sendKeys(Keys.DELETE);
		EnterAccumStructureName();
		OneframeLogger("Edited the Accum Structure Name");
		WaitForObjectVisibility(btnSaveChages);
		ClickWebObject(btnSaveChages);
		OneframeLogger("Clicked on Save Changes button and the changes are saved");
		ClickWebObject(lnkBackbutton);
		blnRC = true;
		}catch (NoSuchElementException NSE) {
			blnRC= false;
		}
		return blnRC;
	}
	
	@Step("Edit the Vendor details")
	public boolean EditVendorDetails() {
		boolean blnRC = false;
		try {
		ClickWebObject(hdrVendorDetails);
		WaitForObjectVisibility(txtVendorPayerID);
		txtVendorPayerID.sendKeys(Keys.CONTROL + "a");
		txtVendorPayerID.sendKeys(Keys.DELETE);
		EnterVendorPayerID();
		OneframeLogger("Edited the Vendor Payer ID");
		WaitForObjectVisibility(btnVendorSaveChages);
		ClickWebObject(btnVendorSaveChages);
		OneframeLogger("Clicked on Save Changes button and the changes are saved");
		ClickWebObject(lnkBackbutton);
		blnRC = true;
		}catch (NoSuchElementException NSE) {
			blnRC= false;
		}
		return blnRC;
	}
	
	@Step("Verify Apply Defaults header is displayed")
	public boolean verifyApplyDefaultsHeader() {
		boolean flag = false;
		if (ObjectExist(hdrApplyDefaults)) {
			ClickWebObject(hdrApplyDefaults);
			if (hdrApplyDefaults.getText().equalsIgnoreCase("Apply Defaults")) {
				flag = true;
			}
		}
		return flag;
	}
	
	
	@Step("Click on the CDHP Toggle")
	public boolean clickCDHPToggle() {
		boolean blnRc = false;
		if (ObjectExist(tglApplyCDHP)) {
//			ClickWebObject(tglApplyDeductible);
//			ClickWebObject(tglApplyMOP);
//			ClickWebObject(tglApplyPSL);
			ClickWebObject(tglApplyCDHP);
			blnRc = true;		
		}
		return blnRc;
	}
	
	@Step("Select Funded By Dropdown")
	public boolean selectFundedByDropdown() {
		boolean blnRC = false;
		try {
			if(WaitForObjectVisibility(drdFundedBy)) {
				ClickWebObject(drdFundedBy);
				WaitForObjectVisibility(dropdownValues.get(0));
				dropdownValues.get(0).click();
				blnRC = true;
			}				
		}catch(NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Select Payer ID Dropdown")
	public boolean selectPayerIDDropdown() {
		boolean blnRC = false;
		try {
			if(WaitForObjectVisibility(drdPayerID)) {
				ClickWebObject(drdPayerID);
				WaitForObjectVisibility(dropdownValues.get(0));
				dropdownValues.get(0).click();
				blnRC = true;
			}				
		}catch(NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Click on CDHP Tab")
	public void clickCDHPTab() {
		if (ObjectExist(tabCDHP)) {
			ClickWebObject(tabCDHP);
			OneframeLogger("Clicked on CDHP Tab");
		}
	}
	
	@Step("Click on Deductible Tab")
	public void clickDeductibleTab() {
		if (ObjectExist(tabDeductible)) {
			ClickWebObject(tabDeductible);
			OneframeLogger("Clicked on Deductible Tab");
		}
	}
	
	@Step("Click on the Deductible Toggle")
	public boolean clickDeductibleToggle() {
		boolean blnRc = false;
		if (ObjectExist(tglApplyDeductible)) {
//			ClickWebObject(tglApplyDeductible);
//			ClickWebObject(tglApplyMOP);
//			ClickWebObject(tglApplyPSL);
			ClickWebObject(tglApplyDeductible);
			blnRc = true;		
		}
		return blnRc;
	}
	
	@Step("Select any record from Libraries Accums Section")
	public boolean selectLibrariesAccumsRecord() throws InterruptedException {
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstAccumItems.size(); i++) {
					if (lstAccumItems.get(i).getText().contains("TESTAUTO")) {
						ClickWebObject(lstAccumItems.get(i));
//						OneframeLogger("Network is created : " + lstNetworkPackageName.get(i).getText());
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException exc) {

		}
		return bln;
	}
	
	@Step("Click on existing Accumulator Structure")
	public void clickonExistingAccumStructure() throws InterruptedException {
		try {

			Thread.sleep(500);

			if (WaitForObject(lstAccumStructure.get(0))) {
				ClickWebObject(lstAccumStructure.get(0));
				OneframeLogger("Clicked on existing Accumulator Structure");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Existing Accumulator Structure is not Clicked");
		}
	}

	
	@Step("Validate text {string} is displayed")
	public boolean validateAccumStructureLabels(String string) {
		
		try {
			WaitForApplicationToLoadCompletely();
			String xpath = String.format("//*[text() and normalize-space()='%s']", string);
			WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
			
			if(ele.isDisplayed()) {
				highlightElement(ele);
				sa.assertEquals(ele.getText().trim(), string, "Validate Actual Text matches with Expected Text");
				return true;
			}
			
			
		} catch (Exception e) {
			OneframeLogger("Actual Text and Expected Text did not match");
		}
		return false;
	}
	
	@Step("Verify Different Home Delivery Toggle is displayed in Deductible tab")
	public boolean verifyDifferentHomeDeliveryToggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglAccumDeductibletoggles.get(0))) {
				
				OneframeLogger("Different Home Delivery Toggle is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Out of Network and In Network Toggle is displayed in Deductible tab")
	public boolean verifyOutandInNetworksToggleDisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(tglAccumDeductibletoggles.get(1))) {
				
				OneframeLogger("Out of Network and In Network Toggle is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify IN Network text Field is displayed in Deductible tab")
	public boolean verifyInNetworkFielddisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtINNetwork)) {
				
				OneframeLogger("IN Network text Field is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify IN Network text Field is displayed in Deductible tab")
	public boolean verifyOutofNetworkFielddisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtOutoFNetwork)) {
				
				OneframeLogger("Out of Network text Field is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Family IN Network text Field is displayed in Deductible tab")
	public boolean verifyFamilyInNetworkFielddisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtFamilyINNetwork)) {
				
				OneframeLogger("Family IN Network text Field is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Family Out of Network text Field is displayed in Deductible tab")
	public boolean verifyFamilyOutofNetworkFielddisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(txtFamilyOutoFNetwork)) {
				
				OneframeLogger("Family Out of Network text Field is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Number of Members to Meet Accum dropdown is displayed in Deductible tab")
	public boolean verifyNumberofMembersdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnnumberMeetAccum)) {
				
				OneframeLogger("Number of Members to Meet Accum dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Apply Integrated Medical IN Network dropdown is displayed in Deductible tab")
	public boolean verifyApplyIntegratedINNdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnapplyIntegratedINN)) {
				
				OneframeLogger("Apply Integrated Medical IN Network dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Apply Integrated Medical Out of Network dropdown is displayed in Deductible tab")
	public boolean verifyApplyIntegratedOONdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnapplyIntegratedOON)) {
				
				OneframeLogger("Apply Integrated Medical Out of Network dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify How does INN and OON Accumulate dropdown is displayed in Deductible tab")
	public boolean verifyHowINNOONAccumulatedrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnHowINNOONAccumulate)) {
				
				OneframeLogger("How does INN and OON Accumulate dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Deductible applies to OOP dropdown is displayed in Deductible tab")
	public boolean verifyDedAppliesOOPdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnDedAppliesOOP)) {
				
				OneframeLogger("Deductible applies to OOP dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Embedded dropdown is displayed in Deductible tab")
	public boolean verifyEmbeddeddrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnEmbedded)) {
				
				OneframeLogger("Embedded dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Deductible with PSL dropdown is displayed in Deductible tab")
	public boolean verifyDedPSLdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnDedwithPSL)) {
				
				OneframeLogger("Deductible with PSL dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify last Quarter Rollover dropdown is displayed in Deductible tab")
	public boolean verifyLastQuarterRolloverdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnlastQuarterRollover)) {
				
				OneframeLogger("Last Quarter Rollover dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Cross Network dropdown is displayed in Deductible tab")
	public boolean verifyCrossNetworkdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnCrossNetwork)) {
				
				OneframeLogger("Cross Network dropdown is displayed in Deductible tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	

	@Step("Click on Cancel button")
	public void clickAccumStructureCancelButton() {
		btnAccumStructureCancel.click();
		OneframeLogger("Clicked on Cancel button");
	}

	
	@Step("Click on existing Accumulator Structure CDHP")
	public void clickonExistingAccumStructureCDHP() throws InterruptedException {
		try {

			Thread.sleep(500);

			if (WaitForObject(lstAccumStructure.get(2))) {
				ClickWebObject(lstAccumStructure.get(2));
				OneframeLogger("Clicked on existing Accumulator Structure CDHP");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Existing Accumulator Structure CDHP is not Clicked");
		}
	}
	
	@Step("Verify Funded By dropdown is displayed in CDHP tab")
	public boolean verifyFundedBydrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnFundedBy)) {
				
				OneframeLogger("Funded By dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Payer ID dropdown is displayed in CDHP tab")
	public boolean verifyPayerIDdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnPayerId)) {
				
				OneframeLogger("Payer ID dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify HRA applies to Pharmacy dropdown is displayed in CDHP tab")
	public boolean verifyHRAAppliestoPharmacydrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnApplyPharmacy)) {
				
				OneframeLogger("HRA applies to Pharmacy dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Apply Upfront Deductible dropdown is displayed in CDHP tab")
	public boolean verifyApplyUpfrontDeductibledrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnApplyUpfrontDeductible)) {
				
				OneframeLogger("Apply Upfront Deductible dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Upfront Deductible dropdown is displayed in CDHP tab")
	public boolean verifyUpfrontDeductibledrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnUpfrontDeductible)) {
				
				OneframeLogger("Upfront Deductible dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	
	@Step("Verify Deductible dropdown is displayed in CDHP tab")
	public boolean verifyDeductibledrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnDeductible)) {
				
				OneframeLogger("Deductible dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Apply HRA OOP dropdown is displayed in CDHP tab")
	public boolean verifyapplyHraOopdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnApplyHraOop)) {
				
				OneframeLogger("Apply HRA OOP dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Apply HRA Daw dropdown is displayed in CDHP tab")
	public boolean verifyapplyHraDawdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnApplyHraDaw)) {
				
				OneframeLogger("Apply HRA Daw dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Cross UFDED Deductible Process dropdown is displayed in CDHP tab")
	public boolean verifyCrossUfdeddrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwncrossUfdedDeductibleProcess)) {
				
				OneframeLogger("Cross UFDED Deductible Process dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Split HRA dropdown is displayed in CDHP tab")
	public boolean verifySplitHRAdrpDwndisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drpDwnSplitHraEnabled)) {
				
				OneframeLogger("Split HRA dropdown is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Verify Split HRA input Value field is displayed in CDHP tab")
	public boolean verifySplitHRAValuedisplayed() {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(inputSplitHraValue)) {
				
				OneframeLogger("Split HRA input Value field is displayed in CDHP tab");
						
				blnRC = true;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = true;
		}
		return blnRC;
	}
	
	@Step("Click on HRA Benefit Check Box")
	public void clickHRABenefitCheckBox() {
		chkboxEnabled.click();
		OneframeLogger("Clicked on HRA Benefit Check Box");
	}
}

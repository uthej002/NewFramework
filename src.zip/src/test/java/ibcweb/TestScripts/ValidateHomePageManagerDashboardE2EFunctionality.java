package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateHomePageManagerDashboardE2EFunctionality extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;

	@BeforeClass
	@Step("Initializing Test Script for Validate Manager Dashboard E2E Functionality")
	public void setUp() {
		InitializeLaunchPad("IBPW_977");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {
		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Manager Dashboard E2E Functionality", dataProvider = "TestData")
	@Description("Validate Manager Dashboard E2E Functionality")
	public void verifyPaginationIsImplementedInRemediationQueue(String TestCaseID, String TestStatus)
			throws AWTException, InterruptedException, IOException {
		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {

			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickManagerDashboardHeaderHomePage();
			welcomePage.clickManagerDashboardHeaderHomePage();
			welcomePage.clickManagerDashboardHeaderHomePage();
			welcomePage.clickViewAllButtonManagerDashboard();
			welcomePage.verifyHeaderManagerDashboard();
			welcomePage.clickManagerDashboard();
			welcomePage.verifyMessageInManagerDashboard();
			welcomePage.clickManagerDashboard();
			welcomePage.clickManagerDashboard();


			welcomePage.clickBenefitsCheckbox();
			String benefit = welcomePage.getBenefitName();
			String agId = welcomePage.getAGId();
			welcomePage.verifyReaasignButtonEnabled();
			welcomePage.clickReaasignButton();
			welcomePage.clickYesPopUpInManagerDashboard();
			welcomePage.clickProceedButton();
			welcomePage.verifyUserDetailsHeader();
			welcomePage.clickUserDetailsHeader();
			String assignee = welcomePage.enterAndGetAGIdInUserDetails(agId);
			welcomePage.clickUserDetailsCheckbox();
			welcomePage.clickReaasignButton();
			welcomePage.clickYesPopUpInManagerDashboard();
			welcomePage.verifyHeaderManagerDashboard();
			welcomePage.clickManagerDashboard();
			welcomePage.clickManagerDashboard();
			welcomePage.clickManagerDashboard();

			welcomePage.verifyBenefitAssignedToAssignee(benefit, assignee);

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Manager Dashboard E2E Functionality Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Manager Dashboard E2E Functionality");
		}
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();

		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}

}

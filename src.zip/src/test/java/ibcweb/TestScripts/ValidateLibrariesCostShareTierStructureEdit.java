package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibrariesCostShareTierStructureEdit extends OneframeContainer{
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;

	@BeforeClass
	@Step("Initializing Test Script for validating libraries Cost share structure edit functionality")
	public void setUp() {
		InitializeLaunchPad("IBPW_405");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		librariesCostShareStructurePage=new IBPLibrariesCostShareStructurePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validating libraries Cost share structure edit functionality", dataProvider = "TestData")
	@Description("Validate libraries Cost share structure edit functionality")
	public void ValidateLibrariesCostShareStructureEditFunctionality(String TestCaseID, String TestStatus)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),"Verified and clicked on Libraries Section");
			librariesCostShareStructurePage.clickViewButtonOfCostShareStructure();
			sa.assertTrue(librariesCostShareStructurePage.verifyCostShareStructureHeader(),"Cost Share Structure header is verified");
			librariesCostShareStructurePage.clickFirstRecordOfCostShareTierStructure();
			sa.assertTrue(librariesCostShareStructurePage.verifyCostShareStructureDetailsHeader(),"Cost Share Structure Details header is verified");
			librariesCostShareStructurePage.clickEditButton();
			String strucType=librariesCostShareStructurePage.editAndGetTextStructureType();
			String strucName=librariesCostShareStructurePage.editAndGetTextStructureName();
			String CostShareRows=librariesCostShareStructurePage.editAndGetCostShareRows();
			String content=librariesCostShareStructurePage.editAndGetStructureContent();
			librariesCostShareStructurePage.clickSaveChangesButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyTextChangesSaved(),"Changes saved message is verified");
			librariesCostShareStructurePage.clickBackButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyCostShareStructureHeader(),"Cost Share Structure header is verified");
			sa.assertTrue(librariesCostShareStructurePage.verifyEditedStructureTypeIsSame(strucType),"The edited Structure type value is same and its verified");
			sa.assertTrue(librariesCostShareStructurePage.verifyEditedStructureNameIsSame(strucName),"The edited Structure Name value is same and its verified");
			sa.assertTrue(librariesCostShareStructurePage.verifyEditedCostShareRowsIsSame(CostShareRows),"The edited Cost Share Rows value is same and its verified");
			sa.assertTrue(librariesCostShareStructurePage.verifyEditedStructureContentIsSame(content),"The edited Structure content value is same and its verified");
			sa.assertAll();
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated libraries Cost share structure edit functionality successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate libraries Cost share structure edit functionality");
		}
		sa.assertAll();
		homepage.clickLogout();
	}
	

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

		}


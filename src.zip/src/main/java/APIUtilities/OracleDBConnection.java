package APIUtilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.utilities.ConfigFileReader;

public class OracleDBConnection extends OneframeContainer {

	public static OracleDBConnection ibpDbInstance;
	public static String DB_URL;
	public static String DB_USER;
	public static String DB_PASSWORD;

	public static final String IBP_CONFIGURATION = "APIConfig.properties";
	public static final String IBP_CONFIG_FILE = CONFIG_FOLDER + IBP_CONFIGURATION;

	public static ConfigFileReader OneframeConfiguration = new ConfigFileReader(IBP_CONFIG_FILE);

	private static Statement stmt;
	private static String dbClass = "oracle.jdbc.OracleDriver";
	private static Connection con = null;

	public OracleDBConnection() {
	};

	public static OracleDBConnection getIepDBInstance() {
		return createObject();
	}

	private static OracleDBConnection createObject() {
		return ibpDbInstance = new OracleDBConnection();
	}

	public void readIBPConfigurations() {

		DB_URL = OneframeConfiguration.getProperty("dburloracle");
		DB_USER = OneframeConfiguration.getProperty("db_useridoracle");
		DB_PASSWORD = OneframeConfiguration.getProperty("db_passwordoracle");
	}

	// open
	public Connection getDataBaseConnection() {
		try {
			readIBPConfigurations();
			OneframeLogger("Connecting to database");
			Class.forName(dbClass).newInstance();
			// Get connection to DB
			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			// Statement object to send the SQL statement to the Database
			OneframeLogger("Connected to the database");
			return con;
		} catch (Exception e) {
			closeDataBaseConnection();
			OneframeLogger("Exception occured so closing connection to the database");
			e.printStackTrace();
			return con;
		}
	}

	public Connection getConnection() throws SQLException {
		if (con == null || con.isClosed()) {
			con = getDataBaseConnection();
		}
		return con;
	}

	// run
	public ResultSet executeDatebaseQuery(String query) throws Exception {
		getConnection();
		OneframeLogger("Query is " + query);
		ResultSet res = null;
		try {

			res = stmt.executeQuery(query);
			return res;

		} catch (Exception e) {
			closeDataBaseConnection();
			OneframeLogger("Closed connection to the database");
			e.printStackTrace();
		}
		return res;
	}

//close
	public void closeDataBaseConnection() {
		try {
			con.close();
			OneframeLogger("Closed connection to the database");
		} catch (Exception e) {
			OneframeLogger("Error closing connection to the database");
			e.printStackTrace();
		}
	}

	public Map<String, String> readValuesFronResultSet(String query) throws Exception {
		Map<String, String> dbDataToMap = new HashMap<String, String>();
		String tempStore = "";
		ResultSet resultSet;
		ResultSetMetaData resultSetMetaData;
		resultSet = executeDatebaseQuery(query);
		if (resultSet != null) {
			try {
				resultSetMetaData = resultSet.getMetaData();
				int columns = resultSetMetaData.getColumnCount();
				// OneframeLogger("Columns values size is " + columns);
				while (resultSet.next()) {
					for (int count = 1; count <= columns; count++) {
						if (resultSet.getObject(count) == null)
							tempStore = "";
						else
							tempStore = resultSet.getObject(count).toString().trim();
						dbDataToMap.put(resultSetMetaData.getColumnName(count).toString().trim(), tempStore);
					}
				}
			} catch (SQLException e) {
				closeDataBaseConnection();
			}
			return dbDataToMap;
		} else {
			OneframeLogger("Data from Db is null");
			return null;
		}
	}

	public List<HashMap<String, String>> getResultSet(String query) throws Exception {
		getConnection();
		List<HashMap<String, String>> dbDataToList = new ArrayList<HashMap<String, String>>();
		String tempStore = "";
		ResultSet resultSet;
		ResultSetMetaData resultSetMetaData;
		resultSet = executeDatebaseQuery(query);
		resultSetMetaData = resultSet.getMetaData();
		int columns = resultSetMetaData.getColumnCount();
		while (resultSet.next()) {
			HashMap<String, String> testData = new HashMap<String, String>();
			for (int count = 1; count <= columns; count++) {
				if (resultSet.getObject(count) == null) {
					tempStore = "";
				} else {
					tempStore = resultSet.getObject(count).toString().trim();
					testData.put(resultSetMetaData.getColumnName(count).toString().trim(), tempStore);
				}
			}
			dbDataToList.add(testData);
		}
		return dbDataToList;
	}

	public int getTotalRecordCountFromTable(String query) throws Exception {
		ResultSet resultSet = executeDatebaseQuery(query);
		/* resultSet.next(); */

		int totalRows = 0;
		try {
			resultSet.last();
			totalRows = resultSet.getRow();
			resultSet.beforeFirst();
		} catch (Exception ex) {
			return 0;
		}
		return totalRows;

//                           Long i = resultSet.getLong("COUNT(*)");
//                           return i;
	}

	public int getRows(ResultSet res) {
		int totalRows = 0;
		try {
			res.last();
			totalRows = res.getRow();
			res.beforeFirst();
		} catch (Exception ex) {
			return 0;
		}
		return totalRows;
	}

	public ResultSet getResultSetFromTable(String query) throws Exception {
		ResultSet resultSet = executeDatebaseQuery(query);
		/* resultSet.next(); */
		return resultSet;
	}

}

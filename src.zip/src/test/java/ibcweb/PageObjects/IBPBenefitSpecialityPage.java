package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeContainer;
import io.qameta.allure.Step;

public class IBPBenefitSpecialityPage extends OneframeContainer {

	@FindBy(xpath = "//div[text()=' Specialty ']")
	WebElement tabSpecialty;

	@FindBy(xpath = "//span[text()=' Add Specialty ']")
	WebElement lnkAddSpecialty;
	
	@FindBy(xpath="//div[@class='header__title']")
	WebElement txtAddaSpecialty;
	
	@FindBy(xpath="//span[text()=' Add to benefit ']")
	WebElement btnAddtoBenefit;
	
	@FindBy(xpath="//div[text()='Specialty - Plan']/..")
	WebElement SubTabSpecialtyPlan;
	
	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;
	
	@FindBy(xpath = "//*[@class='mat-paginator-icon']")
	List<WebElement> lstPageTraverseChevronButton;
	
	@FindBy(xpath="//mat-selection-list[@role='listbox']//mat-list-option[@role='option']/div")
	List<WebElement> lstBenefitPrograms;
	
	@FindBy(xpath="//tbody[@role='rowgroup']//tr[@role='row']//td[contains(@class, 'mat-column-programName ')]")
	List<WebElement> lstProgramNames;	
	
	@FindBy(xpath="//div[@class='header__title']")
	WebElement txtAddaProgram;
	
	@FindBy(xpath="//h3[text()='Specialty Setup']")
	WebElement hdrSpecialtySetup;
	
	@FindBy(xpath="//h3[text()='Program description']")
	List<WebElement> hdrProgramDescription;
	
	// Initializing the Page Objects:
	public IBPBenefitSpecialityPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on Specialty Tab")
	public void clickSpecialtyTab() {
		try {
			if (WaitForObjectVisibility(tabSpecialty)) {
				highlightElement(tabSpecialty);
				ClickWebObject(tabSpecialty);
				OneframeLogger("Specialty Tab in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Specialty Tab in Benefit is not clicked");
		}
	}

	@Step("Click on Add Specialty")
	public void clickAddSpecialtyButton() {
		try {
			if (WaitForObjectVisibility(lnkAddSpecialty)) {
				ClickWebObject(lnkAddSpecialty);
				OneframeLogger("Add Specialty in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Add Specialty in Benefit is not clicked");
		}
	}
	
	@Step("Click on Specialty-Plan Sub Tab")
	public void clickSpecialtyPlanSubTab() {
		try {
			if (WaitForObjectVisibility(SubTabSpecialtyPlan)) {
				highlightElement(SubTabSpecialtyPlan);
				ClickWebObject(SubTabSpecialtyPlan);
				OneframeLogger("Specialty-Plan in Benefit is clicked");
			}
		} catch (TimeoutException e) {
			OneframeLogger("Specialty-Plan in Benefit is not clicked");
		}
	}

//	@Step("Add Specfic Speciality Program into the benefit and verify whether it has been added or not")
//	public boolean addSpecificSpecialty(String programName) throws Throwable {
//		Thread.sleep(5000);
//		boolean blnRC = false;
//		try {
//			ClickWebObject(txtAddaSpecialty);
//			String element = String.format(
//					"//tbody[@role='rowgroup']//tr[@role='row']//td[contains(@class, 'mat-column-programName ') and text()=' %s ']",
//					programName);
//			WebElement addspecialty = oneframeDriver.findElement(By.xpath(element));
//			if (WaitForObjectVisibility(addspecialty)) {
//				ClickWebObject(addspecialty);
//				Thread.sleep(5000);
//				OneframeLogger("The Auto Apply as 'No' program has been selected for the benefit");
//				WaitForObjectVisibility(btnAddtoBenefit);
//				ClickWebObject(btnAddtoBenefit);
//				OneframeLogger("The Auto Apply as 'No' program has been added to the benefit");				
//				OneframeLogger("Clicked on Speciality in the benefit");
//				blnRC = true;
////				String elementone = String.format(
////						"//mat-selection-list[@role='listbox']//mat-list-option[@role='option']//div[text()=' %s ']",
////						programName);
////				WebElement addedspecialty = oneframeDriver.findElement(By.xpath(elementone));
////				WaitForObjectVisibility(addedspecialty);
////				OneframeLogger("The Specialty which has been added to the benefit :" + addedspecialty.getText());
////				ClickWebObject(addedspecialty);
////				String elementtwo = String.format("//h3[text()=' %s ']", programName);
////				WebElement hdrAddedSpecialty = oneframeDriver.findElement(By.xpath(elementtwo));							
////				if (programName.equalsIgnoreCase(hdrAddedSpecialty.getText())) {
////					blnRC = true;
////				}
//			}
//		} catch (StaleElementReferenceException SEF) {
//			blnRC = false;
//		}
//		return blnRC;
//	}
	@Step("Click on Add Specialty Text")
	public void clickAddaSpecialty() {
	     ClickWebObject(txtAddaSpecialty);
	     ClickWebObject(txtAddaSpecialty);
	     ClickWebObject(txtAddaSpecialty);
	}
	@Step("Add Specfic Specialty into the benefit and verify whether it has been added or not")
	public boolean addSpecificSpecialty(String programName,String subTabName) throws Throwable {
		boolean blnRC = false;
		String xpath = "//tbody[@role='rowgroup']//tr[@role='row']//td[contains(@class, 'mat-column-programName ')][text()=' "+programName+" ']";
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split(" ");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());
			
			// Dividing totalRecords by 5 because there are only 5 records per page
			int numberOfPages = Math.round(totalRecords/5) + 1;
			
			if(numberOfPages != 0) {
				for(int i=0; i<numberOfPages; i++) {
					try {
						WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
						if(WaitForObjectVisibility(ele)) {
							ClickWebObject(ele);
							//OneframeLogger("Program is Selected : " +ele.getText());
							break;
						}
					}
					catch (NoSuchElementException e) {
						 ClickWebObject(lstPageTraverseChevronButton.get(1));
						 ClickWebObject(txtPageNumber); 
						 ClickWebObject(txtPageNumber);
						 WaitForApplicationToLoadCompletely();
					}
					
				}
			}
						
			WaitForObjectVisibility(btnAddtoBenefit);
			ClickWebObject(btnAddtoBenefit);
			if(btnAddtoBenefit.isDisplayed()) {
				ClickWebObject(btnAddtoBenefit);
			}
			OneframeLogger("The Auto Apply program has been added to the benefit");
			String element = String.format(
					"//div[text()='%s']",subTabName);
			WebElement tabName = oneframeDriver.findElement(By.xpath(element));
			WaitForObjectVisibility(tabName);
			ClickWebObject(tabName);
			OneframeLogger("Clicked on "+tabName.getText()+" in the benefit");
			WaitForObjectVisibility(lstBenefitPrograms.get(0));
			ScrollToBottomOfthePage();
			Thread.sleep(5000);
		    for(WebElement ele : lstBenefitPrograms) {		       
		    	if (programName.equalsIgnoreCase(ele.getText())) {
		    		ClickWebObject(ele);
		    		OneframeLogger("The Program which has been added to the benefit :"+ele.getText());	
		    		WebElement hdrAddedProgram = oneframeDriver.findElement(By.xpath("//div[@class='title']"));
		    		WaitForObjectVisibility(hdrAddedProgram);
		    		highlightElement(hdrAddedProgram);
					blnRC = true;
				}
		    }
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}	

	
	@Step("Verify whether Specialty is not displayed when Auto Apply as No while creating the benefit")
	public boolean verifySpecialtyNotDisplay() {
		boolean blnRC=false;
		WaitForObjectVisibility(SubTabSpecialtyPlan);
		try {
			if(FindObjectByLocatorNoWait(By.xpath("//div[@class='left-panel']//mat-selection-list[@role='listbox']"))!=null) {
				blnRC=true;
			}
		}catch(NoSuchElementException NSE) {
			blnRC=false;
		}
		return blnRC;
	}
	
	@Step("Add any Specialty into the benefit and verify whether it has been added or not")
	public boolean addRandomSpecialty(String subTabName) throws Throwable {
		Thread.sleep(5000);
		ClickWebObject(txtAddaProgram);
		ClickWebObject(txtAddaProgram);
		ClickWebObject(txtAddaProgram);
		boolean blnRC = false;
		try {
			WaitForApplicationToLoadCompletely();
			WaitForObjectVisibility(lstProgramNames.get(0));
			ClickWebObject(lstProgramNames.get(0));
			String value = lstProgramNames.get(0).getText();
			OneframeLogger("Program is Selected : " +value );
			//WaitForObjectVisibility(btnAddtoBenefit);
			//ClickWebObject(btnAddtoBenefit);
			ClickWebObject(txtAddaProgram);
			ClickWebObject(txtAddaProgram);
			if(btnAddtoBenefit.isEnabled()) {
				ClickWebObject(btnAddtoBenefit);
			}
			OneframeLogger("The Auto Apply program has been added to the benefit");
			ClickWebObject(hdrSpecialtySetup);
			ClickWebObject(hdrSpecialtySetup);
			ClickWebObject(hdrSpecialtySetup);
			String element = String.format(
					"//div[text()='%s']",subTabName);
			WebElement tabName = oneframeDriver.findElement(By.xpath(element));
			WaitForObjectVisibility(tabName);
			ClickWebObject(tabName);
			OneframeLogger("Clicked on "+tabName.getText()+" in the benefit");
			Thread.sleep(3000);
			WaitForObjectVisibility(lstBenefitPrograms.get(0));
		    for(WebElement ele : lstBenefitPrograms) {		       
		    	if (value.equalsIgnoreCase(ele.getText())) {
		    		ClickWebObject(ele);
		    		OneframeLogger("The Program which has been added to the benefit :"+ele.getText());	
		    		WebElement hdrAddedProgram = oneframeDriver.findElement(By.xpath("//div[@class='title']"));
		    		WaitForObjectVisibility(hdrAddedProgram);
		    		highlightElement(hdrAddedProgram);
					blnRC = true;
				}
		    }
		} catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}	
	
	@Step("Verify Program Description header is displayed")
	public boolean verifyProgramDescriptionHeaderIsDisplayed() {
		boolean flg = false;
		
			for(WebElement ele: hdrProgramDescription) {
				if(WaitForObjectVisibility(ele)) {
					highlightElement(ele);
					flg = true;
				}
				else {
					return false;
				}
			}
		
		return flg;
	}

}

package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPAccumsBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidatethedeductibletabinAccumsofbenefit extends OneframeContainer {
	
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPAccumsBenefitPage accumsbenefitpage;
	IBPCreateBenefitPage createbenefitpage;

	@BeforeClass
	@Step("Initializing Test Script for validating Verify the deductible tab in Accums of benefit")
	public void setUp() {
		InitializeLaunchPad("IBPW_663");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		accumsbenefitpage = new IBPAccumsBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
	}
	
	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = {  "TestCaseID", "TestStatus", "Benefit" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}
	
	@Test(description = "Validate the deductible tab in Accums of benefit", dataProvider = "TestData")
	@Description("Validate the deductible tab in Accums of benefit ")
	public void ValidatethedeductibletabinAccumofbenefit(String TestCaseID, String TestStatus, String Benefit)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		
		if (loginpage.MemberLogin()) {	
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(createbenefitpage.verifyCreatedBenefitHeader(), "Verified Given Benefit header is displayed");
			createbenefitpage.ClickEditButtoninWFE();
			accumsbenefitpage.clickOnAccumsTab();
			sa.assertTrue(accumsbenefitpage.verifyAccumsContentDisplay(), "Verified Accums Content is Displayed");
			accumsbenefitpage.disableAllToggles();
			accumsbenefitpage.enablerequireToggle("deductible");
			sa.assertTrue(accumsbenefitpage.verifyDeductibleButtonDisplay(),"Verified Deductible Button is displayed");
			accumsbenefitpage.clickOntheDeductibleinAccumsTab();
			sa.assertTrue(accumsbenefitpage.verifyIndividualLabel(),"Verified Individual label");
			sa.assertTrue(accumsbenefitpage.verifyIndividualDeductibleInNetworkField(),"Verified Individual Deductible InNetwork Field is displayed");
			sa.assertTrue(accumsbenefitpage.verifyIndividualDeductibleOutNetworkField(),"Verified Individual Deductible outNetwork Field is displayed");
			sa.assertTrue(accumsbenefitpage.verifyFamilyDeductibleInNetworkField(),"Verified Family Deductible InNetwork Field is displayed");
			sa.assertTrue(accumsbenefitpage.verifyFamilyDeductibleOutNetworkField(),"Verified Family Deductible OutNetwork Field is displayed");
			sa.assertTrue(accumsbenefitpage.verifyNumberOfMembersToMeetAccum(),"Verified Number Of Members To Meet Accum is displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyIntegratedMedicalInNetworkField(),"Verified Apply Integrated Medical InNetwork Field is displayed");
			sa.assertTrue(accumsbenefitpage.verifyApplyIntegratedMedicalOutNetworkField(),"Verified Apply Integrated Medical OutNetwork Field is displayed");
			sa.assertTrue(accumsbenefitpage.verifyINNOONLabel(),"Verify INN and OON Accumulate Values is displayed");
			accumsbenefitpage.clickOnHowdoesINNandOONDropdown();
			sa.assertTrue(accumsbenefitpage.HowdoesINNandOONAccumulate(),"How does INN and OON Accumulate is displayed");
			sa.assertTrue(accumsbenefitpage.verifyDeductibleappliestoOOP(),"Verify Deductible applies to OOP is displayed");
			sa.assertTrue(accumsbenefitpage.verifyEmbeddedLabel(),"verify Embedded Label");
			sa.assertTrue(accumsbenefitpage.verifyEmbeddedDropdown(),"verify Embedded Dropdown");
			sa.assertTrue(accumsbenefitpage.DeductiblewithPSL(),"Deductible with PSL()");
			sa.assertTrue(accumsbenefitpage.verifyLastQuarterRollover(),"Verified Last Quarter Rollover is displayed");
			sa.assertTrue(accumsbenefitpage.verifyCrossNetworkLabel(),"Verified Cross Network Label is displayed");
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated enable and disable toggles in Accums Tab on Benefit successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to validate enable and disable toggles in Accums Tab on Benefit");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}
	


}

package anthem.irx.oneframe.utilities;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

public class DateTimeProcessor {
  private static LocalDate getLocalDate() {
    return LocalDate.now();
  }
  
  public static String getCurrentDate() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-YYYY");
    return formatter.format(getLocalDate());
  }
  
  public static String getCurrentDate(String dateformat) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateformat);
    return formatter.format(getLocalDate());
  }
  
  private static ZoneId getConfiguredTimeZone() {
    return ZoneId.of("America/New_York");
  }
  
  private static Instant getDatetime() {
    return Instant.now();
  }
  
  public static String getCurrentTime() {
    ZonedDateTime ofzonedatetime = ZonedDateTime.ofInstant(getDatetime(), getConfiguredTimeZone());
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hhmmssa");
    return formatter.format(ofzonedatetime);
  }
  
  public static String getCurrentDateTime() {
    ZonedDateTime ofzonedatetime = ZonedDateTime.ofInstant(getDatetime(), getConfiguredTimeZone());
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddmmyyyy_hhmmssa");
    return formatter.format(ofzonedatetime);
  }
  
  public static String getCurrentDateTime(String strformat) {
    ZonedDateTime ofzonedatetime = ZonedDateTime.ofInstant(getDatetime(), getConfiguredTimeZone());
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(strformat);
    return formatter.format(ofzonedatetime);
  }
  
  public static Set<String> getZoneIDs() {
    return ZoneId.getAvailableZoneIds();
  }
}

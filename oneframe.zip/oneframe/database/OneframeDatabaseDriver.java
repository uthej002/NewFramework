// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.database;

import java.sql.Statement;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.util.Properties;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import java.sql.Connection;
import java.util.HashMap;
import java.sql.ResultSet;

public class OneframeDatabaseDriver
{
    protected String ofDBurl;
    protected String ofDBMS;
    protected String ofDBname;
    protected String ofDBusername;
    protected String ofDBpassword;
    protected String ofDBParameters;
    protected ResultSet ofQueryResultSet;
    private HashMap<String, String> DBConfigMap;
    private Connection ofDBconn;
    OneframeSoftAssert ofsa;
    
    public OneframeDatabaseDriver() {
        this.ofDBconn = null;
    }
    
    public OneframeDatabaseDriver OpenDBConnection(final String dbReference) {
        this.ofsa = new OneframeSoftAssert();
        if (OneframeContainer.AppConfigDBMap.containsKey(dbReference)) {
            this.DBConfigMap = OneframeContainer.AppConfigDBMap.get(dbReference);
            this.ofDBurl = this.DBConfigMap.get(".dburl");
            if (this.ofDBurl == null) {
                OneframeContainer.OneframeErrorLogger("DB URL is missing for configuration -> : " + dbReference);
                OneframeContainer.OneframeErrorLogger("Next Steps: \n 1. Open Applications.properties file under Configurations folder under src/test/resources \n 2. Update DB connection information (you can configure multiple databases references");
                System.exit(0);
            }
            final String[] dbURLdetails = this.ofDBurl.split(":");
            if (dbURLdetails.length > 0) {
                this.ofDBMS = dbURLdetails[0].toLowerCase();
            }
            else {
                OneframeContainer.OneframeLogger("Error found in DB configuration -> : " + this.ofDBurl);
            }
            this.ofDBusername = this.DBConfigMap.get(".username");
            this.ofDBpassword = this.DBConfigMap.get(".password");
            this.DBConfigMap.forEach((key, value) -> OneframeContainer.OneframeLogger("[ONEFRAME]" + key + " : " + value));
            if (this.ofDBMS.isEmpty() || this.ofDBMS == null || this.ofDBMS.trim() == "") {
                OneframeContainer.OneframeLogger("Database configuration is missing for reference : " + dbReference);
                System.exit(0);
            }
            final Properties connectionProps = new Properties();
            connectionProps.put("user", this.ofDBusername);
            connectionProps.put("password", this.ofDBpassword);
            final String ConnURL = "jdbc:" + this.ofDBurl;
            try {
                OneframeContainer.OneframeLogger("Initializing database connection object.........");
                this.ofDBconn = DriverManager.getConnection(ConnURL, connectionProps);
            }
            catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
            if (this.ofDBconn == null) {
                return null;
            }
            OneframeContainer.OneframeLogger("Connection to database......Success");
        }
        else {
            OneframeContainer.OneframeLogger("Database configuration is missing for reference : " + dbReference);
        }
        return this;
    }
    
    public ResultSet executeSQLQueryAndgetResultSetObject(final String sqlQuery) {
        try {
            final Statement sqlStatObj = this.ofDBconn.createStatement(1004, 1007);
            OneframeContainer.OneframeLogger("Execute SQL Query : [" + sqlQuery + "]");
            this.ofQueryResultSet = sqlStatObj.executeQuery(sqlQuery);
            if (this.isResultSetEmpty()) {
                OneframeContainer.OneframeLogger("Total number of records returned by the query : " + this.getTotalRecordsCount());
                this.ofQueryResultSet.beforeFirst();
            }
            else {
                OneframeContainer.OneframeLogger("The query returned zero records");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return this.ofQueryResultSet;
    }
    
    public OneframeDatabaseDriver executeSQLQuery(final String sqlQuery) {
        try {
            final Statement sqlStatObj = this.ofDBconn.createStatement(1004, 1007);
            OneframeContainer.OneframeLogger("Execute SQL Query : [" + sqlQuery + "]");
            this.ofQueryResultSet = sqlStatObj.executeQuery(sqlQuery);
            if (this.isResultSetEmpty()) {
                OneframeContainer.OneframeLogger("Total number of records returned by the query : " + this.getTotalRecordsCount());
                this.ofQueryResultSet.beforeFirst();
            }
            else {
                OneframeContainer.OneframeLogger("The query returned zero records");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return this;
    }
    
    public OneframeDatabaseDriver executeSQLFunctionsQuery(final String sqlQuery) {
        try {
            final Statement sqlStatObj = this.ofDBconn.createStatement();
            OneframeContainer.OneframeLogger("Execute SQL Query : [" + sqlQuery + "]");
            (this.ofQueryResultSet = sqlStatObj.executeQuery(sqlQuery)).next();
            OneframeContainer.OneframeLogger("Query Result : " + this.ofQueryResultSet.getObject(1));
        }
        catch (SQLException e) {
            if (e.getMessage().contains("java.sql.SQLException: No row found.")) {
                return null;
            }
            e.printStackTrace();
        }
        return this;
    }
    
    public ResultSet executeSQLFunctionsQueryAndgetResultSetObject(final String sqlQuery) {
        try {
            final Statement sqlStatObj = this.ofDBconn.createStatement();
            OneframeContainer.OneframeLogger("Execute SQL Query : [" + sqlQuery + "]");
            (this.ofQueryResultSet = sqlStatObj.executeQuery(sqlQuery)).next();
            OneframeContainer.OneframeLogger("Query Result : " + this.ofQueryResultSet.getObject(1));
        }
        catch (SQLException e) {
            if (e.getMessage().contains("java.sql.SQLException: No row found.")) {
                return null;
            }
            e.printStackTrace();
        }
        return this.ofQueryResultSet;
    }
    
    public int executeCURDSQLQuery(final String sqlQuery) {
        int intNbrOfRows = -1;
        try {
            final Statement sqlStatObj = this.ofDBconn.createStatement();
            OneframeContainer.OneframeLogger("Execute SQL Query : [" + sqlQuery + "]");
            intNbrOfRows = sqlStatObj.executeUpdate(sqlQuery);
            OneframeContainer.OneframeLogger("Total number of records impacted by the query : " + intNbrOfRows);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return intNbrOfRows;
    }
    
    public OneframeDatabaseDriver validateDBColumnValue(final String columnName, String expectedValue) {
        String dbActColValue = "";
        try {
            this.moveCursorPointerToFirstRecord();
            if (this.ofQueryResultSet.getString(columnName) == null) {
                dbActColValue = "null";
            }
            else {
                dbActColValue = this.ofQueryResultSet.getString(columnName).toLowerCase();
            }
            expectedValue = expectedValue.toLowerCase();
            this.ofsa.assertEquals(dbActColValue, expectedValue, "Database validation on column [" + columnName + "] -> Expected Result : " + expectedValue + " Actual Result : " + dbActColValue);
        }
        catch (SQLException e) {
            this.ofsa.assertTrue(false, "Get value of column - " + columnName + "| " + e.getLocalizedMessage());
        }
        return this;
    }
    
    public OneframeDatabaseDriver AssertAll() {
        this.ofsa.assertAll();
        return this;
    }
    
    public boolean moveCursorPointerToNextRecord() throws SQLException {
        return this.ofQueryResultSet.next();
    }
    
    public boolean moveCursorPointerToFirstRecord() throws SQLException {
        return this.ofQueryResultSet.first();
    }
    
    public boolean moveCursorPointerToLastRecord() throws SQLException {
        return this.ofQueryResultSet.last();
    }
    
    public void moveCursorPointer(final int rowNumber) {
        try {
            this.ofQueryResultSet.beforeFirst();
            for (int i = 0; i < rowNumber; ++i) {
                this.ofQueryResultSet.next();
            }
            OneframeContainer.OneframeLogger("Cursor moved to record -> " + this.ofQueryResultSet.getRow());
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public OneframeDatabaseDriver validateDBColumnValues(final String[] columnNames, final String[] expectedValues) {
        if (columnNames.length == expectedValues.length) {
            for (int i = 0; i < columnNames.length; ++i) {
                this.validateDBColumnValue(columnNames[i], expectedValues[i]);
            }
        }
        else {
            OneframeContainer.OneframeErrorLogger("Expected columns and values array size is not equal");
        }
        return this;
    }
    
    public int getTotalRecordsCount() {
        int recordCount = 0;
        try {
            final int currentCursor = this.ofQueryResultSet.getRow();
            this.ofQueryResultSet.last();
            recordCount = this.ofQueryResultSet.getRow();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return recordCount;
    }
    
    public boolean isResultSetEmpty() {
        boolean flag = false;
        try {
            flag = this.ofQueryResultSet.first();
        }
        catch (SQLException e) {
            OneframeContainer.OneframeErrorLogger(e.getLocalizedMessage());
        }
        if (!flag) {
            OneframeContainer.OneframeLogger("Resultset is empty, no records retrieved by the query");
        }
        return flag;
    }
    
    public void closeDBConnection() {
        try {
            if (this.ofQueryResultSet != null && !this.ofQueryResultSet.isClosed()) {
                this.ofQueryResultSet.close();
            }
            if (this.ofDBconn != null && !this.ofDBconn.isClosed()) {
                this.ofDBconn.close();
            }
            OneframeContainer.OneframeLogger("[ONEFRAME]Database connection is closed");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    protected void finalize() {
        this.closeDBConnection();
    }
}

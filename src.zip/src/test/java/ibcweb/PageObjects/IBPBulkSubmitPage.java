
package ibcweb.PageObjects;

import java.lang.*;
import static anthem.irx.oneframe.core.OneframeContainer.OneframeLogger;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.stream.IntStream;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.utilities.ExcelFile;
import io.qameta.allure.Step;

public class IBPBulkSubmitPage extends OneframeContainer {
	
	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();
	Robot robot;
	String projectID = "";

	@FindBy(xpath = "//p[normalize-space()='CREATE PROJECT']")
	WebElement hdrCreateProject;

	@FindBy(xpath = "//h2")
	WebElement hdrBenefitBulkSubmit;
	
	@FindBy(xpath = "//p[normalize-space()='PROJECT CREATION IN PROGRESS']")
	WebElement hdrProjectCreationInProgress;
	
	@FindBy(xpath = "//b[contains(text(), \"benefits found\")]")
	WebElement uploadSuccessMessage;

	@FindBy(xpath = "//b[contains(text(),'Benefits not found')]")
	WebElement uploadBenefitNotFoundMessage;
	
	@FindBy(xpath = "//p[normalize-space()='PROJECT CREATED']/preceding-sibling::div[@class='active-eye']")
	WebElement projectCreatedActive;
	
	@FindBy(xpath = "//h4")
	WebElement hdrProjectCreated;
	
	@FindBy(xpath = "//span[text()=' Go Back ']/..")
	WebElement btnGoBack;
	
	@FindBy(xpath = "//span[text()=' Quit Process ']/..")
	WebElement btnQuitProcess;
	
	@FindBy(xpath = "//span[text()=' Submit To Adjudication ']/..")
	WebElement btnSubmitToAdjudication;
	
	@FindBy(xpath = "//input[@formcontrolname='q']")
	WebElement inputSearchBox;
	
	@FindBy(xpath = "//ingeniorx-ws-listing/table/tbody/tr")
	List<WebElement> searchResults;
	
	// Initializing the Page Objects:
	public IBPBulkSubmitPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions
	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Entered text into Bulk Submit Search Box")
	public boolean enterTextIntoSearchBar(String string) {
		boolean flg = false;
		if(ObjectExist(inputSearchBox)) {
			oneframeDriver.navigate().refresh();
			EnterText(inputSearchBox, string);
			inputSearchBox.sendKeys(Keys.ENTER);
			
			if(inputSearchBox.getText() != null) {
				flg = true;
			}
			else {
				flg = false;
			}
		}
		
		return flg;
	}
	
	@Step("Verify 'Create Project' heading in stepper menu")
	public boolean verifyCreateProjectInStepperMenu() {
		boolean flg = false;
		
		if(ObjectExist(hdrCreateProject)) {
			highlightElement(hdrCreateProject);
			OneframeLogger("Create Project header is displayed in stepper menu");
			System.out.println(hdrCreateProject.getCssValue("color"));
			flg = true;
		}
		else {
			OneframeLogger("Create project header is not displayed in stepper menu");
			flg = false;
		}
		
		return flg;
	}
	
	@Step("Verify success message after uploading the file")
	public boolean verifySuccessfulUploadMessage(String string) {
		WaitForObjectVisibility(uploadSuccessMessage);
		if(uploadSuccessMessage.getText().equalsIgnoreCase(string)) {
			highlightElement(uploadSuccessMessage);
			OneframeLogger("File uploaded successfully");
			return true;
		}
		return false;
	}
	
	@Step("Verify error message after uploading the file")
	public boolean verifyUnSuccessfulUploadMessage(String string) {
		WaitForObjectVisibility(uploadBenefitNotFoundMessage);
		String x = uploadBenefitNotFoundMessage.getText();
		if(uploadBenefitNotFoundMessage.getText().contains(string)) {
			highlightElement(uploadBenefitNotFoundMessage);
			OneframeLogger("Benefits not found");
			return true;
		}
		return false;
	}

	@Step("Verify 'Project created' heading in stepper menu is active")
	public boolean verifyProjectCreatedIsActive() {
		boolean flg = false;
		if(WaitForObject(projectCreatedActive)) {
			System.out.println(hdrCreateProject.getCssValue("color"));
			OneframeLogger("PROJECT CREATED is active in the stepper menu");
			flg = true;
		}		
		else {
			OneframeLogger("PROJECT CREATED is not active in the stepper menu");
			flg = false;
		}
		
		return flg;
	}

	@Step("Verify 'Project Created' message is displayed")
	public boolean verifyProjectCreatedHeading(String projectID) {
		boolean flg = false;
		if(WaitForObject(hdrProjectCreated)) {
			String actualData = hdrProjectCreated.getText().trim();
			String expectedData = projectID + " Project Created";
			
			if(actualData.equalsIgnoreCase(expectedData)) {
				flg = true;
			}
			else {
				flg = false;
			}
		}
		return flg;
	}
	
	@Step("Click on Quit Button")
	public void clickQuitProcess() {
		if(WaitForObject(btnQuitProcess)) {
			ClickWebObject(btnQuitProcess);
			OneframeLogger("Clicked on Quit Process button");
		}
	}
	
	@Step("Click on Submit To Adjudication Button")
	public void clickSubmitToAdjudication() {
		if(WaitForObject(btnSubmitToAdjudication)) {
			ClickWebObject(btnSubmitToAdjudication);
			OneframeLogger("Clicked on Submit To Adjudication button");
		}
	}
	
	@Step("Verify search results are empty")
	public boolean verifySearchResultsAreEmpty() {
		hdrBenefitBulkSubmit.click();
		hdrBenefitBulkSubmit.click();
		hdrBenefitBulkSubmit.click();
		if(searchResults.size() != 0) {
			return false;
		}
		else {
			oneframeDriver.navigate().refresh();
			IBPHomePage homepage = new IBPHomePage();
			homepage.clickMenuButton();
			return true;		
		}
	}
	
	@Step("Verify the status of a project")
	public boolean verifyStatus(String projectID, String status) throws InterruptedException {
		hdrBenefitBulkSubmit.click();
		hdrBenefitBulkSubmit.click();
		hdrBenefitBulkSubmit.click();
		hdrBenefitBulkSubmit.click();
		String xpath = "//table/tbody/tr/td[1][text()=' " +projectID+ " ']/../td";
		WaitForObjectToBeClickable(oneframeDriver.findElement(By.xpath(xpath)));
		List<WebElement> projectInGrid = oneframeDriver.findElements(By.xpath(xpath));
		if(projectInGrid.get(3).getText().trim().equalsIgnoreCase(status)) {
			highlightElement(projectInGrid.get(3));
			//OneframeLogger("Project status is displayed as " +status);
			oneframeDriver.navigate().refresh();
			return true;
		}
		return false;
	}
	
}

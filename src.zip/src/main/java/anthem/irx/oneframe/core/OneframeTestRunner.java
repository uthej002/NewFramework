package anthem.irx.oneframe.core;

import anthem.irx.oneframe.utilities.DateTimeProcessor;
import anthem.irx.oneframe.utilities.ExcelIOStream;
import anthem.irx.oneframe.utilities.FileOpsHelper;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class OneframeTestRunner extends OneframeContainer {
  String[][] ScriptConfigurations;
  
  HashMap<String, String> ConfigIndexMap = new HashMap<>();
  
  XmlSuite ofTestSuite;
  
  XmlClass ofTestClass;
  
  XmlTest ofxmlTest;
  
  String pkgTestClass;
  
  String ofTestSuiteFile;
  
  int testScripts = 0;
  
  public void CreateAndSaveTestSuiteXML() {
    createDynamicTestSuite();
    saveDynamicTestSuite();
  }
  
  private void saveDynamicTestSuite() {
    this.ofTestSuiteFile = TESTSUITES_FOLDER + TSXMLFileOutput + "_" + DateTimeProcessor.getCurrentDateTime("MMddYYYY_hhmm") + ".xml";
    FileOpsHelper.writeToFile(this.ofTestSuiteFile, this.ofTestSuite.toXml());
    OneframeLogger("Test Suite [" + this.ofTestSuiteFile + "] saved to the 'Test Suites' folder");
  }
  
  private void createDynamicTestSuite() {
    ReadTestBedConfiguration();
    this.ofTestSuite = new XmlSuite();
    this.ofTestSuite.setName(TestSuiteName);
    this.ofTestSuite.addListener(TSListenerClass);
    if (TSParallelExec) {
      this.ofTestSuite.setParallel(XmlSuite.ParallelMode.TESTS);
      this.ofTestSuite.setThreadCount(TSThreadCount);
    } 
    ExcelIOStream ofTestSuiteXlsX = new ExcelIOStream(TestSuiteFile);
    this.ScriptConfigurations = ofTestSuiteXlsX.readScriptConfiguration();
    createConfigurationIndexMap();
    for (int irow = 1; irow < this.ScriptConfigurations.length; irow++) {
      Map<String, String> ofTestParameters = new HashMap<>();
      if (this.ScriptConfigurations[irow][0] == "" || this.ScriptConfigurations[irow][0] == null)
        break; 
      this.pkgTestClass = TSPackageName + "." + this.ScriptConfigurations[irow][getConfigIndex("ScriptName")];
      this.ofTestClass = new XmlClass(this.pkgTestClass);
      ofTestParameters.put(this.ScriptConfigurations[0][getConfigIndex("TestScenarioID")], this.ScriptConfigurations[irow][getConfigIndex("TestScenarioID")]);
      try {
        XmlTest ofxmlTest = new XmlTest(this.ofTestSuite);
        ofxmlTest.setParameters(ofTestParameters);
        ofxmlTest.setName(getConfigValue(irow, "TestScenarioID") + "_" + getConfigValue(irow, "ScriptName"));
        ofxmlTest.setClasses(Arrays.asList(new XmlClass[] { this.ofTestClass }));
        OneframeLogger("[ONEFRAME]Adding test script [" + this.ofTestClass.getName() + "] to test suite.....Done");
        this.testScripts++;
      } catch (Exception TNGE) {
        OneframeLogger("Unable to add test script : " + TNGE.getMessage());
      } 
    } 
    OneframeLogger("[ONEFRAME]Total Number of test scripts added to the test suite : " + this.testScripts);
  }
  
  private void executeSavedTestSuite() {
    TestNG oftestNG = new TestNG();
    oftestNG.setXmlSuites(Arrays.asList(new XmlSuite[] { this.ofTestSuite }));
    oftestNG.run();
  }
  
  public void executeConfiguredTestSuite() {
    createDynamicTestSuite();
    saveDynamicTestSuite();
    executeSavedTestSuite();
  }
  
  private void createConfigurationIndexMap() {
    for (int cfindex = 0; cfindex < (this.ScriptConfigurations[0]).length; cfindex++)
      this.ConfigIndexMap.put(this.ScriptConfigurations[0][cfindex], String.valueOf(cfindex)); 
  }
  
  private int getConfigIndex(String Config) {
    return Integer.parseInt(this.ConfigIndexMap.get(Config));
  }
  
  private String getConfigValue(int irow, String TSConfiguration) {
    return this.ScriptConfigurations[irow][getConfigIndex(TSConfiguration)];
  }
}

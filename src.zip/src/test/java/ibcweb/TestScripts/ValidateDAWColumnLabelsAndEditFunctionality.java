package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesBaseFormularies;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesDAWPage;
import ibcweb.PageObjects.IBPLibrariesFormulariesPosDur;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateDAWColumnLabelsAndEditFunctionality extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;
	IBPLibrariesFormulariesPosDur posdur;
	IBPLibrariesBaseFormularies baseFormulary;
	IBPLibrariesDAWPage daw;

	@BeforeClass
	@Step("Initializing Test Script for Validate DAW column labels and Edit functionality")
	public void setUp() {
		InitializeLaunchPad("IBPW_359");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();
		posdur = new IBPLibrariesFormulariesPosDur();
		baseFormulary = new IBPLibrariesBaseFormularies();
		daw = new IBPLibrariesDAWPage();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate DAW column labels and Edit functionality", dataProvider = "TestData")
	@Description("Validate DAW column labels and Edit functionality")
	public void ValidateDAWFunctionality(String TestCaseID, String TestStatus)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			controls.clickViewButtonofControls();
			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'Controls' header is displayed");
			daw.clickDAWTab();

			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("PACKAGE NAME");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("DESCRIPTION");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("STOP SALE DATE");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("CLIENT");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("LOB");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("STATE");

			daw.clickFirstRecordDaw();
			daw.clickDawHeader();

			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Dispense as Written Package");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Package name");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Description");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Stop sale date");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Client");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("Line of Business");
			baseFormulary.verifyBaseFormularyDetailslabelsAreDisplayed("States");

			daw.verifyDAWFieldsisDisplayed("Package name");
			daw.verifyDAWFieldsisDisplayed("Description");
			daw.verifyDAWFieldsisDisplayed("Stop sale date");
			daw.verifyDAWFieldsisDisplayed("Client");
			daw.verifyDAWFieldsisDisplayed("Line of Business");
			daw.verifyDAWFieldsisDisplayed("States");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated DAW column labels and Edit functionality is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate DAW column labels and Edit functionality");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

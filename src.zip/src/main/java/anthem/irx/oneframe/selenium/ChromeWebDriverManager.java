package anthem.irx.oneframe.selenium;

import anthem.irx.oneframe.core.OneframeContainer;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ChromeWebDriverManager extends WebDriverManager {
  ChromeOptions options = new ChromeOptions();
  
  DriverType chromeDriverType;
  
  public ChromeWebDriverManager(DriverType chromeDriverType) {
    this.chromeDriverType = chromeDriverType;
  }
  
  public void createWebDriver() {
    Map<String, String> mobileEmulation;
    HashMap<String, Object> map = new HashMap<>();
    map.put("profile.default_content_setting_values.notifications", Integer.valueOf(2));
    map.put("profile.default_content_settings.popups", Integer.valueOf(0));
    map.put("download.default_directory", System.getProperty("user.dir") + "\\src\\test\\resources\\RunTime");
    map.put("download.prompt_for_download", "false");
    OneframeContainer.OneframeLogger(System.getProperty("user.dir"));
    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/src/main/resources/DriverBinaries/chromedriver_win32/chromedriver.exe");
    switch (this.chromeDriverType) {
      case CHROME_MOB_EMULATOR:
        mobileEmulation = new HashMap<>();
        mobileEmulation.put("deviceName", "iPad Pro");
        this.options.setExperimentalOption("mobileEmulation", mobileEmulation);
        break;
      case CHROME:
    	this.options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
    	this.options.setCapability("ensureCleanSession", true);
    	this.options.setExperimentalOption("prefs", map);
    	this.options.addArguments(new String[] { "ignore-certificate-errors" });
    	this.options.addArguments(new String[] { "start-maximized" });
    	this.driver = (WebDriver)new ChromeDriver(this.options);
    	break;
      case CHROME_HEADLESS:
    	this.options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
      	this.options.setCapability("ensureCleanSession", true);
      	this.options.setExperimentalOption("prefs", map);
      	this.options.addArguments(new String[] { "ignore-certificate-errors" });
    	this.options.addArguments("--headless");
    	this.driver = (WebDriver)new ChromeDriver(this.options);
    } 
    
  }
}

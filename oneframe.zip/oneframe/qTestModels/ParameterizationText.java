// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class ParameterizationText
{
    @JsonProperty("parameters")
    private List<ParameterInfo> parameters;
    @JsonProperty("rawText")
    private String rawText;
    @JsonProperty("htmlText")
    private String htmlText;
    @JsonProperty("plainText")
    private String plainText;
    @JsonProperty("valueText")
    private String valueText;
    @JsonProperty("editedParameters")
    private List<ParameterInfo> editedParameters;
    @JsonProperty("plainValueText")
    private String plainValueText;
    
    public ParameterizationText() {
        this.parameters = new ArrayList<ParameterInfo>();
        this.rawText = null;
        this.htmlText = null;
        this.plainText = null;
        this.valueText = null;
        this.editedParameters = new ArrayList<ParameterInfo>();
        this.plainValueText = null;
    }
    
    public ParameterizationText parameters(final List<ParameterInfo> parameters) {
        this.parameters = parameters;
        return this;
    }
    
    public ParameterizationText addParametersItem(final ParameterInfo parametersItem) {
        this.parameters.add(parametersItem);
        return this;
    }
    
    public List<ParameterInfo> getParameters() {
        return this.parameters;
    }
    
    public void setParameters(final List<ParameterInfo> parameters) {
        this.parameters = parameters;
    }
    
    public ParameterizationText rawText(final String rawText) {
        this.rawText = rawText;
        return this;
    }
    
    public String getRawText() {
        return this.rawText;
    }
    
    public void setRawText(final String rawText) {
        this.rawText = rawText;
    }
    
    public ParameterizationText htmlText(final String htmlText) {
        this.htmlText = htmlText;
        return this;
    }
    
    public String getHtmlText() {
        return this.htmlText;
    }
    
    public void setHtmlText(final String htmlText) {
        this.htmlText = htmlText;
    }
    
    public ParameterizationText plainText(final String plainText) {
        this.plainText = plainText;
        return this;
    }
    
    public String getPlainText() {
        return this.plainText;
    }
    
    public void setPlainText(final String plainText) {
        this.plainText = plainText;
    }
    
    public ParameterizationText valueText(final String valueText) {
        this.valueText = valueText;
        return this;
    }
    
    public String getValueText() {
        return this.valueText;
    }
    
    public void setValueText(final String valueText) {
        this.valueText = valueText;
    }
    
    public ParameterizationText editedParameters(final List<ParameterInfo> editedParameters) {
        this.editedParameters = editedParameters;
        return this;
    }
    
    public ParameterizationText addEditedParametersItem(final ParameterInfo editedParametersItem) {
        this.editedParameters.add(editedParametersItem);
        return this;
    }
    
    public List<ParameterInfo> getEditedParameters() {
        return this.editedParameters;
    }
    
    public void setEditedParameters(final List<ParameterInfo> editedParameters) {
        this.editedParameters = editedParameters;
    }
    
    public ParameterizationText plainValueText(final String plainValueText) {
        this.plainValueText = plainValueText;
        return this;
    }
    
    public String getPlainValueText() {
        return this.plainValueText;
    }
    
    public void setPlainValueText(final String plainValueText) {
        this.plainValueText = plainValueText;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ParameterizationText parameterizationText = (ParameterizationText)o;
        return Objects.equals(this.parameters, parameterizationText.parameters) && Objects.equals(this.rawText, parameterizationText.rawText) && Objects.equals(this.htmlText, parameterizationText.htmlText) && Objects.equals(this.plainText, parameterizationText.plainText) && Objects.equals(this.valueText, parameterizationText.valueText) && Objects.equals(this.editedParameters, parameterizationText.editedParameters) && Objects.equals(this.plainValueText, parameterizationText.plainValueText);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.parameters, this.rawText, this.htmlText, this.plainText, this.valueText, this.editedParameters, this.plainValueText);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class ParameterizationText {\n");
        sb.append("    parameters: ").append(this.toIndentedString(this.parameters)).append("\n");
        sb.append("    rawText: ").append(this.toIndentedString(this.rawText)).append("\n");
        sb.append("    htmlText: ").append(this.toIndentedString(this.htmlText)).append("\n");
        sb.append("    plainText: ").append(this.toIndentedString(this.plainText)).append("\n");
        sb.append("    valueText: ").append(this.toIndentedString(this.valueText)).append("\n");
        sb.append("    editedParameters: ").append(this.toIndentedString(this.editedParameters)).append("\n");
        sb.append("    plainValueText: ").append(this.toIndentedString(this.plainValueText)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}

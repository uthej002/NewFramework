package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPBenefitDetailsPage extends OneframeContainer {

	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//td[contains(text(),'History & Documents')]")
	WebElement hdrHistory;

	@FindBy(xpath = "//td[contains(text(),' Notes ')]")
	WebElement hdrNotes;

	@FindBy(xpath = "//*[@class='mat-paginator-icon']")
	List<WebElement> lstPageTraverseChevronButton;

	@FindBy(xpath = "//mat-paginator/div/div/div")
	WebElement txtPageNumber;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-status mat-column-status ng-star-inserted']")
	List<WebElement> lstBenefitStatus;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-version mat-column-version ng-star-inserted']")
	List<WebElement> lstBenefitVersion;

	@FindBy(xpath = "//textarea[@formcontrolname='notes']")
	WebElement txtEnterNotes;

	@FindBy(xpath = "//*[@class='mat-error notes-message ng-star-inserted']")
	WebElement numOfCharactersNotes;

	@FindBy(xpath = "//*[@data-automation-id='detailsViewAudit']")
	WebElement btnViewAuditTrail;

	@FindBy(xpath = "//div[contains(text(),'Audit Trail')]")
	WebElement hdrAuditTrailPage;

	@FindBy(xpath = "//th[text()='VERSION']")
	WebElement txtVersion;

	@FindBy(xpath = "//th[text()='DATE & TIME']")
	WebElement txtDateandTime;

	@FindBy(xpath = "//th[text()='USER']")
	WebElement txtUser;

	@FindBy(xpath = "//th[text()='CHANGES']")
	WebElement txtChanges;

	@FindBy(xpath = "//th[text()='NR']")
	WebElement txtNR;

	@FindBy(xpath = "//th[text()='FIELD ']")
	WebElement txtField;

	@FindBy(xpath = "//th[text()='ORIGINAL VALUE']")
	WebElement txtOriginalValue;

	@FindBy(xpath = "//th[text()='NEW VALUE']")
	WebElement txtNewValue;

	@FindBy(xpath = "//*[@svgicon='down-arrow']")
	WebElement btnDownArrow;

	@FindBy(xpath = "//td[text()='Details']")
	WebElement txtDetails;

	@FindBy(xpath = "//td[@class='mat-cell cdk-cell cdk-column-no mat-column-no ng-tns-c364-108 ng-star-inserted']")
	WebElement txtSerialNum;

	@FindBy(xpath = "//span[text()=' Back ']")
	WebElement btnBack;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[4]")
	List<WebElement> lstrowChanges;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[5]")
	List<WebElement> btnRowDropDown;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[2]/../td[1]")
	List<WebElement> lstVersion;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[2]")
	List<WebElement> lstDateandTime;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[3]")
	List<WebElement> lstUser;

	@FindBy(xpath = "(//table[@ngclass='irx-listing'])[2]/tbody/tr")
	List<WebElement> lstSubTableValues;

	@FindBy(xpath = "//td[text()='Details']/..")
	WebElement detailsRow;

	@FindBy(xpath = "//*[text()='●']")
	List<WebElement> lstVersionUpdates;

	@FindBy(xpath = "//*[@placeholder='Select']/div/div/span")
	List<WebElement> btnDropDowns;

	@FindBy(xpath = "//mat-option[@role='option']/span")
	List<WebElement> btnCBStateId;

	@FindBy(xpath = "//span[text()=' Save ']")
	WebElement btnSave;

	// Search page header
	@FindBy(css = ".benefit-header--left")
	WebElement benefitId;

	@FindBy(css = "span.label-value")
	WebElement benefitIdValue;

	@FindBy(css = "[data-automation-id=\"headerLob\"]")
	WebElement headerLob;

	@FindBy(css = "[data-automation-id=\"headerLobValue\"]")
	WebElement headerLobValue;

	@FindBy(css = "[data-automation-id=\"headerState\"]")
	WebElement headerState;

	@FindBy(css = "[data-automation-id=\"headerStatebValue\"]")
	WebElement headerStateValue;

	@FindBy(css = "[data-automation-id=\"headerFormulary\"]")
	WebElement headerFormulary;

	@FindBy(css = "[data-automation-id=\"headerFormularyValue\"]")
	WebElement headerFormularyValue;

	@FindBy(css = "[data-automation-id=\"headerClient\"]")
	WebElement headerClient;

	@FindBy(css = "[data-automation-id=\"headerClientValue\"]")
	WebElement headerClientValue;

	@FindBy(css = "[data-automation-id=\"headerEffectiveDate\"]")
	WebElement headerEffectiveDate;

	@FindBy(css = "[data-automation-id=\"headerEffectiveDateValue\"]")
	WebElement headerEffectiveDateValue;

	@FindBy(css = "[data-automation-id=\"headerEndDate\"]")
	WebElement headerEndDate;

	@FindBy(css = "[data-automation-id=\"headerEndDateValue\"]")
	WebElement headerEndDateValue;

	@FindBy(css = "[data-automation-id=\"headerVersion\"]")
	WebElement headerVersion;

	@FindBy(css = "[data-automation-id=\"headerVersionValue\"]")
	WebElement headerVersionValue;

	// Effective version header

	@FindBy(css = "[data-automation-id=\"headerEffectiveVersion\"]")
	WebElement headerEffectiveVersion;

	@FindBy(css = "[data-automation-id=\"headerEffectiveVersionValue\"]")
	WebElement headerEffectiveVersionValue;

	@FindBy(css = "[data-automation-id=\"headerEffectiveVersionDate\"]")
	WebElement headerEffectiveVersionDate;

	@FindBy(css = "[data-automation-id=\"headerEffectiveVersionDateValue\"]")
	WebElement headerEffectiveVersionDateValue;

	@FindBy(css = "[data-automation-id=\"headerEffectiveVersioEndDate\"]")
	WebElement headerEffectiveVersioEndDate;

	@FindBy(css = "[data-automation-id=\"headerEffectiveVersioEndDateValue\"]")
	WebElement headerEffectiveVersioEndDateValue;

	@FindBy(xpath = "//span[text()='Funding Type']//following::span[1]")
	WebElement txtFundingType;

	@FindBy(xpath = "//span[text()='STATE']//following::span[1]")
	WebElement txtState;

	@FindBy(xpath = "//h1")
	WebElement hdrBenefitID;

	@FindBy(xpath = "//div[text()='General']")
	WebElement btnGeneralTab;

	@FindBy(xpath = "//*[text()='PENCD']")
	WebElement txtPENCD;

	@FindBy(xpath = "//*[@formcontrolname='pencd']/label/div/input[@aria-checked ='true']")
	WebElement tglPencdON;

	@FindBy(xpath = "//*[@formcontrolname='pencd']/label/div/input[@aria-checked ='false']")
	WebElement tglPencdOFF;

	public IBPBenefitDetailsPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Verify History & Documents header")
	public boolean verifyHistoryAndDocumentHeader() {
		boolean bln = false;
		if (WaitForObjectVisibility(hdrHistory)) {
			ScrollToElement(hdrHistory);
			if (hdrHistory.getText().equalsIgnoreCase("History & Documents")) {
				bln = true;
			}
		}
		return bln;
	}

	@Step("Verify Notes header")
	public boolean verifyNotesHeader() {
		boolean bln = false;
		if (ObjectExist(hdrNotes)) {
			if (hdrNotes.getText().equalsIgnoreCase("Notes")) {
				bln = true;
			}
		}
		return bln;
	}

	@Step("Verify and Click Benefit with In Progress Status")
	public boolean verifyAndClickBenefitWithInProgressStatus(String status) {
		boolean bln = false;
		try {
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split("–");
			String[] totalRecordCnt = recordCnt[1].split("of");
			int totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
			int recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			outer: while (recordsPresentPerPage <= totalRecords) {
				for (int i = 0; i < lstBenefitStatus.size(); i++) {
					String lstBen = lstBenefitStatus.get(i).getText().trim();
					if (lstBen.contains(status)) {
						highlightElement(lstBenefitStatus.get(i));
						lstBenefitStatus.get(i).click();
						bln = true;
						break outer;
					}
				}
				if (totalRecords != recordsPresentPerPage) {
					ClickWebObject(lstPageTraverseChevronButton.get(1));
					OneframeLogger("clicked next page chevron button");
					ClickWebObject(txtPageNumber);
					ClickWebObject(txtPageNumber);
				}
				String record = txtPageNumber.getText();
				recordCnt = record.split("–");
				totalRecordCnt = recordCnt[1].split("of");
				totalRecords = Integer.parseInt(totalRecordCnt[1].trim());
				recordsPresentPerPage = Integer.parseInt(totalRecordCnt[0].trim());
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to get Program Name");
			bln = false;
		}
		return bln;
	}

	@Step("Verify and Click Benefit with Submitted PBM Status")
	public String verifyAndClickBenefitWithSubmittedPBMStatus(String status) {
		boolean bln = false;
		String benVersion = null;
		try {
			Thread.sleep(5000);
			String xpath = "//tbody[@role='rowgroup']//tr[@role='row']//td[contains(@class, 'mat-column-status ')][text()=' "+ status +" ']";
			String verXpath = xpath + "/../td[9]";
			WaitForObjectVisibility(txtPageNumber);
			String records = txtPageNumber.getText();
			String[] recordCnt = records.split(" ");
			int totalRecords = Integer.parseInt(recordCnt[4].trim());

			// Dividing totalRecords by 10 because there are only 10 records per page
			int numberOfPages = Math.round(totalRecords / 10);

			if (numberOfPages != 0) {
				for (int i = 0; i < numberOfPages; i++) {
					try {
						WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
						if (WaitForObjectVisibility(ele)) {
							benVersion = oneframeDriver.findElement(By.xpath(verXpath)).getText().trim();
							ClickWebObject(ele);
							OneframeLogger("Benefit Clicked : " + ele.getText());
							break;
						}
					} catch (NoSuchElementException e) {
						ClickWebObject(lstPageTraverseChevronButton.get(1));
						ClickWebObject(txtPageNumber);
						ClickWebObject(txtPageNumber);
						WaitForApplicationToLoadCompletely();
					}

				}

			}
			WaitForApplicationToLoadCompletely();
			
		} catch (StaleElementReferenceException | InterruptedException e) {
			OneframeLogger("Unable to get Program Name");
			bln = false;
		}
		return benVersion;
	}

	@Step("Verify and Enter Notes")
	public String verifyAndEnterNotes() {
		String notesVal;
		if (txtEnterNotes.getAttribute("value").equalsIgnoreCase("")) {
			String note = "Notes";
			int randomNumber = getRandomNumber();
			String enterNotes = note + randomNumber;
			txtEnterNotes.sendKeys(enterNotes);
			notesVal = txtEnterNotes.getAttribute("value");
			OneframeLogger("The Entered notes is : " + notesVal);
		} else {
			String notes = " Notes";
			int randomNumber = getRandomNumber();
			String enterNotes = notes + randomNumber;
			txtEnterNotes.sendKeys(enterNotes);
			notesVal = txtEnterNotes.getAttribute("value");
			OneframeLogger("The Entered notes is : " + notesVal);
		}
		return notesVal;
	}

	@Step("Verify and Enter Notes")
	public String verifyAndEditEnterNotes() {
		String notesVal;
		if (txtEnterNotes.getAttribute("value").equalsIgnoreCase("")) {
			String note = "Notes";
			int randomNumber = getRandomNumber();
			String enterNotes = note + randomNumber;
			txtEnterNotes.sendKeys(enterNotes);
			notesVal = txtEnterNotes.getAttribute("value");
			OneframeLogger("The Entered notes is : " + notesVal);
		} else {
			while (!txtEnterNotes.getAttribute("value").equalsIgnoreCase("")) {
				txtEnterNotes.sendKeys(Keys.BACK_SPACE);
			}
			String notes = " Notes";
			int randomNumber = getRandomNumber();
			String enterNotes = notes + randomNumber;
			txtEnterNotes.sendKeys(enterNotes);
			notesVal = txtEnterNotes.getAttribute("value");
			OneframeLogger("The Entered notes is : " + notesVal);
		}
		return notesVal;
	}

	@Step("Verify Enter Notes")
	public boolean verifyEnterNotes(String notes) {
		boolean bln = false;
		String notesVal;
		while (!txtEnterNotes.getAttribute("value").equalsIgnoreCase("")) {
			txtEnterNotes.sendKeys(Keys.BACK_SPACE);
		}
		txtEnterNotes.sendKeys(notes);
		notesVal = txtEnterNotes.getAttribute("value");
		OneframeLogger("Notes value before adding : " + notes.length());
		OneframeLogger("Notes value after adding : " + notesVal.length());
		if (notes.length() != notesVal.length()) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify Enter Notes is same")
	public boolean verifyEnterNotesValue(String notes) {
		boolean bln = false;
		String notesVal;
		while (!txtEnterNotes.getAttribute("value").equalsIgnoreCase("")) {
			txtEnterNotes.sendKeys(Keys.BACK_SPACE);
		}
		txtEnterNotes.sendKeys(notes);
		String numberOfCharacters = numOfCharactersNotes.getText();
		String noOfCharactersLeft = numberOfCharacters.split("/")[0];
		String totalCharacters = numberOfCharacters.split("/")[1];
		int numOfCharacterLeft = Integer.parseInt(noOfCharactersLeft);
		int totalCharcter = Integer.parseInt(totalCharacters);

		notesVal = txtEnterNotes.getAttribute("value");
		String character = noOfCharactersLeft + "/" + totalCharacters;

		if (notesVal.length() == numOfCharacterLeft && notesVal.length() < totalCharcter) {
			if (character.equalsIgnoreCase(numberOfCharacters)) {
				bln = true;
			}
		}
		return bln;
	}

	@Step("Verify Enter Notes is same")
	public boolean verifyEnterNotesValues(String notes) {
		boolean bln = false;
		String notesVal;
		while (!txtEnterNotes.getAttribute("value").equalsIgnoreCase("")) {
			txtEnterNotes.sendKeys(Keys.BACK_SPACE);
		}
		txtEnterNotes.sendKeys(notes);
		String numberOfCharacters = numOfCharactersNotes.getText();
		String noOfCharactersLeft = numberOfCharacters.split("/")[0];
		String totalCharacters = numberOfCharacters.split("/")[1];
		int numOfCharacter = Integer.parseInt(noOfCharactersLeft);
		int numOfTotalCharacters = Integer.parseInt(totalCharacters);

		notesVal = txtEnterNotes.getAttribute("value");

		if (notesVal.length() == numOfCharacter) {
			if (numOfCharacter == numOfTotalCharacters) {
				bln = true;
			}
		}
		return bln;
	}

	@Step("Verify Notes field is in editable mode")
	public boolean verifyNotesField() {
		boolean bln = false;
		if (txtEnterNotes.isEnabled()) {
			bln = true;
		}
		return bln;
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Verify Entered notes value")
	public boolean verifyNotesValue(String notesValue) {
		boolean bln = false;
		WaitForObjectVisibility(txtEnterNotes);
		ScrollToElement(txtEnterNotes);
		if (txtEnterNotes.getAttribute("value").equalsIgnoreCase(notesValue)
				|| txtEnterNotes.getAttribute("value") == null) {
			OneframeLogger("Actual Notes is : " +txtEnterNotes.getAttribute("value"));
			OneframeLogger("Expected Notes is : " +notesValue);
			bln = true;
		}
		else {
			OneframeLogger("Actual Notes is : " +txtEnterNotes.getAttribute("value"));
			OneframeLogger("Expected Notes is : " +notesValue);
			
			bln = false;
		}

		return bln;
	}

	@Step("Verify and Click on View Audit Trail button")
	public boolean verifyAndClickViewAuditTrailBtn() {
		boolean bln = false;
		if (ObjectExist(btnViewAuditTrail)) {
			btnViewAuditTrail.click();
			OneframeLogger("Audit Trail button is clicked");
			bln = true;
		}
		return bln;
	}

	@Step("Verify Aduti Trail Program header is displayed")
	public boolean verifyAuditTrailProgramHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAuditTrailPage)) {
			if (hdrAuditTrailPage.getText().contains("Audit Trail")) {
				OneframeLogger("Audit Trail Program Headeris Displayed");
				flag = true;
			}

		}
		return flag;
	}

	@Step("Verify Audit details components are displayed")
	public boolean verifyAuditDetailComponents() {
		boolean flag = false;
		WaitForObject(txtVersion);
		if (txtVersion.getText().equalsIgnoreCase("VERSION") && txtDateandTime.getText().equalsIgnoreCase("DATE & TIME")
				&& txtUser.getText().equalsIgnoreCase("USER") && txtChanges.getText().equalsIgnoreCase("CHANGES")) {
			OneframeLogger("Version,Date & Time, User and Changes component details are Displayed");
			flag = true;
		}

		return flag;
	}

	@Step("Verify Row dropdown is clicked")
	public void clickRowDropDownToggle() {

		for (int i = 0; i < lstrowChanges.size(); i++) {
			int num = Integer.parseInt(lstrowChanges.get(i).getText());
			if (num == 0) {
				OneframeLogger("Version : " + lstVersion.get(i).getText());
				OneframeLogger("Date and Time : " + lstDateandTime.get(i).getText());
				OneframeLogger("User : " + lstUser.get(i).getText());
				btnRowDropDown.get(i).click();
				OneframeLogger("Row Dropdown is clicked");
				break;
			}
		}

	}

	@Step("Verify drop down component details are displayed")
	public boolean verifyDropDownComponents() {
		boolean flag = false;
		WaitForObjectVisibility(txtNR);
		if (txtNR.getText().equalsIgnoreCase("NR") && txtField.getText().equalsIgnoreCase("FIELD")
				&& txtOriginalValue.getText().equalsIgnoreCase("ORIGINAL VALUE")
				&& txtNewValue.getText().equalsIgnoreCase("NEW VALUE")) {
			OneframeLogger("NR, FIELD, ORIGINAL VALUE and NEW VALUE component details are Displayed");
			flag = true;
		}

		return flag;
	}

	@Step("Verify and Click on Details button")
	public boolean verifyAndClickDetailsBtn() {
		boolean bln = false;
		if (ObjectExist(txtDetails)) {
			txtDetails.click();
			OneframeLogger("Details button is clicked");
			bln = true;
		}
		return bln;
	}

	@Step("Verify and Click on Back button")
	public boolean verifyAndClickBackBtn() {
		boolean bln = false;
		if (ObjectExist(btnBack)) {
			btnBack.click();
			OneframeLogger("Back button is clicked");
			bln = true;
		}
		return bln;
	}

	@Step("Verify sub list values is displayed")
	public void verifySubListValues() {

		for (WebElement ele : lstSubTableValues) {
			List<WebElement> lstTDValues = ele.findElements(By.tagName("td"));
			OneframeLogger("Field : " + lstTDValues.get(1).getText());
			OneframeLogger("Original Value : " + lstTDValues.get(2).getText());
			OneframeLogger("New Value : " + lstTDValues.get(3).getText());
		}
	}

	@Step("Verify View Audit Trail button")
	public boolean verifyClickViewAuditTrailBtn() {
		boolean bln = false;
		if (ObjectExist(btnViewAuditTrail)) {
			if (btnViewAuditTrail.getText().equalsIgnoreCase("View Audit Trail >>")) {
				bln = true;
			}
		}
		return bln;
	}

	@Step("Verify Audit Trail versions are displayed")
	public boolean verifyAuditTrailVersions() {
		boolean bln = false;
		for (int i = 0; i < lstVersion.size(); i++) {
			OneframeLogger("Version : " + lstVersion.get(i).getText() + " Displayed");
			bln = true;
		}

		return bln;
	}

	@Step("Verify Audit Trail Changes Count")
	public boolean verifyChangesCount() {
		int size = lstVersionUpdates.size();
		int changescount = 0;
		for (int i = 0; i < lstrowChanges.size(); i++) {
			int num = Integer.parseInt(lstrowChanges.get(i).getText());
			if (num != 0) {
				changescount = num;

				break;
			}
		}

		if (size == changescount) {
			OneframeLogger("Count" + changescount);
			OneframeLogger("Count changes number are matching with updates in the version");

			return true;
		} else {
			OneframeLogger("Count changes number are not matching with updates in the version");
			return false;

		}
	}

	@Step("Verify Audit Trail Versions are in descending order")
	public boolean verifyVersionsDescendingOrder() {
		List<Float> versions = new ArrayList<Float>();
		int count = 0;
		int size = lstVersion.size() - 1;
		for (int i = 0; i < lstVersion.size(); i++) {
			float num = Float.parseFloat(lstVersion.get(i).getText());
			versions.add(num);
			OneframeLogger("Version: " + num);

		}

		for (int j = 0; j < versions.size() - 1; j++) {
			// OneframeLogger(""+versions.get(j));
			if (versions.get(j) > versions.get(j + 1)) {
				count++;
			} else {
				break;
			}
		}

		if (count == size) {
			OneframeLogger("Latest version: " + versions.get(0));
			OneframeLogger("Displayed Versions are in descending Order");
			return true;
		}

		else {
			OneframeLogger("Displayed Versions are not in descending Order");
			return false;
		}

	}

	@Step("Verify Audit Trail starting Version is 0.2 benefit")
	public boolean verifyStartingVersion() {

		int firstVersion = lstVersion.size() - 1;
		float num = Float.parseFloat(lstVersion.get(firstVersion).getText());
		float expected = 0.2f;

		if (Float.compare(num, expected) == 0) {

			OneframeLogger("Starting Version of Audit Trail is " + num);
			return true;
		} else {
			OneframeLogger("Starting version of Audit Trail is not execpted");
			return false;
		}
	}

	@Step("Select State drop down")
	public boolean selectStateDropdown(String StateId) throws AWTException {
		boolean bln = false;
		try {
			if (WaitForObjectVisibility(btnDropDowns.get(2))) {
				ClickWebObject(btnDropDowns.get(2));
				WebElement drdValue = null;
				for (WebElement ele : btnCBStateId) {
					if (ele.getText().equalsIgnoreCase(StateId)) {
						drdValue = ele;
						break;
					}
				}
				WaitForObjectVisibility(drdValue);
				SelectDropDownListByValue(drdValue, StateId);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_ESCAPE);
				robot.keyRelease(KeyEvent.VK_ESCAPE);
				bln = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Given Value has not been Selected from State Id dropdown");
		}
		return bln;
	}

	@Step("Enter Copy Right and Trademark symbols in Notes Field")
	public boolean enterCopyRightandTrademarkSymbols(String Notes) throws InterruptedException {
		boolean bln = false;
		if (WaitForObject(txtEnterNotes)) {
			ClickWebObject(txtEnterNotes);
			txtEnterNotes.sendKeys(Notes);
			OneframeLogger("Copy Right and Trademark symbols entered : " + txtEnterNotes.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	@Step("Verify and Click on Save button")
	public boolean clickSavebutton() {
		boolean bln = false;
		if (ObjectExist(btnSave)) {
			btnSave.click();
			OneframeLogger("Save button is clicked");
			bln = true;
		}
		return bln;
	}

	public boolean addRegisteredandTradeMarkSymbols() {
		boolean bln = false;
		if (WaitForObject(txtEnterNotes)) {
			ClickWebObject(txtEnterNotes);
			txtEnterNotes.sendKeys(Keys.CONTROL + "a");
			txtEnterNotes.sendKeys(Keys.DELETE);
			String registerandTrademarkSymbols = "© ®";
			txtEnterNotes.sendKeys(registerandTrademarkSymbols);
			OneframeLogger("The Contract Platform value is : " + txtEnterNotes.getAttribute("value"));
			bln = true;
		}
		return bln;
	}

	public String getNotes() {
		WaitForApplicationToLoadCompletely();
		WaitForObject(txtEnterNotes);
		return txtEnterNotes.getAttribute("value");
	}

	public boolean checkIfHeaderUIElementsProperlyDisplayed() {
		boolean flg = false;

		if (!benefitId.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitId);
			OneframeLogger("Benefit ID Header is displayed");
			flg = true;
		}

		if (!benefitIdValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(benefitIdValue);
			OneframeLogger("Benefit ID Header value is displayed");
			flg = true;
		}

		if (!headerLob.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerLob);
			OneframeLogger("LOB Header is displayed");
			flg = true;
		}

		if (!headerLobValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerLobValue);
			OneframeLogger("LOB Header value is displayed");
			flg = true;
		}

		if (!headerState.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerState);
			OneframeLogger("State Header is displayed");
			flg = true;
		}

		if (!headerStateValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerStateValue);
			OneframeLogger("State Value Header is displayed");
			flg = true;
		}

		if (!headerFormulary.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerFormulary);
			OneframeLogger("Formulary Header is displayed");
			flg = true;
		}

		if (!headerFormularyValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerFormularyValue);
			OneframeLogger("Formulary Value Header is displayed");
			flg = true;
		}

		if (!headerClient.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerClient);
			OneframeLogger("Client Header is displayed");
			flg = true;
		}

		if (!headerClientValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerClientValue);
			OneframeLogger("Client value Header is displayed");
			flg = true;
		}

		if (!headerEffectiveDate.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEffectiveDate);
			OneframeLogger("Effective Date Header is displayed");
			flg = true;
		}

		if (!headerEffectiveDateValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEffectiveDateValue);
			OneframeLogger("Effective Date value Header is displayed");
			flg = true;
		}

		if (!headerEndDate.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEndDate);
			OneframeLogger("End Date Header is displayed");
			flg = true;
		}

		if (!headerEndDateValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEndDateValue);
			OneframeLogger("End Date value Header is displayed");
			flg = true;
		}

		if (!headerVersion.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerVersion);
			OneframeLogger("Version Header is displayed");
			flg = true;
		}

		if (!headerVersionValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerVersionValue);
			OneframeLogger("Version value Header is displayed");
			flg = true;
		}

		if (!headerEffectiveVersion.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEffectiveVersion);
			OneframeLogger("Effective Version Header is displayed");
			flg = true;
		}

		if (!headerEffectiveVersionValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEffectiveVersionValue);
			OneframeLogger("Effective Version value Header is displayed");
			flg = true;
		}

		if (!headerEffectiveVersionDate.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEffectiveVersionDate);
			OneframeLogger("Effective Version Date Header is displayed");
			flg = true;
		}

		if (!headerEffectiveVersionDateValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEffectiveVersionDateValue);
			OneframeLogger("Effective Version Date value Header is displayed");
			flg = true;
		}

		if (!headerEffectiveVersioEndDate.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEffectiveVersioEndDate);
			OneframeLogger("Effective Version Status Header is displayed");
			flg = true;
		}

		if (!headerEffectiveVersioEndDateValue.isDisplayed()) {
			return false;
		} else {
			highlightElement(headerEffectiveVersioEndDateValue);
			OneframeLogger("Effective Version Status value Header is displayed");
			flg = true;
		}

		return flg;
	}

	public boolean verifyBenefitHeader(String benefitId) {
		WaitForApplicationToLoadCompletely();
		boolean flg = false;

		WaitForObjectVisibility(hdrBenefitID);

		if (hdrBenefitID.getText().equalsIgnoreCase(benefitId)) {
			flg = true;
			highlightElement(hdrBenefitID);
			OneframeLogger("Benefit header is displayed in edit page");
		} else {
			flg = false;
			OneframeLogger("Benefit header is not displayed in edit page");
		}

		return flg;
	}

	@Step("Verify Funding type value")
	public void verifyFundingType(String fundingType) {
		WaitForObjectVisibility(txtFundingType);
		ScrollToElement(txtFundingType);
		if (txtFundingType.getText().equalsIgnoreCase(fundingType)) {
			highlightElement(txtFundingType);
			OneframeLogger("Funding type value is same as expected");
		}
		sa.assertEquals(txtFundingType.getText(), fundingType, "Verified funding type value is same as expected");
	}

	@Step("Verify and Click on General Tab")
	public boolean clickGeneralTab() {
		boolean bln = false;
		if (ObjectExist(btnGeneralTab)) {
			btnGeneralTab.click();
			btnGeneralTab.click();
			btnGeneralTab.click();
			OneframeLogger("General Tab is clicked");
			bln = true;
		}
		return bln;
	}

	@Step("Verify PENCD Toggle is Enabled")
	public boolean verifyPENCDToggleIsEnabled() {
		boolean bln = false;
		if (ObjectExist(tglPencdON)) {
			txtPENCD.click();
			if (tglPencdON.getAttribute("aria-checked").equalsIgnoreCase("true")) {
				OneframeLogger("PENCD Toggle  is Enabled");
				bln = true;
			} else {
				OneframeLogger("PENCD Toggle is disabled");

			}
		}
		return bln;
	}

	@Step("Verify PENCD Toggle is Disabled")
	public boolean verifyPENCDToggleIsDisabled() {
		boolean bln = false;
		if (ObjectExist(tglPencdOFF)) {
			txtPENCD.click();
			if (tglPencdOFF.getAttribute("aria-checked").equalsIgnoreCase("false")) {
				OneframeLogger("PENCD Toggle  is disabled");
				bln = true;
			} else {
				OneframeLogger("PENCD Toggle is Enabled");

			}
		}
		return bln;
	}

	public boolean verifyStateValue(String state) {
		boolean bln = false;
		WaitForObjectVisibility(txtState);
		ScrollToElement(txtState);
		if (txtState.getText().equalsIgnoreCase(state)) {
			bln = true;
			highlightElement(txtState);
			OneframeLogger("State value is same as expected");
		}
		return bln;
	}

}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateFederalMandateTabIsDisplayedWhenAutoApplyNo extends OneframeContainer {

	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;

	@BeforeClass
	@Step("Initializing Test Script for Validating Federal Mandate is Displayed in the Federal tab when Auto Apply is provided as 'No' in Dynamic layer")
	public void setUp() {
		InitializeLaunchPad("IBPW_690");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "Benefit", "ClientId", "EffectiveDate", "LOBId", "StateId",
				"AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary", "FundingType", "MarketSegment",
				"ProductType", "Other" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Federal Mandate is Displayed in the Federal tab when Auto Apply is provided as 'No' in Dynamic layer", dataProvider = "TestData")
	@Description("Validate Federal Mandate is Displayed in the Federal tab when Auto Apply is provided as 'No' in Dynamic layer")
	public void ValidateCreateBenefitDynamicLayer(String TestCaseID, String TestStatus, String Benefit, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String AutoApply, String BusinessEntity,
			String BusinessUnit, String CDHP, String Formulary, String FundingType, String MarketSegment,
			String ProductType, String Other) throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.verifyandclickSearchButton();
			homepage.verifySearchBenefitTextBox();
			homepage.EnterBenefit(Benefit);
			sa.assertTrue(benefitpage.verifySearchResults(), "Verified Benefit Results is displayed");
			benefitpage.verifyCreateaBenefitButtonDisplay();
			benefitpage.clickCreateaBenefitButton();
			sa.assertTrue(createbenefitpage.verifyCreateBenefit(), "Verified 'Create Benefit button' is displayed");
			sa.assertTrue(createbenefitpage.verifyBenefitHeader(), "Verified 'Benefit Header' is displayed");
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(createbenefitpage.selectClientDropdown(ClientId), "Verified and selected 'Client dropdown'");
			sa.assertTrue(createbenefitpage.selectLOBDropdown(LOBId), "Verified and selected 'LOB dropdown' ");
			sa.assertTrue(createbenefitpage.selectStateDropdown(StateId), "Verified and selected 'State dropdown'");
			createbenefitpage.clickBenefitHeader();
			sa.assertTrue(createbenefitpage.verifyAutoApplyDropdown(), "Verified 'Auto Apply dropdown' is displayed");
			String autoApply = createbenefitpage.selectBenefitAutoApplyDropdown(AutoApply);
			sa.assertTrue(createbenefitpage.selectBusinessEntityDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(createbenefitpage.selectBusinessUnitDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' dropdown");
			sa.assertTrue(createbenefitpage.selectCDHPTypeDropdown(CDHP), "Verified and Selected 'CDHP Type' dropdown");
			sa.assertTrue(createbenefitpage.selectFormularyDropdown(Formulary),
					"Verified and Selected 'Formulary' dropdown");
			sa.assertTrue(createbenefitpage.selectFundingTypeDropdown(FundingType),
					"Verified and Selected 'Funding Type' dropdown");
			sa.assertTrue(createbenefitpage.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' dropdown");
			sa.assertTrue(createbenefitpage.selectProductTypeDropdown(ProductType),
					"Verified and Selected 'Product Type' dropdown");
//			sa.assertTrue(createbenefitpage.selectOtherDropdown(Other), "Verified and Selected 'Others' dropdown");
			sa.assertTrue(createbenefitpage.selectMandatesDropdownForDynamicLayer(),
					"Verified and Selected 'Mandates Dropdown'");
			String NewBenefitId = createbenefitpage.clickRequestBenefitIDButtonGetBenefitID();
			createbenefitpage.ClickCBCreateButton();
//			sa.assertTrue(createbenefitpage.verifyBenefitCreatedHeader(NewBenefitId),
//					"Verified 'Created Benefit' header is same as expected");
			sa.assertTrue(createbenefitpage.verifyAutoApplyInBenefitPage(autoApply),
					"Verified 'Auto Apply is 'Yes' in Benefit Details Page");
			createbenefitpage.clickMandatesTab();
			sa.assertTrue(!createbenefitpage.verifyMandateIsNotDisplayedWhenAutoApplyIsNo(),
					"Verified the 'Federal Mandate Tab' is not Displayed when Auto Apply Functionality is given as 'No'");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger(
					"Validate Federal Mandate is not Displayed in the Federal tab when Auto Apply is provided as 'No' in Dynamic layer Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger(
					"Unable to Validate Federal Mandate is not Displayed in the Federal tab when Auto Apply is provided as 'No' in Dynamic layer");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

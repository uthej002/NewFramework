package ibcweb.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.util.List;

public class IBPAccumsBenefitPage extends OneframeContainer {

	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();

	@FindBy(xpath = "//div[text()=' Accums ']")
	WebElement accumsTab;

	@FindBy(xpath = "//*[contains(text(),'Basic')]")
	WebElement basicAccumsTab;

	@FindBy(css = "ingeniorx-ws-accums")
	WebElement txtaccumsContent;

	@FindBy(css = "[data-automation-id='deductible']")
	WebElement tglbasicAccumsApplyDeductibleToggle;

	@FindBy(css = "[data-automation-id='mop']")
	WebElement tglbasicAccumsApplyMoPToggle;

	@FindBy(xpath = "//span[text()='MEMBERS']")
	WebElement basicAccumsMembersLabel;

	@FindBy(xpath = "//span[text()='Family']")
	WebElement accumsFamilyLabel;

	@FindBy(xpath = "//span[text()='Individual']")
	WebElement accumsIndividualLabel;

	@FindBy(xpath = "//span[text()='IN NETWORK']")
	WebElement accumsInNetworkLabel;

	@FindBy(xpath = "//span[text()='OUT OF NETWORK']")
	WebElement accumsOutNetworkLabel;

	@FindBy(xpath = "//input[@data-automation-id='familyInNetwork']")
	WebElement basicFamilyDeductibleandMOPInNetworkTextField;

	@FindBy(xpath = "//input[@data-automation-id='familyOutOfNetwork']")
	WebElement basicFamilyDeductibleandMOPOutNetworkTextField;

	@FindBy(xpath = "//input[@data-automation-id='individualInNetwork']")
	WebElement basicIndividualDeductibleandMOPInNetworkTextField;

	@FindBy(xpath = "//input[@data-automation-id='individualOutOfNetwork']")
	WebElement basicIndividualDeductibleandMOPOutNetworkTextField;

	@FindBy(xpath = "//span[text()='Apply Integrated Medical?']")
	WebElement accumsApplyIntegratedlabel;
	
	@FindBy(xpath="//mat-select[@data-automation-id='applyIntegratedMedicalInNetwork']")
	WebElement accumsApplyIntegratedlabelInNetwork;
	
	@FindBy(xpath="//mat-select[@data-automation-id='dedAppliesOop']")
	WebElement accumsDeductibleAppliesOOP;
	
	@FindBy(xpath="//mat-select[@data-automation-id='applyIntegratedMedicalOutOfNetwork']")
	WebElement accumsApplyIntegratedlabelOutNetwork;	

	@FindBy(xpath = "//span[text()='Embedded']")
	WebElement lblEmbedded;

	@FindBy(xpath = "//mat-select[@data-automation-id='applyIntegratedMedicalInNetwork']")
	WebElement basicMedicalDeductibleandMOPInNetworkTextField;

	@FindBy(xpath = "//mat-select[@data-automation-id='applyIntegratedMedicalOutOfNetwork']")
	WebElement basicMedicalDeductibleandMOPOutNetworkTextField;

	@FindBy(xpath = "//span[contains(text(),\"How does INN and OON Accumulate\")]//following::div[1]")
	WebElement HowdoesINNandOONAccumulate;

	@FindBy(xpath = "//span[contains(text(),\"Deductible applies to OOP\")]//following::div[1]")
	WebElement DeductibleappliestoOOP;

	@FindBy(xpath = "//*/div/mat-slide-toggle[contains(@class, 'mat-checked')]")
	List<WebElement> tglbasicAccumsTogglesEnabled;

	@FindBy(xpath = "//mat-slide-toggle[@data-automation-id='cdhp']")
	WebElement tglbasicAccumsCDHPToggle;

	@FindBy(xpath = "//input[@role='switch']")
	List<WebElement> basicAccumsAllApplyToggleStatus;

	@FindBy(xpath = "//*[@data-automation-id=\"innAndOonCombined\"]")
	WebElement tglInOutNetwork;

	@FindBy(xpath = "//mat-option[@role='option']")
	List<WebElement> drdupfrontDeductibleAppliesvalues;

	@FindBy(xpath = "//span[text()='Upfront deductible applies?']")
	WebElement lblupfrontDeductibleApplies;

	@FindBy(xpath = "//mat-select[@formcontrolname='applyUpfrontDeductible']")
	WebElement drdupfrontDeductibleApplies;

	@FindBy(xpath = "//div[text()=' Upfront Deductible ']")
	WebElement btnUpfrontDeductible;

	@FindBy(xpath = "//div[text()=' Deductible ']")
	WebElement btnDeductible;

	@FindBy(xpath = "//span[text()=' Out of Network and In Network are a combined amount ']")
	WebElement txtInOutOfNetwork;

	@FindBy(xpath = "//span[@class=\"mat-option-text\"]")
	List<WebElement> dropDownValueDeductible;

	@FindBy(xpath = "//span[contains(text(),\"Number of Members to Meet Accum\")]//following::div[1]")
	WebElement NumberOfMembersToMeetAccum;

	@FindBy(xpath = "//div[contains(text(),'Deductible')]")
	WebElement btnDeductibleinAccumsTab;

	@FindBy(xpath = "//div[text()=' MOP ']")
	WebElement btnMOP;

	@FindBy(xpath = "//div[text()=' PSL ']")
	WebElement btnPSL;

	@FindBy(xpath = "//span[@class='subtitle subtitle--first']")
	WebElement lblUpfrontDeductible;

	@FindBy(xpath = "//td[@class='row-label--subtitle']/span[text()='CDHP']")
	WebElement lblCDHP;

	@FindBy(xpath = "//span[text()='Funded By']")
	WebElement lblFundedBy;

	@FindBy(xpath = "//span[text()='Payer ID']")
	WebElement lblPayerID;

	@FindBy(xpath = "//span[text()='HRA Benefit']")
	WebElement lblHRABenefit;

	@FindBy(xpath = "//span[text()='HRA applies to Pharmacy']")
	WebElement lblHRAAppliestoPharmacy;

	@FindBy(xpath = "//span[text()='Apply HRA ($)']")
	WebElement lblApplyHRA;

	@FindBy(xpath = "//span[text()='Cross UFDED and Deductible Process']")
	WebElement lblCrossUFDED;

	@FindBy(xpath = "//span[text()='Cross Network']")
	WebElement lblCrossNetwork;

	@FindBy(xpath = "//mat-select[@data-automation-id='embedded']")
	WebElement drdEmbedded;

	@FindBy(xpath = "//span[contains(text(),'Deductible with PSL')]//following::div")
	WebElement DeductiblewithPSL;

	@FindBy(xpath = "//span[contains(text(),\"Last Quarter Rollover\")]//following::div")
	WebElement LastQuarterRollover;

	@FindBy(xpath = "//mat-select[@data-automation-id='postDeductibleCrossNetwork']")
	WebElement drdCrossNetwork;

	@FindBy(xpath = "//mat-select[@data-automation-id='fundedBy']")
	WebElement drdFundedBy;

	@FindBy(xpath = "//mat-select[@data-automation-id='payerId']")
	WebElement drdPayerID;

	@FindBy(xpath = "//mat-checkbox[@data-automation-id='enabled']")
	WebElement cbkHRABeneit;

	@FindBy(xpath = "//mat-select[@data-automation-id='applyPharmacy']")
	WebElement drdHRAApplyPharmacy;

	@FindBy(xpath = "//mat-select[@data-automation-id='upfrontDeductible']")
	WebElement drdUpfrontDeductibleApplyHRA;

	@FindBy(xpath = "//mat-select[@data-automation-id='deductible']")
	WebElement drdDeductibleApplyHRA;

	@FindBy(xpath = "//mat-select[@data-automation-id='crossUfdedDeductibleProcess']")
	WebElement drdcrossUfdedDeductible;

	@FindBy(xpath = "//span[text()='Split HRA']")
	WebElement lblSplitHRA;

	@FindBy(xpath = "//span[text()='How does INN and OON Accumulate']")
	WebElement lblINNandOON;

	@FindBy(xpath = "//mat-select[@data-automation-id='howDoesINNAndOONAccumulate']")
	WebElement drdhowDoesINNAndOONAccumulate;

	@FindBy(xpath = "//div[contains(@class,'mat-select-panel-wrap')]/div//mat-option[@role='option']/span")
	List<WebElement> drdhowDoesINNAndOONAccumulatevalues;

	@FindBy(xpath = "//mat-select[@data-automation-id='splitHraEnabled']")
	WebElement drdSplitHRAEnabled;

	@FindBy(xpath = "//input[@data-automation-id='splitHraValue']")
	WebElement SplitHRATextField;

	@FindBy(xpath = "//div[@class='left-panel']//mat-selection-list[@role='listbox']")
	WebElement leftpanelelements;

	@FindBy(xpath = "//*[@formcontrolname=\"inNetwork\"]")
	List<WebElement> txtInOutNetworkCombinedField;

	@FindBy(xpath = "//span[contains(text(),\"Family\")]//following::div[2]")
	WebElement txtFamilyFieldInOutNetworkCombined;
	
	@FindBy(xpath="//input[@data-automation-id='individualInNetwork']")
	WebElement txtINNIndividualRetailValue;
	
	@FindBy(xpath="//input[@data-automation-id='innHomeDelivery']")
	List<WebElement> txtINNHomeDeliveryValue;
	
	@FindBy(xpath="//input[@data-automation-id='individualOutOfNetwork']")
	WebElement txtOONIndividualRetailValue;
	
	@FindBy(xpath="//input[@data-automation-id='familyInNetwork']")
	WebElement txtINNFamilyIndividualValue;
	
	@FindBy(xpath="//input[@data-automation-id='familyOutOfNetwork']")
	WebElement txtOONFamilyRetailValue;
	
	@FindBy(xpath="//mat-slide-toggle[@formcontrolname='differentHomeDelivery']")
	WebElement tglDifferentHomeDelivery;
	
	@FindBy(xpath="//mat-select[@formcontrolname='numberMembersMeetAccum']")
	WebElement drdAccumMembers;
	
	@FindBy(xpath="//mat-option[@role='option']/span")
	List<WebElement> dropdownSelectValues;
	
	@FindBy(xpath = "//div[contains(text(),'Deductible')]")
	WebElement clickOnthebtnDeductibleinAccumsTab ;

	@FindBy(xpath = "//*[@data-automation-id='numberMembersMeetAccum']")
	WebElement dropdownMembersAccum;
	
	@FindBy(xpath = "//*[@data-automation-id='howDoesINNAndOONAccumulate']")
	WebElement dropdownINNOONAccum;

	@FindBy(xpath = "//*[@data-automation-id='dedAppliesOop']")
	WebElement dropdownOOPDed;
	
	@FindBy(xpath="//h3[text()='Accums']")
	WebElement txtAccums;
	
	@FindBy(xpath = "//*[@data-automation-id='deductibleWithPSL']")
	WebElement dropdownPSLDed;

	@FindBy(xpath = "//*[@data-automation-id='postDeductibleLastQuarterRollover']")
	WebElement dropdownRollover;
	
	
	@FindBy(xpath = "//*[@data-automation-id='postDeductibleCrossNetwork']")
	WebElement dropdownCrossNetwork;
	
	@FindBy(xpath="//mat-slide-toggle[@formcontrolname='differentHomeDelivery']/label/div/input[@aria-checked='false']")
	WebElement tglHomeDeliveryCheckClick;

	@FindBy(xpath = "//mat-slide-toggle[@formcontrolname='differentHomeDelivery']//input[@role='switch']")
	WebElement differentHomeDeliveryToggle;
		
	@FindBy(xpath = "//div[normalize-space()='Cost Shares Apply']")
	WebElement costSharesApply;
	
	@FindBy(xpath = "//span[normalize-space()='Others']")
	WebElement lblOthers;
	
	@FindBy(xpath = "//span[normalize-space()='Others']/../..//span[text()='IN NETWORK']")
	List<WebElement> hdrInNetwork;
	
	@FindBy(xpath = "//span[normalize-space()='Others']/../..//span[text()='OUT OF NETWORK']")
	List<WebElement> hdrOutOfNetwork;
	
	@FindBy(xpath = "//span[text()='Generic Drugs']")
	WebElement lblGenericDrugs;
	
	@FindBy(xpath = "//span[text()='DAW Penalty']")
	WebElement lblDawPenalty;
	
	@FindBy(xpath = "//span[text()='Generic Drugs']/../..//input")
	List<WebElement> inputGenericDrugs;
	
	@FindBy(xpath = "//span[text()='DAW Penalty']/../..//input")
	List<WebElement> inputDawPenalty;
	
	@FindBy(xpath = "//span[text()='Generic Drugs']/../..//mat-slide-toggle")
	List<WebElement> toggleGenericDrugs;
	
	@FindBy(xpath = "//span[text()='DAW Penalty']/../..//mat-slide-toggle")
	List<WebElement> toggleDawPenalty;
	
	@FindBy(xpath = "//span[@data-automation-id='accumsVendorPayerId']/../../../div")
	List<WebElement> vendorPageTable;
	
	@FindBy(xpath = "//div[text()='Vendor']")
	WebElement vendorTab;
	
	@FindBy(css = "tr.ng-star-inserted > td.cost-share__text")
	List<WebElement> tierList;
	
	@FindBy(xpath = "//div[text()='Advanced Accums']")
	WebElement advancedAccumsTab;
	
	@FindBy(xpath = "//div[@class='advanced']")
	WebElement PSLDetails;

	public IBPAccumsBenefitPage() {
		// Initializing the Page Objects
		PageFactory.initElements(oneframeDriver, this);
	}
	
	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	// Actions
	@Step("Click on Accums Tab")
	public boolean clickOnAccumsTab() {
		boolean flg = false;
		
		WaitForApplicationToLoadCompletely();
		try {
			if (ObjectExist(accumsTab)) {
				ClickWebObject(accumsTab);
				ClickWebObject(accumsTab);
				ClickWebObject(accumsTab);
				ClickWebObject(accumsTab);
				ClickWebObject(accumsTab);
				ClickWebObject(accumsTab);
				Thread.sleep(3000);
				OneframeLogger("Clicked on Accums Tab");
				flg = true;
			}
		} catch (Exception e) {
			OneframeLogger("Accums Tab is not clicked");
			OneframeLogger(e.toString());
		}
		
		return flg;
	}

	@Step("Verify Accums content in Accums on Benefit Page")
	public boolean verifyAccumsContentDisplay() {
		WaitForApplicationToLoadCompletely();
		highlightElement(txtaccumsContent);
		return txtaccumsContent.isDisplayed();
	}

	@Step("Click on Basic in Accums Tab")
	public void clickOnBasicAccumsTab() {
		if (ObjectExist(basicAccumsTab)) {
			ClickWebObject(basicAccumsTab);
			OneframeLogger("Clicked on Basic in Accums Tab");
		} else {
			OneframeLogger("Basic in Accums Tab is not clicked");
		}
	}

	@Step("Verify Apply Deductible Toggle is displayed")
	public boolean verifyApplyDeductibleToggle() {
		WaitForObjectVisibility(tglbasicAccumsApplyDeductibleToggle);
		highlightElement(tglbasicAccumsApplyDeductibleToggle);
		return tglbasicAccumsApplyDeductibleToggle.isDisplayed();
	}

	@Step("Verify Apply MOP Toggle is displayed")
	public boolean verifyApplyMOPToggle() {
		WaitForObjectVisibility(tglbasicAccumsApplyMoPToggle);
		highlightElement(tglbasicAccumsApplyMoPToggle);
		return tglbasicAccumsApplyMoPToggle.isDisplayed();
	}

	@Step("Verify Members Label is displayed")
	public boolean verifyMembersLabel() {
		WaitForObjectVisibility(basicAccumsMembersLabel);
		highlightElement(basicAccumsMembersLabel);
		return basicAccumsMembersLabel.isDisplayed();
	}

	@Step("Verify Family Label is displayed")
	public boolean verifyFamilyLabel() {
		WaitForObjectVisibility(accumsFamilyLabel);
		highlightElement(accumsFamilyLabel);
		return accumsFamilyLabel.isDisplayed();
	}

	@Step("Verify Individual Label is displayed")
	public boolean verifyIndividualLabel() {
		WaitForObjectVisibility(accumsIndividualLabel);
		highlightElement(accumsIndividualLabel);
		return accumsIndividualLabel.isDisplayed();
	}

	@Step("Verify In Network Label is displayed")
	public boolean verifyInNetworkLabel() {
		WaitForObjectVisibility(accumsInNetworkLabel);
		highlightElement(accumsInNetworkLabel);
		return accumsInNetworkLabel.isDisplayed();
	}

	@Step("Verify Out Network Label is displayed")
	public boolean verifyOutNetworkLabel() {
		WaitForObjectVisibility(accumsOutNetworkLabel);
		highlightElement(accumsOutNetworkLabel);
		return accumsOutNetworkLabel.isDisplayed();
	}

	@Step("Verify Family Deductible In Network TextField is displayed")
	public boolean verifyFamilyDeductibleInNetworkField() {
		WaitForObjectVisibility(basicFamilyDeductibleandMOPInNetworkTextField);
		highlightElement(basicFamilyDeductibleandMOPInNetworkTextField);
		return basicFamilyDeductibleandMOPInNetworkTextField.isDisplayed();
	}

	@Step("Verify  Family Deductible Out Network TextField is displayed")
	public boolean verifyFamilyDeductibleOutNetworkField() {
		WaitForObjectVisibility(basicFamilyDeductibleandMOPOutNetworkTextField);
		highlightElement(basicFamilyDeductibleandMOPOutNetworkTextField);
		return basicFamilyDeductibleandMOPOutNetworkTextField.isDisplayed();
	}

	@Step("Verify Individual Deductible In Network TextField is displayed")
	public boolean verifyIndividualDeductibleInNetworkField() {
		WaitForObjectVisibility(basicIndividualDeductibleandMOPInNetworkTextField);
		highlightElement(basicIndividualDeductibleandMOPInNetworkTextField);
		return basicIndividualDeductibleandMOPInNetworkTextField.isDisplayed();
	}

	@Step("Verify Individual Deductible Out of Network TextField is displayed")
	public boolean verifyIndividualDeductibleOutNetworkField() {
		WaitForObjectVisibility(basicIndividualDeductibleandMOPOutNetworkTextField);
		highlightElement(basicIndividualDeductibleandMOPOutNetworkTextField);
		return basicIndividualDeductibleandMOPOutNetworkTextField.isDisplayed();
	}

	@Step("Verify Apply Integrated Medical In Network TextField is displayed")
	public boolean verifyApplyIntegratedMedicalInNetworkField() {
		WaitForObjectVisibility(basicMedicalDeductibleandMOPInNetworkTextField);
		highlightElement(basicMedicalDeductibleandMOPInNetworkTextField);
		return basicMedicalDeductibleandMOPInNetworkTextField.isDisplayed();
	}

	@Step("Verify Apply Integrated Medical In Network dropdown value")
	public void verifyApplyIntegratedMedicalInNetworkDropdownValue() {
		WaitForObjectVisibility(basicMedicalDeductibleandMOPInNetworkTextField);
		ClickWebObject(basicMedicalDeductibleandMOPInNetworkTextField);
		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("Yes")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("No"),
				"Verified Dropdown values in Apply Integrated Medical In Network");
		clickOverlayElement();
	}

	@Step("Verify Apply Integrated Medical Out Network dropdown value")
	public void verifyApplyIntegratedMedicalOutNetworkDropdownValue() {
		WaitForObjectVisibility(basicMedicalDeductibleandMOPOutNetworkTextField);
		ClickWebObject(basicMedicalDeductibleandMOPOutNetworkTextField);
		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("Yes")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("No"),
				"Verified Dropdown values in Apply Integrated Medical Out Network");
		clickOverlayElement();
	}

	@Step("Verify How does INN and ONN Accumulate dropdown value")
	public void verifyHowDoesInnAndOnnAccumulateDropdownValue() {
		WaitForObjectVisibility(HowdoesINNandOONAccumulate);
		ClickWebObject(HowdoesINNandOONAccumulate);
		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("INN and OON Apply to Each Other")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("INN applies to OON")
						&& dropDownValueDeductible.get(2).getText().equalsIgnoreCase("INN and OON are combined")
						&& dropDownValueDeductible.get(3).getText().equalsIgnoreCase("OON Applies to INN")
						&& dropDownValueDeductible.get(4).getText()
								.equalsIgnoreCase("INN and OON do NOT apply to each other"),
				"Verified Dropdown values in How does INN and ONN Accumulate ");
		clickOverlayElement();
	}

	@Step("Verify Deductible Applies to OOP dropdown value")
	public void verifyDeductibleAppliesToOOPDropdownValue() {
		WaitForObjectVisibility(DeductibleappliestoOOP);
		ClickWebObject(DeductibleappliestoOOP);
		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("Yes")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("No"),
				"Verified Dropdown values in Deductible Applies to OOP");
		clickOverlayElement();
	}

	@Step("Verify Embedded dropdown value")
	public void verifyEmbeddedDropdownValue() {
		WaitForObjectVisibility(drdEmbedded);
		ClickWebObject(drdEmbedded);
		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("Not applicable")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("Embedded")
						&& dropDownValueDeductible.get(2).getText().equalsIgnoreCase("Non-Embedded"),
				"Verified Dropdown values in Embedded");
		clickOverlayElement();
	}

	@Step("Verify Deductible with PSL dropdown value")
	public void verifyDeductibleWithPSLDropdownValue() {
		WaitForObjectVisibility(DeductiblewithPSL);
		ClickWebObject(DeductiblewithPSL);
		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("Yes")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("No"),
				"Verified Dropdown values in Deductible with PSL");
		clickOverlayElement();
	}

	@Step("Verify Last Quarter Rollover dropdown value")
	public void verifyLastQuarterRolloverDropdownValue() {
		WaitForObjectVisibility(LastQuarterRollover);
		ClickWebObject(LastQuarterRollover);
		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("Yes")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("No"),
				"Verified Dropdown values in Last Quarter Rollover");
		clickOverlayElement();
	}

	@Step("Verify Cross Network dropdown value")
	public void verifyCrossNetworkDropdownValue() {
		WaitForObjectVisibility(drdCrossNetwork);
		ClickWebObject(drdCrossNetwork);
		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("Not Combined")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("Combined"),
				"Verified Dropdown values in Last Quarter Rollover");
		clickOverlayElement();
	}

	@Step("Verify Apply Integrated Medical Out Network TextField is displayed")
	public boolean verifyApplyIntegratedMedicalOutNetworkField() {
		WaitForObjectVisibility(basicMedicalDeductibleandMOPOutNetworkTextField);
		highlightElement(basicMedicalDeductibleandMOPOutNetworkTextField);
		return basicMedicalDeductibleandMOPOutNetworkTextField.isDisplayed();
	}

	@Step("Click on MOP in Accums Tab")
	public void clickOnMOPToggle() {
		if (ObjectExist(tglbasicAccumsApplyMoPToggle)) {
			ClickWebObject(tglbasicAccumsApplyMoPToggle);
			OneframeLogger("Clicked on MOP Toggle in Accums Tab");
		} else {
			OneframeLogger("MOP Toggle in Accums Tab is not clicked");
		}
	}

	@Step("Verify Family MOP In Network TextField is displayed")
	public boolean verifyFamilyMOPInNetworkField() {
		WaitForObjectVisibility(basicFamilyDeductibleandMOPInNetworkTextField);
		highlightElement(basicFamilyDeductibleandMOPInNetworkTextField);
		return basicFamilyDeductibleandMOPInNetworkTextField.isDisplayed();
	}

	@Step("Verify Family MOP Out Network TextField is displayed")
	public boolean verifyFamilyMOPOutNetworkField() {
		WaitForObjectVisibility(basicFamilyDeductibleandMOPOutNetworkTextField);
		highlightElement(basicFamilyDeductibleandMOPOutNetworkTextField);
		return basicFamilyDeductibleandMOPOutNetworkTextField.isDisplayed();
	}

	@Step("Verify Individual Max out of Pocket Out Network TextField is displayed")
	public boolean verifyIndividualMOPOutNetworkField() {
		WaitForObjectVisibility(basicFamilyDeductibleandMOPOutNetworkTextField);
		highlightElement(basicFamilyDeductibleandMOPOutNetworkTextField);
		return basicFamilyDeductibleandMOPOutNetworkTextField.isDisplayed();
	}

	@Step("Verify Individual Max out of Pocket In Network TextField is displayed")
	public boolean verifyIndividualMOPInNetworkField() {
		WaitForObjectVisibility(basicIndividualDeductibleandMOPInNetworkTextField);
		highlightElement(basicIndividualDeductibleandMOPInNetworkTextField);
		return basicIndividualDeductibleandMOPInNetworkTextField.isDisplayed();
	}

	@Step("Verify Apply Integrated Medical Max out of Pocket Out Network TextField is displayed")
	public boolean verifyMedicalDeductibleMOPOutNetworkField() {
		WaitForObjectVisibility(basicMedicalDeductibleandMOPOutNetworkTextField);
		highlightElement(basicMedicalDeductibleandMOPOutNetworkTextField);
		return basicMedicalDeductibleandMOPOutNetworkTextField.isDisplayed();
	}

	@Step("Verify Apply Integrated Medical Max out of Pocket In Network TextField is displayed")
	public boolean verifyMedicalDeductibleMOPOInNetworkField() {
		WaitForObjectVisibility(basicMedicalDeductibleandMOPInNetworkTextField);
		highlightElement(basicMedicalDeductibleandMOPInNetworkTextField);
		return basicMedicalDeductibleandMOPInNetworkTextField.isDisplayed();
	}

	@Step("Verify the user disables all toggles which are already enabled")
	public void disableAllToggles() {
		try {
			for (int i = 0; i < tglbasicAccumsTogglesEnabled.size(); i++) {
				tglbasicAccumsTogglesEnabled.get(i).click();
				OneframeLogger("All the Enabled Toggles are disabled");
			}
		} catch (NoSuchElementException NE) {
			OneframeLogger("All the Enabled Toggles are not disabled");
		}
	}

	@Step("Enable Required Toggle")
	public void enablerequireToggle(String Item) {
		try {
			for (int i = 0; i < basicAccumsAllApplyToggleStatus.size(); i++) {
				if (basicAccumsAllApplyToggleStatus.get(i).getAttribute("aria-checked").equalsIgnoreCase("false")) {
					String element = String.format("//mat-slide-toggle[@data-automation-id='%s']", Item);
					WebElement ToggleName = oneframeDriver.findElement(By.xpath(element));
					ToggleName.click();
					OneframeLogger("The " + ToggleName.getText() + " Toggle is enabled");
					break;
				}
			}
		} catch (NoSuchElementException NSE) {
			OneframeLogger("The Element is not found");
		}
	}

	@Step("Enable In Out Network Toggle")
	public void enableInOutNetworkToggle() {
		try {
			while (true) {
				if (basicAccumsAllApplyToggleStatus.get(5).getAttribute("aria-checked").equalsIgnoreCase("false")) {
					tglInOutNetwork.click();
					OneframeLogger("The " + tglInOutNetwork.getText() + " Toggle is enabled");
					break;
				} else {
					tglInOutNetwork.click();
				}
			}

		} catch (NoSuchElementException NSE) {
			OneframeLogger("The Element is not found");
		}
	}

	@Step("Disable Required Toggle")
	public void disablerequireToggle(String Item) {
		try {
			for (int i = 0; i < basicAccumsAllApplyToggleStatus.size(); i++) {
				if (basicAccumsAllApplyToggleStatus.get(i).getAttribute("aria-checked").equalsIgnoreCase("true")) {
					String element = String.format("//mat-slide-toggle[@data-automation-id='%s']", Item);
					WebElement ToggleName = oneframeDriver.findElement(By.xpath(element));
					ToggleName.click();
					OneframeLogger("The " + ToggleName.getText() + " Toggle is disabled");
				}
			}
		} catch (NoSuchElementException NSE) {
			OneframeLogger("The Element is not found");
		}
	}

	@Step("Selects 'Yes' option from Upfront deductible applies dropdown")
	public boolean selectYesfromUpfrontDeductible() {
		WaitForObjectVisibility(lblupfrontDeductibleApplies);
		boolean blnRC = false;
		try {
			if (lblupfrontDeductibleApplies.isDisplayed()) {
				ClickWebObject(drdupfrontDeductibleApplies);
				ClickWebObject(drdupfrontDeductibleAppliesvalues.get(0));
				blnRC = true;
			} else {
				blnRC = false;
			}
		} catch (NoSuchElementException NSE) {
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on Upfront Deductible in Accums Tab")
	public void clickOnUpfrontDeductiblebutton() {
		if (ObjectExist(btnUpfrontDeductible)) {
			ClickWebObject(btnUpfrontDeductible);
			OneframeLogger("Clicked on Upfront Deductible in Accums Tab");
		} else {
			OneframeLogger("Upfront Deductible button in Accums Tab is not clicked");
		}
	}

	@Step("Verify Deductible Button is displayed")
	public boolean verifyDeductibleButtonDisplay() {
		// WaitForObjectVisibility(btnDeductible);
		// WaitForApplicationToLoadCompletely();
		highlightElement(btnDeductible);
		return btnDeductible.isDisplayed();
	}

	@Step("Click on the Deductible in Accums Tab ")
	public void clickDeductibleinAccumsTab() {
		if (ObjectExist(btnDeductible)) {
			ClickWebObject(btnDeductible);
			OneframeLogger("Clicked on Deductible in Accums Tab");
		} else {
			OneframeLogger("Deductible button in Accums Tab is not clicked");
		}
	}

	@Step("Verify In Out Of Network Label is displayed")
	public boolean verifyInOutOfNetworkLabel() {
		boolean bln = false;
		if (txtInOutOfNetwork.getText().equalsIgnoreCase("Out of Network and In Network are a combined amount")) {
			return bln = true;
		}
		return bln;
	}


	public void clickAccumsText() {
		ClickWebObject(txtAccums);
		ClickWebObject(txtAccums);
		ClickWebObject(txtAccums);
	}

	
	@Step("Verify Number Of Members To Meet Accum Field is Displayed")
	public boolean verifyNumberOfMembersToMeetAccum() {
		WaitForObjectVisibility(NumberOfMembersToMeetAccum);
		highlightElement(NumberOfMembersToMeetAccum);
		return NumberOfMembersToMeetAccum.isDisplayed();
	}

	@Step("Verify Number Of Members To Meet Accum dropdown value")
	public void verifyNumberOfMembersToMeetAccumDropdownValue() {
		WaitForObjectVisibility(NumberOfMembersToMeetAccum);
		ClickWebObject(NumberOfMembersToMeetAccum);

		sa.assertTrue(
				dropDownValueDeductible.get(0).getText().equalsIgnoreCase("All")
						&& dropDownValueDeductible.get(1).getText().equalsIgnoreCase("1")
						&& dropDownValueDeductible.get(2).getText().equalsIgnoreCase("2")
						&& dropDownValueDeductible.get(3).getText().equalsIgnoreCase("3")
						&& dropDownValueDeductible.get(4).getText().equalsIgnoreCase("4")
						&& dropDownValueDeductible.get(5).getText().equalsIgnoreCase("5")
						&& dropDownValueDeductible.get(6).getText().equalsIgnoreCase("CommonFam3")
						&& dropDownValueDeductible.get(7).getText().equalsIgnoreCase("CommonFam2"),
				"Verified Dropdown values of Number Of Members to Meet Accum");
		clickOverlayElement();
	}

	@Step("Click Overlay Element")
	public void clickOverlayElement() {
		WebElement overlayElement = oneframeDriver.findElement(By.xpath("//div[@class='cdk-overlay-container']"));
		ClickWebObject(overlayElement);
	}

	@Step("Verify MOP Button is displayed")
	public boolean verifyMOPButtonDisplay() {
		// WaitForObjectVisibility(btnMOP);
		// WaitForApplicationToLoadCompletely();
		highlightElement(btnMOP);
		return btnMOP.isDisplayed();
	}

	@Step("Verify PSL Button is displayed")
	public boolean verifyPSLButtonDisplay() {
		// WaitForObjectVisibility(btnPSL);
		// WaitForApplicationToLoadCompletely();
		highlightElement(btnPSL);
		return btnPSL.isDisplayed();
	}

	@Step("Verify Upfront Deductible Label is displayed")
	public boolean verifyUpfrontDeductibleLabel() {
		WaitForObjectVisibility(lblUpfrontDeductible);
		highlightElement(lblUpfrontDeductible);
		return lblUpfrontDeductible.isDisplayed();
	}

	@Step("Verify Apply Integrated Medical Label is displayed")
	public boolean verifyApplyIntegrateMedicalLabel() {
		WaitForObjectVisibility(accumsApplyIntegratedlabel);
		highlightElement(accumsApplyIntegratedlabel);
		return accumsApplyIntegratedlabel.isDisplayed();
	}

	@Step("Verify Embedded Label is displayed")
	public boolean verifyEmbeddedLabel() {
		WaitForObjectVisibility(lblEmbedded);
		highlightElement(lblEmbedded);
		return lblEmbedded.isDisplayed();
	}

	@Step("Verify Cross Network Label is displayed")
	public boolean verifyCrossNetworkLabel() {
		WaitForObjectVisibility(lblCrossNetwork);
		highlightElement(lblCrossNetwork);
		return lblCrossNetwork.isDisplayed();
	}

	@Step("Verify CDHP Label is displayed")
	public boolean verifyCDHPLabel() {
		WaitForObjectVisibility(lblCDHP);
		highlightElement(lblCDHP);
		return lblCDHP.isDisplayed();
	}

	@Step("Verify FundedBy Label is displayed")
	public boolean verifyFundedByLabel() {
		WaitForObjectVisibility(lblFundedBy);
		highlightElement(lblFundedBy);
		return lblFundedBy.isDisplayed();
	}

	@Step("Verify Embedded Dropdown is displayed")
	public boolean verifyEmbeddedDropdown() {
		WaitForObjectVisibility(drdEmbedded);
		highlightElement(drdEmbedded);
		return drdEmbedded.isDisplayed();
	}

	@Step("Verify Cross Network Dropdown is displayed")
	public boolean verifyCrossNetworkDropdown() {
		WaitForObjectVisibility(drdCrossNetwork);
		highlightElement(drdCrossNetwork);
		return drdCrossNetwork.isDisplayed();
	}

	@Step("Verify FundedBy Dropdown is displayed")
	public boolean verifyFundedByDropdown() {
		WaitForObjectVisibility(drdFundedBy);
		highlightElement(drdFundedBy);
		return drdFundedBy.isDisplayed();
	}

	@Step("Verify PayerID Label is displayed")
	public boolean verifyPayerIDLabel() {
		WaitForObjectVisibility(lblPayerID);
		highlightElement(lblPayerID);
		return lblPayerID.isDisplayed();
	}

	@Step("Verify PayerID Dropdown is displayed")
	public boolean verifyPayerIDDropdown() {
		WaitForObjectVisibility(drdPayerID);
		highlightElement(drdPayerID);
		return drdPayerID.isDisplayed();
	}

	@Step("Verify HRA Benefit Label is displayed")
	public boolean verifyHRABenefitLabel() {
		WaitForObjectVisibility(lblHRABenefit);
		highlightElement(lblHRABenefit);
		return lblHRABenefit.isDisplayed();
	}

	@Step("Verify HRA Benefit Checkbox is displayed")
	public boolean verifyHRABenefitCheckbox() {
		WaitForObjectVisibility(cbkHRABeneit);
		highlightElement(cbkHRABeneit);
		return cbkHRABeneit.isDisplayed();
	}

	@Step("Verify HRA Applies to Pharmacy Label is displayed")
	public boolean verifyHRAAppliestoPharmacyLabel() {
		WaitForObjectVisibility(lblHRAAppliestoPharmacy);
		highlightElement(lblHRAAppliestoPharmacy);
		return lblHRAAppliestoPharmacy.isDisplayed();
	}

	@Step("Verify Upfront Deductible Applies Label is displayed")
	public boolean verifyUpfrontDeductibleAppliesLabel() {
		WaitForObjectVisibility(lblupfrontDeductibleApplies);
		highlightElement(lblupfrontDeductibleApplies);
		return lblupfrontDeductibleApplies.isDisplayed();
	}

	@Step("Verify HRA Applies to Pharmacy Dropdown is displayed")
	public boolean verifyHRAAppliesDropdown() {
		WaitForObjectVisibility(drdHRAApplyPharmacy);
		highlightElement(drdHRAApplyPharmacy);
		return drdHRAApplyPharmacy.isDisplayed();
	}

	@Step("Verify Apply HRA Label is displayed")
	public boolean verifyApplyHRALabel() {
		WaitForObjectVisibility(lblApplyHRA);
		highlightElement(lblApplyHRA);
		return lblApplyHRA.isDisplayed();
	}

	@Step("Verify Apply HRA Upfront Deductible Dropdown is displayed")
	public boolean verifyHRAUpfrontDeductibleDropdown() {
		WaitForObjectVisibility(drdUpfrontDeductibleApplyHRA);
		highlightElement(drdUpfrontDeductibleApplyHRA);
		return drdUpfrontDeductibleApplyHRA.isDisplayed();
	}

	@Step("Verify Deductible HRA Dropdown is displayed")
	public boolean verifyDeductibleHRADropdown() {
		WaitForObjectVisibility(drdDeductibleApplyHRA);
		highlightElement(drdDeductibleApplyHRA);
		return drdDeductibleApplyHRA.isDisplayed();
	}

	@Step("Verify Cross UFDED Label is displayed")
	public boolean verifyCrossUFDEDLabel() {
		WaitForObjectVisibility(lblCrossUFDED);
		highlightElement(lblCrossUFDED);
		return lblCrossUFDED.isDisplayed();
	}

	@Step("Verify Cross UFDED Dropdown is displayed")
	public boolean verifyCrossUFDEDDropdown() {
		WaitForObjectVisibility(drdcrossUfdedDeductible);
		highlightElement(drdcrossUfdedDeductible);
		return drdcrossUfdedDeductible.isDisplayed();
	}

	@Step("Verify Split HRA Label is displayed")
	public boolean verifySplitHRALabel() {
		WaitForObjectVisibility(lblSplitHRA);
		highlightElement(lblSplitHRA);
		return lblSplitHRA.isDisplayed();
	}

	@Step("Verify Split HRA Dropdown is displayed")
	public boolean verifySplitHRADropdown() {
		WaitForObjectVisibility(drdSplitHRAEnabled);
		highlightElement(drdSplitHRAEnabled);
		return drdSplitHRAEnabled.isDisplayed();
	}

	@Step("Verify Split HRA Text Field is displayed")
	public boolean verifySplitHRATextField() {
		WaitForObjectVisibility(SplitHRATextField);
		highlightElement(SplitHRATextField);
		return SplitHRATextField.isDisplayed();
	}

	@Step("Verify PayerID Dropdown is displayed")
	public boolean verifyUpfrontDeductibleAppliesDropdown() {
		WaitForObjectVisibility(drdupfrontDeductibleApplies);
		highlightElement(drdupfrontDeductibleApplies);
		return drdupfrontDeductibleApplies.isDisplayed();
	}

	@Step("Verify Left Panel Buttons are displayed")
	public boolean verifyleftPanelButtons() {
		WaitForObjectVisibility(leftpanelelements);
		highlightElement(leftpanelelements);
		return leftpanelelements.isDisplayed();
	}

	@Step("Verify Left Panel Buttons are not displayed")
	public boolean verifyNoLeftPanelButtons() {
		if (FindObjectByLocatorNoWait(
				By.xpath("//div[@class='left-panel']//mat-selection-list[@role='listbox']//mat-list-option")) != null) {
			return true;
		} else {
			return false;
		}
	}

	@Step("Verify How does INN and OON Label is displayed")
	public boolean verifyINNOONLabel() {
		WaitForObjectVisibility(lblINNandOON);
		highlightElement(lblINNandOON);
		return lblINNandOON.isDisplayed();
	}

	@Step("Verify How does INN and OON Dropdown is displayed")
	public boolean verifyINNOONDropdown() {
		WaitForObjectVisibility(drdhowDoesINNAndOONAccumulate);
		highlightElement(drdhowDoesINNAndOONAccumulate);
		return drdhowDoesINNAndOONAccumulate.isDisplayed();
	}

	@Step("Verify the INN and OON Auuumulate Values are displayed")
	public boolean verifyINNandOONAccumulateValuesDisplay() {
		boolean blnRC = false;
		try {
			for (int i = 0; i < drdhowDoesINNAndOONAccumulatevalues.size(); i++) {
				highlightElement(drdhowDoesINNAndOONAccumulatevalues.get(i));
				OneframeLogger(
						"The Accumlate dropdown values are " + drdhowDoesINNAndOONAccumulatevalues.get(i).getText());
				blnRC = true;
			}
		} catch (NoSuchElementException NE) {
			OneframeLogger("All the Enabled Toggles are not disabled");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Click on How does INN and OON Dropdown")
	public void clickOnHowdoesINNandOONDropdown() {
		WaitForApplicationToLoadCompletely();
		if (ObjectExist(drdhowDoesINNAndOONAccumulate)) {
			ClickWebObject(drdhowDoesINNAndOONAccumulate);
			OneframeLogger("Clicked on How does INN and OON Dropdown");
		} else {
			OneframeLogger("How does INN and OON Dropdown is not clicked");
		}
	}

	@Step("Edit and Get Individual Field value combined together in In Out of Network in Accums tab of benefit")
	public String editAndGetIndividualFieldValueOfInOutNetwork() {
		ObjectExist(txtInOutNetworkCombinedField.get(0));
		ClickWebObject(txtInOutNetworkCombinedField.get(0));
		while (!txtInOutNetworkCombinedField.get(0).getAttribute("value").equalsIgnoreCase("")) {
			txtInOutNetworkCombinedField.get(0).sendKeys(Keys.BACK_SPACE);
		}
		int randomNumber = getRandomNumber();
		String value = String.valueOf(randomNumber);
		EnterText(txtInOutNetworkCombinedField.get(0), value);
		OneframeLogger("The Individual field value is : " + txtInOutNetworkCombinedField.get(0).getAttribute("value"));
		return txtInOutNetworkCombinedField.get(0).getAttribute("value");
	}

	@Step("Edit and Get Family Field value combined together in In Out of Network in Accums tab of benefit")
	public String editAndGetFamilyFieldValueOfInOutNetwork() {
		ObjectExist(txtInOutNetworkCombinedField.get(1));
		ClickWebObject(txtInOutNetworkCombinedField.get(1));
		while (!txtInOutNetworkCombinedField.get(1).getAttribute("value").equalsIgnoreCase("")) {
			txtInOutNetworkCombinedField.get(1).sendKeys(Keys.BACK_SPACE);
		}
		int randomNumber = getRandomNumber();
		String value = String.valueOf(randomNumber);
		EnterText(txtInOutNetworkCombinedField.get(1), value);
		OneframeLogger("The Family field value is : " + txtInOutNetworkCombinedField.get(1).getAttribute("value"));
		return txtInOutNetworkCombinedField.get(1).getAttribute("value");
	}

	@Step("Get Random Number")
	public int getRandomNumber() {
		int min = 10;
		int max = 1000;
		int b = (int) (Math.random() * (max - min + 1) + min);
		return b;
	}

	@Step("Verify the edited Individual Field Value is same")
	public boolean verifyEditedIndividualFieldValueIsSame(String IndividualField) {
		boolean bln = false;
		ObjectExist(txtInOutNetworkCombinedField.get(0));
		highlightElement(txtInOutNetworkCombinedField.get(0));
		String IndividualFieldValue = txtInOutNetworkCombinedField.get(0).getAttribute("value");
		if (IndividualFieldValue.equalsIgnoreCase(IndividualField)) {
			bln = true;
		}
		return bln;
	}

	@Step("Verify the edited Family Field Value is same")
	public boolean verifyEditedFamilyFieldValueIsSame(String FamilyField) {
		boolean bln = false;
		ObjectExist(txtInOutNetworkCombinedField.get(1));
		highlightElement(txtInOutNetworkCombinedField.get(1));
		String FamilyFieldValue = txtInOutNetworkCombinedField.get(1).getAttribute("value");
		if (FamilyFieldValue.equalsIgnoreCase(FamilyField)) {
			bln = true;
		}
		return bln;
	}

	@Step("Click on Deductible in Accums Tab")
	public void clickOnDeductibleTab() {
		if (WaitForObjectVisibility(btnDeductible)) {
			ClickWebObject(btnDeductible);
			OneframeLogger("Clicked on Deductible in Accums Tab");
		} else {
			OneframeLogger("Deductible in Accums Tab is not clicked");
		}
	}
	
	@Step("Click on Different Home Delivery Toggle")
	public void clickDifferentHomeDeliveryToggle() throws Throwable {
		Thread.sleep(2000);
		
		try {
			if(ObjectExist(differentHomeDeliveryToggle)) {
				String status = differentHomeDeliveryToggle.getAttribute("aria-checked");
				
				if(status.equalsIgnoreCase("false")) {
					WaitForObject(differentHomeDeliveryToggle);
					ClickWebObject(differentHomeDeliveryToggle);
					WaitForApplicationToLoadCompletely();
					OneframeLogger("Different Home Delivery Toggle is ON");
				}
				else {
					OneframeLogger("Different Home Delivery Toggle is ON");
				}
			}
		} catch (TimeoutException e) {
			OneframeLogger("Different Home Delivery Toggle in Benefit is not clicked");
		}
	}
	
	@Step("Edit the Different Home Delivery Individual Member Values")
	public boolean EditDifferentHomeDeliveryIndividualValues(String IndInnRetail, String IndHomeDelivery, String IndOONRetail) {
		boolean blnRC = false;
		WaitForApplicationToLoadCompletely();
		try {
			if(WaitForObjectVisibility(txtINNIndividualRetailValue)) {
				txtINNIndividualRetailValue.sendKeys(Keys.CONTROL + "a");
				txtINNIndividualRetailValue.sendKeys(Keys.DELETE);
				EnterText(txtINNIndividualRetailValue, IndInnRetail);
				OneframeLogger("The Individual INN Retail Value is "+txtINNIndividualRetailValue.getText());
				Thread.sleep(5000);
				txtINNHomeDeliveryValue.get(0).sendKeys(Keys.CONTROL + "a");
				txtINNHomeDeliveryValue.get(0).sendKeys(Keys.DELETE);
				EnterText(txtINNHomeDeliveryValue.get(0), IndHomeDelivery);
				OneframeLogger("The Individual Home Delivery Value is "+txtINNHomeDeliveryValue.get(0).getText());
				txtOONIndividualRetailValue.sendKeys(Keys.CONTROL + "a");
				txtOONIndividualRetailValue.sendKeys(Keys.DELETE);
				EnterText(txtOONIndividualRetailValue, IndOONRetail);
				OneframeLogger("The Individual OON Retail Value is "+txtOONIndividualRetailValue.getText());
				blnRC = true;
			}
		}catch (NoSuchElementException | InterruptedException NSE) {
				OneframeLogger(NSE.toString());
				blnRC = false;
			}
		return blnRC;
		}
	
	@Step("Edit the Different Home Delivery Family Member Values")
	public boolean EditDifferentHomeDeliveryFamilyValues(String IndInnRetail,String IndHomeDelivery, String IndOONRetail) {
		boolean blnRC = false;
		try {
			if(WaitForObjectVisibility(txtINNFamilyIndividualValue)) {
				txtINNFamilyIndividualValue.sendKeys(Keys.CONTROL + "a");
				txtINNFamilyIndividualValue.sendKeys(Keys.DELETE);
				EnterText(txtINNFamilyIndividualValue, IndInnRetail);
				OneframeLogger("The Family INN Retail Value is "+txtINNFamilyIndividualValue.getText());
				txtINNHomeDeliveryValue.get(1).sendKeys(Keys.CONTROL + "a");
				txtINNHomeDeliveryValue.get(1).sendKeys(Keys.DELETE);
				EnterText(txtINNHomeDeliveryValue.get(1), IndHomeDelivery);
				OneframeLogger("The Family Home Delivery Value is "+txtINNHomeDeliveryValue.get(1).getText());
				txtOONFamilyRetailValue.sendKeys(Keys.CONTROL + "a");
				txtOONFamilyRetailValue.sendKeys(Keys.DELETE);
				EnterText(txtOONFamilyRetailValue, IndOONRetail);
				OneframeLogger("The Family OON Retail Value is "+txtOONFamilyRetailValue.getText());
				blnRC = true;
			}
		}catch (NoSuchElementException NSE) {
				blnRC = false;
			}
		return blnRC;
		}
	
		
	@Step("Enter the Deductible values in Create Accums Page from Libraries Accumulator Structures Section")
	public boolean EnterDeductibleValues() {
		String IndividualInNetwork = "NULL";
		String IndividualOutNetwork = "NULL";
		String FamilyInNetwork = "NULL";
		String FamilyOutNetwork = "NULL";
		boolean blnRC = false;
		try {
			if(WaitForObjectVisibility(basicIndividualDeductibleandMOPInNetworkTextField)) {
				IndividualInNetwork = String.valueOf(getRandomNumber());
				IndividualOutNetwork = String.valueOf(getRandomNumber());
				FamilyInNetwork = String.valueOf(getRandomNumber());
				FamilyOutNetwork = String.valueOf(getRandomNumber());
				EnterText(basicIndividualDeductibleandMOPInNetworkTextField, IndividualInNetwork);
				OneframeLogger("The Individual InNetwork value Enetred");
				EnterText(basicIndividualDeductibleandMOPOutNetworkTextField, IndividualOutNetwork);
				OneframeLogger("The Individual OutNetwork value Entered ");
				EnterText(basicFamilyDeductibleandMOPInNetworkTextField, FamilyInNetwork);
				OneframeLogger("The Family InNetwork value Entered ");
				EnterText(basicFamilyDeductibleandMOPOutNetworkTextField, FamilyOutNetwork);
				OneframeLogger("The Family OutNetwork value Entered ");
			    WaitForObjectVisibility(drdAccumMembers);
			    ClickWebObject(drdAccumMembers);
			    WaitForObjectVisibility(dropdownSelectValues.get(0));
			    ClickWebObject(dropdownSelectValues.get(0));
//			    OneframeLogger("The Number of Meets to Accums value is " +dropdownSelectValues.get(0).getText());		    
			    ClickWebObject(accumsApplyIntegratedlabelInNetwork);
			    ClickWebObject(dropdownSelectValues.get(0));
			    ClickWebObject(accumsApplyIntegratedlabelOutNetwork);
			    ClickWebObject(dropdownSelectValues.get(0));
			    OneframeLogger("The Apply Integrated Medical Values are selected");
			    ClickWebObject(HowdoesINNandOONAccumulate);
			    ClickWebObject(dropDownValueDeductible.get(0)); 
			    OneframeLogger("The How does INN and OON Accumulate Value has been selected");
			    ClickWebObject(accumsDeductibleAppliesOOP);
			    ClickWebObject(dropdownSelectValues.get(0));
			    OneframeLogger("The Deductible applies to OOP Value has been selected");
			    ClickWebObject(drdEmbedded);
			    ClickWebObject(dropdownSelectValues.get(0));
			    OneframeLogger("The Embedded Value has been selected");
			    ClickWebObject(DeductiblewithPSL);
			    ClickWebObject(dropdownSelectValues.get(0));
			    OneframeLogger("The Deductible with PSL Value has been selected");
			    ScrollWebPageByPixel(200);
			    ClickWebObject(LastQuarterRollover);
			    ClickWebObject(dropdownSelectValues.get(0));
			    OneframeLogger("The Last Quarter Rollover Value has been selected");
			    ClickWebObject(drdCrossNetwork);
			    ClickWebObject(dropdownSelectValues.get(0));
			    OneframeLogger("The Cross Network Value has been selected");
			    blnRC = true;
			}
		}catch (StaleElementReferenceException SEF) {
			blnRC = false;
		}
		return blnRC;
	}

	
	@Step("Click on the Deductible in Accums Tab ")
	public void clickOntheDeductibleinAccumsTab() {
		if (ObjectExist(clickOnthebtnDeductibleinAccumsTab)) {
			ClickWebObject(clickOnthebtnDeductibleinAccumsTab);
			OneframeLogger("Clicked on Deductible in Accums Tab");
		} else {
			OneframeLogger("Deductible button in Accums Tab is not clicked");
		}
	}
	
	@Step("Verify How does INN and OON Accumulate displayed")
	public boolean HowdoesINNandOONAccumulate() {
		WaitForObjectVisibility(HowdoesINNandOONAccumulate);
		highlightElement(HowdoesINNandOONAccumulate);
		return HowdoesINNandOONAccumulate.isDisplayed();
	}
	
	@Step("Verify Deductible applies to OOP is displayed")
	public boolean verifyDeductibleappliestoOOP() {
		WaitForObjectVisibility(DeductibleappliestoOOP);
		highlightElement(DeductibleappliestoOOP);
		return DeductibleappliestoOOP.isDisplayed();
	}

	@Step("Verify Deductible with PSL displayed")
	public boolean DeductiblewithPSL() {
		WaitForObjectVisibility(DeductiblewithPSL);
		highlightElement(DeductiblewithPSL);
		return DeductiblewithPSL.isDisplayed();
	}
	
	@Step("Verify Last Quarter Rollover Field is Displayed")
	public boolean verifyLastQuarterRollover() {
		WaitForObjectVisibility(LastQuarterRollover);
		highlightElement(LastQuarterRollover);
		return LastQuarterRollover.isDisplayed();		
	}


	@Step("Select Number of Members from dropdown")
	public boolean selectNumberofMembersDropdown(String NumberofMembers) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(dropdownMembersAccum)) {
				ClickWebObject(dropdownMembersAccum);
				selectDropdownValues(NumberofMembers);
				dropdownMembersAccum.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The Number of Members has not been Selected from dropdown");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Select the values from dropdowns")
	public void selectDropdownValues(String values) {
		String element = String.format("//*[@class = 'mat-option-text' and text()='%s']", values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + dropdownvalue.getText());
	}
	
	@Step("Select INN and OON Accums from  dropdown")
	public boolean selectINNOONAccumsDropdown(String INNOONAccumulate) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(dropdownINNOONAccum)) {
				ClickWebObject(dropdownINNOONAccum);
				selectDropdownValues(INNOONAccumulate);
				dropdownINNOONAccum.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("The INN and OON Accums has not been Selected from dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Select Deductible applies to OOP values from  dropdown")
	public boolean selectOOPDedDropdown(String OOPDed) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(dropdownOOPDed)) {
				ClickWebObject(dropdownOOPDed);
				selectDropdownValues(OOPDed);
				dropdownOOPDed.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Deductible applies to OOP values has not been Selected from dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Select Embedded values from  dropdown")
	public boolean selectEmbeddedDropdown(String Embedded) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(drdEmbedded)) {
				ClickWebObject(drdEmbedded);
				selectDropdownValues(Embedded);
				drdEmbedded.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Embedded values has not been Selected from dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Select Deductible with PSL values from  dropdown")
	public boolean selectPSLDedDropdown(String PSLDed) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(dropdownPSLDed)) {
				ClickWebObject(dropdownPSLDed);
				selectDropdownValues(PSLDed);
				dropdownPSLDed.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Deductible with PSL values has not been Selected from dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Select Last Quarter Rollover with PSL values from  dropdown")
	public boolean selectRolloverDropdown(String Rollover) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(dropdownRollover)) {
				ClickWebObject(dropdownRollover);
				selectDropdownValues(Rollover);
				dropdownRollover.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Last Quarter Rollover values has not been Selected from dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	
	
	@Step("Select Cross Network values from  dropdown")
	public boolean selectCrossNetworkDropdown(String CrossNetwork) {
		boolean blnRC = false;
		try {
			if (WaitForObjectVisibility(dropdownCrossNetwork)) {
				ClickWebObject(dropdownCrossNetwork);
				selectDropdownValues(CrossNetwork);
				dropdownCrossNetwork.sendKeys(Keys.TAB);
				blnRC = true;
			}
		} catch (NoSuchElementException toException) {
			OneframeLogger("Cross Network values has not been Selected from dropdown");
			blnRC = false;
		}
		return blnRC;
	}
	
	
	@Step("Click on Different Home Delivery Toggle")
	public void clickHomeDeliveryToggle() throws Throwable {
		
		try {
			if (ObjectExist(tglHomeDeliveryCheckClick)) {
				ClickWebObject(tglHomeDeliveryCheckClick);
				OneframeLogger("Different Home Delivery Toggle in Benefit clicked");
			}
		} catch (TimeoutException e) {
			//ClickWebObject(tglHomeDeliveryCheckClick);
			OneframeLogger("Different Home Delivery Toggle in Benefit is already clicked");
		}
	} 

	public boolean checkHomeDeliveryToggle() throws InterruptedException {
		boolean bln=false;
		//Thread.sleep(3000);
		try {
			if (ObjectExist(tglHomeDeliveryCheckClick)) {
				ClickWebObject(tglDifferentHomeDelivery);
				OneframeLogger("Different Home Delivery Toggle in Benefit is clicked");
				bln=true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Different Home Delivery Toggle in Benefit is not clicked");
		}
		return bln;
	}

	@Step("Click on Cost Shares Apply Tab")
	public boolean clickCostSharesApply() {
		boolean flg = false;
		WaitForApplicationToLoadCompletely();
		
		try {
			if (ObjectExist(costSharesApply)) {
				ClickWebObject(costSharesApply);
				OneframeLogger("Clicked on Cost Shares Apply Tab under Accums Tab");
				flg = true;
			}
		}
		catch (Exception e) {
			OneframeLogger("Cost Shares Apply Tab under Accums Tab is not clicked: " +e);
			flg = false;
		}
		
		return flg;
	}
	
	@Step("Validate Others label is displayed") 
	public boolean validteOthersLabelIsDisplayed() {	
		boolean flg = false;
		try {
			if(WaitForObjectVisibility(lblOthers)) {
				highlightElement(lblOthers);
				flg = true;
				OneframeLogger("'Others' label is displayed");
			}
			
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		
		return flg;
	}
	
	@Step("Validate Generic Drugs label is displayed") 
	public boolean validteGenericDrugsLabelIsDisplayed() {		
		boolean flg = false;
		try {
			if(WaitForObjectVisibility(lblGenericDrugs)) {
				highlightElement(lblGenericDrugs);
				flg = true;
				OneframeLogger("'Generic Drugs' label is displayed");
			}
			
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Validate DAW Penalty label is displayed") 
	public boolean validteDawPenaltyLabelIsDisplayed() {	
		boolean flg = false;
		try {
			if(WaitForObjectVisibility(lblDawPenalty)) {
				highlightElement(lblDawPenalty);
				flg = true;
				OneframeLogger("'DAW Penalty' label is displayed");
			}
			
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Validate IN NETWORK label is displayed") 
	public boolean validteInNetworkLabelIsDisplayed() {
		boolean flg = false;
		try {			
			for(WebElement ele: hdrInNetwork) {				
				if(WaitForObjectVisibility(ele)) {
					highlightElement(ele);
					flg = true;
				}
			}
			OneframeLogger("'IN NETWORK' label is displayed");
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Validate OUT OF NETWORK label is displayed") 
	public boolean validteOutOfNetworkLabelIsDisplayed() {	
		boolean flg = false;
		try {			
			for(WebElement ele: hdrOutOfNetwork) {				
				if(WaitForObjectVisibility(ele)) {
					highlightElement(ele);
					flg = true;
				}
			}
			OneframeLogger("'OUT OF NETWORK' label is displayed");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Validate Generic Drugs Toggles are not interactable") 
	public boolean validteGenericDrugsTogglesAreNotInteractable() {	
		boolean flg = false;
		try {			
			for(WebElement ele: inputGenericDrugs) {				
				if(!ele.isEnabled()) {
					highlightElement(ele);
					flg = true;
				}
			}
			OneframeLogger("Generic Drugs Toggles are not interactable");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Validate DAW Penalty Toggles are not interactable") 
	public boolean validteDawPenaltyTogglesAreNotInteractable() {	
		boolean flg = false;
		try {			
			for(WebElement ele: inputGenericDrugs) {				
				if(!ele.isEnabled()) {
					highlightElement(ele);
					flg = true;
				}
			}
			OneframeLogger("Generic DAW Penalty are not interactable");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Enable Generic Drugs Toggles") 
	public boolean enableGenericDrugsToggles() {	
		boolean flg = false;
		try {			
			WaitForApplicationToLoadCompletely();
			for(WebElement ele: toggleGenericDrugs) {	
				WaitForObjectToBeClickable(ele);
				if(!ele.getAttribute("class").contains("mat-checked")) {
					highlightElement(ele);
					ClickWebObject(ele);
				}
				flg = true;
			}
			OneframeLogger("Generic Drugs Toggles are clicked");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Enable DAW Penalty Toggles") 
	public boolean enableDawPenaltyToggles() {	
		boolean flg = false;
		try {			
			WaitForApplicationToLoadCompletely();
			Thread.sleep(5000);
			for(WebElement ele: toggleDawPenalty) {	
				WaitForObjectToBeClickable(ele);
				if(!ele.getAttribute("class").contains("mat-checked")) {
					highlightElement(ele);
					ClickWebObject(ele);
				}
				flg = true;
			}
			OneframeLogger("DAW Penalty are clicked");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Disable Generic Drugs Toggles") 
	public boolean disableGenericDrugsToggles() {	
		boolean flg = false;
		try {			
			WaitForApplicationToLoadCompletely();
			for(WebElement ele: toggleGenericDrugs) {	
				WaitForObjectToBeClickable(ele);
				if(ele.isEnabled()) {
					highlightElement(ele);
					ClickWebObject(ele);
					flg = true;
				}
			}
			OneframeLogger("Generic Drugs Toggles are clicked");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Disable DAW Penalty Toggles") 
	public boolean disableDawPenaltyToggles() {	
		boolean flg = false;
		try {			
			WaitForApplicationToLoadCompletely();
			Thread.sleep(5000);
			for(WebElement ele: toggleDawPenalty) {	
				WaitForObjectToBeClickable(ele);
				if(ele.isEnabled()) {
					highlightElement(ele);
					ClickWebObject(ele);
					flg = true;
				}
			}
			OneframeLogger("DAW Penalty are clicked");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Validate Generic Drugs Toggles are ON") 
	public boolean validteGenericDrugsTogglesAreOn() {	
		boolean flg = false;
		try {			
			WaitForApplicationToLoadCompletely();
			for(WebElement ele: inputGenericDrugs) {				
				if(ele.getAttribute("aria-checked").equalsIgnoreCase("true")) {
					highlightElement(ele);
					flg = true;
				}
			}
			OneframeLogger("Generic Drugs Toggles are ON");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}
	
	@Step("Validate Daw Penalty Toggles are ON") 
	public boolean validteDawPenaltyTogglesAreOn() {	
		boolean flg = false;
		try {			
			for(WebElement ele: inputDawPenalty) {				
				if(ele.getAttribute("aria-checked").equalsIgnoreCase("true")) {
					highlightElement(ele);
					flg = true;
				}
			}
			OneframeLogger("Daw Penalty Toggles are ON");
		
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		return flg;
	}

	@Step("Validate Vendor Tab headers and values are displayed")
	public boolean verifyVendorTabHeaderAndValuesAreDisplayed() {
		boolean flg = false;
		try {
			if(vendorPageTable.size() == 3) {
				for(WebElement ele: vendorPageTable) {
					WebElement header = ele.findElement(By.xpath("./child::div/span[@class='label-text']"));
					WebElement value = ele.findElement(By.xpath("./child::div/span[@class='label-value']"));
					
					if(header.isDisplayed() && value.isDisplayed()) {
						highlightElement(header);
						highlightElement(value);
						OneframeLogger("Header '" +header.getText()+ "' is displayed");
						OneframeLogger("Value '" +value.getText()+ "' is displayed");
					}
				}
				flg = true;
			}
			
			
		} catch (Exception e) {
			flg = false;
			OneframeLogger(e.toString());
		}
		
		return flg;
	}
	
	@Step("Click on Vendor Tab")
	public boolean clickVendorTab() {
		boolean flg = false;
		WaitForApplicationToLoadCompletely();
		
		try {
			if (ObjectExist(vendorTab)) {
				ClickWebObject(vendorTab);
				OneframeLogger("Clicked on Vendor Tab under Accums Tab");
				flg = true;
			}
		}
		catch (Exception e) {
			OneframeLogger("Vendor Tab under Accums Tab is not clicked");
		}
		
		return flg;
	}

	@Step("Verify number of Tiers in Cost Shares Apply is equal to number of tiers displayed in Formulary tab")
	public boolean verifyTierCount(String numberOfTiers) {
		boolean flg = false;
		
		try {
			Thread.sleep(5000);
			WaitForApplicationToLoadCompletely();
			if(WaitForObjectVisibility(tierList.get(0))) {
				flg = Integer.parseInt(numberOfTiers) == tierList.size();
				OneframeLogger("Number of Tiers in Cost Shares Apply is: " +tierList.size());
			}
		} catch (Exception e) {
			OneframeLogger("Number of Tiers in Cost Shares Apply does not match with Number of tiers in Formulary tab");
			OneframeLogger(e.toString());
		}
		
		return flg;
	}
	
	@Step("Click Advanced Accums Tab")
	public boolean clickAdvancedAccumsTab() {
		boolean flg = false;
		
		try {
			if(WaitForObjectVisibility(advancedAccumsTab)) {
				ClickWebObject(advancedAccumsTab);
				OneframeLogger("clicked on Advanced Accums tab");
				flg = true;
			}
		} catch (Exception e) {
			OneframeLogger("Unable to click on Advanced Accums tab: " +e);
		}
		
		return flg;
	}

	@Step("Verify PSL Header & Value is displayed")
	public boolean verifyPSLHeaderAndValueIsDisplayed() {
		boolean flg = false;
		
		try {
			if(WaitForObjectVisibility(PSLDetails)) {
				WebElement hdrPSL = PSLDetails.findElement(By.xpath("./child::div[@class='advanced__text']"));
				WebElement valPSL = PSLDetails.findElement(By.xpath("./child::div[@class='advanced__input']"));
				
				if(hdrPSL.isDisplayed() && valPSL.isDisplayed()) {
					highlightElement(hdrPSL);
					OneframeLogger("PSL Header is displayed: " +hdrPSL.getText());
					highlightElement(valPSL);
					OneframeLogger("PSL input box is displayed");
					flg = true;
				}
			}
		} catch (Exception e) {
			OneframeLogger("PSL header and input box is not displayed: " +e);
		}
		
		return flg;
	}
}

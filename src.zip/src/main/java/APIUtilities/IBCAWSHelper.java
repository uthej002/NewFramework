package APIUtilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.remote.server.handler.interactions.touch.Scroll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.DriverType;
import anthem.irx.oneframe.selenium.WebDriverFactory;
import anthem.irx.oneframe.utilities.ConfigFileReader;
import io.qameta.allure.Step;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

public class IBCAWSHelper extends OneframeContainer {

	public static String AWS_URL;
	public static String AWS_USER, account, role, displayName;
	public static String AWS_PASSWORD;

	// WebDriver OFWebDriver = null;
	public static final String IBC_CONFIGURATION = "APIConfig.properties";
	public static final String IBC_CONFIG_FILE = CONFIG_FOLDER + IBC_CONFIGURATION;
	WebDriverFactory fac = new WebDriverFactory();
	OneframeSoftAssert sa = new OneframeSoftAssert();
	
	@FindBy(xpath = "//div[@id='awsui-expandable-section-4-trigger']")
	WebElement lnkProperties;
	
	public IBCAWSHelper() {
		// Initializing the Page Objects
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	public void readIBCConfigurations() {
		ConfigFileReader OneframeConfiguration = new ConfigFileReader(IBC_CONFIG_FILE);
		AWS_URL = OneframeConfiguration.getProperty("awsURL");
		AWS_USER = OneframeConfiguration.getProperty("aws_userName");
		AWS_PASSWORD = OneframeConfiguration.getProperty("aws_password");
		account = OneframeConfiguration.getProperty("account");
		role = OneframeConfiguration.getProperty("role");
		displayName = OneframeConfiguration.getProperty("displayName");
		TSBrowser = "chrome";
		PageLoadTimeOut = Integer.parseInt(OneframeConfiguration.getProperty("Driver.PageLoadTimeout"));
		drivermanager = fac.getDriverManager(DriverType.CHROME);
		OFWebDriver = drivermanager.getWebDriver();
	}

	@Test
	@Step("Login to AWS Console, Switch Role and Region")
	public boolean loginToAWS() {
		readIBCConfigurations();
		// OFWebDriver = new ChromeDriver();

		// OFWebDriver.manage().window().maximize();
		OFWebDriver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		OFWebDriver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		OFWebDriver.get(AWS_URL);

		// Locating the elements using name locator for the text box
		OFWebDriver.findElement(By.xpath("//input[@name='USER']")).sendKeys(AWS_USER);

		// name locator for google search button WebElement searchIcon =
		OFWebDriver.findElement(By.xpath("//input[@name='PASSWORD']")).sendKeys(AWS_PASSWORD);
		OFWebDriver.findElement(By.xpath("//input[@value='Login']")).click();

		OFWebDriver.findElement(By.xpath("//input[@id='arn:aws:iam::556975064168:role/ADFS-Development-Super']")).click();

		OFWebDriver.findElement(By.xpath("//a[contains(text(),'Sign in')]")).click();

		OFWebDriver.findElement(By.xpath("//button[@id='nav-usernameMenu']")).click();

		OFWebDriver.findElement(By.xpath("//a[contains(text(),'Switch Roles')]")).click();

		OFWebDriver.findElement(By.xpath("//input[@id='switchrole_firstrun_button']")).click();

		OFWebDriver.findElement(By.xpath("//input[@id='account']")).sendKeys(account);
		OFWebDriver.findElement(By.xpath("//input[@id='roleName']")).sendKeys(role);

		OFWebDriver.findElement(By.xpath("//input[@id='displayName']")).sendKeys(displayName);

		OFWebDriver.findElement(By.xpath("//input[@id='input_switchrole_button']")).click();
		OFWebDriver.findElement(By.xpath("//button[contains(@data-testid,'more-menu__awsc-nav-regions-menu-button')]"))
				.click();
		OFWebDriver.findElement(By.xpath("//a[contains(@data-region-id,'us-east-1')]")).click();

		boolean onTheHomePage = OFWebDriver.findElement(By.xpath("//span[contains(@title, 'DeveloperSuperExecutionRole ')]")).isDisplayed();
		sa.assertTrue(onTheHomePage, "AWS logging is Successfull with new roles and region");
		sa.assertAll();
		return onTheHomePage;
	}

	@Test
	public boolean triggerLambda(String funName) {

		OFWebDriver.findElement(By.xpath(
				"//input[contains(@placeholder,'Search for services, features, marketplace products, and docs')]"))
				.sendKeys("lambda");
		OFWebDriver.findElement(By.xpath("//h3//span[contains(text(),'Lambda')]")).click();

		OFWebDriver
				.findElement(By
						.xpath("//input[contains(@placeholder,'Filter by tags and attributes or search by keyword')]"))
				.sendKeys(funName);

		OFWebDriver
				.findElement(By
						.xpath("//input[contains(@placeholder,'Filter by tags and attributes or search by keyword')]"))
				.sendKeys(Keys.ENTER);

		OFWebDriver.findElement(By.xpath("//a[contains(text()," + "'" + funName + "'" + ")]")).click();

		OFWebDriver.findElement(By.xpath("//*[@class='awsui-tabs-tab-label']//span[contains(text(),'Test')]")).click();
		OFWebDriver.findElement(By.xpath(
				"//*[@class='awsui-button awsui-button-variant-primary awsui-hover-child-icons']//span[contains(text(),'Test')]"))
				.click();
		boolean success = OFWebDriver.findElement(By.xpath("//span[contains(text(),'Execution result: succeeded')]"))
				.isDisplayed();

		sa.assertTrue(success, "Lambda trigger is successfull : " + funName);
		return success;

	}

	@Test
	@Step("Trigger Lambda")
	public boolean triggerLambdaWithConfig(String funName, String fileName) {
		OFWebDriver.findElement(By.xpath(
				"//input[contains(@placeholder,'Search for services, features, marketplace products, and docs')]"))
				.sendKeys("lambda");
		OFWebDriver.findElement(By.xpath("//h3//span[contains(text(),'Lambda')]")).click();

		OFWebDriver
				.findElement(By
						.xpath("//input[contains(@placeholder,'Filter by tags and attributes or search by keyword')]"))
				.sendKeys(funName);

		OFWebDriver
				.findElement(By
						.xpath("//input[contains(@placeholder,'Filter by tags and attributes or search by keyword')]"))
				.sendKeys(Keys.ENTER);

		OFWebDriver.findElement(By.xpath("//a[contains(text()," + "'" + funName + "'" + ")]")).click();

		OFWebDriver.findElement(By.xpath("//*[@class='awsui-tabs-tab-label']//span[contains(text(),'Configuration')]"))
				.click();
		OFWebDriver.findElement(By.xpath("//button[contains(text(),'Environment variables')]")).click();
		OFWebDriver.findElement(By.xpath("//button//span[contains(text(),'Edit')]")).click();
		OFWebDriver.findElement(By.xpath(
				"//div[@class='awsui-attribute-editor__row'][6]//*[@class='awsui-attribute-editor__field'][2]//input"))
				.clear();

		OFWebDriver.findElement(By.xpath(
				"//div[@class='awsui-attribute-editor__row'][6]//*[@class='awsui-attribute-editor__field'][2]//input"))
				.sendKeys(fileName);

		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		OFWebDriver.findElement(By.xpath("//button//span[text()='Save']")).click();

		sa.assertTrue(OFWebDriver.findElement(By.xpath("//span[text()='Your changes have been saved.']")).isDisplayed(),
				"Configuration Changed saved successfuly");

		OFWebDriver.findElement(By.xpath("//*[@class='awsui-tabs-tab-label']//span[contains(text(),'Test')]")).click();
		OFWebDriver.findElement(By.xpath(
				"//*[@class='awsui-button awsui-button-variant-primary awsui-hover-child-icons']//span[contains(text(),'Test')]"))
				.click();
		boolean success = OFWebDriver.findElement(By.xpath("//span[contains(text(),'Execution result: succeeded')]"))
				.isDisplayed();

		sa.assertTrue(success, "Lambda trigger is successfull : " + funName);
		sa.assertAll();
		return success;
	}

	@Test
	public void triggerLambdaWithConfChanges(String funName, String configVal) {

		OFWebDriver.findElement(By.xpath(
				"//input[contains(@placeholder,'Search for services, features, marketplace products, and docs')]"))
				.sendKeys("lambda");
		OFWebDriver.findElement(By.xpath("//h3//span[contains(text(),'Lambda')]")).click();

		OFWebDriver
				.findElement(By
						.xpath("//input[contains(@placeholder,'Filter by tags and attributes or search by keyword')]"))
				.sendKeys(funName);

		OFWebDriver
				.findElement(By
						.xpath("//input[contains(@placeholder,'Filter by tags and attributes or search by keyword')]"))
				.sendKeys(Keys.ENTER);

		OFWebDriver.findElement(By.xpath("//a[contains(text()," + funName + ")]")).click();
		OFWebDriver.findElement(By.xpath("//span[contains(text(),'Configuration')]")).click();
		OFWebDriver.findElement(By.xpath(" //button[contains(text(),'Environment variables')]")).click();
		OFWebDriver.findElement(By.xpath(
				"//button[@class='awsui-button awsui-button-variant-normal awsui-hover-child-icons']//span[contains(text(),'Edit')]"))
				.click();

		OFWebDriver.findElement(By.xpath("//*[@class='awsui-tabs-tab-label']//span[contains(text(),'Test')]")).click();
		OFWebDriver.findElement(By.xpath(
				"//*[@class='awsui-button awsui-button-variant-primary awsui-hover-child-icons']//span[contains(text(),'Test')]"))
				.click();
		boolean success = OFWebDriver.findElement(By.xpath("//span[contains(text(),'Execution result: succeeded')]"))
				.isDisplayed();

		sa.assertTrue(success, "Lambda trigger is successfull" + funName);

	}

	@Test
	public void logout() {
		OFWebDriver.findElement(By.xpath("//span[contains(@data-testid,'awsc-nav-account-menu-button')]")).click();
		OFWebDriver.findElement(By.xpath("//a[contains(text(),'Sign Out')]")).click();
		OFWebDriver.close();
	}

	public void tearDown() {
		OFWebDriver.close();
	}

	public void downloadFromS3(String funName, String... args) throws Exception {
//String funName,String mainfolder,String subfolder,String folder	
		OFWebDriver.findElement(By.xpath(
				"//input[contains(@placeholder,'Search for services, features, marketplace products, and docs')]"))
				.sendKeys("S3");
		OFWebDriver.findElement(By.xpath("//h3//span[contains(text(),'S3')]")).click();
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find buckets by name')]")).sendKeys(funName);
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find buckets by name')]"))
				.sendKeys(Keys.ENTER);

		OFWebDriver.findElement(By.xpath("//a[contains(text()," + "'" + funName.toLowerCase() + "'" + ")]")).click();
		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		int folderSize = args.length;
		for (String subFolder : args) {
			OFWebDriver.findElement(
					By.xpath("//td[@class='awsui-table-selection-area']/following-sibling ::td//span[contains(text(),'"
							+ subFolder + "')]"))
					.click();
		}
		// OFWebDriver.findElement(By.xpath("//td[@class='awsui-table-selection-area']/following-sibling
		// ::td//span[contains(text(),'"+subfolder+"')]")).click();
		// OFWebDriver.findElement(By.xpath("//td[@class='awsui-table-selection-area']/following-sibling
		// ::td//span[contains(text(),'"+folder+"')]")).click();

		sortByLastMmodified();

		if (args[folderSize - 3].equals("PAHUB")) {
			if (args[folderSize - 1].contains("delta") && args[folderSize - 2].contains("member")) {
				OFWebDriver.findElement(By.xpath("//span[contains(text(),'PAHUB_TEST_Outbound_Member_Delta')]"))
						.click();
			} else if (args[folderSize - 1].contains("full") && args[folderSize - 2].contains("member")) {
				OFWebDriver.findElement(By.xpath("//span[contains(text(),'PAHUB_TEST_Outbound_Member_Full')]")).click();
			}

		}

		else if (args[folderSize - 1].equals("Inbound/")) {

			OFWebDriver.findElement(By.xpath("//span[contains(text(),'MBR.PRVCY')]")).click();
		} else {

			if (args[folderSize - 1].contains("delta") && args[folderSize - 2].contains("member")) {
				OFWebDriver.findElement(By.xpath("//span[contains(text(),'IEP_Outbound_Member_Delta')]")).click();
			} else if (args[folderSize - 1].contains("full") && args[folderSize - 2].contains("member")) {
				OFWebDriver.findElement(By.xpath("//span[contains(text(),'IEP_Outbound_Member_Full')]")).click();
			}
		}
		OFWebDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		new WebDriverWait(OFWebDriver, 60)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Download')]")))
				.click();
		OFWebDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	@Step("Clean up Download folder")
	public void cleanUpDownloadFolder() {
		// TODO Auto-generated method stub
		String location = System.getProperty("user.dir") + "\\test-output\\Downloads";
		File[] listFiles = new File(location).listFiles();
		for (int i = 0; i < listFiles.length; i++) {

			if (listFiles[i].isFile()) {
				listFiles[i].delete();
			}
		}

	}

	public void cleanUpDownloadFolder(String loc) {

		File[] listFiles = new File(loc).listFiles();
		for (int i = 0; i < listFiles.length; i++) {

			if (listFiles[i].isFile()) {
				listFiles[i].delete();
			}
		}

	}

	public void waitUntilFileToDownload() throws InterruptedException {
		Thread.sleep(5000);
		String folderLocation = System.getProperty("user.dir") + "\\test-output\\Downloads";
		File directory = new File(folderLocation);
		long startTime = System.currentTimeMillis();
		boolean downloadinFilePresence = false;
		boolean tmpFilepresent = false;
		File[] filesList = null;
		LOOP: while ((System.currentTimeMillis() - startTime) < 2000000) {
			filesList = directory.listFiles();
			if (filesList.length == 0) {
				continue LOOP;
			}
			for (File file : filesList) {
				OneframeLogger("File name " + file.getName());
				downloadinFilePresence = file.getName().contains(".crdownload");
				tmpFilepresent = file.getName().contains(".tmp");
				if (downloadinFilePresence || tmpFilepresent) {
					for (; downloadinFilePresence || tmpFilepresent;) {
						OneframeLogger("Downloading............" + file.getName());
						Thread.sleep(5000);
						continue LOOP;
					}
				}
			}
			break;
		}
	}

	public void downloadFromS3Inbound(String funName, String args) throws Exception {

		OFWebDriver.findElement(By.xpath(
				"//input[contains(@placeholder,'Search for services, features, marketplace products, and docs')]"))
				.sendKeys("S3");
		OFWebDriver.findElement(By.xpath("//h3//span[contains(text(),'S3')]")).click();
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find buckets by name')]")).sendKeys(funName);
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find buckets by name')]"))
				.sendKeys(Keys.ENTER);

		OFWebDriver.findElement(By.xpath("//a[contains(text()," + "'" + funName.toLowerCase() + "'" + ")]")).click();
		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");

		OFWebDriver.findElement(
				By.xpath("//td[@class='awsui-table-selection-area']/following-sibling ::td//span[contains(text(),'"
						+ args + "')]"))
				.click();

		OFWebDriver.findElement(By.xpath("//span[contains(text(),'I502.')]")).click();

		OFWebDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		new WebDriverWait(OFWebDriver, 60)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Download')]")))
				.click();
		OFWebDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	public void loginToURL(String url) {
		readIBCConfigurations();
		// OFWebDriver = new ChromeDriver();

		// OFWebDriver.manage().window().maximize();
		OFWebDriver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		OFWebDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		OneframeLogger("Logging to : " + url);

		OFWebDriver.get(url);

	}

	public boolean downloadFromS3WithConfig(String reportPrefix, String funName, String Pli, String... args)
			throws Exception {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat DateForSimple = new SimpleDateFormat("yyyyMM");
		// String funName,String mainfolder,String subfolder,String folder

//		navigateToS3Folder(funName, args);
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find objects by prefix')]"))
				.sendKeys(Pli + reportPrefix + DateForSimple.format(cal.getTime()));

		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find objects by prefix')]"))
				.sendKeys(Keys.ENTER);

		sortByLastMmodified();

		OFWebDriver
				.findElement(By.xpath(
						"//span[contains(text(),'" + Pli + reportPrefix + DateForSimple.format(cal.getTime()) + "')]"))
				.click();

		boolean buttonEnabled = downloadFile();
		return buttonEnabled;

	}

	@Step("Download File")
	public boolean downloadFile() throws InterruptedException {
		OFWebDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		int attempts = 0;
		int maxAttempts = 10;
		boolean buttonEnabled = false;
		while (attempts++ <= maxAttempts) {
			if (OFWebDriver.findElement(By.xpath("//span[contains(text(),'Download')]")).isEnabled()
					&& OFWebDriver.findElement(By.xpath("//span[contains(text(),'Download')]")).isDisplayed()) {
				buttonEnabled = true;
				break;
			} else {
				Thread.sleep(500);
			}
		}
		if (buttonEnabled) {
			new WebDriverWait(OFWebDriver, 80)
					.until(ExpectedConditions
							.elementToBeClickable(By.xpath("//span[contains(text(),'Download')]//parent::button")))
					.click();
			OFWebDriver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			buttonEnabled = buttonEnabled && true;
		} else {
			// Your failure code
			buttonEnabled = buttonEnabled && false;
		}
		return buttonEnabled;
	}
	
	@Step("Click on Upload File Button")
	public boolean clickuploadFilebutton() throws InterruptedException {
		OFWebDriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		int attempts = 0;
		int maxAttempts = 10;
		boolean buttonEnabled = false;
		while (attempts++ <= maxAttempts) {
			if (OFWebDriver.findElement(By.xpath("//span[contains(text(),'Upload')]")).isEnabled()
					&& OFWebDriver.findElement(By.xpath("//span[contains(text(),'Upload')]")).isDisplayed()) {
				buttonEnabled = true;
				break;
			} else {
				Thread.sleep(500);
			}
		}
		if (buttonEnabled) {
			new WebDriverWait(OFWebDriver, 100)
					.until(ExpectedConditions
							.elementToBeClickable(By.xpath("//span[contains(text(),'Upload')]//parent::button")))
					.click();
			OFWebDriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
//			OFWebDriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
//			WebElement addFile = OFWebDriver.findElement(By.xpath("//awsui-button[@class='upload-file-table__add-file-button']"));
//			if (addFile.isEnabled()&& addFile.isDisplayed()) {
//				addFile.click();
//			OneframeLogger("Add Files Button is clicked");
//			OFWebDriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
//			buttonEnabled = buttonEnabled && true;
//			} else {
//				OneframeLogger("Add Files Button is not clicked");
//				buttonEnabled = buttonEnabled && false;
//			}
			} 
			else {
			// Your failure code
			buttonEnabled = buttonEnabled && false;
		}
		return buttonEnabled;
		}
		
	@Step("Upload File from System")
	public boolean uploadFileFromSystem(String fileName) throws Throwable{
		OFWebDriver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
//		OFWebDriver.findElement(By.xpath("//awsui-button[@class='upload-file-table__add-file-button']")).sendKeys("C:\\Repositories\\IBP\\src\\test\\resources\\TestData\\PMT-20210930-0007 - Copy.xlsx");
		
		WebElement addFile = OFWebDriver.findElement(By.xpath("//awsui-button[@class='upload-file-table__add-file-button']"));
		addFile.click();
		
		Thread.sleep(3000);
		Robot rb;
		boolean fileUpload = false;
		try {
			rb = new Robot();
			String str = "C:\\Repositories\\IBP\\src\\test\\resources\\TestData\\"+fileName;
			OneframeLogger("The Message is "+str);
			StringSelection INPUT_FOLDER =new StringSelection(str);			
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(INPUT_FOLDER, null);
			
			 
			 rb.keyPress(KeyEvent.VK_CONTROL);
		     rb.keyPress(KeyEvent.VK_V);
		     
		     rb.keyRelease(KeyEvent.VK_CONTROL);
		     rb.keyRelease(KeyEvent.VK_V);
		     
		     rb.keyPress(KeyEvent.VK_ENTER);
		     
		     rb.keyRelease(KeyEvent.VK_ENTER);	
		     fileUpload = true;
		   
		} catch (AWTException e) {
			e.printStackTrace();
			fileUpload = false;
		}
		 return fileUpload;		 
	}
	
	@Step("Click on Properties")
	public boolean clickonProperties() throws Throwable {
		Thread.sleep(5000);
		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		if(OFWebDriver.findElement(By.xpath("//div[@id='awsui-expandable-section-4-trigger']")).isDisplayed()) {
			OFWebDriver.findElement(By.xpath("//div[@id='awsui-expandable-section-4-trigger']")).click();
			return true;
		}else {
			return false;
		}
	}
	
	@Step("Select the Server-side encryption settings")
	public boolean clickonserversideencryptionsettings( ) {
		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		if(OFWebDriver.findElement(By.xpath("//h3[text()='Server-side encryption settings']")).isDisplayed()) {
			OFWebDriver.findElement(By.xpath("//h3[text()='Server-side encryption settings']")).click();
			OFWebDriver.findElement(By.xpath("//label[text()='Server-side encryption']")).click();
			((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			OFWebDriver.findElement(By.xpath("//div[@class='awsui-radio-button-label-text']//span[text()='Specify an encryption key']")).click();
			((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			OFWebDriver.findElement(By.xpath("//div[@class='awsui-radio-button-label-text']//span[text()='Override default encryption bucket settings']")).click();
			((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			OFWebDriver.findElement(By.xpath("//div[@class='awsui-radio-button-label-text']//span[text()='AWS managed key (aws/s3)']")).click();		
			return true;
		}else {
			return false;
		}
	}
	
	@Step("Click on upload")
	public boolean clickonUpload() {
		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		if(OFWebDriver.findElement(By.xpath("//button[@type='submit']//span[text()='Upload']")).isDisplayed()) {
			OFWebDriver.findElement(By.xpath("//button[@type='submit']//span[text()='Upload']")).click();
			return true;
		}else {
			return false;
		}
	}
	
	@Step("Verify whether upload has been completed")
	public boolean verifyuploadcompleted() {
		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		WebElement message= OFWebDriver.findElement(By.xpath("//div[@class='awsui-flash-header']//span[text()='Upload succeeded']"));
		if(OFWebDriver.findElement(By.xpath("//div[@class='awsui-flash-header']//span[text()='Upload succeeded']")).isDisplayed()) 
			OFWebDriver.findElement(By.xpath("//div[@class='awsui-flash-header']//span[text()='Upload succeeded']")).click();
			if(message.getText().contains("Upload succeeded"))	{
				OneframeLogger("The Message is " + message.getText());
			return true;
		}else {
			return false;
		}
	}
	
	@Step("Click on destination")
	public boolean clickonDestination() {
		OFWebDriver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
//		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		if(OFWebDriver.findElement(By.xpath("//div[@class='key-value-pair__value']//a[@class='console-link']")).isDisplayed()) {
			OFWebDriver.findElement(By.xpath("//div[@class='key-value-pair__value']//a[@class='console-link']")).click();
			return true;
		}else {
			return false;
		}
	}
	
	@Step("Verify whether File Ingestion has been completed")
	public boolean verifyFileIngestionProcess(String fileName) {
		boolean blnRC = false;
		OFWebDriver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		OFWebDriver.findElement(By.xpath("//awsui-button[@id='refresh']")).click();
		OFWebDriver.findElement(By.xpath("//awsui-button[@id='refresh']")).click();
		if(OFWebDriver.findElement(By.xpath("//span[@class='awsui-table-header-content']/span/span[@class='column-LastModified' and text()='Last modified']")).isDisplayed()) 
			OFWebDriver.findElement(By.xpath("//span[@class='awsui-table-header-content']/span/span[@class='column-LastModified' and text()='Last modified']")).click();
			OFWebDriver.findElement(By.xpath("//span[@class='awsui-table-header-content']/span/span[@class='column-LastModified' and text()='Last modified']")).click();
			OneframeLogger("Last Modified button is clicked");
List<WebElement> uploadedfiles = OFWebDriver.findElements(By.xpath("//div[@class='awsui-table-container']//span[@class='name object latest object-name']"));
		for (int i=0;i<uploadedfiles.size();i++) {
			if(uploadedfiles.get(i).getText().equalsIgnoreCase(fileName)) {
				blnRC = true;
		}else {
			blnRC = false;				
		}
		}
		return blnRC;
	}
	//span[@class='awsui-table-header-content']/span/span[@class='column-LastModified' and text()='Last modified']
	
	@Step("Sort by Last Modified")
	public void sortByLastMmodified() {
		OFWebDriver.findElement(By.xpath(
				"//div[contains(@class,'awsui-table-container')]//span[contains(text(),'Last modified')]/parent::span//following-sibling::awsui-icon//span"))
				.click();
		OFWebDriver.findElement(By.xpath(
				"//div[contains(@class,'awsui-table-container')]//span[contains(text(),'Last modified')]/parent::span//following-sibling::awsui-icon//span"))
				.click();
		OneframeLogger("Sorted by Last Modified");
	}

	@Step("Navigate to S3 bucket & subfolders")
	public void navigateToS3Folder(String funName) {
		OFWebDriver.findElement(By.xpath(
				"//input[contains(@placeholder,'Search for services, features, marketplace products, and docs')]"))
				.sendKeys("S3");
		OFWebDriver.findElement(By.xpath("//h3//span[contains(text(),'S3')]")).click();
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find buckets by name')]")).sendKeys(funName);
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find buckets by name')]"))
				.sendKeys(Keys.ENTER);
		OFWebDriver.findElement(By.xpath("//a[contains(text()," + "'" + funName.toLowerCase() + "'" + ")]")).click();
		OneframeLogger("In S3 bucket");
		((JavascriptExecutor) OFWebDriver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		//a[@class='bucket-name']
//		int folderSize = args.length;
//		for (String subFolder : args) {
//			OFWebDriver.findElement(
//					By.xpath("//td[@class='awsui-table-selection-area']/following-sibling ::td//span[contains(text(),'"
//							+ subFolder + "')]"))
//					.click();
//			OneframeLogger("In " + subFolder + " folder");
//		}
	}

	public String get1stObjectFileNameAndClick() {
		WebElement filename = OFWebDriver.findElement(By.xpath("//span[@class=\"name object latest object-name\"]"));
		String fileNameStr = filename.getText();
		filename.click();
		return fileNameStr;
	}

	@Step("Get First Object Name by File Name and Click")
	public String get1stObjectByNameFileNameAndClick(String name) {
		WebElement filename = OFWebDriver.findElement(By.xpath(
				String.format("//span[@class=\"name object latest object-name\" and contains(text(),\"%s\")]", name)));
		String fileNameStr = filename.getText();
		filename.click();
		return fileNameStr;
	}

	public void searchByPrefix(String prefix) {
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find objects by prefix')]")).sendKeys(prefix);
		OFWebDriver.findElement(By.xpath("//input[contains(@placeholder,'Find objects by prefix')]"))
				.sendKeys(Keys.ENTER);
	}
}
package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.ClickWebObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.FindObjectByLocatorNoWait;
import static anthem.irx.oneframe.selenium.WebObjectHandler.ObjectExist;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObject;
import static anthem.irx.oneframe.selenium.WebObjectHandler.WaitForObjectVisibility;
import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.text.WordUtils;
import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.google.common.base.CaseFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import anthem.irx.oneframe.selenium.WebObjectHandler;
import io.qameta.allure.Step;

public class IBPBenefitNetworksPage extends OneframeContainer {
	OneframeSoftAssert sa = new OneframeSoftAssert();
	OneframeAssert ha = new OneframeAssert();
	
	@FindBy(xpath = "//div[text()=' Networks ']")
	WebElement tabNetworks;
	
	@FindBy(xpath = "//div[@class='subheader']/div[text()='Include']")
	List<WebElement> hdrInclude;
	
	@FindBy(xpath = "//div[@class='subheader']/div[text()='Max Day Supply']")
	List<WebElement> hdrMaxDaySupply;
	
	@FindBy(xpath = "//div[@class='subheader']/div[text()='Refill To Soon']")
	List<WebElement> hdrRefillToSoon;
	
	@FindBy(xpath = "//div[@class='subheader']/div[text()='Quantity']")
	List<WebElement> hdrQuantity;
	
	@FindBy(xpath = "//div[@class='header row']/div[@class='start']")
	WebElement hdrNetworkPackage;
	
	@FindBy(xpath = "//h3")
	WebElement hdrNetworksSetup;
	
	@FindBy(xpath = "//div[@class='header row']/div[text()='RxChoice']")
	WebElement hdrPackagedNetwork;
	
	@FindBy(xpath = "//div[@class='header row']/div[text()='Nonpackaged Networks']")
	WebElement hdrNonPackagedNetwork;
	
	@FindBy(xpath = "//span[normalize-space()='Add a Nonpackaged Network']/..")
	WebElement btnAddNonPackagedNetwork;
	
	@FindBy(xpath = "//span[normalize-space()='Add a Network Package']/..")
	WebElement btnAddPackagedNetwork;
	
	@FindBy(xpath = "//div[@class='row network-channel']//mat-checkbox")
	List<WebElement> allRetailAndHomeDeliveryCheckboxes;
	
	@FindBy(xpath = "//div[@class='row network-channel']")
	List<WebElement> networkList;
	
	@FindBy(xpath = "//div[@class='row network-channel']/div[text()]/../div[2]//mat-checkbox")
	List<WebElement> retailCheckBoxes;
	
	@FindBy(xpath = "//div[@class='row network-channel']/div[text()]/../div[3]//mat-checkbox")
	List<WebElement> homeDeliveryCheckBoxes;
	
	
	public IBPBenefitNetworksPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}

	@Step("Click on Networks Tab")
	public boolean clickNetworksTab() {
		boolean flg = false;
		try {
			if (WaitForObjectVisibility(tabNetworks)) {
				ClickWebObject(tabNetworks);
				OneframeLogger("Clicked on Networks tabs");
				flg = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Netowrks tab is not Clicked");
		}
		
		return flg;
	}
	
	@Step("Verify Max Day Supply header is displayed")
	public boolean verifyMaxDaySupplyHeaderIsDisplayed() {
		boolean flg = false;
		
		for(WebElement ele: hdrMaxDaySupply) {
			if(WaitForObjectVisibility(ele)) {
				highlightElement(ele);
				flg = true;
			}
			else {
				return false;
			}
		}
		return flg;
	}
	
	@Step("Verify Refill To Soon header is displayed")
	public boolean verifyRefillToSoonHeaderIsDisplayed() {
		boolean flg = false;
		
		for(WebElement ele: hdrRefillToSoon) {
			if(WaitForObjectVisibility(ele)) {
				highlightElement(ele);
				flg = true;
			}
			else {
				return false;
			}
		}
		return flg;
	}
	
	@Step("Verify Quantity header is displayed")
	public boolean verifyQuantityHeaderIsDisplayed() {
		boolean flg = false;
		
		for(WebElement ele: hdrQuantity) {
			if(WaitForObjectVisibility(ele)) {
				highlightElement(ele);
				flg = true;
			}
			else {
				return false;
			}
		}
		return flg;
	}
	
	@Step("Verify Inlcude header is displayed")
	public boolean verifyIncludeHeaderIsDisplayed() {
		boolean flg = false;
		
		for(WebElement ele: hdrInclude) {
			if(WaitForObjectVisibility(ele)) {
				highlightElement(ele);
				flg = true;
			}
			else {
				return false;
			}
		}
		return flg;
	}
	
	@Step("Verify given header is displayed")
	public boolean verifyHeaderIsDisplayed(String headerName) {
		boolean flg = false;
		
		String xpath = "//div[@class='row network-channel']/div[text()='"+headerName+"']";
		WebElement expectedHeader = oneframeDriver.findElement(By.xpath(xpath));
		
		if(WaitForObject(expectedHeader)) {
			highlightElement(expectedHeader);
			flg = true;
		}
		else {
			flg = false;
		}
		
		return flg;
	}
	
	@Step("Verify RxChoice Header is displayed")
	public boolean verifyRxChoiceHeaderIsDisplayed(String headerName) {
		boolean flg = false;
		
		if(WaitForObject(hdrNetworkPackage)) {
			highlightElement(hdrNetworkPackage);
			String x = hdrNetworkPackage.getText();
			if(hdrNetworkPackage.getText().trim().equalsIgnoreCase(headerName)) {
				flg = true;	
			}
		}
		else {
			flg = false;
		}
		
		return flg;
	}

	@Step("Verify Networks Setup header is displayed")
	public boolean verifyNetworksSetupHeaderIsDisplayed() {
		boolean flg = false;
		
		try {
			if(WaitForObjectVisibility(hdrNetworksSetup)) {
				highlightElement(hdrNetworksSetup);
				OneframeLogger("Networks Setup header is displayed");
				flg = true;
			}
		} catch (Exception e) {
			OneframeLogger("Networks Setup header is not displayed: " +e);
		}
		
		return flg;
	}

	@Step("Verify Network Sub Header is displayed")
	public boolean verifyNetworkHeaderIsDisplayed(String string) {
		boolean flg = false;
		String xpath = "//div[@class='header row']/div[text()='"+string+"']";
		List<WebElement> ele = null;
		
		try {
			ele = oneframeDriver.findElements(By.xpath(xpath));
			
			if(ele.size() != 0) {
				highlightElement(ele.get(0));
				OneframeLogger(string+ " header is displayed");
				flg = true;
			}
			
		} catch (Exception e) {
			OneframeLogger(string+ " header is not displayed: " +e);
		}
		
		return flg;
	}
	
	@Step("Verify Add Non Packaged Networks Button is displayed")
	public boolean verifyAddNonPackagedNetworkButtonIsDisplayed() {
		boolean flg = false;
		
		try {
			if(WaitForObjectVisibility(btnAddNonPackagedNetwork)) {
				highlightElement(btnAddNonPackagedNetwork);
				OneframeLogger("Add Non Packaged Networks Button is displayed");
				flg = true;
			}
		} catch (Exception e) {
			OneframeLogger("Add Non Packaged Networks Button is not displayed: " +e);
		}
		
		return flg;
	}
	
	@Step("Verify Add Network Package Button is displayed")
	public boolean verifyAddNetworkPackageButtonIsDisplayed() {
		boolean flg = false;
		
		try {
			if(WaitForObjectVisibility(btnAddPackagedNetwork)) {
				highlightElement(btnAddPackagedNetwork);
				OneframeLogger("Add Network Package Button is displayed");
				flg = true;
			}
		} catch (Exception e) {
			OneframeLogger("Add Network Package Button is not displayed: " +e);
		}
		
		return flg;
	}
	
	
	@Step("Uncheck Retial & Home Delivery checkboxes for all Networks")
	public boolean uncheckRetailAndHomeDeliveryCheckboxes() {
		boolean flg = false;
		
		try {
			WaitForApplicationToLoadCompletely();
			for(WebElement ele: allRetailAndHomeDeliveryCheckboxes) {
				if(ele.getAttribute("class").contains("mat-checkbox-checked")) {
					ClickWebObject(ele);
				}
			}
			OneframeLogger("Unchecked all checkboxes for Retail & Home Delivery");
			flg = true;
			
		} catch (Exception e) {
			sa.assertTrue(false, "unable to uncheck checkboxes for network packages");
			flg = false;
		}
		
		return flg;
	}
	
	@Step("Check all {string} checkboxes")
	public List<String> checkAllCheckboxes(String string){
		List<String> networksToVerify = new ArrayList<String>();
		
		try {
			List<WebElement> list = (string.equalsIgnoreCase("retail"))?retailCheckBoxes:homeDeliveryCheckBoxes;
			for(WebElement ele: list) {		
				if(!ele.getAttribute("class").contains("mat-checkbox-checked")) {
					ClickWebObject(ele);
				}
				String packageName = ele.findElement(By.xpath("./child::label/ancestor::div/div[@class='start']")).getText().trim();
				networksToVerify.add(packageName);
			}
			OneframeLogger("Checked all "+string+" Checkboxes");			
		} catch (Exception e) {
			OneframeLogger("Unable to check all "+string+" Checkboxes: " +e);
		}	
		return networksToVerify;
	}

	public String getValue(String rowName, String category, String columnName) {
		String value = null;
		
		try {
			String xpath = String.format("//div[text()='%s']/../div[%s]//input[@formcontrolname='%s']", rowName, category.equalsIgnoreCase("retail")?"2":"3", columnName);
			WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
			
			value = ele.getAttribute("value").trim();
			
			if(value.length() == 0) {
				ha.assertFalse(true, "Value is empty");
			}
			
		} catch (Exception e) {
			OneframeLogger("Error while getting value from :" +rowName+ " - " +category+ " - " +columnName);
		}
		
		return value;
	}
	
	@Step("Enter {value} into the field {columnName} under {category} on row {rowName}")
	public Boolean clearAndEnterValue(String rowName, String category, String columnName, String value) {
		
		Boolean flg = false;
		
		try {
			String xpath = String.format("//div[text()='%s']/../div[%s]//input[@formcontrolname='%s']", rowName, category.equalsIgnoreCase("retail")?"2":"3", columnName);
			WebElement ele = oneframeDriver.findElement(By.xpath(xpath));
			ClickWebObject(ele);
			int eleLength = ele.getAttribute("value").length();
			ele.sendKeys(Keys.ARROW_RIGHT);
			ele.sendKeys(Keys.ARROW_RIGHT);
			ele.sendKeys(Keys.ARROW_RIGHT);
			for(int i=0; i<eleLength; i++) {
				ele.sendKeys(Keys.BACK_SPACE);
			}

			EnterText(ele, value);
			flg=true;
			
		} catch (Exception e) {
			OneframeLogger("Error while entering value into Row: " +rowName+ ", Category: " +category+ ", column: " +columnName);
			OneframeLogger(e.toString());
			flg=false;
		}
		
		return flg;
	}

	
	@Step("Verify Actual value matches with Expected value")
	public boolean verifyNetworkValues(Map<String, String> newValues, String string) {
		boolean flg = false;
		
		for(String actualValue: newValues.keySet()) {
			if(!newValues.get(actualValue).equals(string)) {
				return false;
			}
			else {
				flg = true;
			}
		}
		
		return flg;
	}
	
	@Step("Verify Actual value matches with Expected value")
	public boolean verifyNetworkValues(Map<String, String> newValues, Map<String, String> expected) {
		boolean flg = false;
		
		for(String actualValue: newValues.keySet()) {
			if(!newValues.get(actualValue).equals(expected.get(actualValue))) {
				return false;
			}
			else {
				OneframeLogger("Actual Value: " +newValues.get(actualValue)+ ", Expected Value: " +expected.get(actualValue));
				flg = true;
			}
		}
		
		return flg;
	}
	
}

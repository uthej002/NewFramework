package ibcweb.TestScripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateLibrariesCreateCOBDefault extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validating Libraries Create Controls COB Default")
	public void setUp() {
		InitializeLaunchPad("IBPW_794");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "ClientId", "EffectiveDate", "LOBId", "StateId", "TermDate",
				"COBProcessingMethod", "COBPackage", "AutoApply", "BusinessEntity", "BusinessUnit", "CDHP", "Formulary",
				"FundingType", "MarketSegment", "ProductType", "Other" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Libraries Create Controls COB Default", dataProvider = "TestData")
	@Description("Validate Libraries Create Controls COB Default")
	public void ValidateCOBDefaultDynamicLayer(String TestCaseID, String TestStatus, String ClientId,
			String EffectiveDate, String LOBId, String StateId, String TermDate, String COBProcessingMethod,
			String COBPackage, String AutoApply, String BusinessEntity, String BusinessUnit, String CDHP,
			String Formulary, String FundingType, String MarketSegment, String ProductType, String Other)
			throws Throwable {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			controls.clickViewButtonofControls();
			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'Controls' header is displayed");
			controls.clickCOBDefaultTab();
			controls.clickCreateCOBDefault();
			sa.assertTrue(controls.verifyCreateACOBDefaultHeader(),
					"Verified 'Create a COB Default' header is displayed");
			sa.assertTrue(controls.selectClientropdown(ClientId), "Verified and selected 'ClientID' dropdown");
			sa.assertTrue(controls.selectLobdropdown(LOBId), "Verified and selected 'LOB 'dropdown ");
			sa.assertTrue(librariesprogramspage.selectStatedropdown(StateId), "Verified and selected 'State' dropdown");
			controls.EnterTermDate(TermDate);
			createbenefitpage.EnterCBEffectiveDate(EffectiveDate);
			sa.assertTrue(controls.selectCOBProcessingMethodDropdown(COBProcessingMethod),
					"Verified and Selected 'COB Processing Method' dropdown");
			controls.clickCOBDefaultHeader();
			controls.clickCOBDefaultHeader();
			sa.assertTrue(controls.selectCOBPackageDropdown(COBPackage),
					"Verified and Selected 'COB Package' dropdown");
			controls.clickCOBDefaultHeader();
			controls.clickCOBDefaultHeader();
			sa.assertTrue(controls.selectAutoApplyCOBDefaultDropdown(), "Verified 'Auto Apply dropdown' is displayed");
			sa.assertTrue(controls.selectControlDefaultAutoApplyDropdown(AutoApply),
					"Verified and Selected 'Auto Apply' dropdown");
			sa.assertTrue(controls.selectBusinessEntityDropdown(BusinessEntity),
					"Verified and Selected 'Business Entity' dropdown");
			sa.assertTrue(controls.selectBusinessUnitDropdown(BusinessUnit),
					"Verified and Selected 'Business Unit' dropdown");
			sa.assertTrue(controls.selectCDHPTypeDropdown(CDHP), "Verified and Selected 'CDHP Type' dropdown");
			sa.assertTrue(controls.selectFormularyDropdown(Formulary), "Verified and Selected 'Formulary' dropdown");
			sa.assertTrue(controls.selectFundingTypeDropdown(FundingType),
					"Verified and Selected 'Funding Type' dropdown");
			sa.assertTrue(controls.selectMarketSegmentDropdown(MarketSegment),
					"Verified and Selected 'Market Segment' dropdown");
			sa.assertTrue(controls.selectProductTypeDropdown(ProductType),
					"Verified and Selected 'Product Type' dropdown");
			//sa.assertTrue(controls.selectOtherDropdown(Other), "Verified and Selected 'Others' dropdown");
			sa.assertTrue(controls.enterDetails(), "Verified and entered Details");
			controls.clickAddCOBDefaultButton();
			sa.assertTrue(controls.verifyCOBDefaultCreateSuccess(),
					"Verified the 'COB Default Created Successfully' is created");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Libraries Controls COB Default is created Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Libraries Create Controls COB Default");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

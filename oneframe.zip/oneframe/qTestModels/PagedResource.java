// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.qTestModels;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class PagedResource
{
    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("page")
    private Integer page;
    @JsonProperty("page_size")
    private Integer pageSize;
    @JsonProperty("total")
    private Long total;
    @JsonProperty("items")
    private List<ResourceSupport> items;
    
    public PagedResource() {
        this.links = new ArrayList<Link>();
        this.page = null;
        this.pageSize = null;
        this.total = null;
        this.items = new ArrayList<ResourceSupport>();
    }
    
    public PagedResource links(final List<Link> links) {
        this.links = links;
        return this;
    }
    
    public PagedResource addLinksItem(final Link linksItem) {
        this.links.add(linksItem);
        return this;
    }
    
    public List<Link> getLinks() {
        return this.links;
    }
    
    public void setLinks(final List<Link> links) {
        this.links = links;
    }
    
    public PagedResource page(final Integer page) {
        this.page = page;
        return this;
    }
    
    public Integer getPage() {
        return this.page;
    }
    
    public void setPage(final Integer page) {
        this.page = page;
    }
    
    public PagedResource pageSize(final Integer pageSize) {
        this.pageSize = pageSize;
        return this;
    }
    
    public Integer getPageSize() {
        return this.pageSize;
    }
    
    public void setPageSize(final Integer pageSize) {
        this.pageSize = pageSize;
    }
    
    public PagedResource total(final Long total) {
        this.total = total;
        return this;
    }
    
    public Long getTotal() {
        return this.total;
    }
    
    public void setTotal(final Long total) {
        this.total = total;
    }
    
    public PagedResource items(final List<ResourceSupport> items) {
        this.items = items;
        return this;
    }
    
    public PagedResource addItemsItem(final ResourceSupport itemsItem) {
        this.items.add(itemsItem);
        return this;
    }
    
    public List<ResourceSupport> getItems() {
        return this.items;
    }
    
    public void setItems(final List<ResourceSupport> items) {
        this.items = items;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final PagedResource pagedResource = (PagedResource)o;
        return Objects.equals(this.links, pagedResource.links) && Objects.equals(this.page, pagedResource.page) && Objects.equals(this.pageSize, pagedResource.pageSize) && Objects.equals(this.total, pagedResource.total) && Objects.equals(this.items, pagedResource.items);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.links, this.page, this.pageSize, this.total, this.items);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("class PagedResource {\n");
        sb.append("    links: ").append(this.toIndentedString(this.links)).append("\n");
        sb.append("    page: ").append(this.toIndentedString(this.page)).append("\n");
        sb.append("    pageSize: ").append(this.toIndentedString(this.pageSize)).append("\n");
        sb.append("    total: ").append(this.toIndentedString(this.total)).append("\n");
        sb.append("    items: ").append(this.toIndentedString(this.items)).append("\n");
        sb.append("}");
        return sb.toString();
    }
    
    private String toIndentedString(final Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}


package ibcweb.PageObjects;

import static anthem.irx.oneframe.selenium.WebObjectHandler.*;

import java.util.List;
import java.util.stream.IntStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import anthem.irx.oneframe.core.OneframeAssert;
import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import io.qameta.allure.Step;

public class IBPBulkUpdateWorkInProgressPage extends OneframeContainer {
	
	OneframeAssert ha = new OneframeAssert();
	OneframeSoftAssert sa = new OneframeSoftAssert();
	
	
	//PageObjects
	
	@FindBy(xpath="//span[@data-automation-id='headerProjectId']")
	WebElement hdrProjectID;
	
	@FindBy(xpath="//span[@data-automation-id='headerDesc']")
	WebElement hdrDescription;
	
	@FindBy(xpath="//span[@data-automation-id='headerAssignee']")
	WebElement hdrAsignee;
	
	@FindBy(xpath="//span[@data-automation-id='headerStatus']")
	WebElement hdrStatus;
	
	@FindBy(xpath="//span[@data-automation-id='headerProjectIdValue']")
	WebElement valPprojectID;
	
	@FindBy(xpath="//span[@data-automation-id='headerDescValue']")
	WebElement valDescription;
	
	@FindBy(xpath="headerAssigneeValue")
	WebElement valAssignee;
	
	@FindBy(xpath="headerStatusValue")
	WebElement valStatus;
	
	@FindBy(xpath="//h3[text()='Update Fields']")
	WebElement hdrUpdateFields;
	
	@FindBy(xpath="//h3[text()='High Dollar']")
	WebElement hdrHighDollar;
	
	@FindBy(xpath="//mat-select[@formcontrolname='modules']/following-sibling::span/label/mat-label")
	WebElement hdrModule;
	
	@FindBy(xpath="//mat-select[@formcontrolname='actions']/following-sibling::span/label/mat-label")
	WebElement hdrAction;
	
	@FindBy(xpath="//mat-select[@formcontrolname='eff_area']/following-sibling::span/label/mat-label")
	WebElement hdrEffectiveArea;
	
	@FindBy(xpath="//mat-label[text()='Retail']")
	WebElement hdrRetail;
	
	@FindBy(xpath="//mat-label[text()='Home delivery']")
	WebElement hdrHomeDelivery;
	
	@FindBy(xpath="//mat-select[@formcontrolname='modules']/div/div[2]")
	WebElement selModule;
	
	@FindBy(xpath="//mat-select[@formcontrolname='actions']/div/div[2]")
	WebElement selAction;
	
	@FindBy(xpath="//mat-select[@formcontrolname='eff_area']/div/div[2]")
	WebElement selEffectiveArea;
	
	@FindBy(xpath="//input[@formcontrolname='retail']")
	WebElement inputRetail;
	
	@FindBy(xpath="//input[@formcontrolname='homeDelivery']")
	WebElement inputHomeDelivery;
	
	@FindBy(xpath="//div[@class='footer']/p")
	WebElement footerNote;
	
	@FindBy(xpath="//button[@type='button']")
	WebElement btnGoBack;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement btnReviewProject;
	
	@FindBy(xpath="//span[text()=' Cancel Project ']/..")
	WebElement cancelProject;
	
	@FindBy(xpath = "//mat-slide-toggle[@formcontrolname='innAndOonCombined']")
	WebElement innAndOonToggle;
	
	@FindBy(xpath = "//input[@data-automation-id='individualInNetwork']")
	WebElement individualAmountField;
	
	@FindBy(xpath = "//input[@data-automation-id='familyInNetwork']")
	WebElement familyAmountField;
	
// Initializing the Page Objects:
	public IBPBulkUpdateWorkInProgressPage() {
		PageFactory.initElements(oneframeDriver, this);
	}

	// Actions
	
	public void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) oneframeDriver;
		js.executeScript("arguments[0].setAttribute('style', 'background: grey; border: 2px solid yellow;');", element);
	}
	
	@Step("Verify Module Header is displayed")
	public boolean verifyModuleHeader() {
		boolean flag = false;
		if (ObjectExist(hdrModule)) {
			if (hdrModule.getText().trim().equalsIgnoreCase("Module")) {
				flag = true;
				highlightElement(hdrModule);
				OneframeLogger("Module header is displayed");
			}
		}
		else {
			OneframeLogger("Module header is not displayed");
		}
		return flag;
	}

	@Step("Verify Action Header is displayed")
	public boolean verifyActionHeader() {
		boolean flag = false;
		if (ObjectExist(hdrAction)) {
			if (hdrAction.getText().trim().equalsIgnoreCase("Action")) {
				flag = true;
				highlightElement(hdrAction);
				OneframeLogger("Action header is displayed");
			}
		}
		else {
			OneframeLogger("Action header is not displayed");
		}
		return flag;
	}

	@Step("Veify Effective Area Header is displayed")
	public boolean verifyEffectiveAreaHeader() {
		boolean flag = false;
		if (ObjectExist(hdrEffectiveArea)) {
			if (hdrEffectiveArea.getText().trim().equalsIgnoreCase("Effective Area")) {
				flag = true;
				highlightElement(hdrEffectiveArea);
				OneframeLogger("Effective Area is displayed");
			}
		}

		else {
			OneframeLogger("Effectie Area header is not displayed");
		}
		return flag;
	}
	
	@Step("Veify HighDollar Heading is displayed")
	public boolean verifyHighDollarHeading() {
		boolean flag = false;
		if (ObjectExist(hdrHighDollar)) {
			if (hdrHighDollar.getText().trim().equalsIgnoreCase("High Dollar")) {
				flag = true;
				highlightElement(hdrHighDollar);
				OneframeLogger("High Dollar heading is displayed");
			}
		}

		else {
			OneframeLogger("High Dollar heading is not displayed");
		}
		return flag;
	}
	
	@Step("Veify Retail header is displayed")
	public boolean verifyRetailHeader() {
		boolean flag = false;
		if (ObjectExist(hdrRetail)) {
			if (hdrRetail.getText().trim().equalsIgnoreCase("Retail")) {
				flag = true;
				highlightElement(hdrRetail);
				OneframeLogger("Retial heading is displayed");
			}
		}

		else {
			OneframeLogger("Retail heading is not displayed");
		}
		return flag;
	}
	
	@Step("Veify Home delivery header is displayed")
	public boolean verifyHomeDeliveryHeader() {
		boolean flag = false;
		if (ObjectExist(hdrHomeDelivery)) {
			if (hdrHomeDelivery.getText().trim().equalsIgnoreCase("Home delivery")) {
				flag = true;
				highlightElement(hdrHomeDelivery);
				OneframeLogger("Home Delivery heading is displayed");
			}
		}

		else {
			OneframeLogger("Home Delivery heading is not displayed");
		}
		return flag;
	}

	@Step("Select value from Module Dropdown")
	public boolean selectModuleDropdown(String Module) {
		boolean blnRC = false;
		try {
			if (WaitForObject(selModule)) {
				ClickWebObject(selModule);
				selectDropdownValue(Module);
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select Module dropdown ");
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Select value from dropdown")
	public String selectDropdownValue(String values) {
		String element = String.format(
				"//div[contains(@class, ' mat-select-panel mat-primary')]/mat-option//following::span[text()=' %s ']",
				values);
		WebElement dropdownvalue = oneframeDriver.findElement(By.xpath(element));
		WaitForObjectVisibility(dropdownvalue);
		String value=dropdownvalue.getText();
		ClickWebObject(dropdownvalue);
		OneframeLogger("The Selected Dropdown value is " + value);
		return value;
	}

	@Step("Select Value from Action Dropdown")
	public boolean selectActionDropdown(String Action) {
		boolean blnRC = false;
		try {
			if (WaitForObject(selAction)) {
				ClickWebObject(selAction);
				selectDropdownValue(Action);
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select Action dropdown ");
			blnRC = false;
		}
		return blnRC;
	}
	
	@Step("Select value from Effective Area dropdown")
	public boolean selectEffectiveAreaDropdown(String EffectiveArea) {
		boolean blnRC = false;
		try {
			if (WaitForObject(selEffectiveArea)) {
				ClickWebObject(selEffectiveArea);
				selectDropdownValue(EffectiveArea);
				blnRC = true;
			}
		} catch (StaleElementReferenceException e) {
			OneframeLogger("Unable to select Effective Area dropdown ");
			blnRC = false;
		}
		return blnRC;
	}

	@Step("Verify Review Project button is enabled or not")
	public boolean verifyReviewProjectButtonEnabled() {
		if (btnReviewProject.isEnabled()) {
			highlightElement(btnReviewProject);
			OneframeLogger("Review Project button is enabled: " +btnReviewProject.isEnabled());
			return true;
		}

		else {
			OneframeLogger("Review Project Button is not enabled");
		}
		return false;
	}
	
	@Step("Enter Retial value")
	public boolean verifyAndEnterRetailInput(String value) {
		boolean flag = false;
		try {
			if (ObjectExist(inputRetail)) {
				ClickWebObject(inputRetail);
				EnterText(inputRetail, value);
				OneframeLogger("Retial value has been Entered : " + inputRetail.getAttribute("value"));
				flag = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Retail value has been Entered");
			flag = false;
		}
		return flag;
	}
	
	@Step("Enter Retial value")
	public boolean verifyAndEnterHomeDeliveryInput(String value) {
		boolean flag = false;
		try {
			if (ObjectExist(inputHomeDelivery)) {
				ClickWebObject(inputHomeDelivery);
				EnterText(inputHomeDelivery, value);
				OneframeLogger("Home Delivery value has been Entered : " + inputHomeDelivery.getAttribute("value"));
				flag = true;
			}
		} catch (TimeoutException e) {
			OneframeLogger("Home Delivery value has been Entered");
			flag = false;
		}
		return flag;
	}

	@Step("Click on Review Project Button")
	public void clickProjectReviewButton() {
		if (btnReviewProject.isEnabled()) {
			highlightElement(btnReviewProject);
			ClickWebObject(btnReviewProject);
		}
	}

	@Step("Enable OON and INN Toggle")
	public void enableOONandINNToggle() {
		
		try {
			if (WaitForObjectVisibility(innAndOonToggle)) {
				ClickWebObject(innAndOonToggle);
				String xpath = "//mat-slide-toggle[@formcontrolname='innAndOonCombined']//input";
				String isToggleChecked = oneframeDriver.findElement(By.xpath(xpath)).getAttribute("aria-checked");
				sa.assertEquals(isToggleChecked, "true");
				OneframeLogger("Enabled ONN and INN toggle");
			}
		} catch (Exception e) {
			OneframeLogger("Error while trying to enable OON and INN toggle");
			OneframeErrorLogger(e.toString());
		}
		
		sa.assertAll();
		
	}

	@Step("Enter {amount} in Individual field")
	public void enterIndividualAmount(String amount) {
		try {
			if (WaitForObjectVisibility(individualAmountField)) {
				EnterText(individualAmountField, amount);
				individualAmountField.sendKeys(Keys.TAB);
				String actualIndividualAmount = individualAmountField.getAttribute("value");
				sa.assertEquals(actualIndividualAmount, amount);
				OneframeLogger("Entered Individual Amount as " +amount);
			}
		} catch (Exception e) {
			OneframeLogger("Error while trying to enter value into Individual Amount");
			OneframeErrorLogger(e.toString());
		}
		
		sa.assertAll();		
		
	}
	
	@Step("Enter {amount} in Family field")
	public void enterFamilyAmount(String amount) {
		try {
			if (WaitForObjectVisibility(familyAmountField)) {
				EnterText(familyAmountField, amount);
				familyAmountField.sendKeys(Keys.TAB);
				String actualFamilyAmount = familyAmountField.getAttribute("value");
				sa.assertEquals(actualFamilyAmount, amount);
				OneframeLogger("Entered Family Amount as " +amount);
			}
		} catch (Exception e) {
			OneframeLogger("Error while trying to enter value into Family Amount");
			OneframeErrorLogger(e.toString());
		}
		
		sa.assertAll();		
		
	}
	
}

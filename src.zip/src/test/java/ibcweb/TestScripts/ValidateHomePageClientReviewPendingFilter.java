package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateHomePageClientReviewPendingFilter extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;

	@BeforeClass
	@Step("Initializing Test Script for validate Filters has implemented in Client Review Pending Page")
	public void setUp() {
		InitializeLaunchPad("IBPW_102");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "EffectiveDate" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Filters has implemented in   Client Review Pending Page", dataProvider = "TestData")
	@Description("Validate Filters has implemented in  Client Review Pending Page")
	public void ValidateFiltersInClientReviewPending(String TestCaseID, String TestStatus, String EffectiveDate)
			throws Throwable {
		OneframeSoftAssert sa = new OneframeSoftAssert();

		SetTestRunVariables(TestCaseID);
		StartApplication();

		if (loginpage.MemberLogin()) {
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			welcomePage.clickWelcomeHelloText();
			sa.assertTrue(welcomePage.verifyMyTasksWidgetDisplay(), "Verified My Task Widget is displayed");
			sa.assertTrue(welcomePage.verifyRemediationRequiredWidgetDisplay(),
					"Verified Remediation Required Widget is displayed");
			sa.assertTrue(welcomePage.verifyClientReviewPendingWidgetDisplay(),
					"Verified Client Review Pending Widget is Displayed");
			sa.assertTrue(welcomePage.verifyUsersWidgetDisplay(), "Verified User Widget is Displayed");
			homepage.verifySearchButton();
			homepage.verifyMenuButton();
			sa.assertTrue(welcomePage.verifyViewAllButtonClientReviewPendingDisplay(),
					"View all link of Client Review Pending is displayed");
			sa.assertTrue(welcomePage.verifyShowDropdownClientReviewPendingDisplay(),
					"All Error Types filter in home page is displayed for Client Review pending");
			welcomePage.clickViewAllButtonClientReviewPending();
			welcomePage.clickHeaderSections("Client Review Pending");
			welcomePage.clickHeaderSections("Client Review Pending");

			welcomePage.clickFilterIcon();
			String clientValue = welcomePage.getFirstRecordClientValue();
			welcomePage.selectClientIdDropdown(clientValue);
			// welcomePage.selectEffectiveDateDropdown(EffectiveDate);
			// String errorType=welcomePage.getFirstRecordErrorType();
			// welcomePage.selectErrorTypeDropdown(errorType);
			welcomePage.clickApplyFilter();
			welcomePage.verifyClientFilterList(clientValue);

			// sa.assertTrue(welcomePage.verifyFilterforEffectiveDate(EffectiveDate,"Client
			// Review Pending"), "Verified Filteration has been Implemented in Client Review
			// Pending Page");
			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate Filters has implemented in  Client Review Pending Page Successfully");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to  validate Filters has implemented in Client Review Pending Page");
		}
		sa.assertAll();
		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();

		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPBenefitPage;
import ibcweb.PageObjects.IBPCreateBenefitPage;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLibrariesControlsPage;
import ibcweb.PageObjects.IBPLibrariesCostShareStructurePage;
import ibcweb.PageObjects.IBPLibrariesMandatesPage;
import ibcweb.PageObjects.IBPLibrariesNetFormularies;
import ibcweb.PageObjects.IBPLibrariesProgramsPage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

public class ValidateEditFunctionalityOfCOBDefault extends OneframeContainer {
	IBPWelcomePage welcomePage;
	IBPLoginPage loginpage;
	IBPHomePage homepage;
	IBPBenefitPage benefitpage;
	IBPCreateBenefitPage createbenefitpage;
	IBPLibrariesCostShareStructurePage librariesCostShareStructurePage;
	IBPLibrariesMandatesPage mandate;
	IBPLibrariesProgramsPage librariesprogramspage;
	IBPLibrariesControlsPage controls;
	IBPLibrariesNetFormularies netFormulary;

	@BeforeClass
	@Step("Initializing Test Script for Validating Edit Functionality of COB Default")
	public void setUp() {
		InitializeLaunchPad("IBPW_798");
		welcomePage = new IBPWelcomePage();
		loginpage = new IBPLoginPage();
		homepage = new IBPHomePage();
		benefitpage = new IBPBenefitPage();
		createbenefitpage = new IBPCreateBenefitPage();
		librariesCostShareStructurePage = new IBPLibrariesCostShareStructurePage();
		mandate = new IBPLibrariesMandatesPage();
		librariesprogramspage = new IBPLibrariesProgramsPage();
		controls = new IBPLibrariesControlsPage();
		netFormulary = new IBPLibrariesNetFormularies();

	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus", "COBPackage" };
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate Edit Functionality of COB Default", dataProvider = "TestData")
	@Description("Validate Edit Functionality of COB Default")
	public void ValidateCOBDefaultDynamicLayer(String TestCaseID, String TestStatus, String COBPackage)
			throws AWTException, InterruptedException, IOException {

		OneframeSoftAssert sa = new OneframeSoftAssert();
		SetTestRunVariables(TestCaseID);
		StartApplication();
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			sa.assertTrue(librariesCostShareStructurePage.verifyAndClickLibrariesSection(),
					"Verified and clicked on 'Libraries Section'");
			controls.clickViewButtonofControls();
			sa.assertTrue(controls.verifyControlsHeader(), "Verified 'Controls' header is displayed");
			controls.clickCOBDefaultTab();
			controls.clickControlsHeader();
			controls.clickControlsHeader();
			controls.clickControlsHeader();
			controls.clickFirstRecordCOBDefault();
			sa.assertTrue(controls.verifyCOBDefaultDetailsHeader(),
					"Verified 'COB Default Details' header is displayed");
			sa.assertTrue(controls.verifyAndClickEditButton(), "Verified and Clicked 'Edit' button");
			controls.clickCOBDefaultDetailsHeader();
			sa.assertTrue(controls.verifyBOBAndDynamicFieldsAreDisabled(),
					"Verified 'BOB and Dynamic layer fields' are disabled");
			sa.assertTrue(controls.verifyEffectiveDateFieldIsEnabled(), "Verified 'Effective date field' are Enabled");
			sa.assertTrue(controls.verifyTerminationDateFieldIsEnabled(),
					"Verified 'Termination date field' are Enabled");
			sa.assertTrue(controls.verifyCOBProcessingMethodFieldIsEnabled(),
					"Verified 'COB Processing Method field' are Enabled");
			sa.assertTrue(controls.verifyCOBPackageFieldIsEnabled(), "Verified 'COB Package field' are Enabled");
			sa.assertTrue(controls.verifyCOBDetailsFieldIsEnabled(), "Verified 'Details field' are Enabled");
			String effectiveDateField = controls.editEffectiveDate();
			String detailsField = controls.editAndEnterDetails();
			controls.clickCOBDefaultDetailsHeader();
			String cobPackage = controls.editAndSelectCOBPackageDropdown(COBPackage);
			controls.clickSaveChangesButton();
			sa.assertTrue(controls.verifyChangesSavedText(), "Verified 'Save Changes text' is displayed");
			sa.assertTrue(controls.verifyEditedEffectiveDateIsSame(effectiveDateField),
					"Verified 'Effective date field' is same as expected");
			sa.assertTrue(controls.verifyEditedCOBPackageIsSame(cobPackage),
					"Verified 'COB Processing Method field' is same as expected");
			sa.assertTrue(controls.verifyEditedDetailsIsSame(detailsField),
					"Verified 'Details field' is same as expected");

			sa.assertAll();
			gTestResult = RESULT_PASS;
			OneframeLogger("Validated Edit Functionality of COB Default is Successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate Edit Functionality of COB Default");
		}

		homepage.clickLogout();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");
	}

}

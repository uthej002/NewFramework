package ibcweb.TestScripts;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import anthem.irx.oneframe.core.OneframeContainer;
import anthem.irx.oneframe.core.OneframeSoftAssert;
import ibcweb.PageObjects.IBPHomePage;
import ibcweb.PageObjects.IBPLoginPage;
import ibcweb.PageObjects.IBPRuleBuilderStaging;
import ibcweb.PageObjects.IBPRuleIDPage;
import ibcweb.PageObjects.IBPWelcomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Step;

/* Note: Test DAta needs to be updated for each run.
 * 
 * Find a rule id which has Promote Button enabled.
 */

public class ValidatePromotebuttonFeature extends OneframeContainer{
	
	IBPWelcomePage welcomePage;
	IBPLoginPage   loginpage;
	IBPHomePage homepage;
	IBPRuleBuilderStaging rulebuilderstaging;
	IBPRuleIDPage ruleid;

	@BeforeClass
	@Step("Initializing Test Script for validating the Promote Functionality")
	public void setUp() {
		InitializeLaunchPad("IBPW_39");
		welcomePage =  new IBPWelcomePage();
		loginpage   =  new IBPLoginPage();
		homepage = new IBPHomePage();
		rulebuilderstaging = new IBPRuleBuilderStaging();
		ruleid = new IBPRuleIDPage();
	}

	@DataProvider(name = "TestData")
	public Object[][] getTestData() {

		String[] fieldNames = { "TestCaseID", "TestStatus","LibraryName","RuleName"};
		List<String> TestDataFields = Arrays.asList(fieldNames);
		return GetTestDatafromTDS(TestDataFields);
	}

	@Test(description = "Validate the Promote Functionality", dataProvider = "TestData")
	@Description("Validate the Promote Functionality")
	public void ValidatePromoteButtonFunction(String TestCaseID, String TestStatus,String LibraryName,String RuleName) throws AWTException, InterruptedException, IOException {
		
		OneframeSoftAssert sa = new OneframeSoftAssert();
		
		SetTestRunVariables(TestCaseID);
		StartApplication();
		
		if (loginpage.MemberLogin()) {
			homepage.clickMenuButton();
			homepage.clickRuleBuilder();
            homepage.clickStagingLink();          
            rulebuilderstaging.clickLibrary(LibraryName);
          //ruleid.getLatestVersionID(LibraryName, RuleName);
            String versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
           // rulebuilderstaging.clickRuleName(LibraryName, RuleName);
			ruleid.clickLatestVersionofRuleID(versionId);
			ruleid.clickPromoteButton();
			sa.assertTrue(ruleid.verifyProductionTitleDisplay(), "Verified Rule is moved from Stagging to Production");
			sa.assertTrue(!ruleid.verifyRuleNamedisplay(), "Verified Rule Name is disabled");
			sa.assertTrue(!ruleid.verifyDescriptiondisplay(), "Verified Description is disabled");
			sa.assertTrue(!ruleid.verifyStartandEndDatedisplay(), "Verified Start and End Date is disabled");
			sa.assertTrue(!ruleid.verifyMessagedisplay(), "Verified Message is disabled");
			sa.assertTrue(rulebuilderstaging.verifyProductionHeaderdisplay(), "Verified Production header is displayed");
			ruleid.clickBackbutton();
			ruleid.clickBackbutton();
			homepage.clickStagingLink();          
			//rulebuilderstaging.clickRule(LibraryName, RuleName);
			 rulebuilderstaging.clickLibrary(LibraryName);
			 versionId = rulebuilderstaging.clickRule(LibraryName, RuleName);
			 ruleid.clickLatestVersionofRuleID(versionId);
			sa.assertTrue(ruleid.verifyImpactAnalysisbuttondisplay(), "Verified Rule Version is changed into Major Version");
			//sa.assertTrue(!ruleid.verifyVersionIDPromoted(), "Verified The latest version of given RuleID is moved from stagging to production");
			
			gTestResult = RESULT_PASS;
			OneframeLogger("Validate the Promote Functionality successful");
		} else {
			gTestResult = RESULT_FAIL;
			OneframeLogger("Unable to Validate the Promote Functionality unsuccessful");
		}
		sa.assertAll();
	}

	@AfterMethod
	public void TestMethodClosure() {
		OneframeLogger("After Executing the Test");
		UpdateTestResultsToTDS();
		ResetTestResults();
	}

	@AfterClass
	@Step("Cleanup Test Launchpad")
	public void TestClosureAfter() {
		CloseLaunchPad();
		OneframeLogger("AfterClass");
	}

	@AfterTest
	public void TestClosure() {
		OneframeLogger("After Executing All Tests");

	}



}

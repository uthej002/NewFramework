package anthem.irx.oneframe.pojo;

import java.util.ArrayList;

public class MessageSection {
  public String activityTitle;
  
  public String activitySubtitle;
  
  public String activityImage;
  
  public ArrayList<ExecutionFact> facts;
  
  public boolean markdown;
}

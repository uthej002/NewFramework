// 
// Decompiled by Procyon v0.5.36
// 

package anthem.irx.oneframe.utilities;

import java.time.temporal.TemporalAccessor;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import anthem.irx.oneframe.core.OneframeLogger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import java.util.HashMap;
import java.io.InputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFRow;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import anthem.irx.oneframe.core.OneframeContainer;

public class ExcelIOStream extends OneframeContainer
{
    private String tsExceldoc;
    private XSSFWorkbook tsxlsxWorkBook;
    private XSSFSheet tsxlsxSheet;
    FileOutputStream fileOut;
    FileInputStream iStream;
    
    public ExcelIOStream(final String tsExceldoc) {
        this.tsExceldoc = tsExceldoc;
        this.tsxlsxWorkBook = this.openExcelxWorkbook(this.tsExceldoc);
        OneframeContainer.OneframeLogger("[ONEFRAME]Open Excel file : " + this.tsExceldoc);
    }
    
    public ExcelIOStream() {
    }
    
    private void writeToExcelSheet(final String SheetName, final String RowIdentifier, final String ColumnName, final String OutputData) {
        int totalRows = 0;
        this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(SheetName);
        totalRows = this.tsxlsxSheet.getPhysicalNumberOfRows() + 1;
        for (int i = this.tsxlsxSheet.getFirstRowNum() + 1; i < this.tsxlsxSheet.getPhysicalNumberOfRows(); ++i) {
            final XSSFRow row = this.tsxlsxSheet.getRow(i);
            for (int j = row.getFirstCellNum(); j < row.getPhysicalNumberOfCells(); ++j) {}
        }
    }
    
    public void closeWorkbook() throws IOException {
        this.tsxlsxWorkBook.close();
    }
    
    private synchronized XSSFWorkbook openExcelxWorkbook(final String xlsxDoc) {
        try {
            this.iStream = new FileInputStream(xlsxDoc);
            final XSSFWorkbook wb = new XSSFWorkbook((InputStream)this.iStream);
            return wb;
        }
        catch (IOException IOE) {
            OneframeContainer.OneframeLogger("[ONEFRAME]" + IOE.getMessage());
            return null;
        }
    }
    
    public synchronized HashMap<String, String> readScriptConfiguration(final String scenarioID) {
        final HashMap<String, String> scriptConfigs = new HashMap<String, String>();
        int scFound = 0;
        this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(ExcelIOStream.TSScriptConfigSheet);
        final int frow = this.tsxlsxSheet.getFirstRowNum();
        final Row KeyRow = (Row)this.tsxlsxSheet.getRow(frow);
        final Iterator<Cell> KeyCellIterator = (Iterator<Cell>)KeyRow.iterator();
        for (final Row valueRow : this.tsxlsxSheet) {
            if (valueRow.getCell(0).getStringCellValue().equalsIgnoreCase(scenarioID)) {
                scFound = 1;
                final Iterator<Cell> cellIterator = (Iterator<Cell>)valueRow.iterator();
                while (cellIterator.hasNext()) {
                    final Cell keyCell = KeyCellIterator.next();
                    final Cell rowCell = cellIterator.next();
                    if (keyCell.getStringCellValue().equalsIgnoreCase("RunFlag") && rowCell.getStringCellValue().equalsIgnoreCase("no")) {
                        OneframeLogger.throwException("The RunFlag for Test Scenario - " + scenarioID + " is 'No', update it to 'Yes' to enable execution");
                        break;
                    }
                    scriptConfigs.put(keyCell.getStringCellValue(), rowCell.getStringCellValue());
                }
                break;
            }
        }
        if (scFound == 0) {
            OneframeLogger.throwException("Script configurations not found for test scenario [" + scenarioID + "]");
        }
        return scriptConfigs;
    }
    
    public synchronized String[][] readScriptConfiguration() {
        this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(ExcelIOStream.TSScriptConfigSheet);
        final int runflagIndex = this.getColumnIndex("RunFlag");
        final int oftotrows = this.XlsXgetRowCount();
        final int oftotcols = this.XlsXgetColumnCount();
        int runRows = 0;
        int irow = 0;
        int icol = 0;
        int curRowNo = 0;
        int curColNo = 0;
        final String[][] ScriptConfigurations = new String[oftotrows][oftotcols];
        try {
            for (irow = 0; irow < oftotrows; ++irow) {
                final Row currRow = (Row)this.tsxlsxSheet.getRow(irow);
                if (irow == 0 || this.getCellValue(currRow, runflagIndex).equalsIgnoreCase("Yes")) {
                    curRowNo = currRow.getRowNum();
                    OneframeContainer.OneframeLogger("[ONEFRAME] Reading configuration at Row [" + (curRowNo + 1) + "]");
                    for (icol = 0; icol < oftotcols; ++icol) {
                        curColNo = icol;
                        ScriptConfigurations[runRows][icol] = currRow.getCell(icol).getStringCellValue();
                    }
                    ++runRows;
                }
            }
        }
        catch (NullPointerException NE) {
            OneframeContainer.OneframeLogger("[ONEFRAME]Script configuration spreadsheet contains cell format issues, review cell contents at row - " + (curRowNo + 1) + " : column - " + (curColNo + 1));
            OneframeContainer.OneframeLogger("[ONEFRAME]Guidelines: ");
            OneframeContainer.OneframeLogger("[ONEFRAME]1) Make sure there are no empty rows in between Script configurations");
            OneframeContainer.OneframeLogger("[ONEFRAME]2) Remove unused rows at the bottom of the script configuration");
            NE.printStackTrace();
            System.exit(1);
        }
        --runRows;
        OneframeContainer.OneframeLogger("[ONEFRAME]Number of script configurations : " + runRows);
        return ScriptConfigurations;
    }
    
    public int getColumnIndex(final String ColumnName) {
        int colIndex = 0;
        final Row currRow = (Row)this.tsxlsxSheet.getRow(0);
        for (int icol = 0; icol < this.XlsXgetColumnCount(); ++icol) {
            if (currRow.getCell(icol).getStringCellValue().equalsIgnoreCase(ColumnName)) {
                colIndex = icol;
                break;
            }
        }
        return colIndex;
    }
    
    public List<HashMap<String, String>> readScriptConfigurationValue() {
        this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(ExcelIOStream.TSDataSheetKey);
        final int lastRowNum = this.tsxlsxSheet.getLastRowNum();
        final int lastCellNum = this.tsxlsxSheet.getRow(0).getLastCellNum();
        final List<HashMap<String, String>> li = new ArrayList<HashMap<String, String>>();
        for (int i = 0; i < lastRowNum; ++i) {
            final HashMap<String, String> datamap = new HashMap<String, String>();
            for (int j = 0; j < lastCellNum; ++j) {
                if (this.tsxlsxSheet.getRow(i + 1).getCell(j) != null) {
                    datamap.put(this.tsxlsxSheet.getRow(0).getCell(j).toString(), this.tsxlsxSheet.getRow(i + 1).getCell(j).toString());
                }
            }
            li.add(datamap);
        }
        return li;
    }
    
    public HashMap<String, String> writeScriptConfigurationValue(final String columnName, final String columnValue) throws IOException {
        System.out.println(this.tsExceldoc);
        System.out.println(this.tsxlsxWorkBook);
        System.out.println(ExcelIOStream.TSDataSheetKey);
        System.out.println(this.tsxlsxSheet);
        HashMap<String, String> datamap = null;
        this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(ExcelIOStream.TSDataSheetKey);
        final int lastRowNum = this.tsxlsxSheet.getLastRowNum();
        final int lastCellNum = this.tsxlsxSheet.getRow(0).getLastCellNum();
        for (int i = 0; i < lastRowNum; ++i) {
            datamap = new HashMap<String, String>();
            for (int j = 0; j < lastCellNum; ++j) {
                if (this.tsxlsxSheet.getRow(i + 1).getCell(j) != null) {
                    if (this.tsxlsxSheet.getRow(0).getCell(j).toString().equalsIgnoreCase(columnName)) {
                        this.tsxlsxSheet.getRow(i + 1).getCell(j).setCellValue(columnValue);
                    }
                    this.fileOut = new FileOutputStream(this.tsExceldoc);
                    this.tsxlsxWorkBook.write((OutputStream)this.fileOut);
                }
            }
        }
        return datamap;
    }
    
    public void UpdateTestDataToExcel(final String TestCaseID, final String Expected, final String DB, final String Status, final String ColumnName) throws IOException {
        System.out.println(this.tsExceldoc);
        System.out.println(this.tsxlsxWorkBook);
        this.tsxlsxSheet = this.tsxlsxWorkBook.getSheet(ExcelIOStream.TSTDSResultDocument);
        Row row = (Row)this.tsxlsxSheet.createRow(0);
        row.createCell(0).setCellValue("TestCaseID");
        row.createCell(1).setCellValue("ColumnName");
        row.createCell(2).setCellValue("ExpectedResults");
        row.createCell(3).setCellValue("ActualResults");
        row.createCell(4).setCellValue("TestResult");
        row.createCell(5).setCellValue("ExecutionDateAndTime");
        final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH:mm:ss");
        final LocalDateTime now = LocalDateTime.now();
        row = (Row)this.tsxlsxSheet.createRow(this.tsxlsxSheet.getLastRowNum() + 1);
        row.createCell(0).setCellValue(TestCaseID);
        row.createCell(1).setCellValue(ColumnName);
        row.createCell(2).setCellValue(Expected);
        row.createCell(3).setCellValue(DB);
        row.createCell(4).setCellValue(Status);
        row.createCell(5).setCellValue(dtf.format(now));
        this.fileOut = new FileOutputStream(this.tsExceldoc);
        this.tsxlsxWorkBook.write((OutputStream)this.fileOut);
    }
    
    public void DeleteData(final String SheetName) {
        final int numberOfRows = this.tsxlsxSheet.getPhysicalNumberOfRows();
        if (numberOfRows > 0) {
            for (int i = this.tsxlsxSheet.getFirstRowNum(); i <= this.tsxlsxSheet.getLastRowNum(); ++i) {
                if (this.tsxlsxSheet.getRow(i) != null) {
                    this.tsxlsxSheet.removeRow((Row)this.tsxlsxSheet.getRow(i));
                }
                else {
                    System.out.println("Info: clean sheet='" + this.tsxlsxSheet.getSheetName() + "' ... skip line: " + i);
                }
            }
        }
        else {
            System.out.println("Info: clean sheet='" + this.tsxlsxSheet.getSheetName() + "' ... is empty");
        }
    }
    
    private String getCellValue(final Row currRow, final int cellIndex) {
        return currRow.getCell(cellIndex).getStringCellValue();
    }
    
    public int XlsXgetRowCount() {
        return this.tsxlsxSheet.getLastRowNum() + 1;
    }
    
    public int XlsXgetColumnCount() {
        return this.tsxlsxSheet.getRow(0).getLastCellNum();
    }
    
    public String[][] readDataFromReports() {
        this.tsxlsxSheet = this.tsxlsxWorkBook.getSheetAt(0);
        final int lastRowNum = this.tsxlsxSheet.getLastRowNum();
        final int lastCellNum = this.tsxlsxSheet.getRow(0).getLastCellNum();
        final String[][] testData = new String[lastRowNum][lastCellNum];
        for (int i = 0; i <= lastRowNum; ++i) {
            final Row row = (Row)this.tsxlsxSheet.getRow(i);
            for (int j = 0; j < lastCellNum; ++j) {
                testData[i][j] = row.getCell(j).getStringCellValue();
            }
        }
        return testData;
    }
}
